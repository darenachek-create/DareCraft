extends CharacterBody3D

const GRAVITY := 20.0
const SPEED := 2.0
const RANGE := 11.0
var target: Node3D
var world_controller: Node
var health := 9.0
var shot_timer := 1.5
var flash_timer := 0.0
var materials: Array = []

func _ready() -> void:
	name = "NightRunner"
	collision_layer = 1
	collision_mask = 1
	var col := CollisionShape3D.new()
	var shape := CapsuleShape3D.new()
	shape.radius = 0.32
	shape.height = 1.8
	col.shape = shape
	col.position.y = 0.9
	add_child(col)
	var bone_mat := StandardMaterial3D.new()
	bone_mat.albedo_color = Color(0.82, 0.80, 0.68)
	var dark_mat := StandardMaterial3D.new()
	dark_mat.albedo_color = Color(0.16, 0.18, 0.22)
	_add_box(Vector3(0.55,0.62,0.35),Vector3(0,1.25,0),bone_mat)
	_add_box(Vector3(0.46,0.46,0.42),Vector3(0,1.82,0),bone_mat)
	_add_box(Vector3(0.08,0.07,0.04),Vector3(-0.12,1.84,0.22),dark_mat)
	_add_box(Vector3(0.08,0.07,0.04),Vector3(0.12,1.84,0.22),dark_mat)
	_add_box(Vector3(0.13,0.72,0.14),Vector3(-0.37,1.2,0),bone_mat)
	_add_box(Vector3(0.13,0.72,0.14),Vector3(0.37,1.2,0),bone_mat)
	_add_box(Vector3(0.16,0.75,0.18),Vector3(-0.16,0.45,0),bone_mat)
	_add_box(Vector3(0.16,0.75,0.18),Vector3(0.16,0.45,0),bone_mat)
	_add_box(Vector3(0.12,0.55,0.08),Vector3(0.52,1.3,0.08),dark_mat)
	for n in find_children("*","MeshInstance3D",true,false):
		materials.append([n,n.material_override])

func _add_box(size: Vector3, pos: Vector3, mat: Material) -> void:
	var m := MeshInstance3D.new()
	var b := BoxMesh.new()
	b.size = size
	m.mesh = b
	m.position = pos
	m.material_override = mat
	add_child(m)

func _physics_process(delta: float) -> void:
	if flash_timer > 0.0:
		flash_timer -= delta
		if flash_timer <= 0.0:
			for e in materials:
				if is_instance_valid(e[0]): e[0].material_override = e[1]
	if not is_instance_valid(target) or not is_instance_valid(world_controller): return
	if not is_on_floor(): velocity.y -= GRAVITY * delta
	else: velocity.y = -0.2
	var to_player := target.global_position - global_position
	to_player.y = 0.0
	var dist := to_player.length()
	var dir := to_player.normalized() if dist > 0.1 else Vector3.ZERO
	if dist > 5.0:
		velocity.x = dir.x * SPEED
		velocity.z = dir.z * SPEED
	else:
		velocity.x = move_toward(velocity.x,0.0,delta*5.0)
		velocity.z = move_toward(velocity.z,0.0,delta*5.0)
	if dir.length() > 0.05: rotation.y = lerp_angle(rotation.y,atan2(dir.x,dir.z),delta*6.0)
	move_and_slide()
	shot_timer -= delta
	if dist <= RANGE and shot_timer <= 0.0:
		shot_timer = randf_range(2.3,3.4)
		var ray_start := global_position + Vector3(0,1.5,0)
		var ray_end := target.global_position + Vector3(0,0.8,0)
		var query := PhysicsRayQueryParameters3D.create(ray_start,ray_end)
		query.exclude = [get_rid()]
		var hit := get_world_3d().direct_space_state.intersect_ray(query)
		if not hit.is_empty() and hit.get("collider") == target:
			world_controller.take_damage(2.0)

func receive_hit(damage: float) -> bool:
	flash_timer = 0.18
	var flash := StandardMaterial3D.new()
	flash.albedo_color = Color(1.0,0.25,0.22)
	flash.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	for e in materials:
		if is_instance_valid(e[0]): e[0].material_override = flash
	health -= damage
	if health <= 0.0:
		if is_instance_valid(world_controller): world_controller.add_item(73,1)
		queue_free()
	return true
