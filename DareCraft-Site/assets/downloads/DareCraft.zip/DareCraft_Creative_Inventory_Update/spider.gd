extends CharacterBody3D

const SPEED := 5.0
const GRAVITY := 18.0
const ATTACK_DISTANCE := 1.35

@export var target: Node3D
var world_controller: Node
var health := 12.0
var attack_cooldown := 0.0
var surface_normal := Vector3.UP
var step_phase := 0.0
var legs: Array[Node3D] = []
var meshes: Array[MeshInstance3D] = []
var flash_timer := 0.0
var original_materials: Array = []

func _ready() -> void:
	name = "WallSpider"
	collision_layer = 1
	collision_mask = 1
	up_direction = Vector3.UP
	var collision := CollisionShape3D.new()
	var shape := SphereShape3D.new()
	shape.radius = 0.42
	collision.shape = shape
	collision.position.y = 0.38
	add_child(collision)
	_build_model()
	for node in find_children("*", "MeshInstance3D", true, false):
		var mesh := node as MeshInstance3D
		meshes.append(mesh)
		original_materials.append(mesh.material_override)

func _material(color: Color) -> StandardMaterial3D:
	var mat := StandardMaterial3D.new()
	mat.albedo_color = color
	mat.roughness = 1.0
	return mat

func _add_box(size: Vector3, pos: Vector3, mat: Material, parent: Node3D = self) -> MeshInstance3D:
	var mesh := MeshInstance3D.new()
	var box := BoxMesh.new()
	box.size = size
	mesh.mesh = box
	mesh.position = pos
	mesh.material_override = mat
	parent.add_child(mesh)
	return mesh

func _build_model() -> void:
	var shell := _material(Color(0.10, 0.12, 0.13))
	var abdomen := _material(Color(0.20, 0.035, 0.045))
	var eyes := _material(Color(1.0, 0.08, 0.025))
	_add_box(Vector3(0.62, 0.42, 0.72), Vector3(0, 0.42, -0.12), abdomen)
	_add_box(Vector3(0.48, 0.34, 0.42), Vector3(0, 0.45, 0.40), shell)
	for x in [-0.16, -0.05, 0.05, 0.16]:
		_add_box(Vector3(0.055, 0.055, 0.035), Vector3(x, 0.58, 0.62), eyes)
	for side in [-1.0, 1.0]:
		for i in 4:
			var leg := Node3D.new()
			leg.position = Vector3(side * 0.22, 0.42, 0.30 - float(i) * 0.22)
			add_child(leg)
			_add_box(Vector3(0.10, 0.10, 0.58), Vector3(side * 0.28, 0.0, 0.0), shell, leg)
			_add_box(Vector3(0.08, 0.08, 0.42), Vector3(side * 0.52, -0.06, 0.22), shell, leg)
			legs.append(leg)

func _ray(from: Vector3, to: Vector3) -> Dictionary:
	var query := PhysicsRayQueryParameters3D.create(from, to)
	query.exclude = [get_rid()]
	query.collision_mask = 1
	return get_world_3d().direct_space_state.intersect_ray(query)

func _physics_process(delta: float) -> void:
	if not is_instance_valid(target) or not is_instance_valid(world_controller):
		return
	if flash_timer > 0.0:
		flash_timer -= delta
		if flash_timer <= 0.0:
			for i in meshes.size():
				if is_instance_valid(meshes[i]): meshes[i].material_override = original_materials[i]
	attack_cooldown = maxf(0.0, attack_cooldown - delta)
	var to_target := target.global_position - global_position
	var tangent := to_target - surface_normal * to_target.dot(surface_normal)
	var direction := tangent.normalized() if tangent.length() > 0.05 else Vector3.ZERO
	# Ищем стену впереди, чтобы паук мог перейти с пола на вертикальную поверхность.
	if direction.length() > 0.01:
		var forward_hit := _ray(global_position + surface_normal * 0.22, global_position + direction * 0.85 + surface_normal * 0.22)
		if not forward_hit.is_empty():
			var normal: Vector3 = forward_hit.get("normal", surface_normal)
			if normal.dot(surface_normal) < 0.85:
				surface_normal = normal.normalized()
	# Находим потолок рядом и можем прилипнуть к нему.
	var ceiling_hit := _ray(global_position, global_position + Vector3.UP * 1.05)
	if not ceiling_hit.is_empty() and to_target.y < 0.5:
		surface_normal = Vector3.DOWN
	elif surface_normal == Vector3.DOWN:
		var ceiling_stick := _ray(global_position, global_position + Vector3.DOWN * 0.9)
		if ceiling_stick.is_empty(): surface_normal = Vector3.UP
	up_direction = surface_normal
	var stick_hit := _ray(global_position, global_position - surface_normal * 0.9)
	if stick_hit.is_empty():
		velocity += -surface_normal * GRAVITY * delta
	else:
		velocity = Vector3.ZERO
	velocity -= surface_normal * velocity.dot(surface_normal)
	velocity.x = direction.x * SPEED
	velocity.y = direction.y * SPEED
	velocity.z = direction.z * SPEED
	move_and_slide()
	step_phase += delta * 13.0
	for i in legs.size():
		legs[i].rotation.z = sin(step_phase + float(i) * 1.4) * 0.18 * (1.0 if i < 4 else -1.0)
	if to_target.length() <= ATTACK_DISTANCE and attack_cooldown <= 0.0:
		world_controller.take_damage(2.0)
		attack_cooldown = 1.0

func receive_hit(damage: float) -> bool:
	var flash := _material(Color(1.0, 0.08, 0.08))
	flash.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	for mesh in meshes:
		if is_instance_valid(mesh): mesh.material_override = flash
	flash_timer = 0.18
	health -= damage
	if health <= 0.0:
		if is_instance_valid(world_controller): world_controller.add_item(73, 1)
		queue_free()
	return true
