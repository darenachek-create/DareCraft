extends Node

var fov: float = 70.0
var selected_skin: int = 0
const SKIN_PRESETS: Array[Dictionary] = [
	{"name":"Классический", "gender":"Мужской", "skin":Color(0.90,0.70,0.55), "shirt":Color(0.25,0.50,0.85), "pants":Color(0.20,0.22,0.55), "hair":Color(0.30,0.20,0.10), "long_hair":false},
	{"name":"Алекс", "gender":"Женский", "skin":Color(0.92,0.72,0.59), "shirt":Color(0.22,0.65,0.42), "pants":Color(0.24,0.30,0.48), "hair":Color(0.78,0.43,0.16), "long_hair":true},
	{"name":"Рыжий", "gender":"Мужской", "skin":Color(0.96,0.73,0.57), "shirt":Color(0.75,0.22,0.16), "pants":Color(0.18,0.25,0.34), "hair":Color(0.72,0.25,0.08), "long_hair":false},
	{"name":"Ночная", "gender":"Женский", "skin":Color(0.72,0.53,0.43), "shirt":Color(0.28,0.20,0.52), "pants":Color(0.12,0.12,0.25), "hair":Color(0.10,0.08,0.16), "long_hair":true},
	{"name":"Исследователь", "gender":"Мужской", "skin":Color(0.78,0.58,0.43), "shirt":Color(0.72,0.57,0.24), "pants":Color(0.30,0.28,0.20), "hair":Color(0.18,0.12,0.08), "long_hair":false},
	{"name":"Лесная", "gender":"Женский", "skin":Color(0.88,0.67,0.51), "shirt":Color(0.20,0.48,0.25), "pants":Color(0.35,0.25,0.16), "hair":Color(0.40,0.20,0.10), "long_hair":true},
	{"name":"Снежный", "gender":"Мужской", "skin":Color(0.88,0.72,0.63), "shirt":Color(0.72,0.82,0.90), "pants":Color(0.30,0.43,0.60), "hair":Color(0.75,0.78,0.82), "long_hair":false},
	{"name":"Неоновая", "gender":"Женский", "skin":Color(0.85,0.64,0.55), "shirt":Color(0.12,0.72,0.72), "pants":Color(0.22,0.18,0.42), "hair":Color(0.82,0.20,0.58), "long_hair":true},
	{"name":"Пустынник", "gender":"Мужской", "skin":Color(0.58,0.39,0.28), "shirt":Color(0.70,0.48,0.25), "pants":Color(0.42,0.31,0.20), "hair":Color(0.12,0.09,0.07), "long_hair":false},
	{"name":"Звёздная", "gender":"Женский", "skin":Color(0.95,0.77,0.68), "shirt":Color(0.35,0.30,0.75), "pants":Color(0.18,0.20,0.42), "hair":Color(0.28,0.20,0.65), "long_hair":true},
	{"name":"Пират", "gender":"Мужской", "skin":Color(0.80,0.57,0.40), "shirt":Color(0.65,0.18,0.18), "pants":Color(0.18,0.20,0.28), "hair":Color(0.16,0.10,0.07), "long_hair":false},
	{"name":"Золотая", "gender":"Женский", "skin":Color(0.90,0.70,0.55), "shirt":Color(0.82,0.62,0.12), "pants":Color(0.35,0.24,0.12), "hair":Color(0.90,0.67,0.18), "long_hair":true}
]
var current_world := "Мир 1"
var pending_world_seed := 0 # 1..1235 — обычные сиды, 10001..10100 — city1..city100
var splash_shown := false
# true, когда меню открывается сразу после заставки: тогда оно появляется из темноты
var fade_in_menu := false

func worlds_dir() -> String:
	return "user://worlds"

func world_path(world_name: String) -> String:
	return worlds_dir() + "/" + world_name + ".save"

func list_worlds() -> PackedStringArray:
	var result := PackedStringArray()
	DirAccess.make_dir_recursive_absolute(worlds_dir())
	var d := DirAccess.open(worlds_dir())
	if d == null:
		return result
	for f in d.get_files():
		if f.ends_with(".save"):
			result.append(f.get_basename())
	result.sort()
	return result

func clean_name(raw: String) -> String:
	return raw.strip_edges().validate_filename()

func world_exists(world_name: String) -> bool:
	return FileAccess.file_exists(world_path(world_name))

func delete_world(world_name: String) -> void:
	DirAccess.remove_absolute(world_path(world_name))
