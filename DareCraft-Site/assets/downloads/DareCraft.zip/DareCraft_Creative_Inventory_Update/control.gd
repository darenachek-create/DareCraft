extends Control

const GAME_SCENE := "res://minecraft.tscn"
const GAME_TITLE := "DareCraft"
const VERSION_TEXT := "DareCraft 1.3"
const WORLD := 60
const CONTROL_MODE_PC := 0
const CONTROL_MODE_MOBILE := 1
const CONTROL_SETTINGS_PATH := "user://darecraft_controls.cfg"
const SPLASH_TEXTS := [
	"Сундуки и печки!", "Двойные сундуки!", "Железная броня!", "Мир 128×128!",
	"Щит блокирует урон!", "Не копай вниз!", "Made by Danyil!", "Крафти и выживай!",
]

var noise := FastNoiseLite.new()
var cam: Camera3D
var angle := 0.0
var t_anim := 0.0
var main_box: VBoxContainer
var panel_wrap: PanelContainer
var settings_box: VBoxContainer
var scroll_settings: ScrollContainer
var worlds_box: VBoxContainer
var list_box: VBoxContainer
var name_edit: LineEdit
var seed_edit: LineEdit
var msg_label: Label
var vol_label: Label
var logo_node: Control
var splash_label: Label
var btn_textures := {}
var control_mode := CONTROL_MODE_PC
var control_pc_button: Button
var control_mobile_button: Button

func _ready() -> void:
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	randomize()
	_load_control_mode()
	noise.seed = randi()
	noise.frequency = 0.04
	_make_button_styles()
	_build_scenery()
	_add_vignette()
	_build_ui()
	_add_footer()
	# после заставки с картинкой меню плавно появляется из темноты
	if Global.fade_in_menu:
		Global.fade_in_menu = false
		_fade_in_from_black()

func _load_control_mode() -> void:
	var config := ConfigFile.new()
	var error := config.load(CONTROL_SETTINGS_PATH)
	if error == OK:
		control_mode = clampi(
			int(config.get_value("controls", "mode", CONTROL_MODE_PC)),
			CONTROL_MODE_PC,
			CONTROL_MODE_MOBILE
		)
	else:
		control_mode = CONTROL_MODE_PC


func _save_control_mode() -> void:
	var config := ConfigFile.new()
	config.load(CONTROL_SETTINGS_PATH)
	config.set_value("controls", "mode", control_mode)
	var error := config.save(CONTROL_SETTINGS_PATH)
	if error != OK:
		push_warning("Не удалось сохранить режим управления")


func _refresh_control_mode_buttons() -> void:
	if control_pc_button == null or control_mobile_button == null:
		return
	control_pc_button.text = "✓ ПК" if control_mode == CONTROL_MODE_PC else "ПК"
	control_mobile_button.text = "✓ МОБИЛА" if control_mode == CONTROL_MODE_MOBILE else "МОБИЛА"


func _set_menu_control_mode(mode: int) -> void:
	control_mode = clampi(mode, CONTROL_MODE_PC, CONTROL_MODE_MOBILE)
	_save_control_mode()
	_refresh_control_mode_buttons()


# ---------------- фон: мир, над которым летает камера ----------------

func _make_materials() -> Dictionary:
	var colors := {
		"dirt": Color(0.5, 0.33, 0.2),
		"stone": Color(0.5, 0.5, 0.55),
		"wood": Color(0.45, 0.3, 0.15),
		"leaves": Color(0.15, 0.5, 0.18),
	}
	var mats := {}
	for key in colors:
		var m := StandardMaterial3D.new()
		m.albedo_color = colors[key]
		mats[key] = m
	var g := StandardMaterial3D.new()
	g.albedo_texture = load("res://grass_preview.png")
	g.texture_filter = BaseMaterial3D.TEXTURE_FILTER_NEAREST
	mats["grass"] = g
	return mats

func _build_scenery() -> void:
	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-50, -30, 0)
	add_child(sun)
	var we := WorldEnvironment.new()
	var env := Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.background_color = Color(0.5, 0.75, 1.0)
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(1, 1, 1)
	env.ambient_light_energy = 0.5
	we.environment = env
	add_child(we)

	var heights := {}
	for x in WORLD:
		for z in WORLD:
			heights[Vector2i(x, z)] = int(round(noise.get_noise_2d(x, z) * 7.0 + 4.0))

	var cells := {"grass": [], "dirt": [], "stone": [], "wood": [], "leaves": []}
	for x in WORLD:
		for z in WORLD:
			var h: int = heights[Vector2i(x, z)]
			var low := h
			for d in [Vector2i(1, 0), Vector2i(-1, 0), Vector2i(0, 1), Vector2i(0, -1)]:
				var n: Vector2i = Vector2i(x, z) + d
				if heights.has(n):
					low = mini(low, heights[n])
				else:
					low = mini(low, h - 3)
			for y in range(low, h + 1):
				var t := "stone"
				if y == h:
					t = "grass"
				elif y >= h - 3:
					t = "dirt"
				cells[t].append(Vector3i(x, y, z))
			if x > 3 and x < WORLD - 4 and z > 3 and z < WORLD - 4 and randf() < 0.012:
				for y in range(h + 1, h + 5):
					cells["wood"].append(Vector3i(x, y, z))
				for dx in range(-2, 3):
					for dz in range(-2, 3):
						for dy in range(h + 3, h + 6):
							if dy == h + 5 and (abs(dx) > 1 or abs(dz) > 1):
								continue
							if dx == 0 and dz == 0 and dy < h + 5:
								continue
							cells["leaves"].append(Vector3i(x + dx, dy, z + dz))

	var mats := _make_materials()
	var mesh := BoxMesh.new()
	for key in cells:
		var list: Array = cells[key]
		if list.is_empty():
			continue
		var mm := MultiMesh.new()
		mm.transform_format = MultiMesh.TRANSFORM_3D
		mm.mesh = mesh
		mm.instance_count = list.size()
		for i in list.size():
			mm.set_instance_transform(i, Transform3D(Basis(), Vector3(list[i])))
		var inst := MultiMeshInstance3D.new()
		inst.multimesh = mm
		inst.material_override = mats[key]
		add_child(inst)

	cam = Camera3D.new()
	add_child(cam)
	cam.current = true

func _process(delta: float) -> void:
	angle += delta * 0.12
	t_anim += delta
	var c := Vector3(WORLD / 2.0, 0.0, WORLD / 2.0)
	var r := 22.0
	var pos := c + Vector3(cos(angle) * r, 17.0 + sin(angle * 3.0) * 2.0, sin(angle) * r)
	cam.position = pos
	cam.look_at(pos + Vector3(-sin(angle), -0.3, cos(angle)) * 10.0)
	# логотип слегка «дышит», жёлтая надпись пульсирует, как в Minecraft
	if logo_node != null and logo_node.visible:
		logo_node.pivot_offset = logo_node.size / 2.0
		var sc := 1.0 + sin(t_anim * 1.6) * 0.015
		logo_node.scale = Vector2(sc, sc)
	if splash_label != null:
		splash_label.pivot_offset = splash_label.size / 2.0
		var sp := 1.0 + absf(sin(t_anim * 4.0)) * 0.08
		splash_label.scale = Vector2(sp, sp)

# ---------------- оформление: кнопки как в Minecraft ----------------

func _bevel_texture(fill: Color, light: Color, dark: Color, border: Color, seed_val: int) -> ImageTexture:
	var s := 16
	var rng := RandomNumberGenerator.new()
	rng.seed = seed_val
	var img := Image.create(s, s, false, Image.FORMAT_RGBA8)
	for y in s:
		for x in s:
			var c := fill
			if x == 0 or y == 0 or x == s - 1 or y == s - 1:
				c = border
			elif x == 1 or y == 1:
				c = light
			elif x >= s - 3 or y >= s - 3:
				c = dark
			else:
				var v := rng.randf_range(-0.025, 0.025)
				c = Color(fill.r + v, fill.g + v, fill.b + v, 1.0)
			img.set_pixel(x, y, c)
	return ImageTexture.create_from_image(img)

func _make_button_styles() -> void:
	var border := Color(0.05, 0.05, 0.06)
	btn_textures["normal"] = _bevel_texture(Color(0.44, 0.44, 0.47), Color(0.68, 0.68, 0.72), Color(0.26, 0.26, 0.29), border, 1)
	btn_textures["hover"] = _bevel_texture(Color(0.38, 0.45, 0.62), Color(0.62, 0.72, 0.95), Color(0.22, 0.28, 0.42), Color(1, 1, 1), 2)
	btn_textures["pressed"] = _bevel_texture(Color(0.3, 0.3, 0.33), Color(0.2, 0.2, 0.23), Color(0.5, 0.5, 0.54), border, 3)

func _style_box(key: String) -> StyleBoxTexture:
	var sb := StyleBoxTexture.new()
	sb.texture = btn_textures[key]
	sb.texture_margin_left = 4.0
	sb.texture_margin_top = 4.0
	sb.texture_margin_right = 4.0
	sb.texture_margin_bottom = 4.0
	return sb

func _style_button(b: Button, font_size: int) -> void:
	b.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	b.focus_mode = Control.FOCUS_NONE
	b.add_theme_stylebox_override("normal", _style_box("normal"))
	b.add_theme_stylebox_override("hover", _style_box("hover"))
	b.add_theme_stylebox_override("pressed", _style_box("pressed"))
	b.add_theme_stylebox_override("focus", StyleBoxEmpty.new())
	b.add_theme_color_override("font_color", Color(0.92, 0.92, 0.92))
	b.add_theme_color_override("font_hover_color", Color(1.0, 1.0, 0.55))
	b.add_theme_color_override("font_pressed_color", Color(0.78, 0.78, 0.78))
	b.add_theme_color_override("font_outline_color", Color(0.1, 0.1, 0.12))
	b.add_theme_constant_override("outline_size", 4)
	b.add_theme_font_size_override("font_size", font_size)

func _make_button(text: String, w: float = 520.0, h: float = 72.0, font_size: int = 34) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(w, h)
	_style_button(b, font_size)
	return b

# затемнение по краям экрана
func _add_vignette() -> void:
	var g := Gradient.new()
	g.colors = PackedColorArray([Color(0, 0, 0, 0), Color(0, 0, 0, 0.7)])
	g.offsets = PackedFloat32Array([0.45, 1.0])
	var gt := GradientTexture2D.new()
	gt.gradient = g
	gt.fill = GradientTexture2D.FILL_RADIAL
	gt.fill_from = Vector2(0.5, 0.5)
	gt.fill_to = Vector2(1.0, 0.5)
	gt.width = 256
	gt.height = 256
	var vig := TextureRect.new()
	vig.texture = gt
	vig.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	vig.stretch_mode = TextureRect.STRETCH_SCALE
	vig.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(vig)
	vig.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

func _small_label(text: String) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", 18)
	l.add_theme_color_override("font_color", Color(1, 1, 1, 0.85))
	l.add_theme_color_override("font_outline_color", Color(0, 0, 0))
	l.add_theme_constant_override("outline_size", 5)
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return l

# внизу: версия слева и подпись студии справа
func _add_footer() -> void:
	var bar := HBoxContainer.new()
	bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(bar)
	bar.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_WIDE)
	bar.offset_left = 16
	bar.offset_right = -16
	bar.offset_top = -40
	bar.offset_bottom = -8
	bar.add_child(_small_label(VERSION_TEXT))
	var gap := Control.new()
	gap.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	gap.mouse_filter = Control.MOUSE_FILTER_IGNORE
	bar.add_child(gap)
	bar.add_child(_small_label("DARENACHEK studio  ·  MADE WITH DANYIL"))

# жёлтая «пульсирующая» надпись у логотипа
func _add_splash_text() -> void:
	splash_label = Label.new()
	splash_label.text = SPLASH_TEXTS[randi() % SPLASH_TEXTS.size()]
	splash_label.add_theme_font_size_override("font_size", 26)
	splash_label.add_theme_color_override("font_color", Color(1, 0.95, 0.2))
	splash_label.add_theme_color_override("font_outline_color", Color(0.25, 0.2, 0))
	splash_label.add_theme_constant_override("outline_size", 6)
	splash_label.rotation = -0.3
	splash_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	logo_node.add_child(splash_label)
	splash_label.position = Vector2(290.0, 130.0)

# ищет файл логотипа в корне проекта (darecraft_logo*.svg или .png)
func _find_logo() -> Texture2D:
	var d := DirAccess.open("res://")
	if d == null:
		return null
	for f in d.get_files():
		var n := f.trim_suffix(".import").trim_suffix(".remap")
		if n.begins_with("darecraft_logo") and (n.ends_with(".svg") or n.ends_with(".png")):
			var t = load("res://" + n)
			if t is Texture2D:
				return t
	return null

func _title_label(text: String, font_size: int) -> Label:
	var l := Label.new()
	l.text = text
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.add_theme_font_size_override("font_size", font_size)
	l.add_theme_color_override("font_color", Color.WHITE)
	l.add_theme_color_override("font_outline_color", Color(0.15, 0.25, 0.1))
	l.add_theme_constant_override("outline_size", 8)
	return l

# ---------------- интерфейс ----------------

func _build_ui() -> void:
	var center := CenterContainer.new()
	add_child(center)
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	var holder := VBoxContainer.new()
	holder.add_theme_constant_override("separation", 26)
	center.add_child(holder)

	# логотип (если файл не найден, показываем текст)
	var logo_tex := _find_logo()
	if logo_tex != null:
		var logo := TextureRect.new()
		logo.texture = logo_tex
		logo.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		logo.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		logo.custom_minimum_size = Vector2(440, 182)
		logo.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
		logo_node = logo
	else:
		var title := _title_label(GAME_TITLE, 72)
		title.add_theme_constant_override("outline_size", 12)
		logo_node = title
	holder.add_child(logo_node)
	_add_splash_text()

	# ГЛАВНОЕ МЕНЮ: большая «Играть», внизу «Настройки» и «Выход»
	main_box = VBoxContainer.new()
	main_box.add_theme_constant_override("separation", 14)
	holder.add_child(main_box)

	var play := _make_button("Играть", 520, 78, 38)
	play.pressed.connect(_show_panel.bind("worlds"))
	main_box.add_child(play)

	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 14)
	main_box.add_child(row)
	var settings := _make_button("Настройки", 253, 64, 28)
	settings.pressed.connect(_show_panel.bind("settings"))
	row.add_child(settings)
	var quit := _make_button("Выход", 253, 64, 28)
	quit.pressed.connect(_on_quit)
	row.add_child(quit)

	# тёмная панель для экранов «Выбор мира» и «Настройки»
	panel_wrap = PanelContainer.new()
	panel_wrap.visible = false
	var pst := StyleBoxFlat.new()
	pst.bg_color = Color(0, 0, 0, 0.6)
	pst.set_corner_radius_all(10)
	pst.set_border_width_all(2)
	pst.border_color = Color(1, 1, 1, 0.25)
	pst.set_content_margin_all(22)
	panel_wrap.add_theme_stylebox_override("panel", pst)
	holder.add_child(panel_wrap)

	var inner := VBoxContainer.new()
	panel_wrap.add_child(inner)

	# ВЫБОР МИРА
	worlds_box = VBoxContainer.new()
	worlds_box.add_theme_constant_override("separation", 12)
	worlds_box.visible = false
	inner.add_child(worlds_box)
	worlds_box.add_child(_title_label("Выбор мира", 40))

	var scroll := ScrollContainer.new()
	scroll.custom_minimum_size = Vector2(640, 170)
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	worlds_box.add_child(scroll)
	list_box = VBoxContainer.new()
	list_box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	list_box.add_theme_constant_override("separation", 8)
	scroll.add_child(list_box)

	var new_row := HBoxContainer.new()
	new_row.add_theme_constant_override("separation", 10)
	worlds_box.add_child(new_row)
	name_edit = LineEdit.new()
	name_edit.placeholder_text = "Название нового мира"
	name_edit.custom_minimum_size = Vector2(400, 64)
	name_edit.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	name_edit.add_theme_font_size_override("font_size", 28)
	var edit_style := StyleBoxFlat.new()
	edit_style.bg_color = Color(0.06, 0.06, 0.08, 0.95)
	edit_style.set_border_width_all(3)
	edit_style.border_color = Color(0.5, 0.5, 0.55)
	edit_style.set_content_margin_all(10)
	name_edit.add_theme_stylebox_override("normal", edit_style)
	var edit_focus := edit_style.duplicate() as StyleBoxFlat
	edit_focus.border_color = Color(1, 1, 1)
	name_edit.add_theme_stylebox_override("focus", edit_focus)
	new_row.add_child(name_edit)
	var create := _make_button("Создать мир", 220, 64, 26)
	create.pressed.connect(_create_world)
	new_row.add_child(create)
	seed_edit = LineEdit.new()
	seed_edit.placeholder_text = "Сид мира (1–1235, пусто — случайный)"
	seed_edit.custom_minimum_size = Vector2(400, 54)
	seed_edit.add_theme_font_size_override("font_size", 22)
	worlds_box.add_child(seed_edit)

	msg_label = Label.new()
	msg_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	msg_label.add_theme_font_size_override("font_size", 24)
	msg_label.add_theme_color_override("font_color", Color(1, 0.85, 0.3))
	msg_label.add_theme_color_override("font_outline_color", Color.BLACK)
	msg_label.add_theme_constant_override("outline_size", 6)
	worlds_box.add_child(msg_label)

	var wback := _make_button("Назад", 520, 64, 30)
	wback.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	wback.pressed.connect(_show_panel.bind("main"))
	worlds_box.add_child(wback)

	# НАСТРОЙКИ (с прокруткой)
	scroll_settings = ScrollContainer.new()
	scroll_settings.custom_minimum_size = Vector2(640, 430)
	scroll_settings.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	scroll_settings.visible = false
	inner.add_child(scroll_settings)

	settings_box = VBoxContainer.new()
	settings_box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	settings_box.add_theme_constant_override("separation", 15)
	scroll_settings.add_child(settings_box)

	settings_box.add_child(_title_label("Настройки DareCraft", 44))

	# Выбор режима управления: ПК или мобильное устройство
	settings_box.add_child(_title_label("Режим управления", 28))
	var controls_row := HBoxContainer.new()
	controls_row.alignment = BoxContainer.ALIGNMENT_CENTER
	controls_row.add_theme_constant_override("separation", 15)
	settings_box.add_child(controls_row)

	control_pc_button = _make_button("ПК", 220, 60, 24)
	control_pc_button.pressed.connect(_set_menu_control_mode.bind(CONTROL_MODE_PC))
	controls_row.add_child(control_pc_button)

	control_mobile_button = _make_button("МОБИЛА", 220, 60, 24)
	control_mobile_button.pressed.connect(_set_menu_control_mode.bind(CONTROL_MODE_MOBILE))
	controls_row.add_child(control_mobile_button)
	_refresh_control_mode_buttons()

	# поле зрения
	var fov_row := HBoxContainer.new()
	fov_row.alignment = BoxContainer.ALIGNMENT_CENTER
	fov_row.add_theme_constant_override("separation", 20)
	settings_box.add_child(fov_row)

	var fov_label := _title_label("Обзор: " + str(int(Global.fov)), 28)
	fov_row.add_child(fov_label)

	var fov_slider := HSlider.new()
	fov_slider.min_value = 30.0
	fov_slider.max_value = 110.0
	fov_slider.step = 1.0
	fov_slider.value = Global.fov
	fov_slider.custom_minimum_size = Vector2(300, 40)
	fov_slider.value_changed.connect(func(val):
		Global.fov = val
		fov_label.text = "Обзор: " + str(int(val))
	)
	fov_row.add_child(fov_slider)

	# музыка
	var vol_row := HBoxContainer.new()
	vol_row.alignment = BoxContainer.ALIGNMENT_CENTER
	vol_row.add_theme_constant_override("separation", 20)
	settings_box.add_child(vol_row)

	vol_label = _title_label("Музыка: %d%%" % int(Music.music_volume * 100), 28)
	vol_row.add_child(vol_label)

	var slider := HSlider.new()
	slider.min_value = 0.0
	slider.max_value = 1.0
	slider.step = 0.01
	slider.value = Music.music_volume
	slider.custom_minimum_size = Vector2(300, 40)
	slider.value_changed.connect(_on_volume_changed)
	vol_row.add_child(slider)

	# --- НОВЫЙ ПОЛЗУНОК ЗВУКОВ (SFX) ---
	var sfx_row := HBoxContainer.new()
	sfx_row.alignment = BoxContainer.ALIGNMENT_CENTER
	sfx_row.add_theme_constant_override("separation", 20)
	settings_box.add_child(sfx_row)

	var sfx_label := _title_label("Звуки: %d%%" % int(Music.sfx_volume * 100), 28)
	sfx_row.add_child(sfx_label)

	var sfx_slider := HSlider.new()
	sfx_slider.min_value = 0.0
	sfx_slider.max_value = 1.0
	sfx_slider.step = 0.01
	sfx_slider.value = Music.sfx_volume
	sfx_slider.custom_minimum_size = Vector2(300, 40)
	sfx_slider.value_changed.connect(func(val):
		Music.set_sfx_volume(val)
		sfx_label.text = "Звуки: %d%%" % int(val * 100)
	)
	sfx_row.add_child(sfx_slider)
	# -----------------------------------

	# остальные настройки (пока заглушки, добавим позже)
	var grid := GridContainer.new()
	grid.columns = 2
	grid.add_theme_constant_override("h_separation", 20)
	grid.add_theme_constant_override("v_separation", 15)
	grid.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	settings_box.add_child(grid)

	var btn_names := [
		"Графика и Свет", "Звуки и Эффекты",
		"Язык и Шрифты", "Внешний вид",
		"Создатели игры", "Статистика", "Сохранения",
	]
	for b_name in btn_names:
		var btn := _make_button(b_name, 260, 60, 22)
		btn.pressed.connect(func(): print("Нажата кнопка: ", b_name))
		grid.add_child(btn)

	var back := _make_button("Готово", 520, 64, 30)
	back.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	back.pressed.connect(_show_panel.bind("main"))
	settings_box.add_child(back)

func _show_panel(which: String) -> void:
	if which == "settings":
		_load_control_mode()
		_refresh_control_mode_buttons()
	# логотип показываем только в главном меню
	if logo_node != null:
		logo_node.visible = (which == "main")
	main_box.visible = which == "main"
	panel_wrap.visible = which != "main"
	scroll_settings.visible = which == "settings"
	worlds_box.visible = which == "worlds"
	if which == "worlds":
		_refresh_worlds()

func _refresh_worlds() -> void:
	for ch in list_box.get_children():
		ch.queue_free()
	msg_label.text = ""
	var names := Global.list_worlds()
	if names.is_empty():
		list_box.add_child(_title_label("Миров пока нет. Создайте первый!", 26))
	for wn in names:
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 10)
		list_box.add_child(row)
		var play := _make_button(wn, 380, 64, 28)
		play.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		play.pressed.connect(_play_world.bind(wn))
		row.add_child(play)
		var del := _make_button("Удалить", 160, 64, 24)
		del.pressed.connect(_on_delete.bind(wn, del))
		row.add_child(del)

func _on_delete(wn: String, btn: Button) -> void:
	if btn.text == "Удалить":
		btn.text = "Точно?"
	else:
		Global.delete_world(wn)
		_refresh_worlds()

func _create_world() -> void:
	var wn := Global.clean_name(name_edit.text)
	if wn.is_empty():
		var n := Global.list_worlds().size() + 1
		wn = "Мир %d" % n
		while Global.world_exists(wn):
			n += 1
			wn = "Мир %d" % n
	if Global.world_exists(wn):
		msg_label.text = "Мир с таким названием уже есть"
		return
	var seed_text := seed_edit.text.strip_edges() if seed_edit != null else ""
	if not seed_text.is_empty():
		if not seed_text.is_valid_int() or int(seed_text) < 1 or int(seed_text) > 1235:
			msg_label.text = "Сид должен быть от 1 до 1235"
			return
		Global.pending_world_seed = int(seed_text)
	else:
		Global.pending_world_seed = 0
	_play_world(wn)

# выбрали мир: сцена игры сама покажет полёт камеры над миром, советы и загрузку
func _play_world(wn: String) -> void:
	Global.current_world = wn
	get_tree().change_scene_to_file(GAME_SCENE)

func _on_volume_changed(v: float) -> void:
	Music.set_music_volume(v)
	vol_label.text = "Музыка: %d%%" % int(round(v * 100.0))

func _on_quit() -> void:
	get_tree().quit()

# ---------------- появление меню из темноты ----------------

func _fade_in_from_black() -> void:
	var layer := CanvasLayer.new()
	layer.layer = 100
	add_child(layer)
	var black := ColorRect.new()
	black.color = Color(0, 0, 0, 1)
	black.mouse_filter = Control.MOUSE_FILTER_STOP
	layer.add_child(black)
	black.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var tw := create_tween()
	tw.tween_interval(0.5)
	tw.tween_property(black, "color:a", 0.0, 2.0)
	tw.tween_callback(layer.queue_free)
