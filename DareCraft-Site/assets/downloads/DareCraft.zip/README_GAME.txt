Замените этот архив на актуальную сборку DareCraft от DARENACHEK studio.
