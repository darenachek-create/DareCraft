extends Node

const MUSIC_PATH := "res://Where_the_Compass_Rests.mp3"
const SAVE_PATH := "user://settings.cfg"

var music_volume := 0.5
var sfx_volume := 0.5 # <--- НОВАЯ ПЕРЕМЕННАЯ ДЛЯ ЗВУКОВ
var player: AudioStreamPlayer

func _ready() -> void:
	_load_settings()
	player = AudioStreamPlayer.new()
	var stream = load(MUSIC_PATH)
	if stream:
		stream.loop = true
		player.stream = stream
	add_child(player)
	_apply_volume()
	player.play()

func set_music_volume(v: float) -> void:
	music_volume = clamp(v, 0.0, 1.0)
	_apply_volume()
	_save_settings()

# НОВАЯ ФУНКЦИЯ ДЛЯ ЗВУКОВ
func set_sfx_volume(v: float) -> void:
	sfx_volume = clamp(v, 0.0, 1.0)
	_save_settings()

func _apply_volume() -> void:
	if music_volume > 0.001:
		player.volume_db = linear_to_db(music_volume)
	else:
		player.volume_db = -80.0

func _load_settings() -> void:
	var cfg := ConfigFile.new()
	if cfg.load(SAVE_PATH) == OK:
		music_volume = cfg.get_value("audio", "music", 0.5)
		sfx_volume = cfg.get_value("audio", "sfx", 0.5) # <--- Загружаем звуки

func _save_settings() -> void:
	var cfg := ConfigFile.new()
	cfg.set_value("audio", "music", music_volume)
	cfg.set_value("audio", "sfx", sfx_volume) # <--- Сохраняем звуки
	cfg.save(SAVE_PATH)
