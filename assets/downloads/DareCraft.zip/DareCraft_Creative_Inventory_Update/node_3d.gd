extends Node3D

const CW := 96
const CS := 16
const WORLD_SIZE := CW * CS
const WORLD_H := 64
const ROCK_LEVEL := 40
const SPEED := 5.0
const JUMP_SPEED := 7.0
const GRAVITY := 20.0
const MOUSE_SENS := 0.003
const MAX_STACK := 64
const HOTBAR := 9
const TOTAL_SLOTS := 24
const SAVE_VERSION := 2
const CRACK_STAGES := 8
const ATLAS_TILES := 31
const HAND_POS := Vector3(0.55, -0.55, -0.35)
const HAND_L_POS := Vector3(-0.6, -0.55, -0.4)
const HAND_L_BLOCK_POS := Vector3(-0.2, -0.2, 0.25)
const SMALL_MAP := [0, 1, 3, 4]
const GROW_TIME := 45.0
const SEED_CHANCE := 0.15
const CONTROL_MODE_PC := 0
const CONTROL_MODE_MOBILE := 1
const CONTROL_SETTINGS_PATH := "user://darecraft_controls.cfg"

const GRASS := 1
const DIRT := 2
const STONE := 3
const LOG := 4
const LEAVES := 5
const PLANKS := 6
const TABLE := 7
const COAL := 8
const IRON := 9
const STICK := 10
const PICKAXE := 11
const FARMLAND := 12
const SHOVEL := 13
const SWORD := 14
const AXE := 15
const HOE := 16
const WHEAT_SEEDS := 17
const POTATO_SEEDS := 18
const BEET_SEEDS := 19
const WHEAT := 20
const POTATO := 21
const BEETROOT := 22
const HELMET := 23
const CHESTPLATE := 24
const LEGGINGS := 25
const BOOTS := 26
const SHIELD := 27
const DOOR := 28
const FURNACE := 29
const S_PICKAXE := 30
const S_SHOVEL := 31
const S_SWORD := 32
const S_AXE := 33
const S_HOE := 34
const S_HELMET := 35
const S_CHESTPLATE := 36
const S_LEGGINGS := 37
const S_BOOTS := 38
const S_SHIELD := 39
const COAL_ITEM := 40
const IRON_INGOT := 41
const RAW_IRON := 42
const CHEST := 43
const RAW_PORK := 53
const COOKED_PORK := 54
const ROTTEN_FLESH := 55
const COOKED_FLESH := 56
const DIAMOND_ORE := 57
const DIAMOND := 58
const D_PICKAXE := 59
const D_SWORD := 60
const D_AXE := 61
const D_SHOVEL := 62
const GLASS := 63
const RAIL := 64
const MINECART := 65
const D_HOE := 66
const D_HELMET := 67
const D_CHESTPLATE := 68
const D_LEGGINGS := 69
const D_BOOTS := 70
const D_SHIELD := 71
const I_PICKAXE := 44
const I_SHOVEL := 45
const I_SWORD := 46
const I_AXE := 47
const I_HOE := 48
const I_HELMET := 49
const I_CHESTPLATE := 50
const I_LEGGINGS := 51
const I_BOOTS := 52
const THIRD_DIST := 3.5

const TILES := {
	GRASS: [0, 1, 2], DIRT: [2, 2, 2], STONE: [3, 3, 3],
	LOG: [5, 4, 5], LEAVES: [6, 6, 6], PLANKS: [7, 7, 7],
	TABLE: [8, 9, 7], COAL: [10, 10, 10], IRON: [11, 11, 11],
	FARMLAND: [14, 2, 2], FURNACE: [3, 15, 3], CHEST: [19, 20, 19], DIAMOND_ORE: [11, 11, 11], GLASS: [16, 16, 16], RAIL: [12, 12, 12], MINECART: [19, 19, 19],
}
const ICON_TILE := {
	GRASS: 1, DIRT: 2, STONE: 3, LOG: 4, LEAVES: 6, PLANKS: 7,
	TABLE: 9, COAL: 10, IRON: 11, STICK: 12, PICKAXE: 13, FARMLAND: 2, SHOVEL: 14, SWORD: 24, AXE: 25, HOE: 26, WHEAT_SEEDS: 16, POTATO_SEEDS: 16, BEET_SEEDS: 16, WHEAT: 17, POTATO: 17, BEETROOT: 17, HELMET: 27, CHESTPLATE: 28, LEGGINGS: 29, BOOTS: 30, SHIELD: 27, FURNACE: 15,
	COAL_ITEM: 16, RAW_IRON: 17, IRON_INGOT: 18, CHEST: 21,
	I_PICKAXE: 22, I_SHOVEL: 23, I_SWORD: 24, I_AXE: 25, I_HOE: 26,
	I_HELMET: 27, I_CHESTPLATE: 28, I_LEGGINGS: 29, I_BOOTS: 30,
	DIAMOND_ORE: 11, DIAMOND: 18, D_PICKAXE: 22, D_SWORD: 24, D_AXE: 25, D_SHOVEL: 23, D_HOE: 26, D_HELMET: 27, D_CHESTPLATE: 28, D_LEGGINGS: 29, D_BOOTS: 30, D_SHIELD: 27, GLASS: 16, RAIL: 12, MINECART: 21,
}
const ITEM_ICON := {
	SHOVEL: 0, SWORD: 1, AXE: 2, HOE: 3,
	WHEAT_SEEDS: 4, POTATO_SEEDS: 5, BEET_SEEDS: 6,
	WHEAT: 7, POTATO: 8, BEETROOT: 9,
	HELMET: 10, CHESTPLATE: 11, LEGGINGS: 12, BOOTS: 13,
	PICKAXE: 14, SHIELD: 15, RAW_PORK: 16, COOKED_PORK: 17, ROTTEN_FLESH: 18, COOKED_FLESH: 19, D_PICKAXE: 20, D_SWORD: 21, D_AXE: 22, D_SHOVEL: 23,
}
const ITEM2_ICON := {
	S_PICKAXE: 0, S_SHOVEL: 1, S_SWORD: 2, S_AXE: 3, S_HOE: 4,
	S_HELMET: 5, S_CHESTPLATE: 6, S_LEGGINGS: 7, S_BOOTS: 8, S_SHIELD: 9,
	DOOR: 10,
}
const HARDNESS := {
	GRASS: 0.5, DIRT: 0.45, LOG: 1.0, LEAVES: 0.2, PLANKS: 0.8,
	TABLE: 0.8, STONE: 1.6, COAL: 1.8, IRON: 2.2, FARMLAND: 0.45,
	FURNACE: 1.6, DOOR: 0.6, CHEST: 0.8, DIAMOND_ORE: 3.0, GLASS: 0.3, RAIL: 0.4, MINECART: 0.5,
}
const SEED_CROP := {WHEAT_SEEDS: 0, POTATO_SEEDS: 1, BEET_SEEDS: 2}
const CROP_SEED := [WHEAT_SEEDS, POTATO_SEEDS, BEET_SEEDS]
const CROP_DROP := [WHEAT, POTATO, BEETROOT]
const ARMOR_SLOT_IDS := [HELMET, CHESTPLATE, LEGGINGS, BOOTS, SHIELD]
const ARMOR_SLOT_OF := {
	HELMET: 0, CHESTPLATE: 1, LEGGINGS: 2, BOOTS: 3, SHIELD: 4,
	S_HELMET: 0, S_CHESTPLATE: 1, S_LEGGINGS: 2, S_BOOTS: 3, S_SHIELD: 4,
	I_HELMET: 0, I_CHESTPLATE: 1, I_LEGGINGS: 2, I_BOOTS: 3,
	D_HELMET: 0, D_CHESTPLATE: 1, D_LEGGINGS: 2, D_BOOTS: 3, D_SHIELD: 4,
}
const ARMOR_NAMES := ["Шлем", "Нагрудник", "Поножи", "Ботинки", "Щит"]
const ARMOR_POINTS := [1, 3, 2, 1, 0]
const ARMOR_POINTS_STONE := [2, 4, 3, 2, 0]
const ARMOR_POINTS_IRON := [2, 6, 5, 2, 0]
const ARMOR_POINTS_DIAMOND := [3, 8, 6, 3, 0]
const WOOD_COL := [Color(0.72, 0.54, 0.29), Color(0.5, 0.36, 0.18)]
const STONE_COL := [Color(0.62, 0.62, 0.66), Color(0.4, 0.4, 0.45)]
const IRON_COL := [Color(0.8, 0.8, 0.85), Color(0.5, 0.5, 0.55)]
const LOAD_TIPS := [
	"Правый клик мотыгой по траве или земле создаёт грядку.",
	"Семена иногда выпадают, когда вы ломаете траву.",
	"Дважды нажмите на стопку, выберите «Разделить» и укажите слот для одного предмета.",
	"Правую кнопку мыши можно удерживать, чтобы раскладывать стопку по одному предмету.",
	"Верстак открывает крафт 3×3: правый клик по нему.",
	"Броня надевается в слоты слева от персонажа, правый клик по броне тоже надевает её.",
	"Пшеница, картошка и свёкла созревают примерно за 90 секунд.",
	"Ваш мир сохраняется автоматически при паузе и выходе из игры.",
	"Две двери получаются из шести досок: два столбика по три доски.",
	"Печка собирается из восьми камней по кругу на верстаке.",
	"В печке готовится сырая свинина и гнилая плоть; топливо — уголь или дерево.",
	"Два сундука рядом превращаются в двойной сундук.",
	"Щит поднимается правой кнопкой мыши и блокирует урон.",
]

const RECIPES := [
	{"pattern": [[LOG]], "table": false, "out": [PLANKS, 4]},
	{"pattern": [[PLANKS, PLANKS], [PLANKS, PLANKS]], "table": false, "out": [TABLE, 1]},
	{"pattern": [[PLANKS], [PLANKS]], "table": false, "out": [STICK, 4]},
	{"pattern": [[PLANKS, PLANKS, PLANKS], [0, STICK, 0], [0, STICK, 0]], "table": true, "out": [PICKAXE, 1]},
	{"pattern": [[PLANKS], [STICK], [STICK]], "table": true, "out": [SHOVEL, 1]},
	{"pattern": [[PLANKS], [PLANKS], [STICK]], "table": true, "out": [SWORD, 1]},
	{"pattern": [[PLANKS, PLANKS], [PLANKS, STICK], [0, STICK]], "table": true, "out": [AXE, 1]},
	{"pattern": [[PLANKS, PLANKS], [STICK, PLANKS], [STICK, 0]], "table": true, "out": [AXE, 1]},
	{"pattern": [[PLANKS, PLANKS], [0, STICK], [0, STICK]], "table": true, "out": [HOE, 1]},
	{"pattern": [[PLANKS, PLANKS], [STICK, 0], [STICK, 0]], "table": true, "out": [HOE, 1]},
	{"pattern": [[STONE, STONE, STONE], [0, STICK, 0], [0, STICK, 0]], "table": true, "out": [S_PICKAXE, 1]},
	{"pattern": [[STONE], [STICK], [STICK]], "table": true, "out": [S_SHOVEL, 1]},
	{"pattern": [[STONE], [STONE], [STICK]], "table": true, "out": [S_SWORD, 1]},
	{"pattern": [[STONE, STONE], [STONE, STICK], [0, STICK]], "table": true, "out": [S_AXE, 1]},
	{"pattern": [[STONE, STONE], [STICK, STONE], [STICK, 0]], "table": true, "out": [S_AXE, 1]},
	{"pattern": [[STONE, STONE], [0, STICK], [0, STICK]], "table": true, "out": [S_HOE, 1]},
	{"pattern": [[STONE, STONE], [STICK, 0], [STICK, 0]], "table": true, "out": [S_HOE, 1]},
	{"pattern": [[PLANKS, PLANKS, PLANKS], [PLANKS, 0, PLANKS]], "table": true, "out": [HELMET, 1]},
	{"pattern": [[PLANKS, 0, PLANKS], [PLANKS, PLANKS, PLANKS], [PLANKS, PLANKS, PLANKS]], "table": true, "out": [CHESTPLATE, 1]},
	{"pattern": [[PLANKS, PLANKS, PLANKS], [PLANKS, 0, PLANKS], [PLANKS, 0, PLANKS]], "table": true, "out": [LEGGINGS, 1]},
	{"pattern": [[PLANKS, 0, PLANKS], [PLANKS, 0, PLANKS]], "table": true, "out": [BOOTS, 1]},
	{"pattern": [[PLANKS, IRON_INGOT, PLANKS], [PLANKS, PLANKS, PLANKS], [0, PLANKS, 0]], "table": true, "out": [SHIELD, 1]},
	{"pattern": [[STONE, STONE, STONE], [STONE, 0, STONE]], "table": true, "out": [S_HELMET, 1]},
	{"pattern": [[STONE, 0, STONE], [STONE, STONE, STONE], [STONE, STONE, STONE]], "table": true, "out": [S_CHESTPLATE, 1]},
	{"pattern": [[STONE, STONE, STONE], [STONE, 0, STONE], [STONE, 0, STONE]], "table": true, "out": [S_LEGGINGS, 1]},
	{"pattern": [[STONE, 0, STONE], [STONE, 0, STONE]], "table": true, "out": [S_BOOTS, 1]},
	{"pattern": [[STONE, IRON_INGOT, STONE], [STONE, STONE, STONE], [0, STONE, 0]], "table": true, "out": [S_SHIELD, 1]},
	{"pattern": [[PLANKS, PLANKS], [PLANKS, PLANKS], [PLANKS, PLANKS]], "table": true, "out": [DOOR, 2]},
	{"pattern": [[STONE, STONE, STONE], [STONE, 0, STONE], [STONE, STONE, STONE]], "table": true, "out": [FURNACE, 1]},
	{"pattern": [[PLANKS, PLANKS, PLANKS], [PLANKS, 0, PLANKS], [PLANKS, PLANKS, PLANKS]], "table": true, "out": [CHEST, 1]},
	{"pattern": [[IRON_INGOT, IRON_INGOT, IRON_INGOT], [0, STICK, 0], [0, STICK, 0]], "table": true, "out": [I_PICKAXE, 1]},
	{"pattern": [[IRON_INGOT], [STICK], [STICK]], "table": true, "out": [I_SHOVEL, 1]},
	{"pattern": [[IRON_INGOT], [IRON_INGOT], [STICK]], "table": true, "out": [I_SWORD, 1]},
	{"pattern": [[IRON_INGOT, IRON_INGOT], [IRON_INGOT, STICK], [0, STICK]], "table": true, "out": [I_AXE, 1]},
	{"pattern": [[IRON_INGOT, IRON_INGOT], [STICK, IRON_INGOT], [STICK, 0]], "table": true, "out": [I_AXE, 1]},
	{"pattern": [[IRON_INGOT, IRON_INGOT], [0, STICK], [0, STICK]], "table": true, "out": [I_HOE, 1]},
	{"pattern": [[IRON_INGOT, IRON_INGOT], [STICK, 0], [STICK, 0]], "table": true, "out": [I_HOE, 1]},
	{"pattern": [[IRON_INGOT, IRON_INGOT, IRON_INGOT], [IRON_INGOT, 0, IRON_INGOT]], "table": true, "out": [I_HELMET, 1]},
	{"pattern": [[IRON_INGOT, 0, IRON_INGOT], [IRON_INGOT, IRON_INGOT, IRON_INGOT], [IRON_INGOT, IRON_INGOT, IRON_INGOT]], "table": true, "out": [I_CHESTPLATE, 1]},
	{"pattern": [[IRON_INGOT, IRON_INGOT, IRON_INGOT], [IRON_INGOT, 0, IRON_INGOT], [IRON_INGOT, 0, IRON_INGOT]], "table": true, "out": [I_LEGGINGS, 1]},
	{"pattern": [[IRON_INGOT, 0, IRON_INGOT], [IRON_INGOT, 0, IRON_INGOT]], "table": true, "out": [I_BOOTS, 1]},
	{"pattern": [[DIAMOND, DIAMOND, DIAMOND], [0, STICK, 0], [0, STICK, 0]], "table": true, "out": [D_PICKAXE, 1]},
	{"pattern": [[DIAMOND], [DIAMOND], [STICK]], "table": true, "out": [D_SWORD, 1]},
	{"pattern": [[DIAMOND, DIAMOND], [DIAMOND, STICK], [0, STICK]], "table": true, "out": [D_AXE, 1]},
	{"pattern": [[DIAMOND], [STICK], [STICK]], "table": true, "out": [D_SHOVEL, 1]},
	{"pattern": [[DIAMOND, DIAMOND], [0, STICK], [0, STICK]], "table": true, "out": [D_HOE, 1]},
	{"pattern": [[DIAMOND, DIAMOND, DIAMOND], [DIAMOND, 0, DIAMOND]], "table": true, "out": [D_HELMET, 1]},
	{"pattern": [[DIAMOND, 0, DIAMOND], [DIAMOND, DIAMOND, DIAMOND], [DIAMOND, DIAMOND, DIAMOND]], "table": true, "out": [D_CHESTPLATE, 1]},
	{"pattern": [[DIAMOND, DIAMOND, DIAMOND], [DIAMOND, 0, DIAMOND], [DIAMOND, 0, DIAMOND]], "table": true, "out": [D_LEGGINGS, 1]},
	{"pattern": [[DIAMOND, 0, DIAMOND], [DIAMOND, 0, DIAMOND]], "table": true, "out": [D_BOOTS, 1]},
	{"pattern": [[PLANKS, DIAMOND, PLANKS], [PLANKS, PLANKS, PLANKS], [0, PLANKS, 0]], "table": true, "out": [D_SHIELD, 1]},
]
const SMELTING := {
	RAW_IRON: IRON_INGOT,
	RAW_PORK: COOKED_PORK,
	ROTTEN_FLESH: COOKED_FLESH,
}
const FUEL := {
	COAL_ITEM: 80.0, COAL: 80.0, PLANKS: 15.0, LOG: 15.0, STICK: 5.0, TABLE: 15.0,
}
const SMELT_TIME := 10.0

const FACE_N := [
	Vector3i(0, 1, 0), Vector3i(0, -1, 0),
	Vector3i(1, 0, 0), Vector3i(-1, 0, 0),
	Vector3i(0, 0, 1), Vector3i(0, 0, -1),
]
const FACE_V := [
	[Vector3(0, 1, 0), Vector3(1, 1, 0), Vector3(1, 1, 1), Vector3(0, 1, 1)],
	[Vector3(0, 0, 0), Vector3(0, 0, 1), Vector3(1, 0, 1), Vector3(1, 0, 0)],
	[Vector3(1, 0, 0), Vector3(1, 0, 1), Vector3(1, 1, 1), Vector3(1, 1, 0)],
	[Vector3(0, 0, 0), Vector3(0, 1, 0), Vector3(0, 1, 1), Vector3(0, 0, 1)],
	[Vector3(0, 0, 1), Vector3(0, 1, 1), Vector3(1, 1, 1), Vector3(1, 0, 1)],
	[Vector3(0, 0, 0), Vector3(1, 0, 0), Vector3(1, 1, 0), Vector3(0, 1, 0)],
]

var chunks: Array = []
var chunk_top: Array = []
var chunk_mi: Array = []
var chunk_cs: Array = []
var trees_generated: Array[bool] = []
var villages_generated: Array[bool] = []
var heights := PackedInt32Array()
var control_mode := CONTROL_MODE_PC
var mobile_control_style := 0 # 0 — кнопки, 1 — виртуальный джойстик
var mobile_stick_touch := -1
var mobile_stick_origin := Vector2.ZERO
var mobile_stick_vector := Vector2.ZERO
var mobile_stick_base: Control
var mobile_stick_knob: Control
var mobile_dpad: Control
var mobile_virtual_stick: Control

var control_pc_button: Button
var control_mobile_button: Button
var hn := FastNoiseLite.new()
var mn := FastNoiseLite.new()
var world_seed := 0
var world_loaded := false
var saved_pos := Vector3.ZERO
var home_pos := Vector3.ZERO

var atlas_tex: Texture2D
var items_tex: Texture2D
var items2_tex: Texture2D
var block_mat: StandardMaterial3D
var highlight: MeshInstance3D
var break_overlay: MeshInstance3D
var break_mat: StandardMaterial3D
var crack_tex: Array = []

var player: CharacterBody3D
var step_timer := 0.0
var step_player: AudioStreamPlayer
var camera: Camera3D
var ray: RayCast3D
var pitch := 0.0
var player_cs: CollisionShape3D
var player_cap: CapsuleShape3D

var hand_pivot: Node3D
var hand_item: Node3D
var hand_left: Node3D
var fp_shield_mats: Array = []
var held_id := -1
var swing_phase := 0.0
var walk_bob := 0.0
var bob_amp := 0.0

var ready_done := false
var paused := false
var creative_mode := false
var creative_grid: GridContainer
var creative_scroll: ScrollContainer
var creative_scroll_direction := 0
var creative_scroll_repeat := 0.0
var inv_open := false
var table_mode := false
var breaking := false
var breaking_active := false
var mob_attack_cooldown := 0.0
var break_progress := 0.0
var break_cell := Vector3i(-1, -1, -1)

var close_x := MobileCloseX.new()

var blocking := false
var block_amt := 0.0
var health := 20.0
var health_label: Label
var msg_label: Label
var msg_t := 0.0

# Цикл дня и ночи
const DAY_NIGHT_CYCLE := 480.0
const DAY_LENGTH := 240.0
var cycle_time := 0.0
var sun_light: DirectionalLight3D
var world_env: Environment
var moon_node: MeshInstance3D
var star_nodes: Array[MeshInstance3D] = []
var day_night_label: Label
var night_active := false
var zombie_nodes: Array[Node3D] = []
var zombie_spawn_timer := 0.0

var pause_layer: CanvasLayer
var loading_layer: CanvasLayer
var hud_layer: CanvasLayer
var loading_label: Label
var inv_layer: CanvasLayer
var inv_title: Label
var craft_title: Label
var grid_small: GridContainer
var grid_big: GridContainer

var slots: Array = []
var armor: Array = []
var craft_grid: Array = []
var selected := 0
var cursor_item := {"id": 0, "n": 0}
var craft_recipe := {}
var hot_ui: Array = []
var inv_ui: Array = []
var armor_ui: Array = []
var armor_label: Label
var craft_small_ui: Array = []
var craft_big_ui: Array = []
var craft_out_ui: Dictionary = {}
var cursor_ui: Dictionary = {}
var icon_cache := {}
var rmb_down := false
var rmb_visited := {}

# Разделение предметов в инвентаре по двойному нажатию.
var split_button: Button
var split_mode := false
var split_source_slot := -1
var suppress_next_slot_click := false
var last_inv_click_slot := -1
var last_inv_click_time_msec := 0
var last_inv_click_stack := {"id": 0, "n": 0}

var crops := {}
var crop_nodes := {}
var grow_acc := 0.0

var doors := {}
var door_nodes := {}

var furnaces := {}
var furnace_ui_cell := Vector3i(-1, -1, -1)
var furnace_slots_ui: Array = []
var furnace_inv_ui: Array = []
var furnace_hot_ui: Array = []
var furnace_layer: CanvasLayer

var chests := {}
var chest_layer: CanvasLayer
var chest_ui_cell := Vector3i(-1, -1, -1)
var chest_slots_ui: Array = []
var chest_inv_ui: Array = []
var chest_hot_ui: Array = []
var chest_is_double := false
var chest_title_lbl: Label

var load_cam: Camera3D
var view_mode := 0
var aim_pivot: Node3D
var chars: Array = []
var player_char: Dictionary = {}
var preview_char: Dictionary = {}
var load_t := 0.0
var loading_bar: ProgressBar
var mobile_hud: Control
var mobile_move_vec := Vector2.ZERO
var mobile_move_flags := {"up": false, "down": false, "left": false, "right": false}
var mobile_jump_held := false
var creative_flying := false
var commands_enabled := false
var chat_open := false
var chat_panel: PanelContainer
var chat_input: LineEdit
var chat_history: Label
var jump_was_down := false
var last_jump_msec := 0
var mobile_crouch_held := false
var mobile_sprint_held := false
var mobile_break_held := false
var mobile_look_touch_id := -1
var mobile_look_last_pos: Vector2 = Vector2.ZERO

func _ready() -> void:
	randomize()
	_load_control_mode()
	add_child(close_x)
	close_x.setup([], control_mode == CONTROL_MODE_MOBILE, _close_any_open_menu)

	for i in TOTAL_SLOTS:
		slots.append({"id": 0, "n": 0})
	for i in 5:
		armor.append({"id": 0, "n": 0})
	for i in 9:
		craft_grid.append({"id": 0, "n": 0})
	_make_materials()
	_make_crack_textures()
	_make_environment()
	_make_hud()
	_make_chat_ui()
	_make_mobile_hud()
	_make_inventory_ui()
	_make_furnace_ui()
	_make_chest_ui()
	_make_cursor_ui()
	_make_pause_menu()
	_make_loading_ui()
	_make_loading_cam()
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	await get_tree().process_frame
	await _generate_world()
	_make_player()
	_update_chunks(true)
	_make_hand()
	_spawn_loaded_crops()
	_spawn_loaded_doors()
	if load_cam != null:
		load_cam.queue_free()
		load_cam = null
	loading_layer.queue_free()
	ready_done = true
	hud_layer.visible = true
	if not world_loaded:
		_save_world()
	_refresh_slots()
	for i in range(10):
		var rx = int(player.position.x) + randi_range(-15, 15)
		var rz = int(player.position.z) + randi_range(-15, 15)
		rx = clampi(rx, 2, WORLD_SIZE - 2)
		rz = clampi(rz, 2, WORLD_SIZE - 2)
		var ry = _height_at(rx, rz) + 2
		var pig = _create_pig(Vector3(rx + 0.5, ry, rz + 0.5))
		add_child(pig)
	_apply_control_mode()
	day_night_label = Label.new()
	day_night_label.position = Vector2(16, 42)
	day_night_label.add_theme_font_size_override("font_size", 20)
	day_night_label.add_theme_color_override("font_outline_color", Color.BLACK)
	day_night_label.add_theme_constant_override("outline_size", 5)
	hud_layer.add_child(day_night_label)

func _close_any_open_menu() -> void:
	if chest_layer != null and chest_layer.visible:
		_close_chest()
	elif furnace_layer != null and furnace_layer.visible:
		_close_furnace()
	elif inv_open:
		_close_inventory()

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_CLOSE_REQUEST or what == NOTIFICATION_APPLICATION_PAUSED:
		_save_world()

# ---------------- сохранение ----------------

func _save_world() -> void:
	if not ready_done or player == null:
		return
	DirAccess.make_dir_recursive_absolute(Global.worlds_dir())
	var f := FileAccess.open(Global.world_path(Global.current_world), FileAccess.WRITE)
	if f == null:
		return
	f.store_32(SAVE_VERSION)
	f.store_32(world_seed)
	for i in CW * CW:
		f.store_buffer(chunks[i])
	f.store_var(player.position)
	f.store_var(slots)
	f.store_var(armor)
	f.store_var(crops)
	f.store_var(doors)
	f.store_var(furnaces)
	f.store_var(chests)
	f.store_8(1 if commands_enabled else 0)
	f.close()

func _load_control_mode() -> void:
	var config := ConfigFile.new()
	var error := config.load(CONTROL_SETTINGS_PATH)
	if error == OK:
		control_mode = clampi(
			int(config.get_value("controls", "mode", CONTROL_MODE_PC)),
			CONTROL_MODE_PC,
			CONTROL_MODE_MOBILE
		)
	else:
		control_mode = CONTROL_MODE_PC
	mobile_control_style = int(config.get_value("controls", "mobile_style", 0)) if error == OK else 0

func _save_control_mode() -> void:
	var config := ConfigFile.new()
	config.load(CONTROL_SETTINGS_PATH)
	config.set_value("controls", "mode", control_mode)
	var error := config.save(CONTROL_SETTINGS_PATH)
	if error != OK:
		push_warning("Не удалось сохранить режим управления")

func _set_control_mode(mode: int) -> void:
	control_mode = clampi(mode, CONTROL_MODE_PC, CONTROL_MODE_MOBILE)
	_save_control_mode()
	_refresh_control_mode_buttons()
	_apply_control_mode()

func _apply_control_mode() -> void:
	var is_mobile := control_mode == CONTROL_MODE_MOBILE
	close_x.set_mobile(is_mobile)
	if mobile_hud != null:
		mobile_hud.visible = is_mobile and ready_done and not paused and not inv_open
	if not is_mobile:
		_reset_mobile_inputs()
	if ready_done and not paused and not inv_open:
		Input.mouse_mode = Input.MOUSE_MODE_VISIBLE if is_mobile else Input.MOUSE_MODE_CAPTURED

func _reset_mobile_inputs() -> void:
	mobile_move_flags = {"up": false, "down": false, "left": false, "right": false}
	mobile_move_vec = Vector2.ZERO
	mobile_stick_vector = Vector2.ZERO
	mobile_stick_touch = -1
	if mobile_stick_knob != null: mobile_stick_knob.position = Vector2(56, 56)
	mobile_jump_held = false
	mobile_crouch_held = false
	mobile_sprint_held = false
	mobile_break_held = false
	breaking = false
	blocking = false
	mobile_look_touch_id = -1

func _refresh_control_mode_buttons() -> void:
	if control_pc_button == null or control_mobile_button == null:
		return
	control_pc_button.text = "✓ ПК" if control_mode == CONTROL_MODE_PC else "ПК"
	control_mobile_button.text = "✓ МОБИЛА" if control_mode == CONTROL_MODE_MOBILE else "МОБИЛА"

func _load_world() -> bool:
	var path: String = str(Global.world_path(Global.current_world))
	if not FileAccess.file_exists(path):
		return false
	var f := FileAccess.open(path, FileAccess.READ)
	if f == null:
		return false
	if f.get_length() < 8 + CW * CW * CS * CS * WORLD_H:
		f.close()
		return false
	if f.get_32() != SAVE_VERSION:
		f.close()
		return false
	world_seed = f.get_32()
	for i in CW * CW:
		var buf := f.get_buffer(CS * CS * WORLD_H)
		chunks[i] = buf
		var top := 0
		var y := WORLD_H - 1
		while y > 0 and top == 0:
			for j in 256:
				if buf[j + y * 256] != 0:
					top = y
					break
			y -= 1
		chunk_top[i] = top
	var pos = f.get_var()
	if pos is Vector3:
		saved_pos = pos
	var sv = f.get_var()
	if sv is Array and sv.size() == TOTAL_SLOTS:
		slots = sv
	if f.get_position() < f.get_length():
		var av = f.get_var()
		if av is Array:
			for i in mini(av.size(), 5):
				armor[i] = av[i]
	if f.get_position() < f.get_length():
		var cv = f.get_var()
		if cv is Dictionary:
			crops = cv
	if f.get_position() < f.get_length():
		var dv = f.get_var()
		if dv is Dictionary:
			doors = dv
	if f.get_position() < f.get_length():
		var fv = f.get_var()
		if fv is Dictionary:
			furnaces = fv
	if f.get_position() < f.get_length():
		var chv = f.get_var()
		if chv is Dictionary:
			chests = chv
	if f.get_position() < f.get_length():
		commands_enabled = f.get_8() != 0
	f.close()
	return true

# ---------------- материалы и окружение ----------------

func _color_mat(c: Color) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = c
	m.roughness = 1.0
	return m

func _make_materials() -> void:
	atlas_tex = load("res://atlas.png")
	items_tex = load("res://items.png")
	items2_tex = load("res://items2.png")
	block_mat = StandardMaterial3D.new()
	block_mat.albedo_texture = atlas_tex
	block_mat.texture_filter = BaseMaterial3D.TEXTURE_FILTER_NEAREST
	block_mat.roughness = 1.0

	highlight = MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = Vector3(1.01, 1.01, 1.01)
	highlight.mesh = bm
	var hm := StandardMaterial3D.new()
	hm.albedo_color = Color(1, 1, 1, 0.18)
	hm.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	hm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	highlight.material_override = hm
	highlight.visible = false
	add_child(highlight)

	break_overlay = MeshInstance3D.new()
	break_overlay.mesh = _make_cube(0, 0.01)
	break_mat = StandardMaterial3D.new()
	break_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	break_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	break_mat.texture_filter = BaseMaterial3D.TEXTURE_FILTER_NEAREST
	break_overlay.material_override = break_mat
	break_overlay.visible = false
	add_child(break_overlay)

func _make_crack_textures() -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = 4242
	var dirs: Array[Vector2i] = [
		Vector2i(1, 0), Vector2i(1, 1), Vector2i(0, 1), Vector2i(-1, 1),
		Vector2i(-1, 0), Vector2i(-1, -1), Vector2i(0, -1), Vector2i(1, -1),
	]
	var walkers := 6
	var pos: Array[Vector2i] = []
	var main_dir: Array[Vector2i] = []
	for w in walkers:
		pos.append(Vector2i(8, 8))
		main_dir.append(dirs[int(w * 8.0 / walkers)])
	var pts: Array[Vector2i] = []
	for step in 10:
		for w in walkers:
			var d: Vector2i = main_dir[w] if rng.randf() < 0.7 else dirs[rng.randi_range(0, 7)]
			var p: Vector2i = pos[w] + d
			p = Vector2i(clampi(p.x, 0, 15), clampi(p.y, 0, 15))
			pos[w] = p
			pts.append(p)
	for stage in CRACK_STAGES:
		var img := Image.create(16, 16, false, Image.FORMAT_RGBA8)
		img.fill(Color(0, 0, 0, 0))
		var count := int(pts.size() * (stage + 1) / float(CRACK_STAGES))
		for k in count:
			img.set_pixelv(pts[k], Color(0, 0, 0, 0.75))
		crack_tex.append(ImageTexture.create_from_image(img))

func _make_environment() -> void:
	sun_light = DirectionalLight3D.new()
	sun_light.name = "DaySun"
	sun_light.rotation_degrees = Vector3(-50, -30, 0)
	sun_light.light_color = Color(1.0, 0.94, 0.78)
	sun_light.light_energy = 1.15
	add_child(sun_light)
	var we := WorldEnvironment.new()
	world_env = Environment.new()
	world_env.background_mode = Environment.BG_COLOR
	world_env.background_color = Color(0.5, 0.75, 1.0)
	world_env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	world_env.ambient_light_color = Color(1, 1, 1)
	world_env.ambient_light_energy = 0.5
	we.environment = world_env
	add_child(we)
	_make_sky_objects()

func _make_sky_objects() -> void:
	var moon_mesh := SphereMesh.new()
	moon_mesh.radius = 2.4
	moon_mesh.height = 4.8
	moon_node = MeshInstance3D.new()
	moon_node.name = "Moon"
	moon_node.mesh = moon_mesh
	var moon_mat := StandardMaterial3D.new()
	moon_mat.albedo_color = Color(0.78, 0.84, 1.0)
	moon_mat.emission_enabled = true
	moon_mat.emission = Color(0.48, 0.58, 0.9)
	moon_mat.emission_energy_multiplier = 0.8
	moon_node.material_override = moon_mat
	moon_node.visible = false
	add_child(moon_node)
	var star_mesh := SphereMesh.new()
	star_mesh.radius = 0.11
	star_mesh.height = 0.22
	var star_mat := StandardMaterial3D.new()
	star_mat.albedo_color = Color(0.92, 0.95, 1.0)
	star_mat.emission_enabled = true
	star_mat.emission = Color(0.75, 0.82, 1.0)
	star_mat.emission_energy_multiplier = 1.4
	for i in 90:
		var star := MeshInstance3D.new()
		star.mesh = star_mesh
		star.material_override = star_mat
		star.position = Vector3(randf_range(-75.0, 75.0), randf_range(18.0, 65.0), randf_range(-75.0, 75.0))
		star.visible = false
		add_child(star)
		star_nodes.append(star)

func _update_day_night(delta: float) -> void:
	cycle_time = fmod(cycle_time + delta, DAY_NIGHT_CYCLE)
	var is_night := cycle_time >= DAY_LENGTH
	var night_blend := 0.0
	if is_night:
		night_blend = clampf((cycle_time - DAY_LENGTH) / 18.0, 0.0, 1.0)
	else:
		night_blend = 1.0 - clampf(cycle_time / 18.0, 0.0, 1.0)
	var sun_angle := -15.0 - (cycle_time / DAY_NIGHT_CYCLE) * 360.0
	sun_light.rotation_degrees.x = sun_angle
	sun_light.light_energy = lerpf(1.15, 0.04, night_blend)
	world_env.background_color = Color(0.5, 0.75, 1.0).lerp(Color(0.012, 0.018, 0.055), night_blend)
	world_env.ambient_light_color = Color(1.0, 0.96, 0.86).lerp(Color(0.18, 0.22, 0.42), night_blend)
	world_env.ambient_light_energy = lerpf(0.55, 0.22, night_blend)
	moon_node.visible = night_blend > 0.15
	moon_node.global_position = player.global_position + Vector3(35.0, 48.0, -62.0)
	for star in star_nodes:
		star.visible = night_blend > 0.55
		star.global_position += Vector3.ZERO
		# Звёзды держатся вокруг игрока, чтобы не исчезать при перемещении.
		var rel := star.position
		star.global_position = player.global_position + Vector3(rel.x, rel.y, rel.z)
	var darkness_level := lerpf(3.0, 1.0, night_blend)
	if day_night_label != null:
		var remain := int(ceil((DAY_LENGTH - cycle_time) if not is_night else (DAY_NIGHT_CYCLE - cycle_time)))
		var darkness_mark := "3.0 · Утро" if darkness_level > 2.75 else ("2.5 · Сумерки" if darkness_level > 2.25 else ("2.0 · Темнеет" if darkness_level > 1.75 else ("1.5 · Опасно" if darkness_level > 1.25 else "1.0 · Очень темно")))
		day_night_label.text = ("Ночь" if is_night else "День") + " · " + str(remain) + "с · " + darkness_mark
	if is_night != night_active:
		night_active = is_night
		if night_active:
			_show_msg("Наступила ночь. В лесу появились зомби!")
			zombie_spawn_timer = 0.5
		else:
			_show_msg("Рассвет! Зомби прячутся до следующей ночи.")
			for z in zombie_nodes:
				if is_instance_valid(z): z.queue_free()
			zombie_nodes.clear()
	if not creative_mode and darkness_level <= 1.5:
		_update_zombie_spawns(delta, darkness_level)

func _update_zombie_spawns(delta: float, darkness_level: float = 1.0) -> void:
	zombie_nodes = zombie_nodes.filter(func(z): return is_instance_valid(z))
	zombie_spawn_timer -= delta
	var max_mobs := 2 if darkness_level > 1.2 else 4
	if zombie_spawn_timer <= 0.0 and zombie_nodes.size() < max_mobs:
		zombie_spawn_timer = 32.0 if darkness_level > 1.2 else 22.0
		var angle := randf() * TAU
		var distance := randf_range(13.0, 22.0)
		var x := clampi(int(player.position.x + cos(angle) * distance), 2, WORLD_SIZE - 3)
		var zpos := clampi(int(player.position.z + sin(angle) * distance), 2, WORLD_SIZE - 3)
		var y := _height_at(x, zpos) + 1
		var attempts := 0
		while attempts < 8 and (get_block(x, y + 1, zpos) != 0 or get_block(x, y + 2, zpos) != 0):
			angle = randf() * TAU
			x = clampi(int(player.position.x + cos(angle) * distance), 2, WORLD_SIZE - 3)
			zpos = clampi(int(player.position.z + sin(angle) * distance), 2, WORLD_SIZE - 3)
			y = _height_at(x, zpos) + 1
			attempts += 1
		if attempts >= 8 and (get_block(x, y + 1, zpos) != 0 or get_block(x, y + 2, zpos) != 0):
			return
		var mob := CharacterBody3D.new()
		mob.set_script(load("res://zombie.gd"))
		mob.position = Vector3(x + 0.5, y, zpos + 0.5)
		mob.set("target", player)
		mob.set("world_controller", self)
		add_child(mob)
		zombie_nodes.append(mob)

func _make_cube(id: int, grow: float = 0.0) -> ArrayMesh:
	var verts := PackedVector3Array()
	var norms := PackedVector3Array()
	var uvs := PackedVector2Array()
	var idx := PackedInt32Array()
	for f in 6:
		var n: Vector3i = FACE_N[f]
		var fv: Array = FACE_V[f]
		var tile := 0
		if id != 0:
			var tiles: Array = TILES[id]
			tile = tiles[0] if f == 0 else (tiles[2] if f == 1 else tiles[1])
		var base := verts.size()
		for c in 4:
			var v: Vector3 = fv[c]
			verts.append((v - Vector3(0.5, 0.5, 0.5)) * (1.0 + grow))
			norms.append(Vector3(n))
			var u := v.x
			var w := v.z
			if f >= 2 and f < 4:
				u = v.z
				w = 1.0 - v.y
			elif f >= 4:
				w = 1.0 - v.y
			if id != 0:
				uvs.append(Vector2((tile + lerpf(0.01, 0.99, u)) / float(ATLAS_TILES), lerpf(0.01, 0.99, w)))
			else:
				uvs.append(Vector2(u, w))
		idx.append(base)
		idx.append(base + 1)
		idx.append(base + 2)
		idx.append(base)
		idx.append(base + 2)
		idx.append(base + 3)
	var arrays := []
	arrays.resize(Mesh.ARRAY_MAX)
	arrays[Mesh.ARRAY_VERTEX] = verts
	arrays[Mesh.ARRAY_NORMAL] = norms
	arrays[Mesh.ARRAY_TEX_UV] = uvs
	arrays[Mesh.ARRAY_INDEX] = idx
	var mesh := ArrayMesh.new()
	mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
	return mesh

# ---------------- генерация мира ----------------

func _setup_noise() -> void:
	hn.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
	hn.seed = world_seed
	hn.frequency = 0.012
	hn.fractal_type = FastNoiseLite.FRACTAL_FBM
	hn.fractal_octaves = 4
	mn.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
	mn.seed = world_seed + 1337
	mn.frequency = 0.006
	mn.fractal_type = FastNoiseLite.FRACTAL_FBM
	mn.fractal_octaves = 3

func _generate_world() -> void:
	for i in CW * CW:
		chunks.append(PackedByteArray())
		chunk_top.append(0)
		chunk_mi.append(null)
		chunk_cs.append(null)
		trees_generated.append(false)
		villages_generated.append(false)
	heights.resize(WORLD_SIZE * WORLD_SIZE)
	world_loaded = _load_world()
	if not world_loaded:
		world_seed = randi()
	_setup_noise()
	loading_label.text = "Подготовка мира..."
	loading_bar.value = 50.0
	await get_tree().process_frame

func _height_at(x: int, z: int) -> int:
	var n1 := hn.get_noise_2d(x, z)
	var m := maxf(0.0, mn.get_noise_2d(x, z) - 0.05)
	return clampi(int(round(22.0 + n1 * 9.0 + m * m * 60.0)), 4, 52)

func _gen_terrain(cx: int, cz: int) -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = world_seed * 31 + cx + cz * CW + 7
	var data := PackedByteArray()
	data.resize(CS * CS * WORLD_H)
	var top := 0
	for lz in CS:
		for lx in CS:
			var x := cx * CS + lx
			var z := cz * CS + lz
			var h := _height_at(x, z)
			heights[x + z * WORLD_SIZE] = h
			top = maxi(top, h)
			var rocky := h >= ROCK_LEVEL
			for y in range(0, h + 1):
				var id := STONE
				if y == h and not rocky:
					id = GRASS
				elif y >= h - 3 and not rocky and y > 0:
					id = DIRT
				if id == STONE and y > 0:
					var r := rng.randf()
					if y <= 18 and r < 0.004:
						id = DIAMOND_ORE
					elif y <= 22 and r < 0.012:
						id = IRON
					elif y <= 45 and r < 0.03:
						id = COAL
				data[lx + lz * CS + y * 256] = id
	var key := cx + cz * CW
	chunks[key] = data
	chunk_top[key] = top
	_gen_mine_in_chunk(cx, cz, rng)

func _gen_mine_in_chunk(cx: int, cz: int, rng: RandomNumberGenerator) -> void:
	# Небольшая подземная шахта с проходом, деревянными стойками и сундуком.
	if rng.randf() > 0.075:
		return
	var x0 := cx * CS + rng.randi_range(3, 9)
	var z0 := cz * CS + rng.randi_range(3, 11)
	var surface := _height_at(x0, z0)
	var base_y := maxi(8, mini(surface - 5, 24))
	for step in range(0, 7):
		var xx := x0 + step
		for yy in range(base_y - 1, base_y + 3):
			for zz in range(z0 - 1, z0 + 2):
				var idx := (xx & 15) + (zz & 15) * CS + yy * 256
				if xx >= cx * CS and xx < (cx + 1) * CS and zz >= cz * CS and zz < (cz + 1) * CS and yy >= 0 and yy < WORLD_H:
					chunks[cx + cz * CW][idx] = 0
		# Деревянные стойки шахты через каждые три блока.
		if step % 3 == 0:
			for yy in range(base_y - 1, base_y + 3):
				for zz in [z0 - 1, z0 + 1]:
					var idx2: int = (xx & 15) + (zz & 15) * CS + yy * 256
					chunks[cx + cz * CW][idx2] = LOG
		var rail_idx := (xx & 15) + (z0 & 15) * CS + (base_y - 1) * 256
		chunks[cx + cz * CW][rail_idx] = RAIL
		if step == 3:
			chunks[cx + cz * CW][rail_idx + 256] = MINECART
	# Сундук с лутом в конце прохода.
	var chest_x := x0 + 6
	var chest_idx := (chest_x & 15) + (z0 & 15) * CS + base_y * 256
	chunks[cx + cz * CW][chest_idx] = CHEST

func _put(x: int, y: int, z: int, id: int) -> void:
	if y < 0 or y >= WORLD_H or x < 0 or z < 0 or x >= WORLD_SIZE or z >= WORLD_SIZE:
		return
	var key := (x >> 4) + (z >> 4) * CW
	var data: PackedByteArray = chunks[key]
	if data.size() != CS * CS * WORLD_H:
		return
	var i := (x & 15) + (z & 15) * CS + y * 256
	if data[i] != 0:
		return
	data[i] = id
	if y > chunk_top[key]:
		chunk_top[key] = y

func _gen_trees() -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = world_seed + 99
	var c := WORLD_SIZE >> 1
	for x in range(3, WORLD_SIZE - 3):
		for z in range(3, WORLD_SIZE - 3):
			if rng.randf() > 0.008:
				continue
			if abs(x - c) < 6 and abs(z - c) < 6:
				continue
			var h: int = heights[x + z * WORLD_SIZE]
			if h >= ROCK_LEVEL - 2:
				continue
			var th := rng.randi_range(4, 6)
			for y in range(h + 1, h + th + 1):
				_put(x, y, z, LOG)
			for dy in range(-1, 3):
				var r := 2 if dy <= 0 else 1
				for dx in range(-r, r + 1):
					for dz in range(-r, r + 1):
						if r == 2 and abs(dx) == 2 and abs(dz) == 2:
							continue
						_put(x + dx, h + th + dy, z + dz, LEAVES)

func get_block(x: int, y: int, z: int) -> int:
	if y < 0:
		return STONE
	if y >= WORLD_H or x < 0 or z < 0 or x >= WORLD_SIZE or z >= WORLD_SIZE:
		return 0
	var key := (x >> 4) + (z >> 4) * CW
	var data: PackedByteArray = chunks[key]
	if data.size() == 0:
		return 0
	return data[(x & 15) + (z & 15) * CS + y * 256]

func _build_chunk(cx: int, cz: int) -> void:
	var key := cx + cz * CW
	var data: PackedByteArray = chunks[key]
	var top_y: int = chunk_top[key]
	var verts := PackedVector3Array()
	var norms := PackedVector3Array()
	var uvs := PackedVector2Array()
	var idx := PackedInt32Array()
	var ox := cx * CS
	var oz := cz * CS
	for y in range(0, top_y + 1):
		for lz in CS:
			for lx in CS:
				var id := data[lx + lz * CS + y * 256]
				if id == 0:
					continue
				var x := ox + lx
				var z := oz + lz
				for f in 6:
					var n: Vector3i = FACE_N[f]
					if get_block(x + n.x, y + n.y, z + n.z) != 0:
						continue
					var tiles: Array = TILES.get(id, TILES[STONE])
					var tile: int = tiles[0] if f == 0 else (tiles[2] if f == 1 else tiles[1])
					var fv: Array = FACE_V[f]
					var base := verts.size()
					for c in 4:
						var v: Vector3 = fv[c]
						verts.append(Vector3(x, y, z) + v)
						norms.append(Vector3(n))
						var u := v.x
						var w := v.z
						if f >= 2 and f < 4:
							u = v.z
							w = 1.0 - v.y
						elif f >= 4:
							w = 1.0 - v.y
						uvs.append(Vector2((tile + lerpf(0.01, 0.99, u)) / float(ATLAS_TILES), lerpf(0.01, 0.99, w)))
					idx.append(base)
					idx.append(base + 1)
					idx.append(base + 2)
					idx.append(base)
					idx.append(base + 2)
					idx.append(base + 3)

	var mi: MeshInstance3D = chunk_mi[key]
	var cs: CollisionShape3D = chunk_cs[key]
	if mi == null:
		var body := StaticBody3D.new()
		mi = MeshInstance3D.new()
		mi.material_override = block_mat
		cs = CollisionShape3D.new()
		body.add_child(mi)
		body.add_child(cs)
		add_child(body)
		chunk_mi[key] = mi
		chunk_cs[key] = cs
	if verts.is_empty():
		mi.mesh = null
		cs.shape = null
		return
	var arrays := []
	arrays.resize(Mesh.ARRAY_MAX)
	arrays[Mesh.ARRAY_VERTEX] = verts
	arrays[Mesh.ARRAY_NORMAL] = norms
	arrays[Mesh.ARRAY_TEX_UV] = uvs
	arrays[Mesh.ARRAY_INDEX] = idx
	var mesh := ArrayMesh.new()
	mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
	mi.mesh = mesh
	cs.shape = mesh.create_trimesh_shape()

func _set_block(cell: Vector3i, id: int) -> void:
	if cell.y < 0 or cell.y >= WORLD_H:
		return
	if cell.x < 0 or cell.z < 0 or cell.x >= WORLD_SIZE or cell.z >= WORLD_SIZE:
		return

	var cx := cell.x >> 4
	var cz := cell.z >> 4
	var key := cx + cz * CW

	var data: PackedByteArray = chunks[key]
	if data.size() != CS * CS * WORLD_H:
		return

	var lx := cell.x & 15
	var lz := cell.z & 15
	var index := lx + lz * CS + cell.y * 256

	data[index] = id
	chunks[key] = data

	if cell.y > chunk_top[key]:
		chunk_top[key] = cell.y

	_queue_chunk_rebuild(cx, cz)

	if lx == 0:
		_queue_chunk_rebuild(cx - 1, cz)
	elif lx == CS - 1:
		_queue_chunk_rebuild(cx + 1, cz)

	if lz == 0:
		_queue_chunk_rebuild(cx, cz - 1)
	elif lz == CS - 1:
		_queue_chunk_rebuild(cx, cz + 1)

func _gen_village_in_chunk(cx: int, cz: int) -> void:
	# Небольшие деревни через равные интервалы; строятся только при приближении к чанку.
	if cx < 4 or cz < 4 or cx % 24 != 12 or cz % 24 != 12:
		return
	var rng := RandomNumberGenerator.new()
	rng.seed = world_seed + cx * 7919 + cz * 104729
	var x0 := cx * CS + 4
	var z0 := cz * CS + 4
	var y0 := _height_at(x0 + 3, z0 + 3) + 1
	# Домик 7x7, стены и крыша.
	for x in range(7):
		for z in range(7):
			_set_block(Vector3i(x0 + x, y0 - 1, z0 + z), PLANKS)
			for y in range(3):
				if x == 0 or x == 6 or z == 0 or z == 6:
					if not (z == 0 and x == 3 and y < 2):
						_set_block(Vector3i(x0 + x, y0 + y, z0 + z), LOG if y == 2 else PLANKS)
	for x in range(7):
		for z in range(7):
			_set_block(Vector3i(x0 + x, y0 + 3, z0 + z), PLANKS)
	# Сундук с полезной добычей.
	var chest_cell := Vector3i(x0 + 5, y0, z0 + 4)
	_set_block(chest_cell, CHEST)
	var loot: Array = _get_chest_inventory(chest_cell, false)
	var rewards := [[COAL_ITEM, 4], [IRON_INGOT, 2], [RAW_IRON, 3], [DIAMOND, 1], [PLANKS, 12], [COOKED_PORK, 2]]
	for i in 5:
		var reward: Array = rewards[rng.randi_range(0, rewards.size() - 1)]
		loot[i] = {"id": reward[0], "n": reward[1]}
	chests[chest_cell] = loot

func _queue_chunk_rebuild(cx: int, cz: int) -> void:
	if cx < 0 or cx >= CW or cz < 0 or cz >= CW:
		return
	var key := cx + cz * CW
	if chunks[key].size() != CS * CS * WORLD_H:
		return
	if chunk_mi[key] == null:
		return
	dirty_chunks[key] = Vector2i(cx, cz)

func _process_dirty_chunks() -> void:
	if dirty_chunks.is_empty():
		return
	var keys := dirty_chunks.keys()
	var key: int = int(keys[0])
	var coord: Vector2i = dirty_chunks[key]
	dirty_chunks.erase(key)
	if key < 0 or key >= chunk_mi.size():
		return
	if chunk_mi[key] == null:
		return
	if chunks[key].size() != CS * CS * WORLD_H:
		return
	_build_chunk(coord.x, coord.y)

func _make_player() -> void:
	player = CharacterBody3D.new()
	player_cs = CollisionShape3D.new()
	player_cap = CapsuleShape3D.new()
	player_cap.height = 1.8
	player_cap.radius = 0.4
	player_cs.shape = player_cap
	player.add_child(player_cs)
	camera = Camera3D.new()
	camera.position = Vector3(0, 0.7, 0)
	camera.fov = Global.fov
	player.add_child(camera)
	aim_pivot = Node3D.new()
	aim_pivot.position = Vector3(0, 0.7, 0)
	player.add_child(aim_pivot)
	ray = RayCast3D.new()
	ray.target_position = Vector3(0, 0, -6)
	ray.add_exception(player)
	aim_pivot.add_child(ray)
	player_char = _build_character()
	var pr: Node3D = player_char["root"]
	pr.position = Vector3(0, -0.9, 0)
	pr.visible = false
	player.add_child(pr)
	chars.append(player_char)
	var c := WORLD_SIZE >> 1
	home_pos = Vector3(c + 0.5, _height_at(c, c) + 3.0, c + 0.5)
	player.position = home_pos
	step_player = AudioStreamPlayer.new()
	step_player.stream = load("res://шаги по траве.mp3")
	step_player.volume_db = linear_to_db(Music.sfx_volume * 0.8)
	player.add_child(step_player)
	add_child(player)
	camera.current = true

func _make_hand() -> void:
	hand_pivot = Node3D.new()
	hand_pivot.position = HAND_POS
	hand_pivot.rotation_degrees = Vector3(15, 12, 0)
	camera.add_child(hand_pivot)

	var sleeve := MeshInstance3D.new()
	var sm := BoxMesh.new()
	sm.size = Vector3(0.24, 0.24, 0.5)
	sleeve.mesh = sm
	sleeve.position = Vector3(0, 0, -0.25)
	sleeve.material_override = _color_mat(Color(0.25, 0.5, 0.85))
	hand_pivot.add_child(sleeve)

	var skin := MeshInstance3D.new()
	var km := BoxMesh.new()
	km.size = Vector3(0.22, 0.22, 0.32)
	skin.mesh = km
	skin.position = Vector3(0, 0, -0.66)
	skin.material_override = _color_mat(Color(0.9, 0.7, 0.55))
	hand_pivot.add_child(skin)

	hand_item = Node3D.new()
	hand_item.position = Vector3(-0.02, 0.2, -0.78)
	hand_pivot.add_child(hand_item)

	hand_left = Node3D.new()
	hand_left.position = HAND_L_POS
	hand_left.rotation_degrees = Vector3(10, -14, 0)
	hand_left.visible = false
	camera.add_child(hand_left)
	_box(hand_left, Vector3(0.24, 0.24, 0.5), Vector3(0, 0, -0.25), _color_mat(Color(0.25, 0.5, 0.85)))
	_box(hand_left, Vector3(0.22, 0.22, 0.32), Vector3(0, 0, -0.66), _color_mat(Color(0.9, 0.7, 0.55)))
	var fm := _color_mat(WOOD_COL[0])
	var fd := _color_mat(WOOD_COL[1])
	fp_shield_mats = [fm, fd]
	_box(hand_left, Vector3(0.52, 0.68, 0.05), Vector3(0.16, 0.1, -0.86), fd)
	_box(hand_left, Vector3(0.42, 0.58, 0.06), Vector3(0.16, 0.1, -0.83), fm)
	_box(hand_left, Vector3(0.14, 0.14, 0.05), Vector3(0.16, 0.1, -0.79), _color_mat(Color(0.6, 0.62, 0.66)))

	held_id = -1
	_refresh_slots()

func _rebuild_held(id: int) -> void:
	if hand_item != null:
		_fill_item(hand_item, id, 0.3, 0.024, 20.0)
	for c in chars:
		var hand_node: Node3D = c["hand"]
		_fill_item(hand_node, id, 0.16, 0.012, 90.0)

func _fill_item(parent: Node3D, id: int, cube_scale: float, px: float, sprite_yaw: float) -> void:
	for ch in parent.get_children():
		ch.queue_free()
	if id == 0:
		return
	if TILES.has(id):
		var mi := MeshInstance3D.new()
		mi.mesh = _make_cube(id)
		mi.material_override = block_mat
		mi.scale = Vector3(cube_scale, cube_scale, cube_scale)
		mi.rotation_degrees = Vector3(0, 35, 0)
		parent.add_child(mi)
	else:
		var sp := Sprite3D.new()
		if ITEM_ICON.has(id):
			sp.texture = items_tex
			sp.region_rect = Rect2(float(int(ITEM_ICON[id]) * 16), 0.0, 16.0, 16.0)
		elif ITEM2_ICON.has(id):
			sp.texture = items2_tex
			sp.region_rect = Rect2(float(int(ITEM2_ICON[id]) * 16), 0.0, 16.0, 16.0)
		else:
			sp.texture = atlas_tex
			sp.region_rect = Rect2(float(int(ICON_TILE[id]) * 16), 0.0, 16.0, 16.0)
		sp.region_enabled = true
		sp.pixel_size = px
		sp.texture_filter = BaseMaterial3D.TEXTURE_FILTER_NEAREST
		sp.shaded = false
		sp.double_sided = true
		sp.alpha_cut = SpriteBase3D.ALPHA_CUT_DISCARD
		sp.rotation_degrees = Vector3(0, sprite_yaw, 0)
		parent.add_child(sp)

func _update_hand(delta: float) -> void:
	if hand_pivot == null:
		return
	hand_pivot.visible = not inv_open and view_mode == 0
	var moving := Vector2(player.velocity.x, player.velocity.z).length() > 0.5 and player.is_on_floor() and not inv_open and not paused
	bob_amp = move_toward(bob_amp, 1.0 if moving else 0.0, delta * 6.0)
	if moving:
		walk_bob += delta * 9.0
	var bob := Vector3(cos(walk_bob * 0.5) * 0.012, absf(sin(walk_bob)) * -0.02, 0.0) * bob_amp
	if breaking_active or swing_phase > 0.0:
		swing_phase += delta * 3.4
		if swing_phase >= 1.0:
			swing_phase = fmod(swing_phase, 1.0) if breaking_active else 0.0
	var s := sin(swing_phase * PI)
	if not player_char.is_empty():
		var pr: Node3D = player_char["root"]
		pr.visible = view_mode != 0
		if pr.visible:
			_animate_char(player_char, sin(walk_bob) * 0.7 * bob_amp, s, pitch)
	hand_pivot.position = HAND_POS + bob + Vector3(-0.08, -0.12, -0.12) * s
	hand_pivot.rotation_degrees = Vector3(15.0 - 45.0 * s, 12.0 + 8.0 * s, -10.0 * s)
	if hand_left != null:
		if armor[4]["id"] == 0:
			blocking = false
		hand_left.visible = armor[4]["id"] != 0 and view_mode == 0 and not inv_open
		var want := 1.0 if (blocking and hand_left.visible) else 0.0
		block_amt = move_toward(block_amt, want, delta * 9.0)
		var e := block_amt * block_amt * (3.0 - 2.0 * block_amt)
		hand_left.position = HAND_L_POS.lerp(HAND_L_BLOCK_POS, e) + Vector3(-bob.x, bob.y, 0.0) * (1.0 - e)
		hand_left.rotation_degrees = Vector3(10.0, -14.0, 0.0).lerp(Vector3(0.0, 0.0, 0.0), e)

var current_chunk := Vector2i(-999, -999)
var dirty_chunks: Dictionary = {}
var chunk_build_queue: Array[Vector2i] = []
var chunk_build_queued: Dictionary = {}

const RENDER_DISTANCE := 3

func _update_chunks(force := false) -> void:
	if player == null:
		return

	var player_chunk := Vector2i(
		int(player.position.x) >> 4,
		int(player.position.z) >> 4
	)

	if player_chunk == current_chunk and not force:
		return

	current_chunk = player_chunk

	for cz in range(player_chunk.y - RENDER_DISTANCE - 2, player_chunk.y + RENDER_DISTANCE + 3):
		for cx in range(player_chunk.x - RENDER_DISTANCE - 2, player_chunk.x + RENDER_DISTANCE + 3):
			if cx < 0 or cx >= CW or cz < 0 or cz >= CW:
				continue
			var key := cx + cz * CW
			if chunks[key].is_empty():
				_gen_terrain(cx, cz)

	for cz in range(player_chunk.y - RENDER_DISTANCE - 1, player_chunk.y + RENDER_DISTANCE + 2):
		for cx in range(player_chunk.x - RENDER_DISTANCE - 1, player_chunk.x + RENDER_DISTANCE + 2):
			if cx < 0 or cx >= CW or cz < 0 or cz >= CW:
				continue
			var key := cx + cz * CW
			if not trees_generated[key]:
				_gen_trees_in_chunk(cx, cz)
				trees_generated[key] = true
			if not villages_generated[key]:
				_gen_village_in_chunk(cx, cz)
				villages_generated[key] = true

	for cz in range(player_chunk.y - RENDER_DISTANCE, player_chunk.y + RENDER_DISTANCE + 1):
		for cx in range(player_chunk.x - RENDER_DISTANCE, player_chunk.x + RENDER_DISTANCE + 1):
			if cx < 0 or cx >= CW or cz < 0 or cz >= CW:
				continue
			var key := cx + cz * CW
			if chunk_mi[key] == null:
				_queue_chunk_build(cx, cz)

	for key in range(chunk_mi.size()):
		var mi = chunk_mi[key]
		if mi != null:
			var cx := key % CW
			var cz := int(key / CW)
			if abs(cx - player_chunk.x) > RENDER_DISTANCE + 1 or abs(cz - player_chunk.y) > RENDER_DISTANCE + 1:
				mi.get_parent().queue_free()
				chunk_mi[key] = null
				chunk_cs[key] = null

func _physics_process(delta: float) -> void:
	if paused or not ready_done:
		return

	var is_crouching := Input.is_physical_key_pressed(KEY_SHIFT) or (control_mode == CONTROL_MODE_MOBILE and mobile_crouch_held)
	var is_sprinting := (Input.is_physical_key_pressed(KEY_CTRL) or (control_mode == CONTROL_MODE_MOBILE and mobile_sprint_held)) and not is_crouching

	var target_cam_y := 0.2 if is_crouching else 0.7
	camera.position.y = lerp(camera.position.y, target_cam_y, delta * 15.0)

	var dir := Vector3.ZERO
	if not inv_open:
		var b := player.global_transform.basis
		var move_x := float(int(Input.is_physical_key_pressed(KEY_D)) - int(Input.is_physical_key_pressed(KEY_A)))
		var move_z := float(int(Input.is_physical_key_pressed(KEY_S)) - int(Input.is_physical_key_pressed(KEY_W)))
		if control_mode == CONTROL_MODE_MOBILE:
			var mobile_vec := mobile_stick_vector if mobile_control_style == 1 else mobile_move_vec
			move_x += mobile_vec.x
			move_z += mobile_vec.y
		move_x = clampf(move_x, -1.0, 1.0)
		move_z = clampf(move_z, -1.0, 1.0)
		dir = b.x * move_x + b.z * move_z

	dir.y = 0
	dir = dir.normalized()

	if is_crouching and dir != Vector3.ZERO:
		var next_x := player.position.x + dir.x * 0.4
		var next_z := player.position.z + dir.z * 0.4
		var feet_y := player.position.y - 0.9 - 0.1
		if get_block(int(floor(next_x)), int(floor(feet_y)), int(floor(next_z))) == 0:
			dir = Vector3.ZERO

	var current_speed := SPEED
	if is_sprinting and dir != Vector3.ZERO:
		current_speed *= 1.5

	player.velocity.x = dir.x * current_speed
	player.velocity.z = dir.z * current_speed

	var jump_down := Input.is_physical_key_pressed(KEY_SPACE) or (control_mode == CONTROL_MODE_MOBILE and mobile_jump_held)
	if creative_mode and is_crouching:
		creative_flying = false
		player.velocity.y = -0.5
	elif creative_mode and jump_down and not jump_was_down and not inv_open:
		var now_ms := Time.get_ticks_msec()
		if now_ms - last_jump_msec <= 420:
			creative_flying = not creative_flying
		last_jump_msec = now_ms
		if not creative_flying and player.is_on_floor():
			player.velocity.y = JUMP_SPEED
	if creative_mode and creative_flying:
		player.velocity.y = JUMP_SPEED if jump_down else 0.0
	else:
		if not player.is_on_floor():
			player.velocity.y -= GRAVITY * delta
		elif jump_down and not jump_was_down and not inv_open and not is_crouching:
			player.velocity.y = JUMP_SPEED
		else:
			player.velocity.y = -0.5
	jump_was_down = jump_down

	player.move_and_slide()

	var h_speed := Vector2(player.velocity.x, player.velocity.z).length()
	if player.is_on_floor() and h_speed > 0.5:
		step_timer -= delta
		var step_interval := 0.3 if is_sprinting else 0.45
		if step_timer <= 0.0:
			step_timer = step_interval
			var feet_pos := player.position - Vector3(0, 0.95, 0)
			var block_below := get_block(int(floor(feet_pos.x)), int(floor(feet_pos.y)), int(floor(feet_pos.z)))
			if block_below == GRASS:
				step_player.pitch_scale = randf_range(0.9, 1.1)
				step_player.play()
	else:
		step_timer = 0.0
		if step_player.playing:
			step_player.stop()

	player.position.x = clampf(player.position.x, 1.0, WORLD_SIZE - 1.0)
	player.position.z = clampf(player.position.z, 1.0, WORLD_SIZE - 1.0)
	if player.position.y < -10:
		player.position = home_pos
		player.velocity = Vector3.ZERO
	if view_mode != 0:
		_apply_camera_mode()

	_update_chunks()
	mob_attack_cooldown = maxf(0.0, mob_attack_cooldown - delta)
	_update_breaking(delta)

func _queue_chunk_build(cx: int, cz: int) -> void:
	if cx < 0 or cx >= CW or cz < 0 or cz >= CW:
		return
	var key := cx + cz * CW
	if chunk_mi[key] != null:
		return
	if chunks[key].size() != CS * CS * WORLD_H:
		return
	if chunk_build_queued.has(key):
		return
	chunk_build_queued[key] = true
	chunk_build_queue.append(Vector2i(cx, cz))

func _process_chunk_build_queue() -> void:
	if player == null or chunk_build_queue.is_empty():
		return
	var player_cx := int(player.position.x) >> 4
	var player_cz := int(player.position.z) >> 4
	var best_index := -1
	var best_distance := 2147483647
	for i in range(chunk_build_queue.size()):
		var candidate: Vector2i = chunk_build_queue[i]
		var dx := candidate.x - player_cx
		var dz := candidate.y - player_cz
		var distance := dx * dx + dz * dz
		if distance < best_distance:
			best_distance = distance
			best_index = i
	if best_index == -1:
		return
	var selected_coord: Vector2i = chunk_build_queue[best_index]
	chunk_build_queue.remove_at(best_index)
	var key := selected_coord.x + selected_coord.y * CW
	chunk_build_queued.erase(key)
	if abs(selected_coord.x - player_cx) > RENDER_DISTANCE:
		return
	if abs(selected_coord.y - player_cz) > RENDER_DISTANCE:
		return
	if chunks[key].size() != CS * CS * WORLD_H:
		return
	if chunk_mi[key] == null:
		_build_chunk(selected_coord.x, selected_coord.y)

func _process(delta: float) -> void:
	if load_cam != null:
		_update_load_cam(delta)
	if not ready_done:
		return
	var had_dirty_chunks := not dirty_chunks.is_empty()
	_process_dirty_chunks()
	if not had_dirty_chunks:
		_process_chunk_build_queue()

	if inv_open:
		if creative_scroll_direction != 0 and creative_scroll != null and creative_mode:
			creative_scroll_repeat -= delta
			if creative_scroll_repeat <= 0.0:
				creative_scroll.scroll_vertical = maxi(0, creative_scroll.scroll_vertical + creative_scroll_direction * 18)
				creative_scroll_repeat = 0.035
		cursor_ui["btn"].position = get_viewport().get_mouse_position() - Vector2(24, 24)
		highlight.visible = false
		if not preview_char.is_empty():
			var vs := get_viewport().get_visible_rect().size
			var mx := clampf((get_viewport().get_mouse_position().x / vs.x - 0.5) * 2.0, -1.0, 1.0)
			var prv: Node3D = preview_char["root"]
			prv.rotation.y = PI + mx * 0.8
		_rmb_drag()
	else:
		var t := _target()
		if t.is_empty() or paused:
			highlight.visible = false
		else:
			var cell: Vector3i = t["cell"]
			highlight.visible = true
			highlight.position = Vector3(cell) + Vector3(0.5, 0.5, 0.5)
	_update_hand(delta)
	if not paused:
		_update_day_night(delta)
		_grow_crops(delta)
		_update_furnaces(delta)
	if msg_t > 0.0:
		msg_t -= delta
		if msg_t <= 0.0 and msg_label != null:
			msg_label.text = ""

# ---------------- посевы ----------------

func _crop_stage(c: Dictionary) -> int:
	return mini(2, int(float(c["t"]) / GROW_TIME))

func _spawn_crop_node(cell: Vector3i) -> void:
	var root := Node3D.new()
	root.position = Vector3(cell) + Vector3(0.5, 0.5, 0.5)
	for k in 2:
		var sp := Sprite3D.new()
		sp.texture = items_tex
		sp.region_enabled = true
		sp.pixel_size = 1.0 / 16.0
		sp.texture_filter = BaseMaterial3D.TEXTURE_FILTER_NEAREST
		sp.shaded = false
		sp.double_sided = true
		sp.alpha_cut = SpriteBase3D.ALPHA_CUT_DISCARD
		sp.rotation_degrees = Vector3(0, 45 + 90 * k, 0)
		root.add_child(sp)
	add_child(root)
	crop_nodes[cell] = root
	_update_crop_node(cell)

func _update_crop_node(cell: Vector3i) -> void:
	if not crop_nodes.has(cell) or not crops.has(cell):
		return
	var c: Dictionary = crops[cell]
	var tile := 16 + int(c["type"]) * 3 + _crop_stage(c)
	var root: Node3D = crop_nodes[cell]
	for ch in root.get_children():
		var sp := ch as Sprite3D
		sp.region_rect = Rect2(float(tile * 16), 0.0, 16.0, 16.0)

func _spawn_loaded_crops() -> void:
	for k in crops.keys():
		var cell: Vector3i = k
		if get_block(cell.x, cell.y - 1, cell.z) == FARMLAND and get_block(cell.x, cell.y, cell.z) == 0:
			_spawn_crop_node(cell)
		else:
			crops.erase(cell)

func _remove_crop(cell: Vector3i) -> void:
	crops.erase(cell)
	if crop_nodes.has(cell):
		var n: Node3D = crop_nodes[cell]
		n.queue_free()
		crop_nodes.erase(cell)

func _grow_crops(delta: float) -> void:
	grow_acc += delta
	if grow_acc < 1.0:
		return
	var dt := grow_acc
	grow_acc = 0.0
	for k in crops.keys():
		var cell: Vector3i = k
		var c: Dictionary = crops[cell]
		var before := _crop_stage(c)
		c["t"] = float(c["t"]) + dt
		if _crop_stage(c) != before:
			_update_crop_node(cell)

func _break_crop(cell: Vector3i) -> void:
	if not crops.has(cell):
		return
	var c: Dictionary = crops[cell]
	var ty: int = c["type"]
	if _crop_stage(c) >= 2:
		add_item(CROP_DROP[ty], randi_range(1, 2))
		add_item(CROP_SEED[ty], randi_range(1, 2))
	else:
		add_item(CROP_SEED[ty], 1)
	_remove_crop(cell)

func _use_hoe(t: Dictionary) -> void:
	var cell: Vector3i = t["cell"]
	var id: int = t["id"]
	if id != GRASS and id != DIRT:
		return
	if cell.y < 1:
		return
	if get_block(cell.x, cell.y + 1, cell.z) != 0:
		return
	_set_block(cell, FARMLAND)
	swing_phase = 0.001

func _plant_seed(t: Dictionary, s: Dictionary) -> void:
	var cell: Vector3i = t["cell"]
	var up := cell + Vector3i(0, 1, 0)
	if t["id"] != FARMLAND or t["place"] != up:
		return
	if get_block(up.x, up.y, up.z) != 0 or crops.has(up):
		return
	crops[up] = {"type": SEED_CROP[s["id"]], "t": 0.0}
	_spawn_crop_node(up)
	swing_phase = 0.001
	s["n"] -= 1
	if s["n"] <= 0:
		s["id"] = 0
		s["n"] = 0
	_refresh_slots()

# ---------------- двери ----------------

func _door_occupies(c: Vector3i) -> bool:
	return doors.has(c) or doors.has(c + Vector3i(0, -1, 0))

func _spawn_door_node(cell: Vector3i) -> void:
	var d: Dictionary = doors[cell]
	var root := Node3D.new()
	root.position = Vector3(cell) + Vector3(0.5, 0.0, 0.5)
	root.rotation_degrees = Vector3(0.0, float(int(d["dir"]) * 90), 0.0)
	var hinge := StaticBody3D.new()
	hinge.position = Vector3(-0.5, 0.0, 0.0)
	hinge.set_meta("door_cell", cell)
	hinge.rotation_degrees = Vector3(0.0, 90.0 if d["open"] else 0.0, 0.0)
	root.add_child(hinge)
	var cs := CollisionShape3D.new()
	var sh := BoxShape3D.new()
	sh.size = Vector3(1.0, 2.0, 0.16)
	cs.shape = sh
	cs.position = Vector3(0.5, 1.0, 0.0)
	hinge.add_child(cs)
	var wood := _color_mat(Color(0.62, 0.44, 0.24))
	var dark := _color_mat(Color(0.46, 0.31, 0.16))
	var iron := _color_mat(Color(0.7, 0.72, 0.76))
	_box(hinge, Vector3(1.0, 2.0, 0.16), Vector3(0.5, 1.0, 0.0), wood)
	for zs in [1.0, -1.0]:
		_box(hinge, Vector3(0.7, 0.8, 0.02), Vector3(0.5, 0.5, 0.085 * zs), dark)
		_box(hinge, Vector3(0.7, 0.8, 0.02), Vector3(0.5, 1.5, 0.085 * zs), dark)
	_box(hinge, Vector3(0.1, 0.1, 0.24), Vector3(0.82, 1.0, 0.0), iron)
	add_child(root)
	door_nodes[cell] = hinge

func _spawn_loaded_doors() -> void:
	for k in doors.keys():
		var cell: Vector3i = k
		if get_block(cell.x, cell.y, cell.z) == 0 and get_block(cell.x, cell.y + 1, cell.z) == 0:
			_spawn_door_node(cell)
		else:
			doors.erase(cell)

func _toggle_door(cell: Vector3i) -> void:
	if not doors.has(cell) or not door_nodes.has(cell):
		return
	var d: Dictionary = doors[cell]
	d["open"] = not bool(d["open"])
	var hinge: StaticBody3D = door_nodes[cell]
	var tw := create_tween()
	tw.tween_property(hinge, "rotation_degrees:y", 90.0 if d["open"] else 0.0, 0.18)

func _break_door(cell: Vector3i) -> void:
	if door_nodes.has(cell):
		var h: StaticBody3D = door_nodes[cell]
		var r := h.get_parent()
		r.queue_free()
		door_nodes.erase(cell)
	doors.erase(cell)
	add_item(DOOR, 1)

func _place_door(t: Dictionary, s: Dictionary) -> void:
	var cell: Vector3i = t["place"]
	var up := cell + Vector3i(0, 1, 0)
	if cell.y < 1 or up.y >= WORLD_H or cell.x < 0 or cell.z < 0 or cell.x >= WORLD_SIZE or cell.z >= WORLD_SIZE:
		return
	if get_block(cell.x, cell.y, cell.z) != 0 or get_block(up.x, up.y, up.z) != 0:
		return
	if get_block(cell.x, cell.y - 1, cell.z) == 0:
		return
	if _door_occupies(cell) or _door_occupies(up) or crops.has(cell):
		return
	if _overlaps_player(cell) or _overlaps_player(up):
		return
	var q := int(round(player.rotation.y / (PI / 2.0)))
	doors[cell] = {"dir": q & 3, "open": false}
	_spawn_door_node(cell)
	swing_phase = 0.001
	s["n"] -= 1
	if s["n"] <= 0:
		s["id"] = 0
		s["n"] = 0
	_refresh_slots()

# ---------------- ломание блоков ----------------

func _break_time(id: int) -> float:
	var t: float = HARDNESS.get(id, 1.0)
	var held: int = slots[selected]["id"]
	var mult := 1.0
	if id in [STONE, COAL, IRON, FURNACE, DIAMOND_ORE]:
		if held == PICKAXE:
			mult = 3.0
		elif held == S_PICKAXE:
			mult = 5.0
		elif held == I_PICKAXE:
			mult = 8.0
		elif held == D_PICKAXE:
			mult = 11.0
	elif id in [GRASS, DIRT, FARMLAND]:
		if held == SHOVEL:
			mult = 3.0
		elif held == S_SHOVEL:
			mult = 5.0
		elif held == I_SHOVEL:
			mult = 8.0
		elif held == D_SHOVEL:
			mult = 11.0
	elif id in [LOG, PLANKS, TABLE, DOOR, CHEST]:
		if held == AXE:
			mult = 3.0
		elif held == S_AXE:
			mult = 5.0
		elif held == I_AXE:
			mult = 8.0
		elif held == D_AXE:
			mult = 11.0
	elif id == LEAVES:
		if held == SWORD:
			mult = 3.0
		elif held == S_SWORD:
			mult = 5.0
		elif held == I_SWORD:
			mult = 8.0
		elif held == D_SWORD:
			mult = 11.0
	return t / mult

func _update_breaking(delta: float) -> void:
	var active := false
	if breaking and not inv_open and _try_attack_mob():
		breaking_active = true
		break_overlay.visible = false
		return
	if breaking and not inv_open:
		var t := _target()
		if not t.is_empty():
			var cell: Vector3i = t["cell"]
			var id: int = t["id"]
			if id != 0 and cell.y > 0:
				if cell != break_cell:
					break_cell = cell
					break_progress = 0.0
				active = true
				break_progress += delta / _break_time(id)
				if break_progress >= 1.0:
					_break_block_now(cell, id)
					break_progress = 0.0
					break_cell = Vector3i(-1, -1, -1)
	if not active:
		break_progress = 0.0
	breaking_active = active
	if active and break_progress > 0.0:
		var stage := clampi(int(break_progress * CRACK_STAGES), 0, CRACK_STAGES - 1)
		break_mat.albedo_texture = crack_tex[stage]
		break_overlay.position = Vector3(break_cell) + Vector3(0.5, 0.5, 0.5)
		break_overlay.visible = true
	else:
		break_overlay.visible = false

func _break_block_now(cell: Vector3i, id: int) -> void:
	if id == DOOR:
		_break_door(cell)
		return
	if id == FARMLAND:
		var up := cell + Vector3i(0, 1, 0)
		if crops.has(up):
			_break_crop(up)
			return
	if id == GRASS and randf() < SEED_CHANCE:
		add_item(CROP_SEED[randi() % 3], 1)

	if id == CHEST:
		var group := _get_chest_group(cell)
		var origin: Vector3i = group["origin"]
		var inv := _get_chest_inventory(origin, bool(group["double"]))
		for item in inv:
			if item["id"] != 0:
				add_item(item["id"], item["n"])
		chests.erase(origin)
		add_item(CHEST, 1)
		_set_block(cell, 0)
		return

	if id == FURNACE and furnaces.has(cell):
		var fd: Dictionary = furnaces[cell]
		for key in ["input", "fuel", "output"]:
			var it: Dictionary = fd[key]
			if it["id"] != 0:
				add_item(it["id"], it["n"])
		furnaces.erase(cell)

	if id == COAL:
		add_item(COAL_ITEM, randi_range(1, 2))
	elif id == DIAMOND_ORE:
		add_item(DIAMOND, 1)
	elif id == IRON:
		add_item(RAW_IRON, 1)
	else:
		add_item(DIRT if (id == GRASS or id == FARMLAND) else id, 1)
	_set_block(cell, 0)

func add_item(id: int, n: int = 1) -> int:
	var left := _store_items(slots, id, n)
	_refresh_slots()
	return left

func _store_items(arr: Array, id: int, n: int) -> int:
	for i in TOTAL_SLOTS:
		var s: Dictionary = arr[i]
		if s["id"] == id and s["n"] < MAX_STACK and n > 0:
			var add: int = mini(n, MAX_STACK - int(s["n"]))
			s["n"] += add
			n -= add
	for i in TOTAL_SLOTS:
		var s: Dictionary = arr[i]
		if s["id"] == 0 and n > 0:
			var add: int = mini(n, MAX_STACK)
			s["id"] = id
			s["n"] = add
			n -= add
	return n

# ---------------- ввод ----------------

func _unhandled_input(event: InputEvent) -> void:
	if not ready_done:
		return

	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT and not event.pressed:
		breaking = false
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_RIGHT and not event.pressed:
		blocking = false

	if event is InputEventKey and event.pressed and not event.echo:
		if chat_open:
			if event.keycode == KEY_ESCAPE:
				_close_chat()
			return
		if event.keycode == KEY_T and not paused and not inv_open:
			_open_chat()
			return
		if event.keycode == KEY_ESCAPE:
			if control_mode == CONTROL_MODE_MOBILE and (chest_layer.visible or furnace_layer.visible or inv_open):
				return
			if chest_layer.visible:
				_close_chest()
			elif furnace_layer.visible:
				_close_furnace()
			elif inv_open:
				_close_inventory()
			else:
				_set_paused(not paused)
			return

		if event.physical_keycode == KEY_E and not paused:
			if control_mode == CONTROL_MODE_MOBILE:
				return
			if chest_layer.visible:
				_close_chest()
			elif furnace_layer.visible:
				_close_furnace()
			elif inv_open:
				_close_inventory()
			else:
				_open_inventory(false)
			return

		if event.physical_keycode == KEY_K and not paused and not inv_open:
			take_damage(4.0)
			return

		if (event.keycode == KEY_F5 or event.physical_keycode == KEY_V) and not paused and not inv_open:
			view_mode = (view_mode + 1) % 3
			_apply_camera_mode()
			return

	if paused or inv_open or chat_open:
		return

	if control_mode == CONTROL_MODE_MOBILE:
		if event is InputEventScreenTouch:
			if event.pressed and mobile_look_touch_id == -1:
				mobile_look_touch_id = event.index
				mobile_look_last_pos = event.position
			elif not event.pressed and event.index == mobile_look_touch_id:
				mobile_look_touch_id = -1
		elif event is InputEventScreenDrag and event.index == mobile_look_touch_id:
			var delta_pos : Vector2 = event.position - mobile_look_last_pos
			mobile_look_last_pos = event.position
			player.rotate_y(-delta_pos.x * MOUSE_SENS * 1.4)
			pitch = clamp(pitch - delta_pos.y * MOUSE_SENS * 1.4, -1.5, 1.5)
			aim_pivot.rotation.x = pitch
			_apply_camera_mode()
		elif event is InputEventMouseMotion and Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT) and mobile_look_touch_id == -1:
			player.rotate_y(-event.relative.x * MOUSE_SENS * 1.4)
			pitch = clamp(pitch - event.relative.y * MOUSE_SENS * 1.4, -1.5, 1.5)
			aim_pivot.rotation.x = pitch
			_apply_camera_mode()
		return

	if event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
		player.rotate_y(-event.relative.x * MOUSE_SENS)
		pitch = clamp(pitch - event.relative.y * MOUSE_SENS, -1.5, 1.5)
		aim_pivot.rotation.x = pitch
		_apply_camera_mode()

	elif event is InputEventMouseButton and event.pressed:
		if Input.mouse_mode != Input.MOUSE_MODE_CAPTURED:
			Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
			return
		match event.button_index:
			MOUSE_BUTTON_LEFT:
				breaking = true
			MOUSE_BUTTON_RIGHT:
				if _eat_selected_food():
					return
				if _can_block():
					blocking = true
				else:
					_use_or_place()
			MOUSE_BUTTON_WHEEL_UP:
				selected = (selected + HOTBAR - 1) % HOTBAR
				_refresh_slots()
			MOUSE_BUTTON_WHEEL_DOWN:
				selected = (selected + 1) % HOTBAR
				_refresh_slots()

	elif event is InputEventKey and event.pressed and not event.echo:
		var k: int = event.physical_keycode - KEY_1
		if k >= 0 and k < HOTBAR:
			selected = k
			_refresh_slots()

func _mob_damage_for_selected_item() -> float:
	var held: int = slots[selected]["id"]
	if held == SWORD: return 1.0
	if held == S_SWORD: return 3.0
	if held == I_SWORD: return 4.0
	if held == D_SWORD: return 6.0
	return 1.0

func _try_attack_mob() -> bool:
	ray.force_raycast_update()
	if not ray.is_colliding():
		return false
	var hit: Object = ray.get_collider()
	var mob: Node = hit as Node
	while mob != null and not mob.has_method("receive_hit"):
		mob = mob.get_parent()
	if mob == null:
		return false
	if mob_attack_cooldown > 0.0:
		return true # Не добываем блок за мобом, пока идёт перезарядка удара.
	var accepted: bool = mob.receive_hit(_mob_damage_for_selected_item())
	if accepted:
		mob_attack_cooldown = 0.42
		swing_phase = 0.08
		return true
	# A rushing zombie is intentionally immune; still consume the swing.
	if mob.has_method("is_rushing") and mob.is_rushing():
		mob_attack_cooldown = 0.42
		return true
	return false

func _target() -> Dictionary:
	ray.force_raycast_update()
	if not ray.is_colliding():
		return {}
	var col := ray.get_collider()
	if col != null and col.has_meta("door_cell"):
		var dc: Vector3i = col.get_meta("door_cell")
		return {"cell": dc, "place": dc, "id": DOOR}
	var p := ray.get_collision_point()
	var n := ray.get_collision_normal()
	var cell := Vector3i((p - n * 0.01).floor())
	return {
		"cell": cell,
		"place": Vector3i((p + n * 0.01).floor()),
		"id": get_block(cell.x, cell.y, cell.z),
	}

func _overlaps_player(cell: Vector3i) -> bool:
	var p := player.position
	return p.x + 0.4 > cell.x and p.x - 0.4 < cell.x + 1 \
		and p.z + 0.4 > cell.z and p.z - 0.4 < cell.z + 1 \
		and p.y + 0.9 > cell.y and p.y - 0.9 < cell.y + 1

func _eat_selected_food() -> bool:
	var id: int = int(slots[selected]["id"])
	var heal := 0.0
	if id == ROTTEN_FLESH or id == COOKED_FLESH:
		heal = 2.0
	elif id == COOKED_PORK:
		heal = 8.0
	else:
		return false
	if health >= 20.0:
		_show_msg("Здоровье уже полное")
		return true
	health = minf(20.0, health + heal)
	slots[selected]["n"] -= 1
	if slots[selected]["n"] <= 0:
		slots[selected] = {"id": 0, "n": 0}
	_update_health_label()
	_refresh_slots()
	_show_msg("Восстановлено %.0f HP" % heal)
	return true

func _use_or_place() -> void:
	var hs: Dictionary = slots[selected]
	if ARMOR_SLOT_OF.has(int(hs["id"])):
		_equip_from(slots, selected)
		return
	var t := _target()
	if t.is_empty():
		return
	if t["id"] == DOOR:
		_toggle_door(t["cell"])
		swing_phase = 0.001
		return
	if t["id"] == TABLE:
		_open_inventory(true)
		return
	if t["id"] == CHEST:
		_open_chest(t["cell"])
		return
	if t["id"] == FURNACE:
		_open_furnace(t["cell"])
		return
	var s: Dictionary = slots[selected]
	var hid: int = s["id"]
	if hid == HOE or hid == S_HOE or hid == I_HOE or hid == D_HOE:
		_use_hoe(t)
		return
	if SEED_CROP.has(hid):
		_plant_seed(t, s)
		return
	if hid == DOOR:
		_place_door(t, s)
		return
	if hid == 0 or not TILES.has(hid):
		return
	var cell: Vector3i = t["place"]
	if cell.y < 1 or cell.y >= WORLD_H or cell.x < 0 or cell.z < 0 or cell.x >= WORLD_SIZE or cell.z >= WORLD_SIZE:
		return
	if get_block(cell.x, cell.y, cell.z) != 0 or _overlaps_player(cell) or _door_occupies(cell):
		return
	if crops.has(cell):
		_remove_crop(cell)
	_set_block(cell, hid)
	swing_phase = 0.001
	s["n"] -= 1
	if s["n"] <= 0:
		s["id"] = 0
		s["n"] = 0
	_refresh_slots()

# ---------------- щит и урон ----------------

func _can_block() -> bool:
	if armor[4]["id"] == 0:
		return false
	var hid: int = slots[selected]["id"]
	if hid != 0 and (TILES.has(hid) or hid == DOOR or hid == HOE or hid == S_HOE or hid == I_HOE or hid == D_HOE or SEED_CROP.has(hid) or ARMOR_SLOT_OF.has(hid)):
		return false
	var t := _target()
	if not t.is_empty() and (t["id"] == DOOR or t["id"] == TABLE or t["id"] == CHEST or t["id"] == FURNACE):
		return false
	return true

func _armor_points() -> int:
	var pts := 0
	for k in 5:
		var id: int = armor[k]["id"]
		if id == 0:
			continue
		var tier := _armor_tier(id)
		if tier == 3:
			pts += int(ARMOR_POINTS_DIAMOND[k])
		elif tier == 2:
			pts += int(ARMOR_POINTS_IRON[k])
		elif tier == 1:
			pts += int(ARMOR_POINTS_STONE[k])
		else:
			pts += int(ARMOR_POINTS[k])
	return pts

func take_damage(amount: float) -> bool:
	if blocking and armor[4]["id"] != 0:
		_show_msg("Урон заблокирован щитом!")
		return false
	var dmg := amount * (1.0 - minf(0.8, _armor_points() * 0.04))
	health = maxf(0.0, health - dmg)
	_show_msg("Урон: %.1f" % dmg)
	if health <= 0.0:
		health = 20.0
		player.position = home_pos
		player.velocity = Vector3.ZERO
		_show_msg("Вы погибли и возродились")
	_update_health_label()
	return true

func _show_msg(text: String) -> void:
	if msg_label == null:
		return
	msg_label.text = text
	msg_t = 1.6

func _update_health_label() -> void:
	if health_label == null:
		return
	health_label.text = "Здоровье: %d/20   Броня: %d" % [int(ceil(health)), _armor_points()]

# ---------------- инвентарь и крафт ----------------

func _open_inventory(table: bool) -> void:
	if chat_open:
		_close_chat()
	inv_open = true
	breaking = false
	blocking = false
	table_mode = table
	if mobile_hud != null:
		mobile_hud.visible = false
	inv_layer.visible = true
	close_x.set_mobile(control_mode == CONTROL_MODE_MOBILE)
	inv_title.text = ("Верстак" if table else ("Инвентарь — Креатив" if creative_mode else "Инвентарь")) + ("" if control_mode == CONTROL_MODE_MOBILE else "   (E / Esc: закрыть)")
	if creative_grid != null:
		creative_grid.visible = creative_mode and not table
	craft_title.text = "Крафт 3×3" if table else "Крафт 2×2"
	grid_small.visible = not table
	grid_big.visible = table
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	_refresh_all()

func _close_inventory() -> void:
	inv_open = false
	creative_scroll_direction = 0
	inv_layer.visible = false
	rmb_down = false
	rmb_visited.clear()
	_cancel_split_selection(true)
	last_inv_click_slot = -1
	last_inv_click_stack = {"id": 0, "n": 0}
	for i in 9:
		var s: Dictionary = craft_grid[i]
		if s["id"] != 0:
			add_item(s["id"], s["n"])
			craft_grid[i] = {"id": 0, "n": 0}
	if cursor_item["id"] != 0:
		add_item(cursor_item["id"], cursor_item["n"])
		cursor_item = {"id": 0, "n": 0}
	_refresh_all()
	_apply_control_mode()

func _click_slot(arr: Array, i: int) -> void:
	var s: Dictionary = arr[i]
	var c: Dictionary = cursor_item
	if c["id"] == 0:
		if s["id"] != 0:
			cursor_item = s.duplicate()
			arr[i] = {"id": 0, "n": 0}
	elif s["id"] == 0:
		arr[i] = c.duplicate()
		cursor_item = {"id": 0, "n": 0}
	elif s["id"] == c["id"]:
		var moved: int = mini(MAX_STACK - int(s["n"]), int(c["n"]))
		s["n"] += moved
		c["n"] -= moved
		if c["n"] <= 0:
			cursor_item = {"id": 0, "n": 0}
	else:
		arr[i] = c.duplicate()
		cursor_item = s.duplicate()
	_refresh_all()

func _on_slot_pressed(i: int) -> void:
	# Второй клик двойного нажатия нужен только для открытия действия «Разделить».
	if suppress_next_slot_click:
		suppress_next_slot_click = false
		return
	if split_mode:
		_split_one_to_slot(i)
		return
	if split_button != null and split_button.visible:
		_cancel_split_selection(true)
	_click_slot(slots, i)

func _on_craft_slot(i: int) -> void:
	_click_slot(craft_grid, i)

func _on_armor_slot(k: int) -> void:
	var s: Dictionary = armor[k]
	var c: Dictionary = cursor_item
	if c["id"] == 0:
		if s["id"] != 0:
			cursor_item = s.duplicate()
			armor[k] = {"id": 0, "n": 0}
	elif int(ARMOR_SLOT_OF.get(int(c["id"]), -1)) == k:
		if s["id"] == 0:
			armor[k] = {"id": c["id"], "n": 1}
			c["n"] -= 1
			if c["n"] <= 0:
				cursor_item = {"id": 0, "n": 0}
		elif int(c["n"]) == 1:
			var old: Dictionary = s.duplicate()
			armor[k] = {"id": c["id"], "n": 1}
			cursor_item = old
	_refresh_all()

func _place_one(arr: Array, i: int) -> void:
	var c: Dictionary = cursor_item
	if c["id"] == 0:
		return
	var s: Dictionary = arr[i]
	if s["id"] == 0:
		arr[i] = {"id": c["id"], "n": 1}
	elif s["id"] == c["id"] and int(s["n"]) < MAX_STACK:
		s["n"] += 1
	else:
		return
	c["n"] -= 1
	if c["n"] <= 0:
		cursor_item = {"id": 0, "n": 0}
	_refresh_all()

func _rmb_try(kind: String, i: int) -> void:
	var key := kind + str(i)
	if rmb_visited.has(key):
		return
	rmb_visited[key] = true
	var arr: Array = slots
	if kind == "c":
		arr = craft_grid
	elif kind == "k":
		arr = _get_chest_inventory(chest_ui_cell, chest_is_double)
	_place_one(arr, i)

func _slot_gui_input(event: InputEvent, kind: String, i: int) -> void:
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT and event.pressed:
		if kind == "s" and inv_open and not split_mode:
			if _track_inventory_double_click(i, event.double_click):
				suppress_next_slot_click = true
				_open_split_action(i)
				return
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_RIGHT and event.pressed:
		if cursor_item["id"] == 0 and kind == "s":
			if _equip_from(slots, i):
				return
		rmb_down = true
		rmb_visited.clear()
		_rmb_try(kind, i)

func _track_inventory_double_click(slot_index: int, native_double_click: bool) -> bool:
	var now := Time.get_ticks_msec()
	var same_slot := last_inv_click_slot == slot_index
	var within_time := same_slot and now - last_inv_click_time_msec <= 420
	var is_double := same_slot and (native_double_click or within_time)
	if is_double:
		var current: Dictionary = slots[slot_index]
		var previous_id := int(last_inv_click_stack.get("id", 0))
		var previous_count := int(last_inv_click_stack.get("n", 0))
		var restored_from_cursor := false
		if current["id"] == 0 and previous_id != 0 \
				and int(cursor_item["id"]) == previous_id \
				and int(cursor_item["n"]) == previous_count:
			slots[slot_index] = cursor_item.duplicate()
			cursor_item = {"id": 0, "n": 0}
			restored_from_cursor = true
		var restored: Dictionary = slots[slot_index]
		var valid_stack := int(restored["id"]) != 0 and int(restored["n"]) > 1
		last_inv_click_slot = -1
		last_inv_click_stack = {"id": 0, "n": 0}
		if valid_stack and (restored_from_cursor or cursor_item["id"] == 0):
			_refresh_all()
			return true
		return false
	last_inv_click_slot = slot_index
	last_inv_click_time_msec = now
	var stack: Dictionary = slots[slot_index]
	last_inv_click_stack = stack.duplicate() if cursor_item["id"] == 0 and int(stack["id"]) != 0 and int(stack["n"]) > 1 else {"id": 0, "n": 0}
	return false

func _open_split_action(slot_index: int) -> void:
	if split_button == null:
		return
	split_source_slot = slot_index
	split_mode = false
	split_button.text = "Разделить 1 предмет"
	split_button.disabled = false
	split_button.visible = true
	_refresh_all()

func _on_split_button_pressed() -> void:
	if split_button == null:
		return
	if split_mode:
		_cancel_split_selection(true)
		return
	if split_source_slot < 0 or split_source_slot >= TOTAL_SLOTS:
		_cancel_split_selection(true)
		return
	var source: Dictionary = slots[split_source_slot]
	if int(source["id"]) == 0 or int(source["n"]) < 2:
		_cancel_split_selection(true)
		return
	split_mode = true
	split_button.text = "Выберите слот… (Отмена)"

func _split_one_to_slot(target_index: int) -> void:
	if split_source_slot < 0 or split_source_slot >= TOTAL_SLOTS:
		_cancel_split_selection(true)
		return
	if target_index == split_source_slot:
		return
	var source: Dictionary = slots[split_source_slot]
	var target: Dictionary = slots[target_index]
	var item_id := int(source["id"])
	if item_id == 0 or int(source["n"]) < 2:
		_cancel_split_selection(true)
		_refresh_all()
		return
	if int(target["id"]) == 0:
		slots[target_index] = {"id": item_id, "n": 1}
	elif int(target["id"]) == item_id and int(target["n"]) < MAX_STACK:
		target["n"] = int(target["n"]) + 1
	else:
		split_button.text = "Слот занят — выберите другой"
		return
	source["n"] = int(source["n"]) - 1
	if int(source["n"]) <= 0:
		slots[split_source_slot] = {"id": 0, "n": 0}
	_cancel_split_selection(true)
	_refresh_all()

func _cancel_split_selection(hide_button: bool) -> void:
	split_mode = false
	split_source_slot = -1
	if split_button != null:
		split_button.text = "Разделить 1 предмет"
		if hide_button:
			split_button.visible = false

func _rmb_check(ui: Dictionary, kind: String, i: int, mp: Vector2) -> void:
	var b: Button = ui["btn"]
	if b.is_visible_in_tree() and b.get_global_rect().has_point(mp):
		_rmb_try(kind, i)

func _rmb_drag() -> void:
	if not rmb_down:
		return
	if not Input.is_mouse_button_pressed(MOUSE_BUTTON_RIGHT):
		rmb_down = false
		rmb_visited.clear()
		return
	var mp := get_viewport().get_mouse_position()
	if furnace_layer.visible:
		for i in range(HOTBAR, TOTAL_SLOTS):
			_rmb_check(furnace_inv_ui[i - HOTBAR], "s", i, mp)
		for i in HOTBAR:
			_rmb_check(furnace_hot_ui[i], "s", i, mp)
	elif chest_layer.visible:
		var n := 54 if chest_is_double else 27
		for i in n:
			_rmb_check(chest_slots_ui[i], "k", i, mp)
		for i in range(HOTBAR, TOTAL_SLOTS):
			_rmb_check(chest_inv_ui[i - HOTBAR], "s", i, mp)
		for i in HOTBAR:
			_rmb_check(chest_hot_ui[i], "s", i, mp)
	else:
		for j in 4:
			_rmb_check(craft_small_ui[j], "c", SMALL_MAP[j], mp)
		for i in 9:
			_rmb_check(craft_big_ui[i], "c", i, mp)
		for i in TOTAL_SLOTS:
			_rmb_check(inv_ui[i], "s", i, mp)

func _match_recipe() -> Dictionary:
	var size := 3 if table_mode else 2
	var minr := 99
	var maxr := -1
	var minc := 99
	var maxc := -1
	for r in size:
		for c in size:
			if craft_grid[r * 3 + c]["id"] != 0:
				minr = mini(minr, r)
				maxr = maxi(maxr, r)
				minc = mini(minc, c)
				maxc = maxi(maxc, c)
	if maxr < 0:
		return {}
	var h := maxr - minr + 1
	var w := maxc - minc + 1
	for rec in RECIPES:
		if rec["table"] and not table_mode:
			continue
		var p: Array = rec["pattern"]
		var row0: Array = p[0]
		if p.size() != h or row0.size() != w:
			continue
		var ok := true
		for r in h:
			var prow: Array = p[r]
			for c in w:
				var have: int = craft_grid[(minr + r) * 3 + minc + c]["id"]
				if int(prow[c]) != have:
					ok = false
		if ok:
			return rec
	return {}

func _update_craft_output() -> void:
	craft_recipe = _match_recipe()
	if craft_recipe.is_empty():
		_show_item(craft_out_ui, {"id": 0, "n": 0})
	else:
		var out: Array = craft_recipe["out"]
		_show_item(craft_out_ui, {"id": out[0], "n": out[1]})

func _take_output() -> void:
	if craft_recipe.is_empty():
		return
	var out: Array = craft_recipe["out"]
	var oid: int = out[0]
	var on: int = out[1]
	if cursor_item["id"] == 0:
		cursor_item = {"id": oid, "n": on}
	elif cursor_item["id"] == oid and int(cursor_item["n"]) + on <= MAX_STACK:
		cursor_item["n"] += on
	else:
		return
	for i in 9:
		var s: Dictionary = craft_grid[i]
		if s["id"] != 0:
			s["n"] -= 1
			if s["n"] <= 0:
				craft_grid[i] = {"id": 0, "n": 0}
	_refresh_all()

func _icon_for(id: int) -> Texture2D:
	if not icon_cache.has(id):
		var t := AtlasTexture.new()
		if ITEM_ICON.has(id):
			t.atlas = items_tex
			t.region = Rect2(float(int(ITEM_ICON[id]) * 16), 0.0, 16.0, 16.0)
		elif ITEM2_ICON.has(id):
			t.atlas = items2_tex
			t.region = Rect2(float(int(ITEM2_ICON[id]) * 16), 0.0, 16.0, 16.0)
		else:
			t.atlas = atlas_tex
			var tile_index: int = int(ICON_TILE.get(id, 0))
			t.region = Rect2(float(tile_index * 16), 0.0, 16.0, 16.0)
		icon_cache[id] = t
	return icon_cache[id]

func _show_item(ui: Dictionary, s: Dictionary) -> void:
	var icon: TextureRect = ui["icon"]
	var cnt: Label = ui["count"]
	if s["id"] == 0:
		icon.texture = null
		cnt.text = ""
	else:
		icon.texture = _icon_for(s["id"])
		cnt.text = str(s["n"]) if s["n"] > 1 else ""

func _armor_tier(id: int) -> int:
	if id >= D_HELMET and id <= D_SHIELD:
		return 3
	if id >= I_HELMET and id <= I_BOOTS:
		return 2
	if id >= S_HELMET and id <= S_SHIELD:
		return 1
	return 0

func _refresh_slots() -> void:
	if hot_ui.is_empty() or inv_ui.is_empty() or cursor_ui.is_empty() or craft_out_ui.is_empty() or armor_ui.is_empty():
		return
	for i in TOTAL_SLOTS:
		_show_item(inv_ui[i], slots[i])
	for j in 4:
		_show_item(craft_small_ui[j], craft_grid[SMALL_MAP[j]])
	for i in 9:
		_show_item(craft_big_ui[i], craft_grid[i])
	for k in 5:
		var aui: Dictionary = armor_ui[k]
		_show_item(aui, armor[k])
		var aicon: TextureRect = aui["icon"]
		if armor[k]["id"] == 0:
			aicon.texture = _icon_for(ARMOR_SLOT_IDS[k])
			aicon.modulate = Color(1, 1, 1, 0.22)
		else:
			aicon.modulate = Color(1, 1, 1, 1)
	armor_label.text = "Броня: %d" % _armor_points()
	_update_health_label()
	_update_char_gear()
	_update_craft_output()
	for i in HOTBAR:
		var ui: Dictionary = hot_ui[i]
		_show_item(ui, slots[i])
		ui["btn"].add_theme_stylebox_override("normal", _slot_style(i == selected))
	_show_item(cursor_ui, cursor_item)
	cursor_ui["btn"].visible = inv_open and cursor_item["id"] != 0
	var sid: int = slots[selected]["id"]
	if sid != held_id and hand_item != null:
		held_id = sid
		_rebuild_held(sid)

func _refresh_all() -> void:
	_refresh_slots()
	if chest_layer != null and chest_layer.visible:
		_refresh_chest_ui()
	if furnace_layer != null and furnace_layer.visible:
		_refresh_furnace_ui()

# ---------------- интерфейс ----------------

func _slot_style(sel: bool, light: bool = false) -> StyleBoxFlat:
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.3, 0.3, 0.36, 0.95) if light else Color(0.2, 0.2, 0.24, 0.9)
	sb.set_border_width_all(3)
	sb.border_color = Color(1, 0.85, 0.2) if sel else Color(0.45, 0.45, 0.5)
	sb.set_corner_radius_all(4)
	return sb

func _make_slot(size: float, clickable: bool) -> Dictionary:
	var b := Button.new()
	b.custom_minimum_size = Vector2(size, size)
	b.focus_mode = Control.FOCUS_NONE
	if not clickable:
		b.mouse_filter = Control.MOUSE_FILTER_IGNORE
	b.add_theme_stylebox_override("normal", _slot_style(false))
	b.add_theme_stylebox_override("hover", _slot_style(false, true))
	b.add_theme_stylebox_override("pressed", _slot_style(false, true))

	var icon := TextureRect.new()
	icon.mouse_filter = Control.MOUSE_FILTER_IGNORE
	icon.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	icon.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	icon.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	b.add_child(icon)
	icon.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	icon.offset_left = 8
	icon.offset_top = 8
	icon.offset_right = -8
	icon.offset_bottom = -8

	var cnt := Label.new()
	cnt.mouse_filter = Control.MOUSE_FILTER_IGNORE
	cnt.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	cnt.vertical_alignment = VERTICAL_ALIGNMENT_BOTTOM
	cnt.add_theme_font_size_override("font_size", 18)
	cnt.add_theme_color_override("font_outline_color", Color.BLACK)
	cnt.add_theme_constant_override("outline_size", 6)
	b.add_child(cnt)
	cnt.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	cnt.offset_right = -5
	cnt.offset_bottom = -2
	return {"btn": b, "icon": icon, "count": cnt}

func _on_hotbar_mobile_select(i: int) -> void:
	if control_mode != CONTROL_MODE_MOBILE or paused or inv_open:
		return
	selected = i
	_refresh_slots()

func _make_hud() -> void:
	var layer := CanvasLayer.new()
	hud_layer = layer
	layer.visible = false
	add_child(layer)
	var cross := Label.new()
	cross.text = "+"
	cross.mouse_filter = Control.MOUSE_FILTER_IGNORE
	cross.add_theme_font_size_override("font_size", 32)
	cross.set_anchors_preset(Control.PRESET_CENTER)
	layer.add_child(cross)

	var root := VBoxContainer.new()
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	layer.add_child(root)
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var spacer := Control.new()
	spacer.size_flags_vertical = Control.SIZE_EXPAND_FILL
	spacer.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(spacer)
	msg_label = Label.new()
	msg_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	msg_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	msg_label.add_theme_font_size_override("font_size", 22)
	msg_label.add_theme_color_override("font_outline_color", Color.BLACK)
	msg_label.add_theme_constant_override("outline_size", 6)
	root.add_child(msg_label)
	var cc := CenterContainer.new()
	cc.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(cc)
	var hb := HBoxContainer.new()
	hb.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hb.add_theme_constant_override("separation", 4)
	cc.add_child(hb)
	for i in HOTBAR:
		var s := _make_slot(56, true)
		s["btn"].pressed.connect(_on_hotbar_mobile_select.bind(i))
		hb.add_child(s["btn"])
		hot_ui.append(s)
	var gap := Control.new()
	gap.custom_minimum_size = Vector2(0, 14)
	gap.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(gap)
	health_label = Label.new()
	health_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	health_label.position = Vector2(16, 12)
	health_label.add_theme_font_size_override("font_size", 22)
	health_label.add_theme_color_override("font_outline_color", Color.BLACK)
	health_label.add_theme_constant_override("outline_size", 6)
	layer.add_child(health_label)

func _make_mobile_btn(text: String, size: Vector2) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = size
	b.focus_mode = Control.FOCUS_NONE
	b.add_theme_font_size_override("font_size", 22)
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.15, 0.15, 0.18, 0.65)
	sb.set_border_width_all(2)
	sb.border_color = Color(1, 1, 1, 0.45)
	sb.set_corner_radius_all(10)
	b.add_theme_stylebox_override("normal", sb)
	var sbp := sb.duplicate() as StyleBoxFlat
	sbp.bg_color = Color(0.35, 0.55, 0.85, 0.8)
	b.add_theme_stylebox_override("pressed", sbp)
	return b

func _make_mobile_hud() -> void:
	if hud_layer == null:
		return
	mobile_hud = Control.new()
	mobile_hud.name = "MobileHUD"
	mobile_hud.mouse_filter = Control.MOUSE_FILTER_IGNORE
	mobile_hud.visible = false
	hud_layer.add_child(mobile_hud)
	mobile_hud.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	var top_bar := HBoxContainer.new()
	top_bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
	top_bar.add_theme_constant_override("separation", 8)
	top_bar.set_anchors_preset(Control.PRESET_TOP_RIGHT)
	top_bar.offset_top = 14
	top_bar.offset_right = -16
	top_bar.offset_left = -360
	top_bar.offset_bottom = 64
	mobile_hud.add_child(top_bar)

	var btn_cam := _make_mobile_btn("Вид", Vector2(92, 48))
	btn_cam.pressed.connect(func():
		if not paused and not inv_open:
			view_mode = (view_mode + 1) % 3
			_apply_camera_mode()
	)
	top_bar.add_child(btn_cam)

	var btn_inv := _make_mobile_btn("Инв", Vector2(92, 48))
	btn_inv.pressed.connect(func():
		if not paused:
			if inv_open:
				_close_inventory()
			else:
				_open_inventory(false)
	)
	top_bar.add_child(btn_inv)

	var btn_pause := _make_mobile_btn("Пауза", Vector2(114, 48))
	btn_pause.pressed.connect(func():
		if not paused:
			_set_paused(true)
	)
	top_bar.add_child(btn_pause)

	var left_col := VBoxContainer.new()
	left_col.mouse_filter = Control.MOUSE_FILTER_IGNORE
	left_col.add_theme_constant_override("separation", 8)
	left_col.set_anchors_preset(Control.PRESET_BOTTOM_LEFT)
	left_col.offset_left = 24
	left_col.offset_bottom = -24
	left_col.offset_top = -256
	left_col.offset_right = 216
	mobile_hud.add_child(left_col)

	var btn_sprint := _make_mobile_btn("Бег", Vector2(186, 44))
	btn_sprint.button_down.connect(func(): mobile_sprint_held = true)
	btn_sprint.button_up.connect(func(): mobile_sprint_held = false)
	left_col.add_child(btn_sprint)

	var dpad := GridContainer.new()
	dpad.name = "DPadControls"
	dpad.mouse_filter = Control.MOUSE_FILTER_IGNORE
	dpad.columns = 3
	dpad.add_theme_constant_override("h_separation", 6)
	dpad.add_theme_constant_override("v_separation", 6)
	left_col.add_child(dpad)

	var empty1 := Control.new(); empty1.mouse_filter = Control.MOUSE_FILTER_IGNORE; dpad.add_child(empty1)
	var btn_w := _make_mobile_btn("W", Vector2(58, 58))
	btn_w.button_down.connect(_on_mobile_dir.bind("up", true))
	btn_w.button_up.connect(_on_mobile_dir.bind("up", false))
	dpad.add_child(btn_w)
	var empty2 := Control.new(); empty2.mouse_filter = Control.MOUSE_FILTER_IGNORE; dpad.add_child(empty2)

	var btn_a := _make_mobile_btn("A", Vector2(58, 58))
	btn_a.button_down.connect(_on_mobile_dir.bind("left", true))
	btn_a.button_up.connect(_on_mobile_dir.bind("left", false))
	dpad.add_child(btn_a)
	var btn_s := _make_mobile_btn("S", Vector2(58, 58))
	btn_s.button_down.connect(_on_mobile_dir.bind("down", true))
	btn_s.button_up.connect(_on_mobile_dir.bind("down", false))
	dpad.add_child(btn_s)
	var btn_d := _make_mobile_btn("D", Vector2(58, 58))
	btn_d.button_down.connect(_on_mobile_dir.bind("right", true))
	btn_d.button_up.connect(_on_mobile_dir.bind("right", false))
	dpad.add_child(btn_d)

	var virtual_stick := Control.new()
	virtual_stick.name = "VirtualStick"
	virtual_stick.custom_minimum_size = Vector2(170, 170)
	virtual_stick.set_anchors_preset(Control.PRESET_BOTTOM_LEFT)
	virtual_stick.offset_left = 28
	virtual_stick.offset_bottom = -24
	virtual_stick.offset_top = -194
	virtual_stick.offset_right = 198
	virtual_stick.visible = mobile_control_style == 1
	mobile_hud.add_child(virtual_stick)
	var stick_base := ColorRect.new()
	stick_base.color = Color(0.1, 0.1, 0.12, 0.45)
	stick_base.size = Vector2(150, 150)
	stick_base.position = Vector2(10, 10)
	stick_base.mouse_filter = Control.MOUSE_FILTER_STOP
	virtual_stick.add_child(stick_base)	
	stick_base.gui_input.connect(_on_virtual_stick_input)
	var stick_knob := ColorRect.new()
	stick_knob.color = Color(0.75, 0.8, 0.9, 0.75)
	stick_knob.size = Vector2(58, 58)
	stick_knob.position = Vector2(56, 56)
	stick_knob.mouse_filter = Control.MOUSE_FILTER_IGNORE
	stick_base.add_child(stick_knob)
	mobile_stick_base = stick_base
	mobile_stick_knob = stick_knob
	mobile_dpad = dpad
	mobile_virtual_stick = virtual_stick
	virtual_stick.visible = mobile_control_style == 1
	dpad.visible = mobile_control_style == 0

	var actions := VBoxContainer.new()
	actions.mouse_filter = Control.MOUSE_FILTER_IGNORE
	actions.add_theme_constant_override("separation", 8)
	actions.set_anchors_preset(Control.PRESET_BOTTOM_RIGHT)
	actions.offset_right = -24
	actions.offset_bottom = -24
	actions.offset_left = -194
	actions.offset_top = -280
	mobile_hud.add_child(actions)

	var btn_crouch := _make_mobile_btn("Присед", Vector2(160, 52))
	btn_crouch.button_down.connect(func(): mobile_crouch_held = true)
	btn_crouch.button_up.connect(func(): mobile_crouch_held = false)
	actions.add_child(btn_crouch)

	var btn_jump := _make_mobile_btn("Прыжок", Vector2(160, 52))
	btn_jump.button_down.connect(func(): mobile_jump_held = true)
	btn_jump.button_up.connect(func(): mobile_jump_held = false)
	actions.add_child(btn_jump)

	var btn_break := _make_mobile_btn("Ломать", Vector2(160, 52))
	btn_break.button_down.connect(func():
		mobile_break_held = true
		breaking = true
	)
	btn_break.button_up.connect(func():
		mobile_break_held = false
		breaking = false
	)
	actions.add_child(btn_break)

	var btn_place := _make_mobile_btn("Поставить", Vector2(160, 52))
	btn_place.pressed.connect(func():
		if not paused and not inv_open:
			if _eat_selected_food(): return
			if _can_block():
				blocking = not blocking
			else:
				_use_or_place()
	)
	actions.add_child(btn_place)

func _on_virtual_stick_input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		if event.pressed:
			mobile_stick_touch = event.index
			_update_virtual_stick(event.position)
		else:
			mobile_stick_touch = -1
			mobile_stick_vector = Vector2.ZERO
			if mobile_stick_knob != null: mobile_stick_knob.position = Vector2(56, 56)
	elif event is InputEventScreenDrag and event.index == mobile_stick_touch:
		_update_virtual_stick(event.position)

func _update_virtual_stick(screen_pos: Vector2) -> void:
	if mobile_stick_base == null: return
	var local := screen_pos
	var center := Vector2(75, 75)
	var v := local - center
	if v.length() > 48.0: v = v.normalized() * 48.0
	mobile_stick_vector = Vector2(v.x / 48.0, v.y / 48.0)
	if mobile_stick_knob != null: mobile_stick_knob.position = center + v - Vector2(29, 29)

func _on_mobile_dir(dir_key: String, pressed: bool) -> void:
	mobile_move_flags[dir_key] = pressed
	var x := float(int(mobile_move_flags["right"]) - int(mobile_move_flags["left"]))
	var y := float(int(mobile_move_flags["down"]) - int(mobile_move_flags["up"]))
	mobile_move_vec = Vector2(x, y)

func _make_inventory_ui() -> void:
	inv_layer = CanvasLayer.new()
	inv_layer.layer = 5
	inv_layer.visible = false
	add_child(inv_layer)

	var dim := ColorRect.new()
	dim.color = Color(0, 0, 0, 0.6)
	inv_layer.add_child(dim)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	var center := CenterContainer.new()
	inv_layer.add_child(center)
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	var panel := PanelContainer.new()
	center.add_child(panel)
	var margin := MarginContainer.new()
	for side in ["left", "right", "top", "bottom"]:
		margin.add_theme_constant_override("margin_" + side, 14)
	panel.add_child(margin)
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 6)
	margin.add_child(box)

	var header := HBoxContainer.new()
	box.add_child(header)
	inv_title = Label.new()
	inv_title.add_theme_font_size_override("font_size", 26)
	header.add_child(inv_title)
	close_x.attach_to_header(header, _close_inventory)

	var top_row := HBoxContainer.new()
	top_row.add_theme_constant_override("separation", 14)
	box.add_child(top_row)

	var acol := VBoxContainer.new()
	acol.add_theme_constant_override("separation", 3)
	top_row.add_child(acol)
	for k in 5:
		var s := _make_slot(46, true)
		s["btn"].tooltip_text = ARMOR_NAMES[k]
		s["btn"].pressed.connect(_on_armor_slot.bind(k))
		acol.add_child(s["btn"])
		armor_ui.append(s)

	var pv := SubViewportContainer.new()
	pv.stretch = true
	pv.custom_minimum_size = Vector2(170, 240)
	pv.mouse_filter = Control.MOUSE_FILTER_IGNORE
	top_row.add_child(pv)
	var vp := SubViewport.new()
	vp.own_world_3d = true
	vp.size = Vector2i(170, 240)
	vp.render_target_update_mode = SubViewport.UPDATE_WHEN_VISIBLE
	pv.add_child(vp)
	var env := Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.background_color = Color(0.09, 0.09, 0.12)
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(1, 1, 1)
	env.ambient_light_energy = 0.7
	var we := WorldEnvironment.new()
	we.environment = env
	vp.add_child(we)
	var light := DirectionalLight3D.new()
	light.rotation_degrees = Vector3(-30, 20, 0)
	vp.add_child(light)
	var pcam := Camera3D.new()
	pcam.position = Vector3(0, 0.95, 3.4)
	pcam.fov = 35.0
	vp.add_child(pcam)
	pcam.current = true
	preview_char = _build_character()
	var prv: Node3D = preview_char["root"]
	prv.rotation.y = PI
	vp.add_child(prv)
	chars.append(preview_char)

	var right := VBoxContainer.new()
	right.add_theme_constant_override("separation", 6)
	top_row.add_child(right)

	craft_title = Label.new()
	craft_title.add_theme_font_size_override("font_size", 20)
	right.add_child(craft_title)

	var craft_box := HBoxContainer.new()
	craft_box.add_theme_constant_override("separation", 12)
	right.add_child(craft_box)

	grid_small = GridContainer.new()
	grid_small.columns = 2
	grid_small.add_theme_constant_override("h_separation", 4)
	grid_small.add_theme_constant_override("v_separation", 4)
	craft_box.add_child(grid_small)
	for j in 4:
		var idx: int = SMALL_MAP[j]
		var s := _make_slot(46, true)
		s["btn"].pressed.connect(_on_craft_slot.bind(idx))
		s["btn"].gui_input.connect(_slot_gui_input.bind("c", idx))
		grid_small.add_child(s["btn"])
		craft_small_ui.append(s)

	grid_big = GridContainer.new()
	grid_big.columns = 3
	grid_big.add_theme_constant_override("h_separation", 4)
	grid_big.add_theme_constant_override("v_separation", 4)
	grid_big.visible = false
	craft_box.add_child(grid_big)
	for i in 9:
		var s := _make_slot(46, true)
		s["btn"].pressed.connect(_on_craft_slot.bind(i))
		s["btn"].gui_input.connect(_slot_gui_input.bind("c", i))
		grid_big.add_child(s["btn"])
		craft_big_ui.append(s)

	var arrow := Label.new()
	arrow.text = "→"
	arrow.add_theme_font_size_override("font_size", 36)
	craft_box.add_child(arrow)

	craft_out_ui = _make_slot(56, true)
	craft_out_ui["btn"].pressed.connect(_take_output)
	craft_box.add_child(craft_out_ui["btn"])

	armor_label = Label.new()
	armor_label.add_theme_font_size_override("font_size", 20)
	right.add_child(armor_label)

	var bl := Label.new()
	bl.text = "Рюкзак"
	bl.add_theme_font_size_override("font_size", 18)
	box.add_child(bl)

	inv_ui.resize(TOTAL_SLOTS)
	var grid := GridContainer.new()
	grid.columns = 5
	grid.add_theme_constant_override("h_separation", 6)
	grid.add_theme_constant_override("v_separation", 6)
	box.add_child(grid)
	for i in range(HOTBAR, TOTAL_SLOTS):
		var s := _make_slot(46, true)
		s["btn"].pressed.connect(_on_slot_pressed.bind(i))
		s["btn"].gui_input.connect(_slot_gui_input.bind("s", i))
		grid.add_child(s["btn"])
		inv_ui[i] = s

	var hl := Label.new()
	hl.text = "Быстрые слоты"
	hl.add_theme_font_size_override("font_size", 18)
	box.add_child(hl)

	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 6)
	box.add_child(row)
	for i in HOTBAR:
		var s := _make_slot(46, true)
		s["btn"].pressed.connect(_on_slot_pressed.bind(i))
		s["btn"].gui_input.connect(_slot_gui_input.bind("s", i))
		row.add_child(s["btn"])
		inv_ui[i] = s

	split_button = Button.new()
	split_button.text = "Разделить 1 предмет"
	split_button.custom_minimum_size = Vector2(210, 42)
	split_button.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	split_button.focus_mode = Control.FOCUS_NONE
	split_button.add_theme_font_size_override("font_size", 18)
	split_button.visible = false
	split_button.pressed.connect(_on_split_button_pressed)
	box.add_child(split_button)

	var creative_title := Label.new()
	creative_title.text = "Креатив: каталог предметов (бесконечно)"
	creative_title.add_theme_font_size_override("font_size", 18)
	box.add_child(creative_title)
	var creative_catalog_row := HBoxContainer.new()
	creative_catalog_row.add_theme_constant_override("separation", 6)
	box.add_child(creative_catalog_row)
	creative_scroll = ScrollContainer.new()
	creative_scroll.custom_minimum_size = Vector2(0, 190)
	creative_scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	creative_scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	creative_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	creative_catalog_row.add_child(creative_scroll)
	creative_grid = GridContainer.new()
	creative_grid.columns = 6
	creative_grid.add_theme_constant_override("h_separation", 4)
	creative_grid.add_theme_constant_override("v_separation", 4)
	creative_scroll.add_child(creative_grid)
	var creative_arrows := VBoxContainer.new()
	creative_arrows.add_theme_constant_override("separation", 8)
	creative_catalog_row.add_child(creative_arrows)
	var creative_up_button := Button.new()
	creative_up_button.text = "▲"
	creative_up_button.custom_minimum_size = Vector2(48, 64)
	creative_up_button.focus_mode = Control.FOCUS_NONE
	creative_up_button.button_down.connect(_set_creative_scroll_direction.bind(-1))
	creative_up_button.button_up.connect(_set_creative_scroll_direction.bind(0))	
	creative_arrows.add_child(creative_up_button)
	var creative_down_button := Button.new()
	creative_down_button.text = "▼"
	creative_down_button.custom_minimum_size = Vector2(48, 64)
	creative_down_button.focus_mode = Control.FOCUS_NONE
	creative_down_button.button_down.connect(_set_creative_scroll_direction.bind(1))
	creative_down_button.button_up.connect(_set_creative_scroll_direction.bind(0))
	creative_arrows.add_child(creative_down_button)
	for item_id in range(1, 72):
		var item_btn := Button.new()
		item_btn.custom_minimum_size = Vector2(58, 54)
		item_btn.tooltip_text = _item_name(item_id)
		var icon_rect := TextureRect.new()
		icon_rect.texture = _icon_for(item_id)
		icon_rect.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		icon_rect.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		icon_rect.custom_minimum_size = Vector2(28, 28)
		item_btn.add_child(icon_rect)
		item_btn.pressed.connect(_creative_give_item.bind(item_id))
		creative_grid.add_child(item_btn)
	creative_title.visible = creative_mode
	creative_grid.visible = creative_mode

func _make_cursor_ui() -> void:
	var layer := CanvasLayer.new()
	layer.layer = 20
	add_child(layer)
	cursor_ui = _make_slot(48, false)
	cursor_ui["btn"].add_theme_stylebox_override("normal", StyleBoxEmpty.new())
	cursor_ui["btn"].visible = false
	layer.add_child(cursor_ui["btn"])

# ---------------- загрузка мира: камера летает над миром ----------------

func _make_loading_cam() -> void:
	load_cam = Camera3D.new()
	add_child(load_cam)
	load_cam.current = true
	_update_load_cam(0.0)

func _update_load_cam(delta: float) -> void:
	load_t += delta
	var c := Vector3(WORLD_SIZE / 2.0, 0.0, WORLD_SIZE / 2.0)
	var a := load_t * 0.16
	var r := 46.0 + sin(load_t * 0.3) * 14.0
	var pos := c + Vector3(cos(a) * r, 44.0 + sin(load_t * 0.5) * 6.0, sin(a) * r)
	load_cam.position = pos
	load_cam.look_at(pos + Vector3(-sin(a), -0.35, cos(a)) * 10.0)

func _make_loading_ui() -> void:
	loading_layer = CanvasLayer.new()
	loading_layer.layer = 100
	add_child(loading_layer)

	var shade := ColorRect.new()
	shade.color = Color(0, 0, 0, 0.18)
	shade.mouse_filter = Control.MOUSE_FILTER_IGNORE
	loading_layer.add_child(shade)
	shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 8)
	loading_layer.add_child(vb)
	vb.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	var top := Control.new()
	top.custom_minimum_size = Vector2(0, 24)
	vb.add_child(top)

	var logo := TextureRect.new()
	logo.texture = load("res://darecraft_logo_clean.svg")
	logo.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	logo.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	logo.custom_minimum_size = Vector2(380, 157)
	logo.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	vb.add_child(logo)

	var credit := Label.new()
	credit.text = "MADE WITH CLAUDE AND DANYIL"
	credit.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	credit.add_theme_font_size_override("font_size", 20)
	credit.add_theme_color_override("font_outline_color", Color(0.1, 0.2, 0.1))
	credit.add_theme_constant_override("outline_size", 6)
	vb.add_child(credit)

	var spacer := Control.new()
	spacer.size_flags_vertical = Control.SIZE_EXPAND_FILL
	spacer.mouse_filter = Control.MOUSE_FILTER_IGNORE
	vb.add_child(spacer)

	var cc := CenterContainer.new()
	vb.add_child(cc)
	var panel := PanelContainer.new()
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.1, 0.1, 0.13, 0.9)
	sb.set_border_width_all(3)
	sb.border_color = Color(0.5, 0.5, 0.55)
	sb.set_corner_radius_all(6)
	sb.set_content_margin_all(20)
	panel.add_theme_stylebox_override("panel", sb)
	cc.add_child(panel)

	var pv := VBoxContainer.new()
	pv.add_theme_constant_override("separation", 14)
	panel.add_child(pv)

	loading_label = Label.new()
	loading_label.text = "Генерация мира..."
	loading_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	loading_label.add_theme_font_size_override("font_size", 28)
	pv.add_child(loading_label)

	var tip := Label.new()
	tip.text = LOAD_TIPS[randi() % LOAD_TIPS.size()]
	tip.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	tip.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	tip.custom_minimum_size = Vector2(560, 0)
	tip.add_theme_font_size_override("font_size", 20)
	tip.add_theme_color_override("font_color", Color(0.8, 0.85, 0.9))
	pv.add_child(tip)

	loading_bar = ProgressBar.new()
	loading_bar.custom_minimum_size = Vector2(560, 18)
	loading_bar.show_percentage = false
	loading_bar.min_value = 0.0
	loading_bar.max_value = 100.0
	loading_bar.value = 0.0
	var fill := StyleBoxFlat.new()
	fill.bg_color = Color(0.4, 0.8, 0.25)
	var back := StyleBoxFlat.new()
	back.bg_color = Color(0.22, 0.22, 0.26)
	loading_bar.add_theme_stylebox_override("fill", fill)
	loading_bar.add_theme_stylebox_override("background", back)
	pv.add_child(loading_bar)

	var bottom := Control.new()
	bottom.custom_minimum_size = Vector2(0, 40)
	bottom.mouse_filter = Control.MOUSE_FILTER_IGNORE
	vb.add_child(bottom)

# ---------------- пауза ----------------

func _set_paused(value: bool) -> void:
	if value and chat_open:
		_close_chat()
	paused = value
	breaking = false
	blocking = false
	break_overlay.visible = false
	pause_layer.visible = paused
	if paused:
		_save_world()
		_reset_mobile_inputs()
		if mobile_hud != null:
			mobile_hud.visible = false
		Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	else:
		_apply_control_mode()

func _set_creative_mode(enabled: bool) -> void:
	creative_mode = enabled
	if enabled:
		creative_flying = false
		for mob in zombie_nodes:
			if is_instance_valid(mob): mob.queue_free()
		zombie_nodes.clear()
	if creative_grid != null:
		creative_grid.visible = enabled and inv_open
	if inv_open and inv_title != null:
		inv_title.text = "Инвентарь — Креатив" if enabled else "Инвентарь"
	_show_msg("Креатив включён" if enabled else "Креатив выключен")

func _item_name(item_id: int) -> String:
	var names := {
		1:"Трава", 2:"Земля", 3:"Камень", 4:"Бревно", 5:"Листва", 6:"Доски", 7:"Верстак", 8:"Угольная руда", 9:"Железная руда", 10:"Палка",
		11:"Деревянная кирка", 12:"Пашня", 13:"Деревянная лопата", 14:"Деревянный меч", 15:"Деревянный топор", 16:"Деревянная мотыга", 17:"Семена пшеницы", 18:"Семена картофеля", 19:"Семена свёклы", 20:"Пшеница", 21:"Картофель", 22:"Свёкла",
		23:"Шлем", 24:"Нагрудник", 25:"Поножи", 26:"Ботинки", 27:"Щит", 28:"Дверь", 29:"Печь", 30:"Каменная кирка", 31:"Каменная лопата", 32:"Каменный меч", 33:"Каменный топор", 34:"Каменная мотыга", 35:"Каменный шлем", 36:"Каменный нагрудник", 37:"Каменные поножи", 38:"Каменные ботинки", 39:"Каменный щит",
		40:"Уголь", 41:"Железный слиток", 42:"Железо", 43:"Сундук", 44:"Железная кирка", 45:"Железная лопата", 46:"Железный меч", 47:"Железный топор", 48:"Железная мотыга", 49:"Железный шлем", 50:"Железный нагрудник", 51:"Железные поножи", 52:"Железные ботинки", 53:"Сырая свинина", 54:"Жареная свинина", 55:"Гнилая плоть", 56:"Приготовленная плоть", 57:"Алмазная руда", 58:"Алмаз", 59:"Алмазная кирка", 60:"Алмазный меч", 61:"Алмазный топор", 62:"Алмазная лопата", 63:"Стекло", 64:"Рельсы", 65:"Вагонетка", 66:"Алмазная мотыга", 67:"Алмазный шлем", 68:"Алмазный нагрудник", 69:"Алмазные поножи", 70:"Алмазные ботинки", 71:"Алмазный щит"
	}
	return str(names.get(item_id, "Неизвестный предмет"))

func _set_creative_scroll_direction(direction: int) -> void:
	creative_scroll_direction = direction
	creative_scroll_repeat = 0.0

func _creative_give_item(item_id: int) -> void:
	if not creative_mode:
		return
	add_item(item_id, MAX_STACK)
	_refresh_slots()

func _make_chat_ui() -> void:
	chat_panel = PanelContainer.new()
	chat_panel.visible = false
	chat_panel.custom_minimum_size = Vector2(380, 250)
	chat_panel.set_anchors_preset(Control.PRESET_BOTTOM_LEFT)
	chat_panel.position = Vector2(14, -166)
	chat_panel.z_index = 80
	hud_layer.add_child(chat_panel)
	var column := VBoxContainer.new()
	chat_panel.add_child(column)
	var title := Label.new()
	title.text = "Чат DareCraft"
	column.add_child(title)
	chat_history = Label.new()
	chat_history.text = "Нажми T, чтобы открыть чат. Команды начинаются с /"
	chat_history.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	chat_history.custom_minimum_size = Vector2(340, 160)
	column.add_child(chat_history)
	chat_input = LineEdit.new()
	chat_input.placeholder_text = "Сообщение или /give ID [количество]"
	chat_input.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	chat_input.text_submitted.connect(_on_chat_submitted)
	column.add_child(chat_input)
	var send := Button.new()
	send.text = "Отправить"
	send.pressed.connect(func(): _on_chat_submitted(chat_input.text))
	column.add_child(send)
	var close_btn := Button.new()
	close_btn.text = "Закрыть чат"
	close_btn.pressed.connect(_close_chat)
	column.add_child(close_btn)
	var open_btn := Button.new()
	open_btn.text = "Чат"
	open_btn.position = Vector2(-94, 12)
	open_btn.set_anchors_preset(Control.PRESET_TOP_RIGHT)
	open_btn.custom_minimum_size = Vector2(82, 42)
	open_btn.z_index = 50
	open_btn.pressed.connect(_open_chat)
	hud_layer.add_child(open_btn)

func _open_chat() -> void:
	if paused or inv_open or chat_panel == null:
		return
	chat_open = true
	chat_panel.visible = true
	chat_input.grab_focus()
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE

func _close_chat() -> void:
	chat_open = false
	if chat_panel != null:
		chat_panel.visible = false
	if control_mode == CONTROL_MODE_PC and not paused and not inv_open:
		Input.mouse_mode = Input.MOUSE_MODE_CAPTURED

func _set_commands_enabled(enabled: bool) -> void:
	commands_enabled = enabled
	_save_world()
	_show_msg("Команды включены" if enabled else "Команды выключены")

func _on_chat_submitted(raw_text: String) -> void:
	var message := raw_text.strip_edges()
	chat_input.clear()
	if message.is_empty():
		return
	if message.begins_with("/"):
		_run_chat_command(message)
	else:
		chat_history.text = "Ты: " + message

func _run_chat_command(command_text: String) -> void:
	var parts := command_text.split(" ", false)
	var command := String(parts[0]).to_lower()
	if command == "/help":
		chat_history.text = "Команды: /give ID [количество], /ids. Читы включаются в настройках мира."
		return
	if command == "/ids":
		chat_history.text = "1 Трава · 2 Земля · 3 Камень · 4 Бревно · 5 Листва · 6 Доски · 7 Верстак · 8 Угольная руда · 9 Железная руда · 10 Палка\n11 Деревянная кирка · 12 Пашня · 13 Деревянная лопата · 14 Деревянный меч · 15 Деревянный топор · 16 Деревянная мотыга · 17 Семена пшеницы · 18 Семена картофеля · 19 Семена свёклы · 20 Пшеница · 21 Картофель · 22 Свёкла · 23 Шлем · 24 Нагрудник · 25 Поножи · 26 Ботинки · 27 Щит · 28 Дверь · 29 Печь · 30 Каменная кирка · 31 Каменная лопата · 32 Каменный меч · 33 Каменный топор · 34 Каменная мотыга · 35 Каменный шлем · 36 Каменный нагрудник · 37 Каменные поножи · 38 Каменные ботинки · 39 Каменный щит · 40 Уголь · 41 Железный слиток · 42 Железо · 43 Сундук · 44 Железная кирка · 45 Железная лопата · 46 Железный меч · 47 Железный топор · 48 Железная мотыга · 49 Железный шлем · 50 Железный нагрудник · 51 Железные поножи · 52 Железные ботинки · 53 Сырая свинина · 54 Жареная свинина · 55 Гнилая плоть · 56 Приготовленная плоть · 57 Алмазная руда · 58 Алмаз · 59 Алмазная кирка · 60 Алмазный меч · 61 Алмазный топор · 62 Алмазная лопата · 63 Стекло · 64 Рельсы · 65 Вагонетка · 66 Алмазная мотыга · 67 Алмазный шлем · 68 Алмазный нагрудник · 69 Алмазные поножи · 70 Алмазные ботинки · 71 Алмазный щит"
		return
	if command != "/give":
		chat_history.text = "Неизвестная команда. Используй /help"
		return
	if not commands_enabled:
		chat_history.text = "Команды отключены. Включи их в настройках мира."
		return
	if parts.size() < 2 or not String(parts[1]).is_valid_int():
		chat_history.text = "Использование: /give ID [количество]"
		return
	var item_id := int(parts[1])
	if item_id < 1 or item_id > 71:
		chat_history.text = "Нет предмета с ID %d. Допустимые ID: 1–71." % item_id
		return
	var amount := 1
	if parts.size() >= 3 and String(parts[2]).is_valid_int():
		amount = clampi(int(parts[2]), 1, 64)
	add_item(item_id, amount)
	_refresh_slots()
	chat_history.text = "Выдано: %s (ID %d) × %d" % [_item_name(item_id), item_id, amount]

func _set_mobile_control_style(style: int) -> void:
	mobile_control_style = clampi(style, 0, 1)
	var config := ConfigFile.new()
	config.load(CONTROL_SETTINGS_PATH)
	config.set_value("controls", "mobile_style", mobile_control_style)
	config.save(CONTROL_SETTINGS_PATH)
	if mobile_dpad != null: mobile_dpad.visible = mobile_control_style == 0
	if mobile_virtual_stick != null: mobile_virtual_stick.visible = mobile_control_style == 1

func _make_pause_menu() -> void:
	pause_layer = CanvasLayer.new()
	pause_layer.layer = 101
	pause_layer.visible = false
	add_child(pause_layer)

	var dim := ColorRect.new()
	dim.color = Color(0, 0, 0, 0.55)
	pause_layer.add_child(dim)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	var center := CenterContainer.new()
	pause_layer.add_child(center)
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	var main_box := VBoxContainer.new()
	main_box.add_theme_constant_override("separation", 20)
	center.add_child(main_box)

	var logo := TextureRect.new()
	logo.texture = load("res://darecraft_logo_clean.svg")
	logo.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	logo.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	logo.custom_minimum_size = Vector2(320, 132)
	main_box.add_child(logo)

	var title := Label.new()
	title.text = "Пауза"
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_size_override("font_size", 56)
	main_box.add_child(title)

	var resume := Button.new()
	resume.text = "Продолжить"
	resume.custom_minimum_size = Vector2(480, 70)
	resume.add_theme_font_size_override("font_size", 28)
	resume.pressed.connect(_set_paused.bind(false))
	main_box.add_child(resume)

	var settings_btn := Button.new()
	settings_btn.text = "Настройки"
	settings_btn.custom_minimum_size = Vector2(480, 70)
	settings_btn.add_theme_font_size_override("font_size", 28)
	main_box.add_child(settings_btn)

	var to_menu := Button.new()
	to_menu.text = "Выйти в меню"
	to_menu.custom_minimum_size = Vector2(480, 70)
	to_menu.add_theme_font_size_override("font_size", 24)
	to_menu.pressed.connect(_on_to_menu)
	main_box.add_child(to_menu)

	var settings_box := VBoxContainer.new()
	settings_box.add_theme_constant_override("separation", 20)
	settings_box.visible = false
	center.add_child(settings_box)

	var st_title := Label.new()
	st_title.text = "Настройки"
	st_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	st_title.add_theme_font_size_override("font_size", 48)
	settings_box.add_child(st_title)

	var world_settings_title := Label.new()
	world_settings_title.text = "Настройки мира"
	world_settings_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	world_settings_title.add_theme_font_size_override("font_size", 24)
	settings_box.add_child(world_settings_title)
	var creative_toggle := CheckButton.new()
	creative_toggle.text = "Креативный режим"
	creative_toggle.button_pressed = creative_mode
	creative_toggle.toggled.connect(_set_creative_mode)
	creative_toggle.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	settings_box.add_child(creative_toggle)
	var commands_toggle := CheckButton.new()
	commands_toggle.text = "Команды в чате (читы)"
	commands_toggle.button_pressed = commands_enabled
	commands_toggle.toggled.connect(_set_commands_enabled)
	commands_toggle.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	settings_box.add_child(commands_toggle)

	var controls_label := Label.new()
	controls_label.text = "Управление"
	controls_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	controls_label.add_theme_font_size_override("font_size", 24)
	settings_box.add_child(controls_label)

	var controls_row := HBoxContainer.new()
	controls_row.alignment = BoxContainer.ALIGNMENT_CENTER
	controls_row.add_theme_constant_override("separation", 16)
	settings_box.add_child(controls_row)

	control_pc_button = Button.new()
	control_pc_button.custom_minimum_size = Vector2(180, 55)
	control_pc_button.add_theme_font_size_override("font_size", 22)
	control_pc_button.pressed.connect(_set_control_mode.bind(CONTROL_MODE_PC))
	controls_row.add_child(control_pc_button)

	control_mobile_button = Button.new()
	control_mobile_button.custom_minimum_size = Vector2(180, 55)
	control_mobile_button.add_theme_font_size_override("font_size", 22)
	control_mobile_button.pressed.connect(_set_control_mode.bind(CONTROL_MODE_MOBILE))
	controls_row.add_child(control_mobile_button)

	_refresh_control_mode_buttons()

	var mobile_style_row := HBoxContainer.new()
	mobile_style_row.alignment = BoxContainer.ALIGNMENT_CENTER
	mobile_style_row.add_theme_constant_override("separation", 12)
	settings_box.add_child(mobile_style_row)
	var mobile_style_label := Label.new()
	mobile_style_label.text = "Мобильное управление:"
	mobile_style_label.add_theme_font_size_override("font_size", 20)
	mobile_style_row.add_child(mobile_style_label)
	var buttons_style := Button.new()
	buttons_style.text = "Кнопки"
	buttons_style.pressed.connect(func(): _set_mobile_control_style(0))
	mobile_style_row.add_child(buttons_style)
	var stick_style := Button.new()
	stick_style.text = "Джойстик"
	stick_style.pressed.connect(func(): _set_mobile_control_style(1))
	mobile_style_row.add_child(stick_style)

	var fov_row := HBoxContainer.new()
	fov_row.alignment = BoxContainer.ALIGNMENT_CENTER
	fov_row.add_theme_constant_override("separation", 20)
	settings_box.add_child(fov_row)

	var fov_lbl := Label.new()
	fov_lbl.text = "Обзор: " + str(int(Global.fov))
	fov_lbl.add_theme_font_size_override("font_size", 24)
	fov_row.add_child(fov_lbl)

	var fov_slider := HSlider.new()
	fov_slider.custom_minimum_size = Vector2(250, 30)
	fov_slider.min_value = 30.0
	fov_slider.max_value = 110.0
	fov_slider.step = 1.0
	fov_slider.value = Global.fov
	fov_row.add_child(fov_slider)
	fov_slider.value_changed.connect(func(val):
		Global.fov = val
		fov_lbl.text = "Обзор: " + str(int(val))
		if camera != null:
			camera.fov = val
	)

	var vol_row := HBoxContainer.new()
	vol_row.alignment = BoxContainer.ALIGNMENT_CENTER
	vol_row.add_theme_constant_override("separation", 20)
	settings_box.add_child(vol_row)

	var vol_lbl := Label.new()
	vol_lbl.text = "Музыка: " + str(int(Music.music_volume * 100)) + "%"
	vol_lbl.add_theme_font_size_override("font_size", 24)
	vol_row.add_child(vol_lbl)

	var vol_slider := HSlider.new()
	vol_slider.custom_minimum_size = Vector2(250, 30)
	vol_slider.min_value = 0.0
	vol_slider.max_value = 1.0
	vol_slider.step = 0.01
	vol_slider.value = Music.music_volume
	vol_row.add_child(vol_slider)
	vol_slider.value_changed.connect(func(val):
		Music.set_music_volume(val)
		vol_lbl.text = "Музыка: " + str(int(val * 100)) + "%"
	)

	var sfx_row := HBoxContainer.new()
	sfx_row.alignment = BoxContainer.ALIGNMENT_CENTER
	sfx_row.add_theme_constant_override("separation", 20)
	settings_box.add_child(sfx_row)

	var sfx_lbl := Label.new()
	sfx_lbl.text = "Звуки: " + str(int(Music.sfx_volume * 100)) + "%"
	sfx_lbl.add_theme_font_size_override("font_size", 24)
	sfx_row.add_child(sfx_lbl)

	var sfx_slider := HSlider.new()
	sfx_slider.custom_minimum_size = Vector2(250, 30)
	sfx_slider.min_value = 0.0
	sfx_slider.max_value = 1.0
	sfx_slider.step = 0.01
	sfx_slider.value = Music.sfx_volume
	sfx_row.add_child(sfx_slider)
	sfx_slider.value_changed.connect(func(val):
		Music.set_sfx_volume(val)
		sfx_lbl.text = "Звуки: " + str(int(val * 100)) + "%"
	)

	var back_btn := Button.new()
	back_btn.text = "Назад"
	back_btn.custom_minimum_size = Vector2(480, 70)
	back_btn.add_theme_font_size_override("font_size", 28)
	settings_box.add_child(back_btn)

	settings_btn.pressed.connect(func():
		main_box.visible = false
		settings_box.visible = true
	)

	back_btn.pressed.connect(func():
		settings_box.visible = false
		main_box.visible = true
	)

func _on_to_menu() -> void:
	get_tree().change_scene_to_file("res://menu.tscn")

# ---------------- персонаж и камера ----------------

func _box(parent: Node3D, size: Vector3, pos: Vector3, mat: StandardMaterial3D) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	mi.mesh = bm
	mi.position = pos
	mi.material_override = mat
	parent.add_child(mi)
	return mi

func _build_character() -> Dictionary:
	var skin := _color_mat(Color(0.9, 0.7, 0.55))
	var shirt := _color_mat(Color(0.25, 0.5, 0.85))
	var pants := _color_mat(Color(0.2, 0.22, 0.55))
	var hair := _color_mat(Color(0.3, 0.2, 0.1))
	var dark := _color_mat(Color(0.08, 0.08, 0.15))
	var mouth := _color_mat(Color(0.55, 0.3, 0.25))
	var iron := _color_mat(Color(0.6, 0.62, 0.66))
	var gmat: Array = []
	for k in 5:
		gmat.append([_color_mat(WOOD_COL[0]), _color_mat(WOOD_COL[1])])
	var gh: Array = gmat[0]
	var gc: Array = gmat[1]
	var gl: Array = gmat[2]
	var gb: Array = gmat[3]
	var gs: Array = gmat[4]
	var root := Node3D.new()
	var gear: Array = [[], [], [], [], []]

	_box(root, Vector3(0.45, 0.675, 0.225), Vector3(0, 1.0125, 0), shirt)
	gear[1].append(_box(root, Vector3(0.5, 0.7, 0.27), Vector3(0, 1.0125, 0), gc[0]))
	gear[1].append(_box(root, Vector3(0.51, 0.08, 0.28), Vector3(0, 0.72, 0), gc[1]))

	var head := Node3D.new()
	head.position = Vector3(0, 1.35, 0)
	root.add_child(head)
	_box(head, Vector3(0.45, 0.45, 0.45), Vector3(0, 0.225, 0), skin)
	_box(head, Vector3(0.47, 0.12, 0.47), Vector3(0, 0.42, 0), hair)
	_box(head, Vector3(0.47, 0.3, 0.06), Vector3(0, 0.26, 0.215), hair)
	_box(head, Vector3(0.09, 0.07, 0.02), Vector3(-0.1, 0.26, -0.226), dark)
	_box(head, Vector3(0.09, 0.07, 0.02), Vector3(0.1, 0.26, -0.226), dark)
	_box(head, Vector3(0.14, 0.035, 0.02), Vector3(0, 0.1, -0.226), mouth)
	gear[0].append(_box(head, Vector3(0.5, 0.16, 0.5), Vector3(0, 0.43, 0), gh[0]))
	gear[0].append(_box(head, Vector3(0.5, 0.38, 0.07), Vector3(0, 0.24, 0.235), gh[0]))
	gear[0].append(_box(head, Vector3(0.07, 0.38, 0.5), Vector3(0.235, 0.24, 0), gh[0]))
	gear[0].append(_box(head, Vector3(0.07, 0.38, 0.5), Vector3(-0.235, 0.24, 0), gh[0]))
	gear[0].append(_box(head, Vector3(0.5, 0.07, 0.07), Vector3(0, 0.37, -0.235), gh[1]))

	var arms: Array = []
	for sx in [1.0, -1.0]:
		var arm := Node3D.new()
		arm.position = Vector3(0.3375 * sx, 1.35, 0)
		root.add_child(arm)
		_box(arm, Vector3(0.225, 0.45, 0.225), Vector3(0, -0.225, 0), shirt)
		_box(arm, Vector3(0.225, 0.225, 0.225), Vector3(0, -0.5625, 0), skin)
		gear[1].append(_box(arm, Vector3(0.27, 0.24, 0.27), Vector3(0, -0.12, 0), gc[0]))
		arms.append(arm)
	var arm_l: Node3D = arms[1]
	gear[4].append(_box(arm_l, Vector3(0.38, 0.54, 0.04), Vector3(0, -0.38, -0.15), gs[1]))
	gear[4].append(_box(arm_l, Vector3(0.3, 0.46, 0.06), Vector3(0, -0.38, -0.155), gs[0]))
	gear[4].append(_box(arm_l, Vector3(0.12, 0.12, 0.09), Vector3(0, -0.38, -0.17), iron))

	var legs: Array = []
	for sx in [1.0, -1.0]:
		var leg := Node3D.new()
		leg.position = Vector3(0.1125 * sx, 0.675, 0)
		root.add_child(leg)
		_box(leg, Vector3(0.225, 0.675, 0.225), Vector3(0, -0.3375, 0), pants)
		gear[2].append(_box(leg, Vector3(0.27, 0.42, 0.27), Vector3(0, -0.21, 0), gl[0]))
		gear[3].append(_box(leg, Vector3(0.27, 0.2, 0.27), Vector3(0, -0.575, 0), gb[1]))
		legs.append(leg)

	for k in 5:
		for n in gear[k]:
			var node: Node3D = n
			node.visible = false

	var hand := Node3D.new()
	hand.position = Vector3(0, -0.6, -0.12)
	var arm_r: Node3D = arms[0]
	arm_r.add_child(hand)
	return {
		"root": root, "head": head, "arm_r": arm_r, "arm_l": arm_l,
		"leg_r": legs[0], "leg_l": legs[1], "hand": hand, "gear": gear, "gmat": gmat,
	}

func _animate_char(c: Dictionary, sw: float, hit: float, head_pitch: float) -> void:
	var ar: Node3D = c["arm_r"]
	var al: Node3D = c["arm_l"]
	var lr: Node3D = c["leg_r"]
	var ll: Node3D = c["leg_l"]
	var hd: Node3D = c["head"]
	ar.rotation.x = -sw + hit * 1.6
	al.rotation.x = sw
	lr.rotation.x = sw
	ll.rotation.x = -sw
	hd.rotation.x = head_pitch

func _tier_colors(tier: int) -> Array:
	if tier == 2:
		return IRON_COL
	if tier == 1:
		return STONE_COL
	return WOOD_COL

func _update_char_gear() -> void:
	var tiers: Array = []
	for k in 5:
		tiers.append(_armor_tier(int(armor[k]["id"])))
	for c in chars:
		var gear: Array = c["gear"]
		var gmat: Array = c["gmat"]
		for k in 5:
			var vis: bool = armor[k]["id"] != 0
			for n in gear[k]:
				var node: Node3D = n
				node.visible = vis
			var cols: Array = _tier_colors(int(tiers[k]))
			var gm: Array = gmat[k]
			var m0: StandardMaterial3D = gm[0]
			var m1: StandardMaterial3D = gm[1]
			m0.albedo_color = cols[0]
			m1.albedo_color = cols[1]
	if fp_shield_mats.size() == 2:
		var cols2: Array = _tier_colors(int(tiers[4]))
		var f0: StandardMaterial3D = fp_shield_mats[0]
		var f1: StandardMaterial3D = fp_shield_mats[1]
		f0.albedo_color = cols2[0]
		f1.albedo_color = cols2[1]

func _apply_camera_mode() -> void:
	if camera == null or player == null:
		return
	if view_mode == 2:
		camera.rotation = Vector3(-pitch, PI, 0.0)
	else:
		camera.rotation = Vector3(pitch, 0.0, 0.0)
	var head_pos := Vector3(0, 0.7, 0)
	if view_mode == 0:
		camera.position = head_pos
		return
	var d := THIRD_DIST
	var local_off: Vector3 = camera.basis * Vector3(0, 0, 1)
	var from: Vector3 = player.global_transform * head_pos
	var to: Vector3 = from + player.global_transform.basis * (local_off * d)
	var q := PhysicsRayQueryParameters3D.create(from, to)
	var ex: Array[RID] = [player.get_rid()]
	q.exclude = ex
	var hit := get_world_3d().direct_space_state.intersect_ray(q)
	if not hit.is_empty():
		var hp: Vector3 = hit["position"]
		d = maxf(0.4, from.distance_to(hp) - 0.25)
	camera.position = head_pos + local_off * d

func _equip_from(arr: Array, i: int) -> bool:
	var s: Dictionary = arr[i]
	var k: int = int(ARMOR_SLOT_OF.get(int(s["id"]), -1))
	if k < 0:
		return false
	var old: Dictionary = armor[k].duplicate()
	armor[k] = {"id": s["id"], "n": 1}
	s["n"] -= 1
	if s["n"] <= 0:
		arr[i] = old
	elif old["id"] != 0:
		add_item(old["id"], old["n"])
	_refresh_all()
	return true

# ---------------- печка ----------------

func _make_furnace_ui() -> void:
	furnace_layer = CanvasLayer.new()
	furnace_layer.layer = 6
	furnace_layer.visible = false
	add_child(furnace_layer)

	var dim := ColorRect.new()
	dim.color = Color(0, 0, 0, 0.6)
	furnace_layer.add_child(dim)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	var center := CenterContainer.new()
	furnace_layer.add_child(center)
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	var panel := PanelContainer.new()
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.7, 0.7, 0.7)
	sb.set_border_width_all(3)
	sb.border_color = Color(0.2, 0.2, 0.2)
	panel.add_theme_stylebox_override("panel", sb)
	center.add_child(panel)

	var margin := MarginContainer.new()
	for side in ["left", "right", "top", "bottom"]:
		margin.add_theme_constant_override("margin_" + side, 14)
	panel.add_child(margin)

	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 10)
	margin.add_child(box)

	var header := HBoxContainer.new()
	box.add_child(header)
	var title := Label.new()
	title.text = "Печка" if control_mode == CONTROL_MODE_MOBILE else "Печка (E / Esc: закрыть)"
	title.add_theme_font_size_override("font_size", 20)
	title.add_theme_color_override("font_color", Color(0.2, 0.2, 0.2))
	header.add_child(title)
	close_x.attach_to_header(header, _close_furnace)

	var top_row := CenterContainer.new()
	box.add_child(top_row)
	var main_row := HBoxContainer.new()
	main_row.add_theme_constant_override("separation", 16)
	top_row.add_child(main_row)

	var left_col := VBoxContainer.new()
	left_col.add_theme_constant_override("separation", 4)
	main_row.add_child(left_col)

	var s_in := _make_slot(50, true)
	s_in["btn"].pressed.connect(_on_furnace_slot.bind("input"))
	left_col.add_child(s_in["btn"])
	furnace_slots_ui.append(s_in)

	var flame := ProgressBar.new()
	flame.name = "FlameBar"
	flame.custom_minimum_size = Vector2(50, 20)
	flame.show_percentage = false
	flame.fill_mode = ProgressBar.FILL_BOTTOM_TO_TOP
	var flame_bg := StyleBoxFlat.new()
	flame_bg.bg_color = Color(0.3, 0.3, 0.3)
	var flame_fill := StyleBoxFlat.new()
	flame_fill.bg_color = Color(1.0, 0.5, 0.0)
	flame.add_theme_stylebox_override("background", flame_bg)
	flame.add_theme_stylebox_override("fill", flame_fill)
	left_col.add_child(flame)

	var s_fuel := _make_slot(50, true)
	s_fuel["btn"].pressed.connect(_on_furnace_slot.bind("fuel"))
	left_col.add_child(s_fuel["btn"])
	furnace_slots_ui.append(s_fuel)

	var right_col := HBoxContainer.new()
	right_col.add_theme_constant_override("separation", 10)
	right_col.alignment = BoxContainer.ALIGNMENT_CENTER
	main_row.add_child(right_col)

	var arrow := ProgressBar.new()
	arrow.name = "ArrowBar"
	arrow.custom_minimum_size = Vector2(60, 20)
	arrow.show_percentage = false
	arrow.max_value = SMELT_TIME
	var arrow_bg := StyleBoxFlat.new()
	arrow_bg.bg_color = Color(0.4, 0.4, 0.4)
	var arrow_fill := StyleBoxFlat.new()
	arrow_fill.bg_color = Color(1, 1, 1)
	arrow.add_theme_stylebox_override("background", arrow_bg)
	arrow.add_theme_stylebox_override("fill", arrow_fill)
	right_col.add_child(arrow)

	var s_out := _make_slot(56, true)
	s_out["btn"].pressed.connect(_on_furnace_slot.bind("output"))
	right_col.add_child(s_out["btn"])
	furnace_slots_ui.append(s_out)

	box.add_child(HSeparator.new())

	var inv_lbl := Label.new()
	inv_lbl.text = "Инвентарь"
	inv_lbl.add_theme_font_size_override("font_size", 18)
	inv_lbl.add_theme_color_override("font_color", Color(0.2, 0.2, 0.2))
	box.add_child(inv_lbl)

	furnace_inv_ui.clear()
	furnace_hot_ui.clear()

	var grid := GridContainer.new()
	grid.columns = 5
	grid.add_theme_constant_override("h_separation", 6)
	grid.add_theme_constant_override("v_separation", 6)
	box.add_child(grid)
	for i in range(HOTBAR, TOTAL_SLOTS):
		var s := _make_slot(46, true)
		s["btn"].pressed.connect(_on_slot_pressed.bind(i))
		s["btn"].gui_input.connect(_slot_gui_input.bind("s", i))
		grid.add_child(s["btn"])
		furnace_inv_ui.append(s)

	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 6)
	box.add_child(row)
	for i in HOTBAR:
		var s := _make_slot(46, true)
		s["btn"].pressed.connect(_on_slot_pressed.bind(i))
		s["btn"].gui_input.connect(_slot_gui_input.bind("s", i))
		row.add_child(s["btn"])
		furnace_hot_ui.append(s)

func _on_furnace_slot(kind: String) -> void:
	if furnace_ui_cell == Vector3i(-1, -1, -1):
		return
	var f := _get_furnace(furnace_ui_cell)
	var s: Dictionary = f[kind]
	var c: Dictionary = cursor_item

	if kind == "output":
		if s["id"] != 0 and c["id"] == 0:
			cursor_item = s.duplicate()
			f["output"] = {"id": 0, "n": 0}
		elif s["id"] != 0 and c["id"] == s["id"] and int(c["n"]) + int(s["n"]) <= MAX_STACK:
			c["n"] += s["n"]
			f["output"] = {"id": 0, "n": 0}
		else:
			return
		_refresh_furnace_ui()
		return

	if c["id"] == 0:
		if s["id"] != 0:
			cursor_item = s.duplicate()
			f[kind] = {"id": 0, "n": 0}
	elif s["id"] == 0:
		f[kind] = c.duplicate()
		cursor_item = {"id": 0, "n": 0}
	elif s["id"] == c["id"]:
		var moved: int = mini(MAX_STACK - int(s["n"]), int(c["n"]))
		s["n"] += moved
		c["n"] -= moved
		if c["n"] <= 0:
			cursor_item = {"id": 0, "n": 0}
	else:
		f[kind] = c.duplicate()
		cursor_item = s.duplicate()
	_refresh_furnace_ui()

func _get_furnace(cell: Vector3i) -> Dictionary:
	if not furnaces.has(cell):
		furnaces[cell] = {
			"input": {"id": 0, "n": 0}, "fuel": {"id": 0, "n": 0},
			"output": {"id": 0, "n": 0}, "progress": 0.0, "burn": 0.0, "burn_max": 80.0,
		}
	return furnaces[cell]

func _open_furnace(cell: Vector3i) -> void:
	_get_furnace(cell)
	furnace_ui_cell = cell
	inv_open = true
	breaking = false
	blocking = false
	if mobile_hud != null:
		mobile_hud.visible = false
	inv_layer.visible = false
	furnace_layer.visible = true
	close_x.set_mobile(control_mode == CONTROL_MODE_MOBILE)
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	_refresh_furnace_ui()

func _close_furnace() -> void:
	furnace_layer.visible = false
	furnace_ui_cell = Vector3i(-1, -1, -1)
	rmb_down = false
	rmb_visited.clear()
	if cursor_item["id"] != 0:
		add_item(cursor_item["id"], cursor_item["n"])
		cursor_item = {"id": 0, "n": 0}
	inv_open = false
	_refresh_slots()
	_apply_control_mode()

func _refresh_furnace_ui() -> void:
	if furnace_ui_cell == Vector3i(-1, -1, -1):
		return
	var f := _get_furnace(furnace_ui_cell)
	_show_item(furnace_slots_ui[0], f["input"])
	_show_item(furnace_slots_ui[1], f["fuel"])
	_show_item(furnace_slots_ui[2], f["output"])

	var flame_bar = furnace_layer.find_child("FlameBar", true, false)
	var arrow_bar = furnace_layer.find_child("ArrowBar", true, false)
	if arrow_bar:
		arrow_bar.value = float(f["progress"])
	if flame_bar:
		if float(f["burn"]) > 0.0:
			flame_bar.value = clampf(float(f["burn"]) / float(f.get("burn_max", 80.0)), 0.0, 1.0) * 100.0
		else:
			flame_bar.value = 0.0

	for i in range(HOTBAR, TOTAL_SLOTS):
		_show_item(furnace_inv_ui[i - HOTBAR], slots[i])
	for i in HOTBAR:
		_show_item(furnace_hot_ui[i], slots[i])

	_show_item(cursor_ui, cursor_item)
	cursor_ui["btn"].visible = inv_open and cursor_item["id"] != 0

func _update_furnaces(delta: float) -> void:
	for k in furnaces.keys():
		var f: Dictionary = furnaces[k]
		var inp: Dictionary = f["input"]
		var fuel: Dictionary = f["fuel"]
		var out: Dictionary = f["output"]

		var can_smelt: bool = inp["id"] != 0 and SMELTING.has(int(inp["id"]))
		if can_smelt:
			var res_id: int = int(SMELTING[int(inp["id"])])
			can_smelt = out["id"] == 0 or (out["id"] == res_id and int(out["n"]) < MAX_STACK)

		if f["burn"] <= 0.0 and can_smelt and fuel["id"] != 0 and FUEL.has(int(fuel["id"])):
			f["burn"] = float(FUEL[int(fuel["id"])])
			f["burn_max"] = f["burn"]
			fuel["n"] -= 1
			if fuel["n"] <= 0:
				f["fuel"] = {"id": 0, "n": 0}

		if f["burn"] > 0.0:
			f["burn"] -= delta
			if can_smelt:
				f["progress"] += delta
				if f["progress"] >= SMELT_TIME:
					f["progress"] = 0.0
					var res: int = int(SMELTING[int(inp["id"])])
					inp["n"] -= 1
					if inp["n"] <= 0:
						f["input"] = {"id": 0, "n": 0}
					if out["id"] == 0:
						f["output"] = {"id": res, "n": 1}
					else:
						out["n"] += 1
			else:
				f["progress"] = 0.0
		else:
			f["progress"] = maxf(0.0, f["progress"] - delta * 2.0)

		if inv_open and furnace_ui_cell == k:
			_refresh_furnace_ui()

# ---------------- сундук ----------------

func _make_chest_ui() -> void:
	chest_layer = CanvasLayer.new()
	chest_layer.layer = 6
	chest_layer.visible = false
	add_child(chest_layer)

	var dim := ColorRect.new()
	dim.color = Color(0, 0, 0, 0.6)
	chest_layer.add_child(dim)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	var center := CenterContainer.new()
	chest_layer.add_child(center)
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	var panel := PanelContainer.new()
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.7, 0.7, 0.7)
	sb.set_border_width_all(3)
	sb.border_color = Color(0.2, 0.2, 0.2)
	panel.add_theme_stylebox_override("panel", sb)
	center.add_child(panel)

	var margin := MarginContainer.new()
	for side in ["left", "right", "top", "bottom"]:
		margin.add_theme_constant_override("margin_" + side, 12)
	panel.add_child(margin)

	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 8)
	margin.add_child(box)

	var header := HBoxContainer.new()
	box.add_child(header)
	chest_title_lbl = Label.new()
	chest_title_lbl.text = "Сундук"
	chest_title_lbl.add_theme_font_size_override("font_size", 20)
	chest_title_lbl.add_theme_color_override("font_color", Color(0.2, 0.2, 0.2))
	header.add_child(chest_title_lbl)
	close_x.attach_to_header(header, _close_chest)

	var c_grid := GridContainer.new()
	c_grid.columns = 9
	c_grid.add_theme_constant_override("h_separation", 4)
	c_grid.add_theme_constant_override("v_separation", 4)
	box.add_child(c_grid)

	chest_slots_ui.clear()
	for i in 54:
		var s := _make_slot(40, true)
		s["btn"].pressed.connect(_on_chest_slot.bind(i))
		s["btn"].gui_input.connect(_slot_gui_input.bind("k", i))
		c_grid.add_child(s["btn"])
		chest_slots_ui.append(s)

	box.add_child(HSeparator.new())

	var inv_lbl := Label.new()
	inv_lbl.text = "Инвентарь"
	inv_lbl.add_theme_font_size_override("font_size", 18)
	inv_lbl.add_theme_color_override("font_color", Color(0.2, 0.2, 0.2))
	box.add_child(inv_lbl)

	chest_inv_ui.clear()
	chest_hot_ui.clear()
	var grid := GridContainer.new()
	grid.columns = 9
	grid.add_theme_constant_override("h_separation", 4)
	grid.add_theme_constant_override("v_separation", 4)
	box.add_child(grid)
	for i in range(HOTBAR, TOTAL_SLOTS):
		var s := _make_slot(40, true)
		s["btn"].pressed.connect(_on_slot_pressed.bind(i))
		s["btn"].gui_input.connect(_slot_gui_input.bind("s", i))
		grid.add_child(s["btn"])
		chest_inv_ui.append(s)

	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 4)
	box.add_child(row)
	for i in HOTBAR:
		var s := _make_slot(40, true)
		s["btn"].pressed.connect(_on_slot_pressed.bind(i))
		s["btn"].gui_input.connect(_slot_gui_input.bind("s", i))
		row.add_child(s["btn"])
		chest_hot_ui.append(s)

func _get_chest_group(cell: Vector3i) -> Dictionary:
	var dirs := [Vector3i(1, 0, 0), Vector3i(-1, 0, 0), Vector3i(0, 0, 1), Vector3i(0, 0, -1)]
	for d in dirs:
		if get_block(cell.x + d.x, cell.y, cell.z + d.z) == CHEST:
			var origin := Vector3i(mini(cell.x, cell.x + d.x), cell.y, mini(cell.z, cell.z + d.z))
			return {"origin": origin, "double": true}
	return {"origin": cell, "double": false}

func _get_chest_inventory(origin: Vector3i, is_double: bool) -> Array:
	var size := 54 if is_double else 27
	if not chests.has(origin):
		var loot: Array = []
		for j in 27: loot.append({"id": 0, "n": 0})
		var loot_rng := RandomNumberGenerator.new()
		loot_rng.seed = world_seed + origin.x * 7919 + origin.z * 104729
		var loot_ids := [COAL_ITEM, IRON_INGOT, STICK, DIAMOND]
		for j in loot_rng.randi_range(3, 6):
			var li := loot_rng.randi_range(0, 26)
			loot[li] = {"id": loot_ids[loot_rng.randi_range(0, loot_ids.size() - 1)], "n": loot_rng.randi_range(1, 4)}
		chests[origin] = loot
	var inv: Array = chests[origin]
	while inv.size() < size:
		inv.append({"id": 0, "n": 0})
	return inv

func _open_chest(cell: Vector3i) -> void:
	var group := _get_chest_group(cell)
	var origin: Vector3i = group["origin"]
	chest_is_double = bool(group["double"])
	_get_chest_inventory(origin, chest_is_double)
	chest_ui_cell = origin
	inv_open = true
	breaking = false
	blocking = false
	if mobile_hud != null:
		mobile_hud.visible = false
	inv_layer.visible = false
	chest_layer.visible = true
	close_x.set_mobile(control_mode == CONTROL_MODE_MOBILE)
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	chest_title_lbl.text = "Двойной сундук" if chest_is_double else "Сундук"
	for i in 54:
		chest_slots_ui[i]["btn"].visible = i < (54 if chest_is_double else 27)
	_refresh_chest_ui()

func _close_chest() -> void:
	chest_layer.visible = false
	chest_ui_cell = Vector3i(-1, -1, -1)
	rmb_down = false
	rmb_visited.clear()
	if cursor_item["id"] != 0:
		add_item(cursor_item["id"], cursor_item["n"])
		cursor_item = {"id": 0, "n": 0}
	inv_open = false
	_refresh_slots()
	_apply_control_mode()

func _on_chest_slot(i: int) -> void:
	if chest_ui_cell == Vector3i(-1, -1, -1):
		return
	var inv := _get_chest_inventory(chest_ui_cell, chest_is_double)
	_click_slot(inv, i)

func _refresh_chest_ui() -> void:
	if chest_ui_cell == Vector3i(-1, -1, -1):
		return
	var inv := _get_chest_inventory(chest_ui_cell, chest_is_double)
	for i in inv.size():
		_show_item(chest_slots_ui[i], inv[i])
	for i in range(HOTBAR, TOTAL_SLOTS):
		_show_item(chest_inv_ui[i - HOTBAR], slots[i])
	for i in HOTBAR:
		_show_item(chest_hot_ui[i], slots[i])
	_show_item(cursor_ui, cursor_item)
	cursor_ui["btn"].visible = cursor_item["id"] != 0

func _create_pig(pos: Vector3) -> CharacterBody3D:
	var pig = CharacterBody3D.new()
	pig.set_script(load("res://pig.gd"))
	pig.position = pos
	pig.set("world_controller", self)

	var col = CollisionShape3D.new()
	var shape = BoxShape3D.new()
	shape.size = Vector3(0.9, 0.9, 1.4)
	col.shape = shape
	col.position.y = 0.45
	pig.add_child(col)

	var pink = _color_mat(Color(0.95, 0.65, 0.65))
	var dark_pink = _color_mat(Color(0.85, 0.5, 0.5))
	var black = _color_mat(Color.BLACK)

	_box(pig, Vector3(0.9, 0.9, 1.4), Vector3(0, 0.45, 0), pink)

	var head = Node3D.new()
	head.position = Vector3(0, 0.6, 0.8)
	pig.add_child(head)
	_box(head, Vector3(0.7, 0.7, 0.7), Vector3.ZERO, pink)
	_box(head, Vector3(0.4, 0.3, 0.1), Vector3(0, -0.1, 0.35), dark_pink)
	_box(head, Vector3(0.1, 0.1, 0.05), Vector3(0.2, 0.15, 0.35), black)
	_box(head, Vector3(0.1, 0.1, 0.05), Vector3(-0.2, 0.15, 0.35), black)

	var legs: Array[Node3D] = []
	for x in [-0.3, 0.3]:
		for z in [-0.5, 0.5]:
			var leg_pivot := Node3D.new()
			leg_pivot.position = Vector3(x, 0.15, z)
			pig.add_child(leg_pivot)
			_box(leg_pivot, Vector3(0.25, 0.4, 0.25), Vector3(0, -0.2, 0), dark_pink)
			legs.append(leg_pivot)
	pig.set("leg_pivots", legs)
	return pig

func _gen_trees_in_chunk(cx: int, cz: int) -> void:
	var ox := cx * CS
	var oz := cz * CS
	for lx in CS:
		for lz in CS:
			var x := ox + lx
			var z := oz + lz
			var rng := RandomNumberGenerator.new()
			rng.seed = hash(Vector2i(x, z)) + world_seed
			if rng.randf() > 0.008:
				continue

			var h: int = _height_at(x, z)
			if h >= ROCK_LEVEL - 2:
				continue

			var th := rng.randi_range(4, 6)
			for y in range(h + 1, h + th + 1):
				_put(x, y, z, LOG)
			for dy in range(-1, 3):
				var r := 2 if dy <= 0 else 1
				for dx in range(-r, r + 1):
					for dz in range(-r, r + 1):
						if r == 2 and abs(dx) == 2 and abs(dz) == 2:
							continue
						_put(x + dx, h + th + dy, z + dz, LEAVES)
