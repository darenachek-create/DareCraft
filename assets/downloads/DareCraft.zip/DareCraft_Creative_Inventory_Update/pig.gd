extends CharacterBody3D

const GRAVITY := 20.0
const SPEED := 1.5
const JUMP_FORCE := 5.5
var health := 5.0
var change_dir_timer := 0.0
var direction := Vector3.ZERO
var oink_timer := 0.0
var jump_timer := 3.0
var step_phase := 0.0
var leg_pivots: Array[Node3D] = []
var oink_player: AudioStreamPlayer3D
var world_controller: Node
var flash_timer := 0.0
var mesh_materials: Array = []

func _ready() -> void:
	oink_player = AudioStreamPlayer3D.new()
	oink_player.stream = load("res://хрюк свиньи.mp3")
	oink_player.volume_db = linear_to_db(Music.sfx_volume * 0.8)
	add_child(oink_player)
	for node in find_children("*", "MeshInstance3D", true, false):
		var mesh := node as MeshInstance3D
		mesh_materials.append([mesh, mesh.material_override])
	oink_timer = randf_range(3.0, 8.0)
	_pick_new_direction()

func _physics_process(delta: float) -> void:
	if flash_timer > 0.0:
		flash_timer -= delta
		if flash_timer <= 0.0: _restore_color()
	if not is_on_floor(): velocity.y -= GRAVITY * delta
	else:
		velocity.y = -0.1
		jump_timer -= delta
		if jump_timer <= 0.0 and randf() < 0.035:
			velocity.y = JUMP_FORCE
			jump_timer = randf_range(2.0, 5.0)
	change_dir_timer -= delta
	if change_dir_timer <= 0.0: _pick_new_direction()
	velocity.x = direction.x * SPEED
	velocity.z = direction.z * SPEED
	if direction.length() > 0.1:
		rotation.y = lerp_angle(rotation.y, atan2(direction.x, direction.z), delta * 5.0)
	move_and_slide()
	var speed := Vector2(velocity.x, velocity.z).length()
	if is_on_floor() and speed > 0.1 and leg_pivots.size() == 4:
		step_phase += delta * 9.0 * speed / SPEED
		for i in 4:
			leg_pivots[i].rotation.x = sin(step_phase + (PI if i % 2 else 0.0)) * 0.35
	else:
		for leg in leg_pivots: leg.rotation.x = move_toward(leg.rotation.x, 0.0, delta * 5.0)
	oink_timer -= delta
	if oink_timer <= 0.0:
		oink_timer = randf_range(5.0, 12.0)
		oink_player.pitch_scale = randf_range(0.8, 1.2)
		oink_player.play()

func _flash_red() -> void:
	flash_timer = 1.0
	var red := StandardMaterial3D.new()
	red.albedo_color = Color(1.0, 0.08, 0.08)
	red.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	for entry in mesh_materials:
		var mesh: MeshInstance3D = entry[0]
		if is_instance_valid(mesh): mesh.material_override = red

func _restore_color() -> void:
	for entry in mesh_materials:
		var mesh: MeshInstance3D = entry[0]
		if is_instance_valid(mesh): mesh.material_override = entry[1]

func receive_hit(damage: float) -> bool:
	_flash_red()
	health -= damage
	if health <= 0.0:
		if is_instance_valid(world_controller): world_controller.add_item(53, randi_range(1, 2))
		queue_free()
	return true

func _pick_new_direction() -> void:
	if randf() < 0.3:
		direction = Vector3.ZERO
		change_dir_timer = randf_range(1.0, 3.0)
	else:
		var angle := randf() * TAU
		direction = Vector3(cos(angle), 0, sin(angle)).normalized()
		change_dir_timer = randf_range(2.0, 5.0)
