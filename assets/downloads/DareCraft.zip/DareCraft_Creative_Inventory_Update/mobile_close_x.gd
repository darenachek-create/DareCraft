extends Node
class_name MobileCloseX

var menu_panels: Array[Control] = []
var is_mobile: bool = false
var close_callback: Callable

func setup(panels: Array[Control], mobile_mode: bool, on_close: Callable) -> void:
	menu_panels = panels
	is_mobile = mobile_mode
	close_callback = on_close
	refresh()

func set_mobile(mobile_mode: bool) -> void:
	is_mobile = mobile_mode
	refresh()

func attach_to_header(header: HBoxContainer, on_close: Callable) -> Button:
	if header == null:
		return null
	var existing := header.get_node_or_null("CloseXButton") as Button
	if existing != null:
		existing.visible = is_mobile
		return existing

	var spacer := Control.new()
	spacer.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	spacer.mouse_filter = Control.MOUSE_FILTER_IGNORE
	header.add_child(spacer)

	var btn := Button.new()
	btn.name = "CloseXButton"
	btn.text = "✕"
	btn.focus_mode = Control.FOCUS_NONE
	btn.custom_minimum_size = Vector2(36, 36)
	btn.add_theme_font_size_override("font_size", 20)
	btn.visible = is_mobile
	btn.pressed.connect(func():
		if on_close.is_valid():
			on_close.call()
	)
	header.add_child(btn)
	return btn

func refresh() -> void:
	for panel in menu_panels:
		if panel == null:
			continue
		var btn := panel.find_child("CloseXButton", true, false) as Button
		if btn != null:
			btn.visible = is_mobile
