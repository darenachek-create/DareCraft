extends Control

const FADE_IN := 0.8     # картинка плавно проявляется
const SHOW_TIME := 6.0   # картинка на экране 6 секунд
const FADE_OUT := 1.4    # потом экран затемняется

func _ready() -> void:
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE

	# тонкая красная полоска загрузки внизу
	var bar := ProgressBar.new()
	bar.max_value = FADE_IN + SHOW_TIME
	bar.value = 0.0
	bar.show_percentage = false
	bar.custom_minimum_size = Vector2(400, 6)
	bar.set_anchors_and_offsets_preset(Control.PRESET_CENTER_BOTTOM)
	bar.offset_left = -200
	bar.offset_right = 200
	bar.offset_top = -50
	bar.offset_bottom = -44
	var fill := StyleBoxFlat.new()
	fill.bg_color = Color(1.0, 0.2, 0.2)
	fill.set_corner_radius_all(3)
	var back := StyleBoxFlat.new()
	back.bg_color = Color(0, 0, 0, 0.5)
	back.set_corner_radius_all(3)
	bar.add_theme_stylebox_override("fill", fill)
	bar.add_theme_stylebox_override("background", back)
	add_child(bar)

	# чёрный экран поверх всего: сначала открывает картинку, потом гасит её
	var dark := ColorRect.new()
	dark.color = Color(0, 0, 0, 1)
	dark.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	dark.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(dark)

	var bar_tw := create_tween()
	bar_tw.tween_property(bar, "value", FADE_IN + SHOW_TIME, FADE_IN + SHOW_TIME)

	var tw := create_tween()
	tw.tween_property(dark, "color:a", 0.0, FADE_IN)
	tw.tween_interval(SHOW_TIME)
	tw.tween_property(dark, "color:a", 1.0, FADE_OUT)
	await tw.finished

	# меню откроется из темноты
	Global.fade_in_menu = true
	get_tree().change_scene_to_file("res://menu.tscn")
