extends Node

var fov: float = 70.0
var current_world := "Мир 1"
var splash_shown := false
# true, когда меню открывается сразу после заставки: тогда оно появляется из темноты
var fade_in_menu := false

func worlds_dir() -> String:
	return "user://worlds"

func world_path(world_name: String) -> String:
	return worlds_dir() + "/" + world_name + ".save"

func list_worlds() -> PackedStringArray:
	var result := PackedStringArray()
	DirAccess.make_dir_recursive_absolute(worlds_dir())
	var d := DirAccess.open(worlds_dir())
	if d == null:
		return result
	for f in d.get_files():
		if f.ends_with(".save"):
			result.append(f.get_basename())
	result.sort()
	return result

func clean_name(raw: String) -> String:
	return raw.strip_edges().validate_filename()

func world_exists(world_name: String) -> bool:
	return FileAccess.file_exists(world_path(world_name))

func delete_world(world_name: String) -> void:
	DirAccess.remove_absolute(world_path(world_name))
