extends Node

signal language_changed(language_code: String)

const LANGUAGE_PATH := "user://darecraft_language.cfg"
var language: String = "ru"

const TEXTS := {
	"ru": {
		"play": "Играть", "settings": "Настройки", "multiplayer": "Мультиплеер",
		"inventory": "Инвентарь", "back": "Назад", "done": "Готово",
		"language": "Язык", "theme": "Тема оформления", "classic": "Классика DareCraft",
		"neon": "Ночной неон", "retro": "Ретро-песочница", "copy_room": "Скопировать код комнаты",
		"connected": "Подключено", "reconnecting": "Переподключение…", "offline": "Нет соединения"
	},
	"uk": {
		"play": "Грати", "settings": "Налаштування", "multiplayer": "Мультиплеєр",
		"inventory": "Інвентар", "back": "Назад", "done": "Готово",
		"language": "Мова", "theme": "Тема оформлення", "classic": "Класика DareCraft",
		"neon": "Нічний неон", "retro": "Ретро-пісочниця", "copy_room": "Скопіювати код кімнати",
		"connected": "Підключено", "reconnecting": "Перепідключення…", "offline": "Немає з’єднання"
	},
	"en": {
		"play": "Play", "settings": "Settings", "multiplayer": "Multiplayer",
		"inventory": "Inventory", "back": "Back", "done": "Done",
		"language": "Language", "theme": "Interface theme", "classic": "DareCraft Classic",
		"neon": "Night Neon", "retro": "Retro Sandbox", "copy_room": "Copy room code",
		"connected": "Connected", "reconnecting": "Reconnecting…", "offline": "Offline"
	}
}

const UI_TRANSLATIONS := {
	"uk": {
		"Выход": "Вихід", "Выбор мира": "Вибір світу", "Создать мир": "Створити світ",
		"Название нового мира": "Назва нового світу", "Удалить": "Видалити", "Точно?": "Точно?",
		"Имя игрока": "Ім’я гравця", "Твоё имя в игре": "Твоє ім’я у грі", "Сервер комнат": "Сервер кімнат",
		"Создать комнату": "Створити кімнату", "Создать онлайн-мир": "Створити онлайн-світ",
		"Подключиться к другу": "Приєднатися до друга", "Подключиться": "Приєднатися",
		"Код комнаты DC1-12345": "Код кімнати DC1-12345", "Настройки DareCraft": "Налаштування DareCraft",
		"Язык / Language / Мова": "Мова / Language", "Тема оформления": "Тема оформлення",
		"Классика": "Класика", "Ночной неон": "Нічний неон", "Ретро": "Ретро",
		"Режим управления": "Режим керування", "Скины персонажа": "Скіни персонажа",
		"Кожа": "Шкіра", "Одежда": "Одяг", "Штаны": "Штани", "Волосы": "Волосся",
		"Обзор": "Огляд", "Текущий язык": "Поточна мова", "Выбран": "Обрано",
		"Мой скин": "Мій скін", "Мужской": "Чоловічий", "Женский": "Жіночий",
		"Мир с таким названием уже есть": "Світ із такою назвою вже існує",
		"Миров пока нет. Создайте первый!": "Світів поки немає. Створіть перший!",
		"Назад": "Назад", "Играть": "Грати", "Настройки": "Налаштування", "Мультиплеер": "Мультиплеєр",
		"До 8 игроков · Android ↔ Windows · без проброса портов": "До 8 гравців · Android ↔ Windows · без перенаправлення портів",
		"Мой мир для мультиплеера": "Мій світ для мультиплеєра",
		"Новый случайный мир": "Новий випадковий світ",
		"Можно загрузить уже сохранённый мир. Он будет отправлен друзьям при подключении.": "Можна завантажити вже збережений світ. Його буде надіслано друзям під час підключення."
	},
	"en": {
		"Выход": "Exit", "Выбор мира": "World selection", "Создать мир": "Create world",
		"Название нового мира": "New world name", "Удалить": "Delete", "Точно?": "Sure?",
		"Имя игрока": "Player name", "Твоё имя в игре": "Your in-game name", "Сервер комнат": "Room server",
		"Создать комнату": "Create room", "Создать онлайн-мир": "Host online world",
		"Подключиться к другу": "Join a friend", "Подключиться": "Join",
		"Код комнаты DC1-12345": "Room code DC1-12345", "Настройки DareCraft": "DareCraft settings",
		"Язык / Language / Мова": "Language / Мова", "Тема оформления": "Interface theme",
		"Классика": "Classic", "Ночной неон": "Night Neon", "Ретро": "Retro",
		"Режим управления": "Control mode", "Скины персонажа": "Character skins",
		"Кожа": "Skin", "Одежда": "Shirt", "Штаны": "Pants", "Волосы": "Hair",
		"Обзор": "Field of view", "Текущий язык": "Current language", "Выбран": "Selected",
		"Мой скин": "Custom skin", "Мужской": "Male", "Женский": "Female",
		"Мир с таким названием уже есть": "A world with this name already exists",
		"Миров пока нет. Создайте первый!": "There are no worlds yet. Create the first one!",
		"Назад": "Back", "Играть": "Play", "Настройки": "Settings", "Мультиплеер": "Multiplayer",
		"До 8 игроков · Android ↔ Windows · без проброса портов": "Up to 8 players · Android ↔ Windows · no port forwarding",
		"Мой мир для мультиплеера": "My multiplayer world",
		"Новый случайный мир": "New random world",
		"Можно загрузить уже сохранённый мир. Он будет отправлен друзьям при подключении.": "You can load a saved world. It will be sent to friends when they join."
	}
}


# Extra runtime strings: inventory item names and achievement titles.
const GAME_TRANSLATIONS := {
	"uk": {
		"Трава": "Трава",
		"Земля": "Ґрунт",
		"Камень": "Камінь",
		"Бревно": "Колода",
		"Листва": "Листя",
		"Доски": "Дошки",
		"Верстак": "Верстак",
		"Угольная руда": "Вугільна руда",
		"Железная руда": "Залізна руда",
		"Палка": "Палиця",
		"Деревянная кирка": "Дерев'яна кирка",
		"Пашня": "Рілля",
		"Деревянная лопата": "Дерев'яна лопата",
		"Деревянный меч": "Дерев'яний меч",
		"Деревянный топор": "Дерев'яна сокира",
		"Деревянная мотыга": "Дерев'яна мотика",
		"Семена пшеницы": "Насіння пшениці",
		"Семена картофеля": "Насіння картоплі",
		"Семена свёклы": "Насіння буряка",
		"Пшеница": "Пшениця",
		"Картофель": "Картопля",
		"Свёкла": "Буряк",
		"Шлем": "Шолом",
		"Нагрудник": "Нагрудник",
		"Поножи": "Поножі",
		"Ботинки": "Черевики",
		"Щит": "Щит",
		"Дверь": "Двері",
		"Печь": "Піч",
		"Каменная кирка": "Кам’яна кирка",
		"Каменная лопата": "Кам’яна лопата",
		"Каменный меч": "Кам’яний меч",
		"Каменный топор": "Кам’яна сокира",
		"Каменная мотыга": "Кам’яна мотика",
		"Каменный шлем": "Кам’яний шолом",
		"Каменный нагрудник": "Кам’яний нагрудник",
		"Каменные поножи": "Кам’яні поножі",
		"Каменные ботинки": "Кам’яні черевики",
		"Каменный щит": "Кам’яний щит",
		"Уголь": "Вугілля",
		"Железный слиток": "Залізний злиток",
		"Железо": "Залізо",
		"Сундук": "Скриня",
		"Железная кирка": "Залізна кирка",
		"Железная лопата": "Залізна лопата",
		"Железный меч": "Залізний меч",
		"Железный топор": "Залізна сокира",
		"Железная мотыга": "Залізна мотика",
		"Железный шлем": "Залізний шолом",
		"Железный нагрудник": "Залізний нагрудник",
		"Железные поножи": "Залізні поножі",
		"Железные ботинки": "Залізні черевики",
		"Сырая свинина": "Сира свинина",
		"Жареная свинина": "Смажена свинина",
		"Гнилая плоть": "Гнила плоть",
		"Приготовленная плоть": "Приготована плоть",
		"Алмазная руда": "Алмазна руда",
		"Алмаз": "Алмаз",
		"Алмазная кирка": "Алмазна кирка",
		"Алмазный меч": "Алмазний меч",
		"Алмазный топор": "Алмазна сокира",
		"Алмазная лопата": "Алмазна лопата",
		"Стекло": "Скло",
		"Рельсы": "Рейки",
		"Вагонетка": "Вагонетка",
		"Алмазная мотыга": "Алмазна мотика",
		"Алмазный шлем": "Алмазний шолом",
		"Алмазный нагрудник": "Алмазний нагрудник",
		"Алмазные поножи": "Алмазні поножі",
		"Алмазные ботинки": "Алмазні черевики",
		"Алмазный щит": "Алмазний щит",
		"Кровать": "Ліжко",
		"Кость": "Кістка",
		"Факел": "Смолоскип",
		"Песок": "Пісок",
		"Гравий": "Гравій",
		"Светящийся блок": "Світний блок",
		"Музыкальный проигрыватель": "Музичний програвач",
		"Пластинка «Рассвет»": "Платівка «Світанок»",
		"Пластинка «Лес»": "Платівка «Ліс»",
		"Пластинка «Пещера»": "Платівка «Печера»",
		"Пластинка «Море»": "Платівка «Море»",
		"Пластинка «Звёзды»": "Платівка «Зорі»",
		"Лук": "Лук",
		"Паутина": "Павутина",
		"Яйцо призыва скелета": "Яйце виклику скелета",
		"Яйцо призыва свиньи": "Яйце виклику свині",
		"Яйцо призыва паука": "Яйце виклику павука",
		"Яйцо призыва зомби": "Яйце виклику зомбі",
		"Лодка": "Човен",
		"Снег": "Сніг",
		"Плот 5×8": "Пліт 5×8",
		"Карта сокровищ": "Мапа скарбів",
		"Неизвестный предмет": "Невідомий предмет",
		"Лингвист": "Мовознавець",
		"Оборотень": "Перевертень",
		"Гусачок": "Гусачок",
		"Самые быстрые победы Магнуса Карлсена": "Найшвидші перемоги Магнуса Карлсена",
		"Самые быстрые проигрыши Магнуса Карлсена": "Найшвидші поразки Магнуса Карлсена",
		"Бесчувственный": "Безжальний",
		"Пацифист": "Пацифіст",
		"Грядочник": "Городник",
		"Дровосек": "Лісоруб",
		"Медальник": "Медальник",
		"Коллекционер": "Колекціонер",
		"Игрок": "Гравець",
		"Инвентарь — Креатив": "Інвентар — Творчий режим",
		"Креатив включён": "Творчий режим увімкнено",
		"Креатив выключен": "Творчий режим вимкнено",
		"Пустая рука": "Порожня рука",
		"Чат DareCraft": "Чат DareCraft",
		"Нажми T, чтобы открыть чат. Команды начинаются с /": "Натисни T, щоб відкрити чат. Команди починаються з /",
		"Закрыть чат": "Закрити чат",
		"Возродиться": "Відродитися",
		"Ваше приключение не окончено": "Твоя пригода ще не завершена",
		"Спать можно только ночью": "Спати можна лише вночі",
		"Все игроки легли спать. Наступило утро!": "Усі гравці заснули. Настав ранок!",
		"Открыть инвентарь": "Відкрити інвентар",
		"Witty Alien": "Witty Alien",
		"Nokia 3310": "Nokia 3310"
	},
	"en": {
		"Трава": "Grass",
		"Земля": "Dirt",
		"Камень": "Stone",
		"Бревно": "Log",
		"Листва": "Leaves",
		"Доски": "Planks",
		"Верстак": "Crafting Table",
		"Угольная руда": "Coal Ore",
		"Железная руда": "Iron Ore",
		"Палка": "Stick",
		"Деревянная кирка": "Wooden Pickaxe",
		"Пашня": "Farmland",
		"Деревянная лопата": "Wooden Shovel",
		"Деревянный меч": "Wooden Sword",
		"Деревянный топор": "Wooden Axe",
		"Деревянная мотыга": "Wooden Hoe",
		"Семена пшеницы": "Wheat Seeds",
		"Семена картофеля": "Potato Seeds",
		"Семена свёклы": "Beetroot Seeds",
		"Пшеница": "Wheat",
		"Картофель": "Potato",
		"Свёкла": "Beetroot",
		"Шлем": "Helmet",
		"Нагрудник": "Chestplate",
		"Поножи": "Leggings",
		"Ботинки": "Boots",
		"Щит": "Shield",
		"Дверь": "Door",
		"Печь": "Furnace",
		"Каменная кирка": "Stone Pickaxe",
		"Каменная лопата": "Stone Shovel",
		"Каменный меч": "Stone Sword",
		"Каменный топор": "Stone Axe",
		"Каменная мотыга": "Stone Hoe",
		"Каменный шлем": "Stone Helmet",
		"Каменный нагрудник": "Stone Chestplate",
		"Каменные поножи": "Stone Leggings",
		"Каменные ботинки": "Stone Boots",
		"Каменный щит": "Stone Shield",
		"Уголь": "Coal",
		"Железный слиток": "Iron Ingot",
		"Железо": "Iron",
		"Сундук": "Chest",
		"Железная кирка": "Iron Pickaxe",
		"Железная лопата": "Iron Shovel",
		"Железный меч": "Iron Sword",
		"Железный топор": "Iron Axe",
		"Железная мотыга": "Iron Hoe",
		"Железный шлем": "Iron Helmet",
		"Железный нагрудник": "Iron Chestplate",
		"Железные поножи": "Iron Leggings",
		"Железные ботинки": "Iron Boots",
		"Сырая свинина": "Raw Pork",
		"Жареная свинина": "Cooked Pork",
		"Гнилая плоть": "Rotten Flesh",
		"Приготовленная плоть": "Cooked Flesh",
		"Алмазная руда": "Diamond Ore",
		"Алмаз": "Diamond",
		"Алмазная кирка": "Diamond Pickaxe",
		"Алмазный меч": "Diamond Sword",
		"Алмазный топор": "Diamond Axe",
		"Алмазная лопата": "Diamond Shovel",
		"Стекло": "Glass",
		"Рельсы": "Rails",
		"Вагонетка": "Minecart",
		"Алмазная мотыга": "Diamond Hoe",
		"Алмазный шлем": "Diamond Helmet",
		"Алмазный нагрудник": "Diamond Chestplate",
		"Алмазные поножи": "Diamond Leggings",
		"Алмазные ботинки": "Diamond Boots",
		"Алмазный щит": "Diamond Shield",
		"Кровать": "Bed",
		"Кость": "Bone",
		"Факел": "Torch",
		"Песок": "Sand",
		"Гравий": "Gravel",
		"Светящийся блок": "Glow Block",
		"Музыкальный проигрыватель": "Jukebox",
		"Пластинка «Рассвет»": "Music Disc: Dawn",
		"Пластинка «Лес»": "Music Disc: Forest",
		"Пластинка «Пещера»": "Music Disc: Cave",
		"Пластинка «Море»": "Music Disc: Sea",
		"Пластинка «Звёзды»": "Music Disc: Stars",
		"Лук": "Bow",
		"Паутина": "Cobweb",
		"Яйцо призыва скелета": "Skeleton Spawn Egg",
		"Яйцо призыва свиньи": "Pig Spawn Egg",
		"Яйцо призыва паука": "Spider Spawn Egg",
		"Яйцо призыва зомби": "Zombie Spawn Egg",
		"Лодка": "Boat",
		"Снег": "Snow",
		"Плот 5×8": "Raft 5×8",
		"Карта сокровищ": "Treasure Map",
		"Неизвестный предмет": "Unknown item",
		"Лингвист": "Linguist",
		"Оборотень": "Shapeshifter",
		"Гусачок": "Little Goose",
		"Самые быстрые победы Магнуса Карлсена": "Magnus Carlsen’s Fastest Wins",
		"Самые быстрые проигрыши Магнуса Карлсена": "Magnus Carlsen’s Fastest Losses",
		"Бесчувственный": "Heartless",
		"Пацифист": "Pacifist",
		"Грядочник": "Gardener",
		"Дровосек": "Lumberjack",
		"Медальник": "Medal Collector",
		"Коллекционер": "Collector",
		"Игрок": "Player",
		"Инвентарь — Креатив": "Inventory — Creative",
		"Креатив включён": "Creative mode enabled",
		"Креатив выключен": "Creative mode disabled",
		"Пустая рука": "Empty hand",
		"Чат DareCraft": "DareCraft Chat",
		"Нажми T, чтобы открыть чат. Команды начинаются с /": "Press T to open chat. Commands start with /",
		"Закрыть чат": "Close chat",
		"Возродиться": "Respawn",
		"Ваше приключение не окончено": "Your adventure is not over",
		"Спать можно только ночью": "You can only sleep at night",
		"Все игроки легли спать. Наступило утро!": "Everyone slept. Morning has arrived!",
		"Открыть инвентарь": "Open inventory",
		"Witty Alien": "Witty Alien",
		"Nokia 3310": "Nokia 3310"
	}
}

func _ready() -> void:
	var cfg := ConfigFile.new()
	if cfg.load(LANGUAGE_PATH) == OK:
		set_language(str(cfg.get_value("general", "language", "ru")), false)

func tr_key(key: String) -> String:
	var table: Dictionary = TEXTS.get(language, TEXTS["ru"])
	return str(table.get(key, TEXTS["ru"].get(key, key)))

func translate_text(value: String) -> String:
	if language == "ru":
		return value
	var tables: Array = [UI_TRANSLATIONS.get(language, {}), GAME_TRANSLATIONS.get(language, {})]
	for table_variant in tables:
		var table: Dictionary = table_variant
		if table.has(value):
			return str(table[value])
		# Translate labels with appended values while preserving the dynamic part.
		for source in table.keys():
			if value.begins_with(str(source) + ": "):
				return str(table[source]) + value.substr(str(source).length())
	return value

func _localized_original(control: Control, meta_key: String, current_value: String) -> String:
	if not control.has_meta(meta_key):
		control.set_meta(meta_key, current_value)
	return str(control.get_meta(meta_key, current_value))

func apply_to_tree(root: Node) -> void:
	if root == null:
		return
	for item in root.find_children("*", "Control", true, false):
		# OptionButton may inherit Button, so handle its popup entries first.
		if item is OptionButton:
			var option := item as OptionButton
			option.text = translate_text(_localized_original(option, "_loc_text", option.text))
			for index in option.item_count:
				var original_text: String
				if option.has_meta("_loc_item_%d" % index):
					original_text = str(option.get_meta("_loc_item_%d" % index))
				else:
					original_text = option.get_item_text(index)
					option.set_meta("_loc_item_%d" % index, original_text)
				option.set_item_text(index, translate_text(original_text))
		elif item is Button:
			var button := item as Button
			button.text = translate_text(_localized_original(button, "_loc_text", button.text))
			button.tooltip_text = translate_text(_localized_original(button, "_loc_tooltip", button.tooltip_text))
		elif item is Label:
			var label := item as Label
			label.text = translate_text(_localized_original(label, "_loc_text", label.text))
		elif item is LineEdit:
			var line_edit := item as LineEdit
			line_edit.placeholder_text = translate_text(_localized_original(line_edit, "_loc_placeholder", line_edit.placeholder_text))

func set_language(value: String, save_value: bool = true) -> void:
	if not TEXTS.has(value):
		return
	var changed := language != value
	language = value
	if save_value:
		var cfg := ConfigFile.new()
		cfg.set_value("general", "language", language)
		var err := cfg.save(LANGUAGE_PATH)
		if err != OK:
			push_warning("Не удалось сохранить язык интерфейса")
	if changed:
		language_changed.emit(language)
