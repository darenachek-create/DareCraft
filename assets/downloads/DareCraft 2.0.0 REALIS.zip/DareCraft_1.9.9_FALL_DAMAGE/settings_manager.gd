extends Node

const SETTINGS_PATH := "user://darecraft_settings.cfg"
var ui_theme: String = "classic"
var mobile_button_scale: float = 1.0
var mobile_button_opacity: float = 0.82

func _ready() -> void:
	var cfg := ConfigFile.new()
	if cfg.load(SETTINGS_PATH) == OK:
		ui_theme = str(cfg.get_value("ui", "theme", "classic"))
		mobile_button_scale = clampf(float(cfg.get_value("mobile", "button_scale", 1.0)), 0.7, 1.4)
		mobile_button_opacity = clampf(float(cfg.get_value("mobile", "button_opacity", 0.82)), 0.25, 1.0)

func save_settings() -> void:
	var cfg := ConfigFile.new()
	cfg.set_value("ui", "theme", ui_theme)
	cfg.set_value("mobile", "button_scale", mobile_button_scale)
	cfg.set_value("mobile", "button_opacity", mobile_button_opacity)
	var err := cfg.save(SETTINGS_PATH)
	if err != OK:
		push_warning("Не удалось сохранить настройки DareCraft")

func set_ui_theme(value: String) -> void:
	if value not in ["classic", "neon", "retro"]:
		return
	ui_theme = value
	save_settings()
