extends CharacterBody3D

const GRAVITY := 20.0
const SPEED := 2.0
const RANGE := 13.0
const ARROW_SPEED := 13.0
const ARROW_DAMAGE := 2.0
var target: Node3D
var world_controller: Node
var health := 9.0
var shot_timer := 1.5
var flash_timer := 0.0
var materials: Array = []
var bow_root: Node3D
var left_arm_pivot: Node3D
var right_arm_pivot: Node3D
var left_leg_pivot: Node3D
var right_leg_pivot: Node3D
var step_phase := 0.0
var shot_flash := 0.0
var attack_anim_timer := 0.0

func _ready() -> void:
	name = "NightSkeleton"
	collision_layer = 1
	collision_mask = 1
	var col := CollisionShape3D.new()
	var shape := CapsuleShape3D.new()
	shape.radius = 0.32
	shape.height = 1.8
	col.shape = shape
	col.position.y = 0.9
	add_child(col)
	var bone_mat := _mat(Color(0.82, 0.80, 0.68))
	var dark_mat := _mat(Color(0.12, 0.14, 0.17))
	var wood_mat := _mat(Color(0.38, 0.20, 0.085))
	var wood_light := _mat(Color(0.64, 0.39, 0.17))
	var string_mat := _mat(Color(0.88, 0.84, 0.72))
	_add_box(Vector3(0.55,0.62,0.35),Vector3(0,1.25,0),bone_mat)
	_add_box(Vector3(0.46,0.46,0.42),Vector3(0,1.82,0),bone_mat)
	_add_box(Vector3(0.08,0.07,0.04),Vector3(-0.12,1.84,0.22),dark_mat)
	_add_box(Vector3(0.08,0.07,0.04),Vector3(0.12,1.84,0.22),dark_mat)
	left_arm_pivot = _make_limb_pivot(Vector3(-0.37, 1.48, 0.0), Vector3(0.13, 0.72, 0.14), bone_mat)
	right_arm_pivot = _make_limb_pivot(Vector3(0.37, 1.48, 0.0), Vector3(0.13, 0.72, 0.14), bone_mat)
	left_leg_pivot = _make_limb_pivot(Vector3(-0.16, 0.82, 0.0), Vector3(0.16, 0.75, 0.18), bone_mat)
	right_leg_pivot = _make_limb_pivot(Vector3(0.16, 0.82, 0.0), Vector3(0.16, 0.75, 0.18), bone_mat)
	_build_bow(wood_mat, wood_light, string_mat)
	for n in find_children("*", "MeshInstance3D", true, false):
		materials.append([n, n.material_override])

func _mat(color: Color) -> StandardMaterial3D:
	var mat := StandardMaterial3D.new()
	mat.albedo_color = color
	mat.roughness = 1.0
	return mat

func _add_box(size: Vector3, pos: Vector3, mat: Material, parent: Node3D = self) -> MeshInstance3D:
	var m := MeshInstance3D.new()
	var b := BoxMesh.new()
	b.size = size
	m.mesh = b
	m.position = pos
	m.material_override = mat
	parent.add_child(m)
	return m

func _build_bow(wood: StandardMaterial3D, light: StandardMaterial3D, string_mat: StandardMaterial3D) -> void:
	# A curved wooden bow held in front of the skeleton's right arm.
	bow_root = Node3D.new()
	bow_root.position = Vector3(0.48, 1.28, 0.30)
	add_child(bow_root)
	var upper := _add_box(Vector3(0.075, 0.38, 0.075), Vector3(-0.07, 0.25, 0.0), wood, bow_root)
	upper.rotation.z = -0.36
	var lower := _add_box(Vector3(0.075, 0.38, 0.075), Vector3(-0.07, -0.25, 0.0), wood, bow_root)
	lower.rotation.z = 0.36
	_add_box(Vector3(0.09, 0.16, 0.09), Vector3(0.0, 0.0, 0.015), light, bow_root)
	_add_box(Vector3(0.018, 0.78, 0.018), Vector3(0.12, 0.0, 0.0), string_mat, bow_root)


func _make_limb_pivot(pivot_pos: Vector3, limb_size: Vector3, mat: Material) -> Node3D:
	var pivot := Node3D.new()
	pivot.position = pivot_pos
	add_child(pivot)
	_add_box(limb_size, Vector3(0.0, -limb_size.y * 0.5, 0.0), mat, pivot)
	return pivot

func _animate_walk(delta: float, movement: Vector3) -> void:
	var horizontal_speed := Vector2(movement.x, movement.z).length()
	if horizontal_speed > 0.08:
		step_phase += delta * 8.5 * clampf(horizontal_speed / SPEED, 0.4, 1.8)
		var swing := sin(step_phase)
		left_leg_pivot.rotation.x = swing * 0.62
		right_leg_pivot.rotation.x = -swing * 0.62
		left_arm_pivot.rotation.x = -swing * 0.28
		right_arm_pivot.rotation.x = swing * 0.28
	else:
		left_leg_pivot.rotation.x = move_toward(left_leg_pivot.rotation.x, 0.0, delta * 5.0)
		right_leg_pivot.rotation.x = move_toward(right_leg_pivot.rotation.x, 0.0, delta * 5.0)
		left_arm_pivot.rotation.x = move_toward(left_arm_pivot.rotation.x, 0.0, delta * 5.0)
		right_arm_pivot.rotation.x = move_toward(right_arm_pivot.rotation.x, 0.0, delta * 5.0)

func _physics_process(delta: float) -> void:
	if flash_timer > 0.0:
		flash_timer -= delta
		if flash_timer <= 0.0:
			for e in materials:
				if is_instance_valid(e[0]): e[0].material_override = e[1]
	if has_meta("network_remote_mob") and bool(get_meta("network_remote_mob")):
		var remote_velocity: Vector3 = get_meta("network_velocity", Vector3.ZERO)
		var remote_target: Vector3 = get_meta("network_target_position", global_position)
		global_position = global_position.lerp(remote_target, clampf(delta * 12.0, 0.0, 1.0))
		rotation.y = lerp_angle(rotation.y, float(get_meta("network_target_yaw", rotation.y)), clampf(delta * 12.0, 0.0, 1.0))
		velocity = remote_velocity
		_animate_walk(delta, remote_velocity)
		if bool(get_meta("network_attack", false)):
			right_arm_pivot.rotation.x = move_toward(right_arm_pivot.rotation.x, -0.85, delta * 10.0)
			if is_instance_valid(bow_root): bow_root.rotation.z = move_toward(bow_root.rotation.z, -0.22, delta * 10.0)
		else:
			right_arm_pivot.rotation.x = move_toward(right_arm_pivot.rotation.x, 0.0, delta * 7.0)
			if is_instance_valid(bow_root): bow_root.rotation.z = move_toward(bow_root.rotation.z, 0.0, delta * 7.0)
		return
	attack_anim_timer = maxf(0.0, attack_anim_timer - delta)
	if not is_instance_valid(target) or not is_instance_valid(world_controller): return
	if not is_on_floor(): velocity.y -= GRAVITY * delta
	else: velocity.y = -0.2
	var to_player := target.global_position - global_position
	to_player.y = 0.0
	var dist := to_player.length()
	var dir := to_player.normalized() if dist > 0.1 else Vector3.ZERO
	if dist > 7.0:
		velocity.x = dir.x * SPEED
		velocity.z = dir.z * SPEED
	else:
		velocity.x = move_toward(velocity.x, 0.0, delta * 5.0)
		velocity.z = move_toward(velocity.z, 0.0, delta * 5.0)
	if dir.length() > 0.05:
		rotation.y = lerp_angle(rotation.y, atan2(dir.x, dir.z), delta * 6.0)
	move_and_slide()
	_animate_walk(delta, velocity)
	shot_timer -= delta
	if dist <= RANGE and shot_timer <= 0.0:
		shot_timer = randf_range(2.0, 3.0)
		var ray_start := global_position + Vector3(0, 1.45, 0)
		var ray_end := target.global_position + Vector3(0, 0.9, 0)
		var query := PhysicsRayQueryParameters3D.create(ray_start, ray_end)
		query.exclude = [get_rid()]
		query.collision_mask = 1
		var hit := get_world_3d().direct_space_state.intersect_ray(query)
		if not hit.is_empty() and hit.get("collider") == target:
			_shoot_arrow(ray_start, ray_end)

func _shoot_arrow(start: Vector3, aim: Vector3) -> void:
	var projectile := Node3D.new()
	projectile.set_script(load("res://arrow_projectile.gd"))
	var direction := (aim - start).normalized()
	projectile.set("velocity", direction * ARROW_SPEED)
	projectile.set("target", target)
	projectile.set("world_controller", world_controller)
	projectile.set("shooter", self)
	projectile.set("damage", ARROW_DAMAGE)
	get_parent().add_child(projectile)
	projectile.global_position = start + direction * 0.55
	attack_anim_timer = 0.36
	if is_instance_valid(bow_root):
		bow_root.rotation.z = -0.18
		var tween := create_tween()
		tween.tween_property(bow_root, "rotation:z", 0.0, 0.16)
	if is_instance_valid(right_arm_pivot):
		right_arm_pivot.rotation.x = -0.75
		var arm_tween := create_tween()
		arm_tween.tween_property(right_arm_pivot, "rotation:x", 0.0, 0.28)

func receive_hit(damage: float) -> bool:
	flash_timer = 0.18
	var flash := StandardMaterial3D.new()
	flash.albedo_color = Color(1.0, 0.25, 0.22)
	flash.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	for e in materials:
		if is_instance_valid(e[0]): e[0].material_override = flash
	health -= damage
	if health <= 0.0:
		if is_instance_valid(world_controller):
			if randf() < 0.90:
				world_controller.add_item(73, randi_range(1, 2))
			if randf() < 0.20:
				world_controller.add_item(84, 1)
			if world_controller.has_method("on_mob_killed"):
				world_controller.on_mob_killed(self, true)
		if is_instance_valid(world_controller) and world_controller.has_method("spawn_mob_ragdoll"):
			world_controller.spawn_mob_ragdoll(self)
		queue_free()
	return true
