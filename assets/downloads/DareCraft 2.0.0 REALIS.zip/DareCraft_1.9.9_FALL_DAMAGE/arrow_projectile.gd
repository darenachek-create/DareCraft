extends Node3D

const GRAVITY := 0.8
const MAX_LIFETIME := 3.5
var velocity := Vector3.ZERO
var target: Node3D
var world_controller: Node
var shooter: CharacterBody3D
var damage := 2.0
var player_fired := false
var lifetime := MAX_LIFETIME

func _ready() -> void:
	_build_arrow_visual()
	if velocity.length() > 0.1:
		look_at(global_position + velocity.normalized(), Vector3.UP)

func _build_arrow_visual() -> void:
	var shaft_mat := StandardMaterial3D.new()
	shaft_mat.albedo_color = Color(0.42, 0.25, 0.11)
	shaft_mat.roughness = 1.0
	var head_mat := StandardMaterial3D.new()
	head_mat.albedo_color = Color(0.72, 0.75, 0.78)
	head_mat.metallic = 0.35
	var feather_mat := StandardMaterial3D.new()
	feather_mat.albedo_color = Color(0.74, 0.18, 0.13)
	var shaft := MeshInstance3D.new()
	var shaft_mesh := BoxMesh.new()
	shaft_mesh.size = Vector3(0.035, 0.035, 0.62)
	shaft.mesh = shaft_mesh
	shaft.material_override = shaft_mat
	add_child(shaft)
	var tip := MeshInstance3D.new()
	var cone := ConeMesh.new()
	cone.top_radius = 0.0
	cone.bottom_radius = 0.075
	cone.height = 0.18
	tip.mesh = cone
	tip.position = Vector3(0, 0, -0.36)
	tip.rotation.x = -PI / 2.0
	tip.material_override = head_mat
	add_child(tip)
	for side in [-1.0, 1.0]:
		var feather := MeshInstance3D.new()
		var feather_mesh := BoxMesh.new()
		feather_mesh.size = Vector3(0.10, 0.025, 0.12)
		feather.mesh = feather_mesh
		feather.position = Vector3(side * 0.035, 0, 0.26)
		feather.rotation.z = side * 0.25
		feather.material_override = feather_mat
		add_child(feather)

func _physics_process(delta: float) -> void:
	lifetime -= delta
	if lifetime <= 0.0:
		queue_free()
		return
	var from := global_position
	var next := from + velocity * delta
	var query := PhysicsRayQueryParameters3D.create(from, next)
	query.collision_mask = 1
	if is_instance_valid(shooter):
		query.exclude = [shooter.get_rid()]
	var hit := get_world_3d().direct_space_state.intersect_ray(query)
	if not hit.is_empty():
		if player_fired:
			var hit_node: Node = hit.get("collider") as Node
			while hit_node != null and not hit_node.has_method("receive_hit"):
				hit_node = hit_node.get_parent()
			if hit_node != null:
				hit_node.receive_hit(damage)
		elif is_instance_valid(target) and hit.get("collider") == target and is_instance_valid(world_controller):
			world_controller.take_damage(damage)
		queue_free()
		return
	global_position = next
	velocity.y -= GRAVITY * delta
	if velocity.length() > 0.1:
		look_at(global_position + velocity.normalized(), Vector3.UP)
