extends Node

signal achievement_unlocked(id: String, title: String, description: String, is_global: bool)

const GLOBAL_PATH := "user://darecraft_achievements.cfg"
const WORLD_DIR := "user://world_achievements"

const DEFINITIONS := {
	"linguist": {"title": "Лингвист", "description": "Изменить язык в главном меню", "scope": "global"},
	"werewolf": {"title": "Оборотень", "description": "Изменить скин в главном меню", "scope": "global"},
	"gusachok": {"title": "Гусачок", "description": "Установить ник с goose, гусь или гусений", "scope": "global"},
	"magnus_wins": {"title": "Самые быстрые победы Магнуса Карлсена", "description": "Победить 5 враждебных мобов менее чем за 15 секунд", "scope": "world"},
	"magnus_loses": {"title": "Самые быстрые проигрыши Магнуса Карлсена", "description": "Умереть в первые 10 секунд после создания мира", "scope": "world"},
	"witty_alien": {"title": "Witty Alien", "description": "Добраться до Марса", "scope": "world"},
	"nokia_3310": {"title": "Nokia 3310", "description": "Упасть на камень, выжить с 1 HP и разбить камень под собой", "scope": "world"},
	"emotionless": {"title": "Бесчувственный", "description": "Убивать хотя бы одного моба каждую минуту 10 минут подряд", "scope": "world"},
	"pacifist": {"title": "Пацифист", "description": "Прожить 15 минут без убийств", "scope": "world"},
	"farmer": {"title": "Грядочник", "description": "Держать пшеницу в инвентаре 10 минут подряд", "scope": "world"},
	"lumberjack": {"title": "Дровосек", "description": "Иметь в инвентаре не менее 3 стаков брёвен", "scope": "world"},
	"collector": {"title": "Коллекционер", "description": "Иметь хотя бы по одному экземпляру каждого предмета в своих хранилищах", "scope": "world"},
	"medalnik": {"title": "Медальник", "description": "Собрать все доступные достижения", "scope": "world"}
}

# «Медальник» включает Witty Alien: без открытия Марса собрать все достижения нельзя.
const MEDALNIK_REQUIRED := [
	"magnus_wins", "magnus_loses", "witty_alien", "nokia_3310", "emotionless", "pacifist",
	"farmer", "lumberjack", "collector"
]

var active_world: String = ""
var global_unlocked: Dictionary = {}
var world_unlocked: Dictionary = {}

func _ready() -> void:
	_load_global()

func begin_world(world_name: String) -> void:
	active_world = world_name.strip_edges()
	world_unlocked.clear()
	if active_world.is_empty():
		return
	var cfg := ConfigFile.new()
	if cfg.load(_world_path(active_world)) == OK:
		var saved: Variant = cfg.get_value("unlocked", "ids", {})
		if saved is Dictionary:
			world_unlocked = saved.duplicate(true)

func unlock(id: String) -> bool:
	if not DEFINITIONS.has(id):
		return false
	var definition: Dictionary = DEFINITIONS[id]
	var is_global := str(definition["scope"]) == "global"
	var target: Dictionary = global_unlocked if is_global else world_unlocked
	if bool(target.get(id, false)):
		return false
	target[id] = true
	if is_global:
		global_unlocked = target
		_save_global()
	else:
		world_unlocked = target
		_save_world()
	var title := str(definition["title"])
	var description := str(definition["description"])
	achievement_unlocked.emit(id, title, description, is_global)
	if not is_global and id != "medalnik" and _has_all_medalnik_requirements():
		unlock("medalnik")
	return true

func is_unlocked(id: String) -> bool:
	if not DEFINITIONS.has(id):
		return false
	if str(DEFINITIONS[id]["scope"]) == "global":
		return bool(global_unlocked.get(id, false))
	return bool(world_unlocked.get(id, false))

func _has_all_medalnik_requirements() -> bool:
	for id in MEDALNIK_REQUIRED:
		if not bool(world_unlocked.get(id, false)):
			return false
	for id in ["linguist", "werewolf", "gusachok"]:
		if not bool(global_unlocked.get(id, false)):
			return false
	return true

func _load_global() -> void:
	var cfg := ConfigFile.new()
	if cfg.load(GLOBAL_PATH) == OK:
		var saved: Variant = cfg.get_value("unlocked", "ids", {})
		if saved is Dictionary:
			global_unlocked = saved.duplicate(true)

func _save_global() -> void:
	var cfg := ConfigFile.new()
	cfg.set_value("unlocked", "ids", global_unlocked)
	var err := cfg.save(GLOBAL_PATH)
	if err != OK:
		push_warning("Не удалось сохранить глобальные достижения")

func _save_world() -> void:
	if active_world.is_empty():
		return
	var absolute_dir := ProjectSettings.globalize_path(WORLD_DIR)
	var dir_err := DirAccess.make_dir_recursive_absolute(absolute_dir)
	if dir_err != OK and dir_err != ERR_ALREADY_EXISTS:
		push_warning("Не удалось создать папку достижений мира")
		return
	var cfg := ConfigFile.new()
	cfg.set_value("unlocked", "ids", world_unlocked)
	var err := cfg.save(_world_path(active_world))
	if err != OK:
		push_warning("Не удалось сохранить достижения мира")

func _world_path(world_name: String) -> String:
	var safe_name := world_name.strip_edges().validate_filename()
	return WORLD_DIR + "/" + safe_name + ".cfg"
