extends CharacterBody3D

const GRAVITY := 20.0
const WALK_SPEED := 2.1
const RUSH_SPEED := 7.0
const RUSH_DURATION := 0.62
const RUSH_COOLDOWN := 4.8
const HIT_DISTANCE := 1.45
const JUMP_FORCE := 6.0

@export var target: Node3D
var world_controller: Node
var health := 10.0
var rush_timer := 0.0
var rush_cooldown := 2.0
var attack_cooldown := 0.0
var attack_anim_timer := 0.0
var jump_timer := 2.0
var step_phase := 0.0
var left_leg: Node3D
var right_leg: Node3D
var left_arm: Node3D
var right_arm: Node3D
var texture_materials: Dictionary = {}
var flash_timer := 0.0
var mesh_materials: Array = []

func _ready() -> void:
	name = "NightZombie"
	collision_layer = 1
	collision_mask = 1
	var collision := CollisionShape3D.new()
	var capsule := CapsuleShape3D.new()
	capsule.radius = 0.38
	capsule.height = 1.85
	collision.shape = capsule
	collision.position.y = 0.92
	add_child(collision)
	_build_zombie_model()
	for node in find_children("*", "MeshInstance3D", true, false):
		var mesh := node as MeshInstance3D
		mesh_materials.append([mesh, mesh.material_override])

func _texture_mat(region: Rect2, tint: Color = Color.WHITE) -> StandardMaterial3D:
	var key := str(region) + str(tint)
	if texture_materials.has(key): return texture_materials[key]
	var mat := StandardMaterial3D.new()
	var tex := load("res://zombie_uv_texture.png") as Texture2D
	if tex != null:
		mat.albedo_texture = tex
	mat.albedo_color = tint * Color(0.82, 1.0, 0.82, 1.0)
	mat.texture_filter = BaseMaterial3D.TEXTURE_FILTER_NEAREST
	mat.uv1_offset = Vector3(region.position.x, region.position.y, 0.0)
	mat.uv1_scale = Vector3(region.size.x, region.size.y, 1.0)
	mat.roughness = 1.0
	texture_materials[key] = mat
	return mat

func _part(parent: Node3D, size: Vector3, pos: Vector3, region: Rect2) -> MeshInstance3D:
	var mesh := MeshInstance3D.new()
	var box := BoxMesh.new()
	box.size = size
	mesh.mesh = box
	mesh.position = pos
	mesh.material_override = _texture_mat(region)
	parent.add_child(mesh)
	return mesh

func _build_zombie_model() -> void:
	var green_head := Rect2(Vector2(0.015, 0.07), Vector2(0.25, 0.20))
	var green_body := Rect2(Vector2(0.02, 0.25), Vector2(0.35, 0.18))
	var arm_region := Rect2(Vector2(0.43, 0.25), Vector2(0.28, 0.17))
	var leg_region := Rect2(Vector2(0.18, 0.60), Vector2(0.43, 0.20))
	var dark_region := Rect2(Vector2(0.20, 0.68), Vector2(0.35, 0.13))
	_part(self, Vector3(0.78, 0.82, 0.42), Vector3(0, 1.12, 0), green_body)
	_part(self, Vector3(0.58, 0.58, 0.56), Vector3(0, 1.86, 0), green_head)
	left_arm = Node3D.new(); left_arm.position = Vector3(-0.42, 1.42, 0); add_child(left_arm)
	_part(left_arm, Vector3(0.25, 0.78, 0.30), Vector3(-0.13, -0.30, 0), arm_region)
	right_arm = Node3D.new(); right_arm.position = Vector3(0.42, 1.42, 0); add_child(right_arm)
	_part(right_arm, Vector3(0.25, 0.78, 0.30), Vector3(0.13, -0.30, 0), arm_region)
	left_leg = Node3D.new(); left_leg.position = Vector3(-0.22, 0.78, 0); add_child(left_leg)
	_part(left_leg, Vector3(0.31, 0.78, 0.34), Vector3(0, -0.38, 0), leg_region)
	right_leg = Node3D.new(); right_leg.position = Vector3(0.22, 0.78, 0); add_child(right_leg)
	_part(right_leg, Vector3(0.31, 0.78, 0.34), Vector3(0, -0.38, 0), dark_region)
	var eye_mat := StandardMaterial3D.new()
	eye_mat.albedo_color = Color(0.9, 0.08, 0.05)
	eye_mat.emission_enabled = true
	eye_mat.emission = Color(0.8, 0.025, 0.01)
	eye_mat.emission_energy_multiplier = 1.3
	# Передняя сторона модели — +Z, как и направление поворота моба.
	for x in [-0.15, 0.15]:
		var eye := MeshInstance3D.new()
		var eye_box := BoxMesh.new(); eye_box.size = Vector3(0.09, 0.07, 0.035)
		eye.mesh = eye_box; eye.position = Vector3(x, 1.91, 0.292)
		eye.material_override = eye_mat; add_child(eye)
	var eye_light := SpotLight3D.new()
	eye_light.position = Vector3(0, 1.78, 0.34)
	eye_light.rotation.y = PI # SpotLight3D светит вдоль -Z, разворачиваем на +Z.
	eye_light.light_color = Color(1.0, 0.12, 0.08)
	eye_light.light_energy = 0.45
	eye_light.spot_range = 5.0
	eye_light.spot_angle = 35.0
	add_child(eye_light)

func _physics_process(delta: float) -> void:
	if flash_timer > 0.0:
		flash_timer -= delta
		if flash_timer <= 0.0: _restore_color()
	if (has_meta("network_remote_mob") and bool(get_meta("network_remote_mob"))):
		var remote_velocity: Vector3 = get_meta("network_velocity", Vector3.ZERO)
		var remote_target: Vector3 = get_meta("network_target_position", global_position)
		global_position = global_position.lerp(remote_target, clampf(delta * 12.0, 0.0, 1.0))
		rotation.y = lerp_angle(rotation.y, float(get_meta("network_target_yaw", rotation.y)), clampf(delta * 12.0, 0.0, 1.0))
		velocity = remote_velocity
		_update_walk_animation(delta)
		if bool(get_meta("network_attack", false)):
			left_arm.rotation.x = move_toward(left_arm.rotation.x, -1.0, delta * 12.0)
			right_arm.rotation.x = move_toward(right_arm.rotation.x, -1.0, delta * 12.0)
		return
	attack_anim_timer = maxf(0.0, attack_anim_timer - delta)
	if not is_instance_valid(target) or not is_instance_valid(world_controller): return
	attack_cooldown = maxf(0.0, attack_cooldown - delta)
	rush_cooldown = maxf(0.0, rush_cooldown - delta)
	jump_timer -= delta
	if not is_on_floor(): velocity.y -= GRAVITY * delta
	else: velocity.y = -0.2
	var to_player := target.global_position - global_position
	to_player.y = 0.0
	var distance := to_player.length()
	var direction := to_player.normalized() if distance > 0.01 else Vector3.ZERO
	if rush_timer <= 0.0 and rush_cooldown <= 0.0 and distance > 2.2 and distance < 13.0:
		rush_timer = RUSH_DURATION
		rush_cooldown = RUSH_COOLDOWN
	if jump_timer <= 0.0 and is_on_floor() and distance < 12.0:
		velocity.y = JUMP_FORCE
		jump_timer = randf_range(2.5, 5.0)
	var current_speed := RUSH_SPEED if rush_timer > 0.0 else WALK_SPEED
	if rush_timer > 0.0: rush_timer = maxf(0.0, rush_timer - delta)
	velocity.x = direction.x * current_speed
	velocity.z = direction.z * current_speed
	if direction.length() > 0.05:
		rotation.y = lerp_angle(rotation.y, atan2(direction.x, direction.z), delta * 7.0)
	move_and_slide()
	_update_walk_animation(delta)
	if distance <= HIT_DISTANCE and attack_cooldown <= 0.0:
		world_controller.take_damage(5.0 if is_rushing() else 1.0)
		attack_cooldown = 1.15
		attack_anim_timer = 0.32

func _update_walk_animation(delta: float) -> void:
	var speed := Vector2(velocity.x, velocity.z).length()
	if is_on_floor() and speed > 0.1:
		step_phase += delta * 8.0 * (speed / WALK_SPEED)
		var swing := sin(step_phase)
		left_leg.rotation.x = swing * 0.65
		right_leg.rotation.x = -swing * 0.65
		left_arm.rotation.x = -swing * 0.35
		right_arm.rotation.x = swing * 0.35
	else:
		left_leg.rotation.x = move_toward(left_leg.rotation.x, 0.0, delta * 5.0)
		right_leg.rotation.x = move_toward(right_leg.rotation.x, 0.0, delta * 5.0)
		left_arm.rotation.x = move_toward(left_arm.rotation.x, 0.0, delta * 5.0)
		right_arm.rotation.x = move_toward(right_arm.rotation.x, 0.0, delta * 5.0)
	if attack_anim_timer > 0.0:
		left_arm.rotation.x = move_toward(left_arm.rotation.x, -1.0, delta * 12.0)
		right_arm.rotation.x = move_toward(right_arm.rotation.x, -1.0, delta * 12.0)

func is_rushing() -> bool:
	return rush_timer > 0.0

func _flash_red() -> void:
	flash_timer = 1.0
	var red := StandardMaterial3D.new()
	red.albedo_color = Color(1.0, 0.06, 0.06)
	red.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	for entry in mesh_materials:
		var mesh: MeshInstance3D = entry[0]
		if is_instance_valid(mesh): mesh.material_override = red

func _restore_color() -> void:
	for entry in mesh_materials:
		var mesh: MeshInstance3D = entry[0]
		if is_instance_valid(mesh): mesh.material_override = entry[1]

func receive_hit(damage: float) -> bool:
	if is_rushing(): return false
	_flash_red()
	var away := global_position - target.global_position if is_instance_valid(target) else Vector3.BACK
	away.y = 0.0
	if away.length() > 0.01: velocity += away.normalized() * 2.2 + Vector3.UP * 0.8
	health -= damage
	if health <= 0.0:
		if is_instance_valid(world_controller):
			world_controller.add_item(55, randi_range(1, 2))
			if world_controller.has_method("on_mob_killed"):
				world_controller.on_mob_killed(self, true)
		if is_instance_valid(world_controller) and world_controller.has_method("spawn_mob_ragdoll"):
			world_controller.spawn_mob_ragdoll(self)
		queue_free()
	return true
