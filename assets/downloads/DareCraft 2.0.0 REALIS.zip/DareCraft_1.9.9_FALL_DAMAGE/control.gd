extends Control

const GAME_SCENE := "res://minecraft.tscn"
const GAME_TITLE := "DareCraft"
const VERSION_TEXT := "DareCraft 2.0 MEGA VIBE — ALPHA 3 HOTFIX 1"
const WORLD := 60
const CONTROL_MODE_PC := 0
const CONTROL_MODE_MOBILE := 1
const CONTROL_SETTINGS_PATH := "user://darecraft_controls.cfg"
const SPLASH_TEXTS := [
	"Плот 5×8 переживёт даже этот релиз",
	"Сервер жив. Пока что.",
	"Баг? Это локальный артефакт.",
	"Скелет снова прошёл курсы снайпера",
	"Код написан после полуночи",
	"Гусь проверил. Гусь сомневается.",
	"Сундук был здесь секунду назад",
	"Рельсы поверх блока. Мы помним.",
	"Не копай вниз. Хотя ладно.",
	"В этом мире даже лаги строят дом",
	"Пять на восемь — размер мечты",
	"Пинг — это тоже игровой режим",
	"Сохранение сделай. Потом мемы.",
	"Кирпичи не задают вопросов",
	"Ночь длинная, факел короткий",
	"Кто-то опять приручил вагонетку",
	"Вода мокрая. Научно доказано.",
	"DareCraft: кубики с характером",
	"Если мир завис — любуйся пейзажем",
	"Скелет целился в прошлый вторник",
	"Тут мог быть туториал",
	"Крафт — это когда веришь в рецепт",
	"Не баг, а редкий биом",
	"Плот не тонет. Он думает.",
	"Хотфикс? Нет, хот-дог.",
	"Мобы тоже хотят выходной",
	"Координаты ведут к приключению",
	"Сундук мимик? Не открывай. Или открой.",
	"Бутылка принесла записку и вайб",
	"Поставь факел — станет уютнее",
	"Кто выключил солнце?",
	"В 3:00 даже чанки шепчут",
	"Апдейт большой, кофе маленький",
	"Где-то плачет один забытый блок",
	"Проверено на одном энтузиасте",
	"Сделано из пикселей и упрямства",
	"Hotline Miami позвонила. Мы не взяли.",
	"Неон включён. Маска надета.",
	"Слишком много загадок, мало патронов для принтера",
	"Postal-уровень бытового хаоса: найден",
	"Посылка доставлена. Смысл — нет.",
	"Почта принесла ещё один квест",
	"Minecraft? У нас кубы хотя бы знают своё место",
	"Копать бесконечно — это не контент, это смена",
	"У нас блоки квадратные, зато амбиции круглые",
	"Крипер хотя бы предупреждает. Иногда.",
	"Алмазная кирка не чинит дедлайны",
	"Стив, выйди из нашего биома",
	"Manhunt оставил странную кассету",
	"В подвале кто-то перемотал запись",
	"Не всякая тень — моб. Иногда это баг освещения.",
	"Тишина в шахте звучит подозрительно",
	"Секретный сигнал пойман на старом радио",
	"Маска — это просто ещё один скин. Наверное.",
	"Неоновые улицы? Нет, это просто редстоун не завезли",
	"Кто оставил следы у затонувшего корабля?",
	"Капитан скелет просит не трогать его сундук",
	"У этого мира есть второй слой. И третий.",
	"Сид принят. Реальность загружается.",
	"Случайный сид, намеренно странный мир",
	"Здесь даже рыбы знают секретный рецепт",
	"Не забудь поздороваться с жителями",
	"Торговец принимает уголь и хорошие шутки",
	"Факел — лучший друг темноты",
	"Сначала строй. Потом спрашивай, зачем.",
	"Пружинный блок: физика вышла из чата",
	"Нитро включено. Осторожно, впереди вода.",
	"Луна сегодня снижает гравитацию",
	"Дождь из свиней? Обычный вторник.",
	"Эта пластинка знает больше нас",
	"Удача — это когда стрела не застряла в потолке",
	"Пати собралась. План отсутствует.",
	"GG! Даже если проиграли мобу",
	"Эмоция выбрана. Репутация потеряна.",
	"Повелитель багов вошёл в мир",
	"Капитан плота на мостике",
	"Охотник за кладами опять заблудился",
	"Ночной выживальщик не спит",
	"Здесь нет pay-to-win. Только pay attention.",
	"Сделай скрин. Потом никто не поверит.",
	"Секретная дверь открывается хорошим настроением",
	"Если читаешь это — нажми на сплэш",
	"Слишком много кубов? Не бывает.",
	"Версия 2.0: теперь ещё больше причин строить",
	"Движок Godot, настроение — гусь",
	"Мир сохранён. Паника отменяется."
]

var noise := FastNoiseLite.new()
var cam: Camera3D
var angle := 0.0
var t_anim := 0.0
var main_box: VBoxContainer
var panel_wrap: PanelContainer
var settings_box: VBoxContainer
var scroll_settings: ScrollContainer
var worlds_box: VBoxContainer
var list_box: VBoxContainer
var name_edit: LineEdit
var seed_edit: LineEdit
var msg_label: Label
var vol_label: Label
var logo_node: Control
var splash_label: Label
var btn_textures := {}
var control_mode := CONTROL_MODE_PC
var control_pc_button: Button
var control_mobile_button: Button
var skin_status_label: Label
var skin_buttons: Array[Button] = []
var online_box: VBoxContainer
var relay_url_edit: LineEdit
var player_name_edit: LineEdit
var join_code_edit: LineEdit
var online_world_option: OptionButton
var online_status_label: Label
var language_status_label: Label
var theme_status_label: Label
var menu_achievement_layer: CanvasLayer
var menu_achievement_panel: PanelContainer
var menu_achievement_icon: Label
var menu_achievement_title: Label
var menu_achievement_description: Label
var menu_achievement_timer := 0.0

func _ready() -> void:
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	var darecraft_font: Font = load("res://DareCraftDisplay.ttf") as Font
	if darecraft_font != null:
		var font_theme := Theme.new()
		font_theme.default_font = darecraft_font
		theme = font_theme
	if not Achievements.achievement_unlocked.is_connected(_on_menu_achievement_unlocked):
		Achievements.achievement_unlocked.connect(_on_menu_achievement_unlocked)
	_make_menu_achievement_toast()
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	randomize()
	_load_control_mode()
	_load_network_settings()
	_load_selected_skin()
	if not Localization.language_changed.is_connected(_on_language_changed):
		Localization.language_changed.connect(_on_language_changed)
	noise.seed = randi()
	noise.frequency = 0.04
	_make_button_styles()
	_build_scenery()
	_add_vignette()
	_build_ui()
	Localization.apply_to_tree(self)
	_add_footer()
	# после заставки с картинкой меню плавно появляется из темноты
	if Global.fade_in_menu:
		Global.fade_in_menu = false
		_fade_in_from_black()


func _make_menu_achievement_toast() -> void:
	menu_achievement_layer = CanvasLayer.new()
	menu_achievement_layer.layer = 30
	add_child(menu_achievement_layer)
	menu_achievement_panel = PanelContainer.new()
	menu_achievement_panel.visible = false
	menu_achievement_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	menu_achievement_panel.set_anchors_preset(Control.PRESET_TOP_RIGHT)
	menu_achievement_panel.offset_left = -390.0
	menu_achievement_panel.offset_top = 22.0
	menu_achievement_panel.offset_right = -22.0
	menu_achievement_panel.offset_bottom = 112.0
	var style := StyleBoxFlat.new()
	style.bg_color = Color(0.035, 0.045, 0.065, 0.96)
	style.border_color = Color(0.95, 0.78, 0.25, 0.98)
	style.set_border_width_all(2)
	style.set_corner_radius_all(10)
	style.set_content_margin_all(10)
	menu_achievement_panel.add_theme_stylebox_override("panel", style)
	menu_achievement_layer.add_child(menu_achievement_panel)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 12)
	menu_achievement_panel.add_child(row)
	menu_achievement_icon = Label.new()
	menu_achievement_icon.text = "🏆"
	menu_achievement_icon.add_theme_font_size_override("font_size", 34)
	row.add_child(menu_achievement_icon)
	var col := VBoxContainer.new()
	col.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(col)
	var caption := Label.new()
	caption.text = "ДОСТИЖЕНИЕ ПОЛУЧЕНО"
	caption.add_theme_font_size_override("font_size", 11)
	caption.add_theme_color_override("font_color", Color(0.78, 0.82, 0.90))
	col.add_child(caption)
	menu_achievement_title = Label.new()
	menu_achievement_title.add_theme_font_size_override("font_size", 19)
	menu_achievement_title.add_theme_color_override("font_color", Color(1.0, 0.91, 0.58))
	col.add_child(menu_achievement_title)
	menu_achievement_description = Label.new()
	menu_achievement_description.add_theme_font_size_override("font_size", 13)
	menu_achievement_description.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	col.add_child(menu_achievement_description)

func _on_menu_achievement_unlocked(id: String, title: String, description: String, is_global: bool) -> void:
	if not is_global:
		return
	menu_achievement_icon.text = _menu_achievement_icon(id)
	menu_achievement_title.text = Localization.translate_text(title).to_upper()
	menu_achievement_description.text = Localization.translate_text(description)
	menu_achievement_panel.visible = true
	menu_achievement_timer = 6.0

func _menu_achievement_icon(id: String) -> String:
	match id:
		"linguist": return "🌐"
		"werewolf": return "🐺"
		"gusachok": return "🪿"
		_: return "🏆"

func _load_control_mode() -> void:
	var config := ConfigFile.new()
	var error := config.load(CONTROL_SETTINGS_PATH)
	if error == OK:
		control_mode = clampi(
			int(config.get_value("controls", "mode", CONTROL_MODE_PC)),
			CONTROL_MODE_PC,
			CONTROL_MODE_MOBILE
		)
	else:
		control_mode = CONTROL_MODE_PC


func _save_control_mode() -> void:
	var config := ConfigFile.new()
	config.load(CONTROL_SETTINGS_PATH)
	config.set_value("controls", "mode", control_mode)
	var error := config.save(CONTROL_SETTINGS_PATH)
	if error != OK:
		push_warning("Не удалось сохранить режим управления")


func _refresh_control_mode_buttons() -> void:
	if control_pc_button == null or control_mobile_button == null:
		return
	control_pc_button.text = "✓ ПК" if control_mode == CONTROL_MODE_PC else "ПК"
	control_mobile_button.text = "✓ МОБИЛА" if control_mode == CONTROL_MODE_MOBILE else "МОБИЛА"


func _set_menu_control_mode(mode: int) -> void:
	control_mode = clampi(mode, CONTROL_MODE_PC, CONTROL_MODE_MOBILE)
	_save_control_mode()
	_refresh_control_mode_buttons()


# ---------------- фон: мир, над которым летает камера ----------------

func _make_materials() -> Dictionary:
	var colors := {
		"dirt": Color(0.5, 0.33, 0.2),
		"stone": Color(0.5, 0.5, 0.55),
		"wood": Color(0.45, 0.3, 0.15),
		"leaves": Color(0.15, 0.5, 0.18),
	}
	var mats := {}
	for key in colors:
		var m := StandardMaterial3D.new()
		m.albedo_color = colors[key]
		mats[key] = m
	var g := StandardMaterial3D.new()
	g.albedo_texture = load("res://grass_preview.png")
	g.texture_filter = BaseMaterial3D.TEXTURE_FILTER_NEAREST
	mats["grass"] = g
	return mats

func _build_scenery() -> void:
	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-50, -30, 0)
	add_child(sun)
	var we := WorldEnvironment.new()
	var env := Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.background_color = Color(0.5, 0.75, 1.0)
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(1, 1, 1)
	env.ambient_light_energy = 0.5
	we.environment = env
	add_child(we)

	var heights := {}
	for x in WORLD:
		for z in WORLD:
			heights[Vector2i(x, z)] = int(round(noise.get_noise_2d(x, z) * 7.0 + 4.0))

	var cells := {"grass": [], "dirt": [], "stone": [], "wood": [], "leaves": []}
	for x in WORLD:
		for z in WORLD:
			var h: int = heights[Vector2i(x, z)]
			var low := h
			for d in [Vector2i(1, 0), Vector2i(-1, 0), Vector2i(0, 1), Vector2i(0, -1)]:
				var n: Vector2i = Vector2i(x, z) + d
				if heights.has(n):
					low = mini(low, heights[n])
				else:
					low = mini(low, h - 3)
			for y in range(low, h + 1):
				var t := "stone"
				if y == h:
					t = "grass"
				elif y >= h - 3:
					t = "dirt"
				cells[t].append(Vector3i(x, y, z))
			if x > 3 and x < WORLD - 4 and z > 3 and z < WORLD - 4 and randf() < 0.012:
				for y in range(h + 1, h + 5):
					cells["wood"].append(Vector3i(x, y, z))
				for dx in range(-2, 3):
					for dz in range(-2, 3):
						for dy in range(h + 3, h + 6):
							if dy == h + 5 and (abs(dx) > 1 or abs(dz) > 1):
								continue
							if dx == 0 and dz == 0 and dy < h + 5:
								continue
							cells["leaves"].append(Vector3i(x + dx, dy, z + dz))

	var mats := _make_materials()
	var mesh := BoxMesh.new()
	for key in cells:
		var list: Array = cells[key]
		if list.is_empty():
			continue
		var mm := MultiMesh.new()
		mm.transform_format = MultiMesh.TRANSFORM_3D
		mm.mesh = mesh
		mm.instance_count = list.size()
		for i in list.size():
			mm.set_instance_transform(i, Transform3D(Basis(), Vector3(list[i])))
		var inst := MultiMeshInstance3D.new()
		inst.multimesh = mm
		inst.material_override = mats[key]
		add_child(inst)

	cam = Camera3D.new()
	add_child(cam)
	cam.current = true

func _process(delta: float) -> void:
	if menu_achievement_timer > 0.0:
		menu_achievement_timer = maxf(0.0, menu_achievement_timer - delta)
		if menu_achievement_timer <= 0.0 and menu_achievement_panel != null:
			menu_achievement_panel.visible = false
	angle += delta * 0.12
	t_anim += delta
	var c := Vector3(WORLD / 2.0, 0.0, WORLD / 2.0)
	var r := 22.0
	var pos := c + Vector3(cos(angle) * r, 17.0 + sin(angle * 3.0) * 2.0, sin(angle) * r)
	cam.position = pos
	cam.look_at(pos + Vector3(-sin(angle), -0.3, cos(angle)) * 10.0)
	# логотип слегка «дышит», жёлтая надпись пульсирует, как в Minecraft
	if logo_node != null and logo_node.visible:
		logo_node.pivot_offset = logo_node.size / 2.0
		var sc := 1.0 + sin(t_anim * 1.6) * 0.015
		logo_node.scale = Vector2(sc, sc)
	if splash_label != null:
		splash_label.pivot_offset = splash_label.size / 2.0
		var sp := 1.0 + absf(sin(t_anim * 4.0)) * 0.08
		splash_label.scale = Vector2(sp, sp)

# ---------------- оформление: кнопки как в Minecraft ----------------

func _bevel_texture(fill: Color, light: Color, dark: Color, border: Color, seed_val: int) -> ImageTexture:
	var s := 16
	var rng := RandomNumberGenerator.new()
	rng.seed = seed_val
	var img := Image.create(s, s, false, Image.FORMAT_RGBA8)
	for y in s:
		for x in s:
			var c := fill
			if x == 0 or y == 0 or x == s - 1 or y == s - 1:
				c = border
			elif x == 1 or y == 1:
				c = light
			elif x >= s - 3 or y >= s - 3:
				c = dark
			else:
				var v := rng.randf_range(-0.025, 0.025)
				c = Color(fill.r + v, fill.g + v, fill.b + v, 1.0)
			img.set_pixel(x, y, c)
	return ImageTexture.create_from_image(img)

func _make_button_styles() -> void:
	var border := Color(0.05, 0.05, 0.06)
	var normal_fill := Color(0.44, 0.44, 0.47)
	var normal_light := Color(0.68, 0.68, 0.72)
	var normal_dark := Color(0.26, 0.26, 0.29)
	var hover_fill := Color(0.38, 0.45, 0.62)
	var hover_light := Color(0.62, 0.72, 0.95)
	var hover_dark := Color(0.22, 0.28, 0.42)
	if SettingsManager.ui_theme == "neon":
		normal_fill = Color(0.12, 0.16, 0.25)
		normal_light = Color(0.22, 0.42, 0.58)
		normal_dark = Color(0.04, 0.07, 0.14)
		hover_fill = Color(0.28, 0.12, 0.38)
		hover_light = Color(0.2, 0.9, 0.95)
		hover_dark = Color(0.12, 0.04, 0.22)
	elif SettingsManager.ui_theme == "retro":
		normal_fill = Color(0.48, 0.34, 0.22)
		normal_light = Color(0.75, 0.58, 0.35)
		normal_dark = Color(0.25, 0.16, 0.1)
		hover_fill = Color(0.48, 0.42, 0.2)
		hover_light = Color(0.9, 0.78, 0.38)
		hover_dark = Color(0.25, 0.2, 0.08)
	btn_textures["normal"] = _bevel_texture(normal_fill, normal_light, normal_dark, border, 1)
	btn_textures["hover"] = _bevel_texture(hover_fill, hover_light, hover_dark, Color(1, 1, 1), 2)
	btn_textures["pressed"] = _bevel_texture(normal_dark, normal_fill, normal_light, border, 3)

func _style_box(key: String) -> StyleBoxTexture:
	var sb := StyleBoxTexture.new()
	sb.texture = btn_textures[key]
	sb.texture_margin_left = 4.0
	sb.texture_margin_top = 4.0
	sb.texture_margin_right = 4.0
	sb.texture_margin_bottom = 4.0
	return sb

func _style_button(b: Button, font_size: int) -> void:
	b.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	b.focus_mode = Control.FOCUS_NONE
	b.add_theme_stylebox_override("normal", _style_box("normal"))
	b.add_theme_stylebox_override("hover", _style_box("hover"))
	b.add_theme_stylebox_override("pressed", _style_box("pressed"))
	b.add_theme_stylebox_override("focus", StyleBoxEmpty.new())
	b.add_theme_color_override("font_color", Color(0.92, 0.92, 0.92))
	b.add_theme_color_override("font_hover_color", Color(1.0, 1.0, 0.55))
	b.add_theme_color_override("font_pressed_color", Color(0.78, 0.78, 0.78))
	b.add_theme_color_override("font_outline_color", Color(0.1, 0.1, 0.12))
	b.add_theme_constant_override("outline_size", 4)
	b.add_theme_font_size_override("font_size", font_size)

func _make_button(text: String, w: float = 520.0, h: float = 72.0, font_size: int = 34) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(w, h)
	_style_button(b, font_size)
	return b

# затемнение по краям экрана
func _add_vignette() -> void:
	var g := Gradient.new()
	g.colors = PackedColorArray([Color(0, 0, 0, 0), Color(0, 0, 0, 0.7)])
	g.offsets = PackedFloat32Array([0.45, 1.0])
	var gt := GradientTexture2D.new()
	gt.gradient = g
	gt.fill = GradientTexture2D.FILL_RADIAL
	gt.fill_from = Vector2(0.5, 0.5)
	gt.fill_to = Vector2(1.0, 0.5)
	gt.width = 256
	gt.height = 256
	var vig := TextureRect.new()
	vig.texture = gt
	vig.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	vig.stretch_mode = TextureRect.STRETCH_SCALE
	vig.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(vig)
	vig.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

func _small_label(text: String) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", 18)
	l.add_theme_color_override("font_color", Color(1, 1, 1, 0.85))
	l.add_theme_color_override("font_outline_color", Color(0, 0, 0))
	l.add_theme_constant_override("outline_size", 5)
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return l

# внизу: версия слева и подпись студии справа
func _add_footer() -> void:
	var bar := HBoxContainer.new()
	bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(bar)
	bar.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_WIDE)
	bar.offset_left = 16
	bar.offset_right = -16
	bar.offset_top = -40
	bar.offset_bottom = -8
	bar.add_child(_small_label(VERSION_TEXT))
	var gap := Control.new()
	gap.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	gap.mouse_filter = Control.MOUSE_FILTER_IGNORE
	bar.add_child(gap)
	bar.add_child(_small_label("DARENACHEK studio  ·  MADE WITH DANYIL"))

# жёлтая «пульсирующая» надпись у логотипа
func _add_splash_text() -> void:
	splash_label = Label.new()
	splash_label.text = SPLASH_TEXTS[randi() % SPLASH_TEXTS.size()]
	splash_label.add_theme_font_size_override("font_size", 26)
	splash_label.add_theme_color_override("font_color", Color(1, 0.95, 0.2))
	splash_label.add_theme_color_override("font_outline_color", Color(0.25, 0.2, 0))
	splash_label.add_theme_constant_override("outline_size", 6)
	splash_label.rotation = -0.3
	splash_label.mouse_filter = Control.MOUSE_FILTER_STOP
	splash_label.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
	splash_label.gui_input.connect(_on_splash_gui_input)
	logo_node.add_child(splash_label)
	splash_label.position = Vector2(290.0, 130.0)

func _on_splash_gui_input(event: InputEvent) -> void:
	if event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
		_roll_splash()
		accept_event()
	elif event is InputEventScreenTouch and event.pressed:
		_roll_splash()
		accept_event()

func _roll_splash() -> void:
	if splash_label == null or SPLASH_TEXTS.size() < 2:
		return
	var next_index := randi_range(0, SPLASH_TEXTS.size() - 1)
	while splash_label.text == SPLASH_TEXTS[next_index]:
		next_index = randi_range(0, SPLASH_TEXTS.size() - 1)
	splash_label.text = SPLASH_TEXTS[next_index]
	var tw := create_tween()
	tw.tween_property(splash_label, "rotation", 0.0, 0.08)
	tw.tween_property(splash_label, "rotation", -0.3, 0.12)

# ищет файл логотипа в корне проекта (darecraft_logo*.svg или .png)
func _find_logo() -> Texture2D:
	var d := DirAccess.open("res://")
	if d == null:
		return null
	for f in d.get_files():
		var n := f.trim_suffix(".import").trim_suffix(".remap")
		if n.begins_with("darecraft_logo") and (n.ends_with(".svg") or n.ends_with(".png")):
			var t = load("res://" + n)
			if t is Texture2D:
				return t
	return null

func _title_label(text: String, font_size: int) -> Label:
	var l := Label.new()
	l.text = text
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.add_theme_font_size_override("font_size", font_size)
	l.add_theme_color_override("font_color", Color.WHITE)
	l.add_theme_color_override("font_outline_color", Color(0.15, 0.25, 0.1))
	l.add_theme_constant_override("outline_size", 8)
	return l

# ---------------- интерфейс ----------------

func _build_ui() -> void:
	var center := CenterContainer.new()
	add_child(center)
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	var holder := VBoxContainer.new()
	holder.add_theme_constant_override("separation", 26)
	center.add_child(holder)

	# логотип (если файл не найден, показываем текст)
	var logo_tex := _find_logo()
	if logo_tex != null:
		var logo := TextureRect.new()
		logo.texture = logo_tex
		logo.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		logo.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		logo.custom_minimum_size = Vector2(440, 182)
		logo.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
		logo_node = logo
	else:
		var title := _title_label(GAME_TITLE, 72)
		title.add_theme_constant_override("outline_size", 12)
		logo_node = title
	holder.add_child(logo_node)
	_add_splash_text()

	# ГЛАВНОЕ МЕНЮ: большая «Играть», внизу «Настройки» и «Выход»
	main_box = VBoxContainer.new()
	main_box.add_theme_constant_override("separation", 14)
	holder.add_child(main_box)

	var play := _make_button("Играть", 520, 78, 38)
	play.pressed.connect(_show_panel.bind("worlds"))
	main_box.add_child(play)

	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 14)
	main_box.add_child(row)
	var settings := _make_button("Настройки", 253, 64, 28)
	settings.pressed.connect(_show_panel.bind("settings"))
	row.add_child(settings)
	var quit := _make_button("Выход", 253, 64, 28)
	quit.pressed.connect(_on_quit)
	row.add_child(quit)
	var online_btn := _make_button("Мультиплеер", 520, 64, 28)
	online_btn.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	online_btn.pressed.connect(_show_panel.bind("online"))
	main_box.add_child(online_btn)

	# тёмная панель для экранов «Выбор мира» и «Настройки»
	panel_wrap = PanelContainer.new()
	panel_wrap.visible = false
	var pst := StyleBoxFlat.new()
	pst.bg_color = Color(0, 0, 0, 0.6)
	pst.set_corner_radius_all(10)
	pst.set_border_width_all(2)
	pst.border_color = Color(1, 1, 1, 0.25)
	pst.set_content_margin_all(22)
	panel_wrap.add_theme_stylebox_override("panel", pst)
	holder.add_child(panel_wrap)

	var inner := VBoxContainer.new()
	panel_wrap.add_child(inner)

	# ВЫБОР МИРА
	worlds_box = VBoxContainer.new()
	worlds_box.add_theme_constant_override("separation", 12)
	worlds_box.visible = false
	inner.add_child(worlds_box)
	worlds_box.add_child(_title_label("Выбор мира", 40))

	var scroll := ScrollContainer.new()
	scroll.custom_minimum_size = Vector2(640, 170)
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	worlds_box.add_child(scroll)
	list_box = VBoxContainer.new()
	list_box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	list_box.add_theme_constant_override("separation", 8)
	scroll.add_child(list_box)

	var new_row := HBoxContainer.new()
	new_row.add_theme_constant_override("separation", 10)
	worlds_box.add_child(new_row)
	name_edit = LineEdit.new()
	name_edit.placeholder_text = "Название нового мира"
	name_edit.custom_minimum_size = Vector2(400, 64)
	name_edit.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	name_edit.add_theme_font_size_override("font_size", 28)
	var edit_style := StyleBoxFlat.new()
	edit_style.bg_color = Color(0.06, 0.06, 0.08, 0.95)
	edit_style.set_border_width_all(3)
	edit_style.border_color = Color(0.5, 0.5, 0.55)
	edit_style.set_content_margin_all(10)
	name_edit.add_theme_stylebox_override("normal", edit_style)
	var edit_focus := edit_style.duplicate() as StyleBoxFlat
	edit_focus.border_color = Color(1, 1, 1)
	name_edit.add_theme_stylebox_override("focus", edit_focus)
	new_row.add_child(name_edit)
	var create := _make_button("Создать мир", 220, 64, 26)
	create.pressed.connect(_create_world)
	new_row.add_child(create)
	seed_edit = LineEdit.new()
	seed_edit.placeholder_text = "Сид 1–1235 или city1–city100 (пусто — случайный)"
	seed_edit.custom_minimum_size = Vector2(400, 54)
	seed_edit.add_theme_font_size_override("font_size", 22)
	worlds_box.add_child(seed_edit)

	msg_label = Label.new()
	msg_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	msg_label.add_theme_font_size_override("font_size", 24)
	msg_label.add_theme_color_override("font_color", Color(1, 0.85, 0.3))
	msg_label.add_theme_color_override("font_outline_color", Color.BLACK)
	msg_label.add_theme_constant_override("outline_size", 6)
	worlds_box.add_child(msg_label)

	var wback := _make_button("Назад", 520, 64, 30)
	wback.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	wback.pressed.connect(_show_panel.bind("main"))
	worlds_box.add_child(wback)

	# ОНЛАЙН: комнаты через WebSocket-релей, без ручного проброса портов
	online_box = VBoxContainer.new()
	online_box.visible = false
	online_box.add_theme_constant_override("separation", 12)
	inner.add_child(online_box)
	var online_header := HBoxContainer.new()
	online_header.alignment = BoxContainer.ALIGNMENT_CENTER
	online_header.add_theme_constant_override("separation", 12)
	online_box.add_child(online_header)
	var online_title := _title_label("DareCraft Online", 36)
	online_title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	online_header.add_child(online_title)
	var online_close := _make_button("×", 58, 54, 34)
	online_close.tooltip_text = "Закрыть окно мультиплеера"
	online_close.pressed.connect(_show_panel.bind("main"))
	online_header.add_child(online_close)
	online_box.add_child(_small_label("До 8 игроков · Android ↔ Windows · без проброса портов"))
	online_box.add_child(_title_label("Имя игрока", 22))
	player_name_edit = LineEdit.new()
	player_name_edit.text = Global.network_player_name
	player_name_edit.placeholder_text = "Твоё имя в игре"
	player_name_edit.max_length = 20
	player_name_edit.custom_minimum_size = Vector2(520, 54)
	player_name_edit.add_theme_font_size_override("font_size", 20)
	online_box.add_child(player_name_edit)
	online_box.add_child(_title_label("Сервер комнат", 22))
	relay_url_edit = LineEdit.new()
	relay_url_edit.text = Global.network_server_url
	relay_url_edit.placeholder_text = "wss://твой-сервер.onrender.com/ws"
	relay_url_edit.custom_minimum_size = Vector2(520, 54)
	relay_url_edit.add_theme_font_size_override("font_size", 18)
	online_box.add_child(relay_url_edit)
	online_box.add_child(_title_label("Мой мир для мультиплеера", 24))
	online_world_option = OptionButton.new()
	online_world_option.custom_minimum_size = Vector2(520, 54)
	online_world_option.add_theme_font_size_override("font_size", 20)
	online_box.add_child(online_world_option)
	online_box.add_child(_small_label("Можно загрузить уже сохранённый мир. Он будет отправлен друзьям при подключении."))
	online_box.add_child(_title_label("Создать комнату", 26))
	var host_btn := _make_button("Создать онлайн-мир", 520, 60, 26)
	host_btn.pressed.connect(_start_online_host)
	online_box.add_child(host_btn)
	online_box.add_child(_title_label("Подключиться к другу", 26))
	join_code_edit = LineEdit.new()
	join_code_edit.placeholder_text = "Код комнаты DC1-12345"
	join_code_edit.custom_minimum_size = Vector2(520, 54)
	join_code_edit.add_theme_font_size_override("font_size", 20)
	online_box.add_child(join_code_edit)
	var join_btn := _make_button("Подключиться", 520, 60, 26)
	join_btn.pressed.connect(_join_online_room)
	online_box.add_child(join_btn)
	online_status_label = _small_label("Сервер DareCraft уже указан. Хозяин создаёт мир и отправляет код друзьям.")
	online_status_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	online_status_label.custom_minimum_size = Vector2(520, 65)
	online_box.add_child(online_status_label)
	var online_back := _make_button("Назад", 520, 58, 26)
	online_back.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	online_back.pressed.connect(_show_panel.bind("main"))
	online_box.add_child(online_back)

	# НАСТРОЙКИ (с прокруткой)
	scroll_settings = ScrollContainer.new()
	scroll_settings.custom_minimum_size = Vector2(640, 430)
	scroll_settings.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	scroll_settings.visible = false
	inner.add_child(scroll_settings)

	settings_box = VBoxContainer.new()
	settings_box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	settings_box.add_theme_constant_override("separation", 15)
	scroll_settings.add_child(settings_box)

	settings_box.add_child(_title_label("Настройки DareCraft", 44))

	# Язык интерфейса (настройка сохраняется отдельно от миров)
	settings_box.add_child(_title_label("Язык / Language / Мова", 26))
	var language_row := HBoxContainer.new()
	language_row.alignment = BoxContainer.ALIGNMENT_CENTER
	language_row.add_theme_constant_override("separation", 10)
	settings_box.add_child(language_row)
	for language_option in [{"id":"uk", "label":"Українська"}, {"id":"ru", "label":"Русский"}, {"id":"en", "label":"English"}]:
		var language_button := _make_button(str(language_option["label"]), 165, 52, 19)
		language_button.pressed.connect(_set_menu_language.bind(str(language_option["id"])))
		language_row.add_child(language_button)
	language_status_label = _small_label("Текущий язык: " + Localization.language.to_upper())
	language_status_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	settings_box.add_child(language_status_label)

	# Темы оформления сохраняются в user:// и будут применяться к новым панелям UI
	settings_box.add_child(_title_label("Тема оформления", 26))
	var theme_row := HBoxContainer.new()
	theme_row.alignment = BoxContainer.ALIGNMENT_CENTER
	theme_row.add_theme_constant_override("separation", 10)
	settings_box.add_child(theme_row)
	for theme_option in [{"id":"classic", "label":"Классика"}, {"id":"neon", "label":"Ночной неон"}, {"id":"retro", "label":"Ретро"}]:
		var theme_button := _make_button(str(theme_option["label"]), 165, 52, 19)
		theme_button.pressed.connect(_set_menu_theme.bind(str(theme_option["id"])))
		theme_row.add_child(theme_button)
	theme_status_label = _small_label("Тема: " + SettingsManager.ui_theme)
	theme_status_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	settings_box.add_child(theme_status_label)

	# Выбор режима управления: ПК или мобильное устройство
	settings_box.add_child(_title_label("Режим управления", 28))
	var controls_row := HBoxContainer.new()
	controls_row.alignment = BoxContainer.ALIGNMENT_CENTER
	controls_row.add_theme_constant_override("separation", 15)
	settings_box.add_child(controls_row)

	control_pc_button = _make_button("ПК", 220, 60, 24)
	control_pc_button.pressed.connect(_set_menu_control_mode.bind(CONTROL_MODE_PC))
	controls_row.add_child(control_pc_button)

	control_mobile_button = _make_button("МОБИЛА", 220, 60, 24)
	control_mobile_button.pressed.connect(_set_menu_control_mode.bind(CONTROL_MODE_MOBILE))
	controls_row.add_child(control_mobile_button)
	_refresh_control_mode_buttons()

	# Выбор внешности персонажа
	settings_box.add_child(_title_label("Скины персонажа", 32))
	skin_status_label = _small_label("")
	skin_status_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	settings_box.add_child(skin_status_label)
	var skin_grid := GridContainer.new()
	skin_grid.columns = 3
	skin_grid.add_theme_constant_override("h_separation", 10)
	skin_grid.add_theme_constant_override("v_separation", 10)
	skin_grid.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	settings_box.add_child(skin_grid)
	skin_buttons.clear()
	for i in Global.SKIN_PRESETS.size():
		var preset: Dictionary = Global.SKIN_PRESETS[i]
		var skin_button := _make_button(str(preset["name"]), 190, 54, 20)
		skin_button.pressed.connect(_select_skin.bind(i))
		skin_grid.add_child(skin_button)
		skin_buttons.append(skin_button)
	_refresh_skin_buttons()
	_build_custom_skin_editor()

	# поле зрения
	var fov_row := HBoxContainer.new()
	fov_row.alignment = BoxContainer.ALIGNMENT_CENTER
	fov_row.add_theme_constant_override("separation", 20)
	settings_box.add_child(fov_row)

	var fov_label := _title_label("Обзор: " + str(int(Global.fov)), 28)
	fov_row.add_child(fov_label)

	var fov_slider := HSlider.new()
	fov_slider.min_value = 30.0
	fov_slider.max_value = 110.0
	fov_slider.step = 1.0
	fov_slider.value = Global.fov
	fov_slider.custom_minimum_size = Vector2(300, 40)
	fov_slider.value_changed.connect(func(val):
		Global.fov = val
		fov_label.text = "Обзор: " + str(int(val))
	)
	fov_row.add_child(fov_slider)

	# музыка
	var vol_row := HBoxContainer.new()
	vol_row.alignment = BoxContainer.ALIGNMENT_CENTER
	vol_row.add_theme_constant_override("separation", 20)
	settings_box.add_child(vol_row)

	vol_label = _title_label("Музыка: %d%%" % int(Music.music_volume * 100), 28)
	vol_row.add_child(vol_label)

	var slider := HSlider.new()
	slider.min_value = 0.0
	slider.max_value = 1.0
	slider.step = 0.01
	slider.value = Music.music_volume
	slider.custom_minimum_size = Vector2(300, 40)
	slider.value_changed.connect(_on_volume_changed)
	vol_row.add_child(slider)

	# --- НОВЫЙ ПОЛЗУНОК ЗВУКОВ (SFX) ---
	var sfx_row := HBoxContainer.new()
	sfx_row.alignment = BoxContainer.ALIGNMENT_CENTER
	sfx_row.add_theme_constant_override("separation", 20)
	settings_box.add_child(sfx_row)

	var sfx_label := _title_label("Звуки: %d%%" % int(Music.sfx_volume * 100), 28)
	sfx_row.add_child(sfx_label)

	var sfx_slider := HSlider.new()
	sfx_slider.min_value = 0.0
	sfx_slider.max_value = 1.0
	sfx_slider.step = 0.01
	sfx_slider.value = Music.sfx_volume
	sfx_slider.custom_minimum_size = Vector2(300, 40)
	sfx_slider.value_changed.connect(func(val):
		Music.set_sfx_volume(val)
		sfx_label.text = "Звуки: %d%%" % int(val * 100)
	)
	sfx_row.add_child(sfx_slider)
	# -----------------------------------

	# остальные настройки (пока заглушки, добавим позже)
	var grid := GridContainer.new()
	grid.columns = 2
	grid.add_theme_constant_override("h_separation", 20)
	grid.add_theme_constant_override("v_separation", 15)
	grid.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	settings_box.add_child(grid)

	var btn_names := [
		"Графика и Свет", "Звуки и Эффекты",
		"Язык и Шрифты", "Внешний вид",
		"Создатели игры", "Статистика", "Сохранения",
	]
	for b_name in btn_names:
		var btn := _make_button(b_name, 260, 60, 22)
		btn.pressed.connect(func(): print("Нажата кнопка: ", b_name))
		grid.add_child(btn)

	var back := _make_button("Готово", 520, 64, 30)
	back.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	back.pressed.connect(_show_panel.bind("main"))
	settings_box.add_child(back)

func _set_menu_language(language_code: String) -> void:
	var previous_language := Localization.language
	Localization.set_language(language_code)
	if previous_language != Localization.language:
		Achievements.unlock("linguist")
	_on_language_changed(Localization.language)

func _on_language_changed(_language_code: String) -> void:
	if language_status_label != null:
		language_status_label.text = "Текущий язык: " + Localization.language.to_upper()
		if language_status_label.has_meta("_loc_text"):
			language_status_label.remove_meta("_loc_text")
	Localization.apply_to_tree(self)

func _set_menu_theme(theme_code: String) -> void:
	SettingsManager.set_ui_theme(theme_code)
	_make_button_styles()
	for existing_button in find_children("*", "Button", true, false):
		if existing_button is Button:
			var current_size: int = int((existing_button as Button).get_theme_font_size("font_size"))
			_style_button(existing_button, current_size if current_size > 0 else 22)
	if theme_status_label != null:
		theme_status_label.text = "Тема: " + SettingsManager.ui_theme

func _select_skin(index: int) -> void:
	var old_skin := Global.selected_skin
	Global.selected_skin = clampi(index, 0, Global.SKIN_PRESETS.size())
	if old_skin != Global.selected_skin:
		Achievements.unlock("werewolf")
	var config := ConfigFile.new()
	config.load(CONTROL_SETTINGS_PATH)
	config.set_value("player", "skin", Global.selected_skin)
	for key in ["skin", "shirt", "pants", "hair"]:
		config.set_value("custom_skin", key, Global.CUSTOM_SKIN[key].to_html())
	var err := config.save(CONTROL_SETTINGS_PATH)
	if err != OK:
		push_warning("Не удалось сохранить выбранный скин")
	_refresh_skin_buttons()

func _refresh_skin_buttons() -> void:
	if skin_buttons.is_empty():
		return
	var selected: Dictionary = Global.get_skin_preset(Global.selected_skin)
	if skin_status_label != null:
		skin_status_label.text = "Выбран: %s (%s)" % [selected.get("name", "Мой скин"), selected.get("gender", "Своя внешность")]
	for i in skin_buttons.size():
		var label := "Мой скин" if i == Global.SKIN_PRESETS.size() else str(Global.SKIN_PRESETS[i]["name"])
		skin_buttons[i].text = ("✓ " if i == Global.selected_skin else "") + label

func _load_selected_skin() -> void:
	var config := ConfigFile.new()
	if config.load(CONTROL_SETTINGS_PATH) == OK:
		Global.selected_skin = clampi(int(config.get_value("player", "skin", 0)), 0, Global.SKIN_PRESETS.size())
		for key in ["skin", "shirt", "pants", "hair"]:
			var saved: Variant = config.get_value("custom_skin", key, null)
			if saved is String:
				Global.CUSTOM_SKIN[key] = Color.from_string(saved, Global.CUSTOM_SKIN[key])
		Global.CUSTOM_SKIN["long_hair"] = bool(config.get_value("custom_skin", "long_hair", false))

func _build_custom_skin_editor() -> void:
	settings_box.add_child(_title_label("Редактор скина", 28))
	var hint := _small_label("Выбери «Мой скин», настрой цвета и сохрани")
	hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	settings_box.add_child(hint)
	var row := HBoxContainer.new()
	row.alignment = BoxContainer.ALIGNMENT_CENTER
	row.add_theme_constant_override("separation", 12)
	settings_box.add_child(row)
	for entry in [["Кожа", "skin"], ["Одежда", "shirt"], ["Штаны", "pants"], ["Волосы", "hair"]]:
		var col := VBoxContainer.new()
		col.add_child(_small_label(entry[0]))
		var picker := ColorPickerButton.new()
		picker.color = Global.CUSTOM_SKIN[entry[1]]
		picker.custom_minimum_size = Vector2(76, 48)
		picker.color_changed.connect(_on_custom_skin_color_changed.bind(entry[1]))
		col.add_child(picker)
		row.add_child(col)
	var custom_btn := _make_button("Мой скин", 190, 54, 20)
	custom_btn.pressed.connect(_select_skin.bind(Global.SKIN_PRESETS.size()))
	skin_buttons.append(custom_btn)
	settings_box.add_child(custom_btn)

func _on_custom_skin_color_changed(color: Color, key: String) -> void:
	Global.CUSTOM_SKIN[key] = color
	_save_custom_skin()

func _save_custom_skin() -> void:
	var config := ConfigFile.new()
	config.load(CONTROL_SETTINGS_PATH)
	for key in ["skin", "shirt", "pants", "hair"]:
		config.set_value("custom_skin", key, Global.CUSTOM_SKIN[key].to_html())
	config.set_value("custom_skin", "long_hair", bool(Global.CUSTOM_SKIN.get("long_hair", false)))
	config.save(CONTROL_SETTINGS_PATH)

func _show_panel(which: String) -> void:
	if which == "settings":
		_load_control_mode()
		_refresh_control_mode_buttons()
		_refresh_skin_buttons()
	# логотип показываем только в главном меню
	if logo_node != null:
		logo_node.visible = (which == "main")
	main_box.visible = which == "main"
	panel_wrap.visible = which != "main"
	scroll_settings.visible = which == "settings"
	worlds_box.visible = which == "worlds"
	if online_box != null:
		online_box.visible = which == "online"
	if which == "worlds":
		_refresh_worlds()
	elif which == "online":
		_refresh_online_worlds()

func _refresh_online_worlds() -> void:
	if online_world_option == null:
		return
	var previous_count := online_world_option.item_count
	online_world_option.clear()
	for index in range(previous_count):
		var meta_key := "_loc_item_%d" % index
		if online_world_option.has_meta(meta_key):
			online_world_option.remove_meta(meta_key)
	online_world_option.add_item("Новый случайный мир")
	for world_name in Global.list_worlds():
		online_world_option.add_item(str(world_name))
	online_world_option.select(0)
	Localization.apply_to_tree(self)

func _refresh_worlds() -> void:
	for ch in list_box.get_children():
		ch.queue_free()
	msg_label.text = ""
	var names: Array = Global.list_worlds()
	if names.is_empty():
		list_box.add_child(_title_label("Миров пока нет. Создайте первый!", 26))
	for wn in names:
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 10)
		list_box.add_child(row)
		var play := _make_button(wn, 380, 64, 28)
		play.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		play.pressed.connect(_play_world.bind(wn))
		row.add_child(play)
		var del := _make_button("Удалить", 160, 64, 24)
		del.pressed.connect(_on_delete.bind(wn, del))
		row.add_child(del)
	Localization.apply_to_tree(self)

func _on_delete(wn: String, btn: Button) -> void:
	if btn.text == "Удалить":
		btn.text = "Точно?"
	else:
		Global.delete_world(wn)
		_refresh_worlds()

func _create_world() -> void:
	var wn: String = str(Global.clean_name(name_edit.text))
	if wn.is_empty():
		var n: int = Global.list_worlds().size() + 1
		wn = "Мир %d" % n
		while Global.world_exists(wn):
			n += 1
			wn = "Мир %d" % n
	if Global.world_exists(wn):
		msg_label.text = "Мир с таким названием уже есть"
		return
	var seed_text := seed_edit.text.strip_edges() if seed_edit != null else ""
	if not seed_text.is_empty():
		var lower_seed := seed_text.to_lower()
		if lower_seed.begins_with("city"):
			var city_number := lower_seed.substr(4)
			if not city_number.is_valid_int() or int(city_number) < 1 or int(city_number) > 100:
				msg_label.text = "Сид города должен быть city1–city100"
				return
			Global.pending_world_seed = 10000 + int(city_number)
		elif seed_text.is_valid_int() and int(seed_text) >= 1 and int(seed_text) <= 1235:
			Global.pending_world_seed = int(seed_text)
		else:
			msg_label.text = "Сид: 1–1235 или city1–city100"
			return
	else:
		Global.pending_world_seed = 0
	_play_world(wn)

# выбрали мир: сцена игры сама покажет полёт камеры над миром, советы и загрузку
func _play_world(wn: String) -> void:
	Global.current_world = wn
	get_tree().change_scene_to_file(GAME_SCENE)

func _on_volume_changed(v: float) -> void:
	Music.set_music_volume(v)
	vol_label.text = "Музыка: %d%%" % int(round(v * 100.0))

func _on_quit() -> void:
	get_tree().quit()

# ---------------- появление меню из темноты ----------------

func _fade_in_from_black() -> void:
	var layer := CanvasLayer.new()
	layer.layer = 100
	add_child(layer)
	var black := ColorRect.new()
	black.color = Color(0, 0, 0, 1)
	black.mouse_filter = Control.MOUSE_FILTER_STOP
	layer.add_child(black)
	black.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var tw := create_tween()
	tw.tween_interval(0.5)
	tw.tween_property(black, "color:a", 0.0, 2.0)
	tw.tween_callback(layer.queue_free)


func _load_network_settings() -> void:
	var config := ConfigFile.new()
	if config.load(CONTROL_SETTINGS_PATH) == OK:
		Global.network_server_url = str(config.get_value("network", "server_url", Global.network_server_url))
		Global.network_player_name = str(config.get_value("network", "player_name", Global.network_player_name))


func _save_network_settings() -> void:
	var config := ConfigFile.new()
	config.load(CONTROL_SETTINGS_PATH)
	config.set_value("network", "server_url", Global.network_server_url)
	config.set_value("network", "player_name", Global.network_player_name)
	var error := config.save(CONTROL_SETTINGS_PATH)
	if error != OK:
		push_warning("Не удалось сохранить настройки мультиплеера")


func _read_relay_url() -> bool:
	var relay_url := relay_url_edit.text.strip_edges() if relay_url_edit != null else ""
	if not (relay_url.begins_with("wss://") or relay_url.begins_with("ws://")):
		online_status_label.text = "Проверь адрес сервера. Он должен начинаться с wss://"
		return false
	if relay_url.to_lower().contains("your-relay-server") or relay_url.to_lower().contains("example"):
		online_status_label.text = "Укажи адрес своего запущенного сервера."
		return false
	if not relay_url.ends_with("/ws"):
		relay_url = relay_url.trim_suffix("/") + "/ws"
	Global.network_server_url = relay_url
	var player_name := player_name_edit.text.strip_edges() if player_name_edit != null else "Игрок"
	Global.network_player_name = player_name.substr(0, 20) if not player_name.is_empty() else "Игрок"
	var normalized_name := Global.network_player_name.to_lower()
	if normalized_name.contains("goose") or normalized_name.contains("гусь") or normalized_name.contains("гусений"):
		Achievements.unlock("gusachok")
	_save_network_settings()
	return true


func _start_online_host() -> void:
	if not _read_relay_url():
		return
	Global.network_mode = "host"
	Global.network_address = ""
	Global.network_room_code = ""
	var selected_world := ""
	if online_world_option != null and online_world_option.selected > 0:
		selected_world = online_world_option.get_item_text(online_world_option.selected)
	if not selected_world.is_empty() and Global.world_exists(selected_world):
		# Existing saves are loaded by the normal game loader. The world snapshot
		# is then streamed to joining players by the host.
		Global.current_world = selected_world
		Global.pending_world_seed = 0
	else:
		var seed_value := randi_range(1, 1235)
		var seed_text := seed_edit.text.strip_edges() if seed_edit != null else ""
		if seed_text.is_valid_int() and int(seed_text) >= 1 and int(seed_text) <= 1235:
			seed_value = int(seed_text)
		Global.pending_world_seed = seed_value
		var world_name := "Онлайн_%d" % seed_value
		if Global.world_exists(world_name):
			world_name += "_%d" % randi_range(100, 9999)
		Global.current_world = world_name
	get_tree().change_scene_to_file(GAME_SCENE)

func _join_online_room() -> void:
	if not _read_relay_url():
		return
	var code := join_code_edit.text.strip_edges().to_upper()
	var parts := code.split("-", false)
	if parts.size() != 2 or parts[0] != "DC1" or not parts[1].is_valid_int() or parts[1].length() != 5:
		online_status_label.text = "Неверный код комнаты. Пример: DC1-12345"
		return
	Global.network_mode = "client"
	Global.network_address = ""
	Global.network_port = 0
	Global.network_room_code = code
	Global.pending_world_seed = 0
	Global.current_world = "Онлайн_гость_%s" % code.replace("-", "_")
	get_tree().change_scene_to_file(GAME_SCENE)

