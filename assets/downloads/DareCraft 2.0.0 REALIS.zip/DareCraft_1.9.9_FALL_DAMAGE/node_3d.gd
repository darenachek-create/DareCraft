extends Node3D

const CW := 96
const CS := 16
const WORLD_SIZE := CW * CS
const WORLD_H := 64
const CHUNK_DATA_SIZE := CS * CS * WORLD_H
const WORLD_SNAPSHOT_PART_BYTES := 60 * 1024
const ROCK_LEVEL := 40
const SPEED := 5.0
const JUMP_SPEED := 7.0
const GRAVITY := 20.0
const MOUSE_SENS := 0.003
const MAX_STACK := 64
const HOTBAR := 9
const TOTAL_SLOTS := 24
const SAVE_VERSION := 4
const CRACK_STAGES := 8
const ATLAS_TILES := 40
const HAND_POS := Vector3(0.55, -0.55, -0.35)
const HAND_L_POS := Vector3(-0.6, -0.55, -0.4)
const HAND_L_BLOCK_POS := Vector3(-0.2, -0.2, 0.25)
const SMALL_MAP := [0, 1, 3, 4]
const GROW_TIME := 45.0
const SEED_CHANCE := 0.15
const CONTROL_MODE_PC := 0
const CONTROL_MODE_MOBILE := 1
const CONTROL_SETTINGS_PATH := "user://darecraft_controls.cfg"
const PHYSICS_SETTINGS_PATH := "user://darecraft_physics.cfg"
const PHYSICS_MAX_BLOCKS := 36
const PHYSICS_MAX_BODIES := 12

const GRASS := 1
const DIRT := 2
const STONE := 3
const LOG := 4
const LEAVES := 5
const PLANKS := 6
const TABLE := 7
const COAL := 8
const IRON := 9
const STICK := 10
const PICKAXE := 11
const FARMLAND := 12
const SHOVEL := 13
const SWORD := 14
const AXE := 15
const HOE := 16
const WHEAT_SEEDS := 17
const POTATO_SEEDS := 18
const BEET_SEEDS := 19
const WHEAT := 20
const POTATO := 21
const BEETROOT := 22
const HELMET := 23
const CHESTPLATE := 24
const LEGGINGS := 25
const BOOTS := 26
const SHIELD := 27
const DOOR := 28
const FURNACE := 29
const S_PICKAXE := 30
const S_SHOVEL := 31
const S_SWORD := 32
const S_AXE := 33
const S_HOE := 34
const S_HELMET := 35
const S_CHESTPLATE := 36
const S_LEGGINGS := 37
const S_BOOTS := 38
const S_SHIELD := 39
const COAL_ITEM := 40
const IRON_INGOT := 41
const RAW_IRON := 42
const CHEST := 43
const RAW_PORK := 53
const COOKED_PORK := 54
const ROTTEN_FLESH := 55
const COOKED_FLESH := 56
const DIAMOND_ORE := 57
const DIAMOND := 58
const D_PICKAXE := 59
const D_SWORD := 60
const D_AXE := 61
const D_SHOVEL := 62
const GLASS := 63
const RAIL := 64
const MINECART := 65
const D_HOE := 66
const D_HELMET := 67
const D_CHESTPLATE := 68
const D_LEGGINGS := 69
const D_BOOTS := 70
const D_SHIELD := 71
const BED := 72
const BONE := 73
const TORCH := 74
const SAND := 75
const GRAVEL := 76
const GLOW_BLOCK := 77
const MUSIC_PLAYER := 78
const MUSIC_DISC_1 := 79
const MUSIC_DISC_2 := 80
const MUSIC_DISC_3 := 81
const MUSIC_DISC_4 := 82
const MUSIC_DISC_5 := 83
const BOW := 84
const COBWEB := 85
const SPAWN_EGG_SKELETON := 86
const SPAWN_EGG_PIG := 87
const SPAWN_EGG_SPIDER := 88
const SPAWN_EGG_ZOMBIE := 89
const BOAT := 90
const SNOW := 91 # естественный снежный блок генерации мира
const RAFT := 92 # большой управляемый плот 5×8
const TREASURE_MAP := 93 # карта к закопанному сокровищу
const BIOME_PLAINS := 0
const BIOME_FOREST := 1
const BIOME_DESERT := 2
const BIOME_SNOW := 3
const BIOME_JUNGLE := 4
const BIOME_SWAMP := 5
const BIOME_ROCKY := 6
const RAFT_WIDTH := 5
const RAFT_LENGTH := 8
const I_PICKAXE := 44
const I_SHOVEL := 45
const I_SWORD := 46
const I_AXE := 47
const I_HOE := 48
const I_HELMET := 49
const I_CHESTPLATE := 50
const I_LEGGINGS := 51
const I_BOOTS := 52
const THIRD_DIST := 3.5

const TILES := {
	GRASS: [0, 1, 2], DIRT: [2, 2, 2], STONE: [3, 3, 3],
	LOG: [5, 4, 5], LEAVES: [6, 6, 6], PLANKS: [7, 7, 7],
	TABLE: [8, 9, 7], COAL: [10, 10, 10], IRON: [11, 11, 11],
	FARMLAND: [14, 2, 2], FURNACE: [3, 15, 3], CHEST: [19, 20, 19],
	GLASS: [39, 39, 39], RAIL: [11, 11, 11], MINECART: [19, 19, 19],
	DIAMOND_ORE: [31, 31, 31], BED: [37, 37, 7], SAND: [33, 33, 33],
	GRAVEL: [34, 34, 34], GLOW_BLOCK: [35, 35, 35], TORCH: [36, 36, 36], MUSIC_PLAYER: [7, 3, 7], SNOW: [0, 0, 0],
}
const ICON_TILE := {
	GRASS: 1, DIRT: 2, STONE: 3, LOG: 4, LEAVES: 6, PLANKS: 7,
	TABLE: 9, COAL: 10, IRON: 11, STICK: 12, PICKAXE: 13, FARMLAND: 2,
	SHOVEL: 14, SWORD: 24, AXE: 25, HOE: 26, WHEAT_SEEDS: 16,
	POTATO_SEEDS: 16, BEET_SEEDS: 16, WHEAT: 17, POTATO: 17, BEETROOT: 17,
	HELMET: 27, CHESTPLATE: 28, LEGGINGS: 29, BOOTS: 30, SHIELD: 27,
	FURNACE: 15, COAL_ITEM: 16, RAW_IRON: 17, IRON_INGOT: 18, CHEST: 21,
	I_PICKAXE: 22, I_SHOVEL: 23, I_SWORD: 24, I_AXE: 25, I_HOE: 26,
	I_HELMET: 27, I_CHESTPLATE: 28, I_LEGGINGS: 29, I_BOOTS: 30,
	DIAMOND_ORE: 31, DIAMOND: 38, D_PICKAXE: 25, D_SWORD: 26, D_AXE: 27,
	D_SHOVEL: 28, D_HOE: 29, D_HELMET: 30, D_CHESTPLATE: 31,
	D_LEGGINGS: 32, D_BOOTS: 33, D_SHIELD: 34, BED: 32, BONE: 36,
	TORCH: 36, SAND: 33, GRAVEL: 34, GLOW_BLOCK: 35, GLASS: 39, RAIL: 11, MINECART: 21, MUSIC_PLAYER: 7,
}
const ITEM_ICON := {
	SHOVEL: 0, SWORD: 1, AXE: 2, HOE: 3,
	WHEAT_SEEDS: 4, POTATO_SEEDS: 5, BEET_SEEDS: 6,
	WHEAT: 7, POTATO: 8, BEETROOT: 9,
	HELMET: 10, CHESTPLATE: 11, LEGGINGS: 12, BOOTS: 13,
	PICKAXE: 14, SHIELD: 15, RAW_PORK: 16, COOKED_PORK: 17, ROTTEN_FLESH: 18, COOKED_FLESH: 19, D_PICKAXE: 25, D_SWORD: 26, D_AXE: 27, D_SHOVEL: 28, D_HOE: 29, D_HELMET: 30, D_CHESTPLATE: 31, D_LEGGINGS: 32, D_BOOTS: 33, D_SHIELD: 34, DIAMOND: 35, BONE: 36, TORCH: 38, BED: 37, TREASURE_MAP: 21,
}
const ITEM2_ICON := {
	S_PICKAXE: 0, S_SHOVEL: 1, S_SWORD: 2, S_AXE: 3, S_HOE: 4,
	S_HELMET: 5, S_CHESTPLATE: 6, S_LEGGINGS: 7, S_BOOTS: 8, S_SHIELD: 9,
	DOOR: 10,
}
const HARDNESS := {
	GRASS: 0.5, DIRT: 0.45, LOG: 1.0, LEAVES: 0.2, PLANKS: 0.8,
	TABLE: 0.8, STONE: 1.6, COAL: 1.8, IRON: 2.2, FARMLAND: 0.45,
	FURNACE: 1.6, DOOR: 0.6, CHEST: 0.8, DIAMOND_ORE: 3.0,
	GLASS: 0.3, RAIL: 0.4, MINECART: 0.5, BED: 0.8, TORCH: 0.2,
	SAND: 0.4, GRAVEL: 0.6, GLOW_BLOCK: 0.7, MUSIC_PLAYER: 0.9, SNOW: 0.25,
}
const SEED_CROP := {WHEAT_SEEDS: 0, POTATO_SEEDS: 1, BEET_SEEDS: 2}
const CROP_SEED := [WHEAT_SEEDS, POTATO_SEEDS, BEET_SEEDS]
const CROP_DROP := [WHEAT, POTATO, BEETROOT]
const ARMOR_SLOT_IDS := [HELMET, CHESTPLATE, LEGGINGS, BOOTS, SHIELD]
const ARMOR_SLOT_OF := {
	HELMET: 0, CHESTPLATE: 1, LEGGINGS: 2, BOOTS: 3, SHIELD: 4,
	S_HELMET: 0, S_CHESTPLATE: 1, S_LEGGINGS: 2, S_BOOTS: 3, S_SHIELD: 4,
	I_HELMET: 0, I_CHESTPLATE: 1, I_LEGGINGS: 2, I_BOOTS: 3,
	D_HELMET: 0, D_CHESTPLATE: 1, D_LEGGINGS: 2, D_BOOTS: 3, D_SHIELD: 4,
}
const ARMOR_NAMES := ["Шлем", "Нагрудник", "Поножи", "Ботинки", "Щит"]
const ARMOR_POINTS := [1, 3, 2, 1, 0]
const ARMOR_POINTS_STONE := [2, 4, 3, 2, 0]
const ARMOR_POINTS_IRON := [2, 6, 5, 2, 0]
const ARMOR_POINTS_DIAMOND := [3, 8, 6, 3, 0]
const WOOD_COL := [Color(0.72, 0.54, 0.29), Color(0.5, 0.36, 0.18)]
const STONE_COL := [Color(0.62, 0.62, 0.66), Color(0.4, 0.4, 0.45)]
const IRON_COL := [Color(0.8, 0.8, 0.85), Color(0.5, 0.5, 0.55)]
const DIAMOND_COL := [Color(0.28, 0.92, 0.88), Color(0.05, 0.42, 0.52)]
const LOAD_TIPS := [
	"Правый клик мотыгой по траве или земле создаёт грядку.",
	"Семена иногда выпадают, когда вы ломаете траву.",
	"Дважды нажмите на стопку, выберите «Разделить» и укажите слот для одного предмета.",
	"Правую кнопку мыши можно удерживать, чтобы раскладывать стопку по одному предмету.",
	"Верстак открывает крафт 3×3: правый клик по нему.",
	"Броня надевается в слоты слева от персонажа, правый клик по броне тоже надевает её.",
	"Пшеница, картошка и свёкла созревают примерно за 90 секунд.",
	"Ваш мир сохраняется автоматически при паузе и выходе из игры.",
	"Две двери получаются из шести досок: два столбика по три доски.",
	"Печка собирается из восьми камней по кругу на верстаке.",
	"В печке готовится сырая свинина и гнилая плоть; топливо — уголь или дерево.",
	"Два сундука рядом превращаются в двойной сундук.",
	"Щит поднимается правой кнопкой мыши и блокирует урон.",
	"Кровать позволяет пропустить ночь. Факел и светящийся блок освещают укрытие.",
	"В темноте встречаются скелеты с луками и пауки, которые ползают по стенам и потолку.",
]

const RECIPES := [
	{"pattern": [[LOG]], "table": false, "out": [PLANKS, 4]},
	{"pattern": [[PLANKS, PLANKS], [PLANKS, PLANKS]], "table": false, "out": [TABLE, 1]},
	{"pattern": [[PLANKS], [PLANKS]], "table": false, "out": [STICK, 4]},
	{"pattern": [[PLANKS, PLANKS, PLANKS], [0, STICK, 0], [0, STICK, 0]], "table": true, "out": [PICKAXE, 1]},
	{"pattern": [[0, PLANKS, STICK], [PLANKS, 0, STICK], [0, PLANKS, STICK]], "table": true, "out": [BOW, 1]},
	{"pattern": [[PLANKS], [STICK], [STICK]], "table": true, "out": [SHOVEL, 1]},
	{"pattern": [[PLANKS], [PLANKS], [STICK]], "table": true, "out": [SWORD, 1]},
	{"pattern": [[PLANKS, PLANKS], [PLANKS, STICK], [0, STICK]], "table": true, "out": [AXE, 1]},
	{"pattern": [[PLANKS, PLANKS], [STICK, PLANKS], [STICK, 0]], "table": true, "out": [AXE, 1]},
	{"pattern": [[PLANKS, PLANKS], [0, STICK], [0, STICK]], "table": true, "out": [HOE, 1]},
	{"pattern": [[PLANKS, PLANKS], [STICK, 0], [STICK, 0]], "table": true, "out": [HOE, 1]},
	{"pattern": [[STONE, STONE, STONE], [0, STICK, 0], [0, STICK, 0]], "table": true, "out": [S_PICKAXE, 1]},
	{"pattern": [[STONE], [STICK], [STICK]], "table": true, "out": [S_SHOVEL, 1]},
	{"pattern": [[STONE], [STONE], [STICK]], "table": true, "out": [S_SWORD, 1]},
	{"pattern": [[STONE, STONE], [STONE, STICK], [0, STICK]], "table": true, "out": [S_AXE, 1]},
	{"pattern": [[STONE, STONE], [STICK, STONE], [STICK, 0]], "table": true, "out": [S_AXE, 1]},
	{"pattern": [[STONE, STONE], [0, STICK], [0, STICK]], "table": true, "out": [S_HOE, 1]},
	{"pattern": [[STONE, STONE], [STICK, 0], [STICK, 0]], "table": true, "out": [S_HOE, 1]},
	{"pattern": [[PLANKS, PLANKS, PLANKS], [PLANKS, 0, PLANKS]], "table": true, "out": [HELMET, 1]},
	{"pattern": [[PLANKS, 0, PLANKS], [PLANKS, PLANKS, PLANKS], [PLANKS, PLANKS, PLANKS]], "table": true, "out": [CHESTPLATE, 1]},
	{"pattern": [[PLANKS, PLANKS, PLANKS], [PLANKS, 0, PLANKS], [PLANKS, 0, PLANKS]], "table": true, "out": [LEGGINGS, 1]},
	{"pattern": [[PLANKS, 0, PLANKS], [PLANKS, 0, PLANKS]], "table": true, "out": [BOOTS, 1]},
	{"pattern": [[PLANKS, IRON_INGOT, PLANKS], [PLANKS, PLANKS, PLANKS], [0, PLANKS, 0]], "table": true, "out": [SHIELD, 1]},
	{"pattern": [[STONE, STONE, STONE], [STONE, 0, STONE]], "table": true, "out": [S_HELMET, 1]},
	{"pattern": [[STONE, 0, STONE], [STONE, STONE, STONE], [STONE, STONE, STONE]], "table": true, "out": [S_CHESTPLATE, 1]},
	{"pattern": [[STONE, STONE, STONE], [STONE, 0, STONE], [STONE, 0, STONE]], "table": true, "out": [S_LEGGINGS, 1]},
	{"pattern": [[STONE, 0, STONE], [STONE, 0, STONE]], "table": true, "out": [S_BOOTS, 1]},
	{"pattern": [[STONE, IRON_INGOT, STONE], [STONE, STONE, STONE], [0, STONE, 0]], "table": true, "out": [S_SHIELD, 1]},
	{"pattern": [[PLANKS, PLANKS], [PLANKS, PLANKS], [PLANKS, PLANKS]], "table": true, "out": [DOOR, 2]},
	{"pattern": [[STONE, STONE, STONE], [STONE, 0, STONE], [STONE, STONE, STONE]], "table": true, "out": [FURNACE, 1]},
	{"pattern": [[PLANKS, PLANKS, PLANKS], [PLANKS, 0, PLANKS], [PLANKS, PLANKS, PLANKS]], "table": true, "out": [CHEST, 1]},
	{"pattern": [[IRON_INGOT, IRON_INGOT, IRON_INGOT], [0, STICK, 0], [0, STICK, 0]], "table": true, "out": [I_PICKAXE, 1]},
	{"pattern": [[IRON_INGOT], [STICK], [STICK]], "table": true, "out": [I_SHOVEL, 1]},
	{"pattern": [[IRON_INGOT], [IRON_INGOT], [STICK]], "table": true, "out": [I_SWORD, 1]},
	{"pattern": [[IRON_INGOT, IRON_INGOT], [IRON_INGOT, STICK], [0, STICK]], "table": true, "out": [I_AXE, 1]},
	{"pattern": [[IRON_INGOT, IRON_INGOT], [STICK, IRON_INGOT], [STICK, 0]], "table": true, "out": [I_AXE, 1]},
	{"pattern": [[IRON_INGOT, IRON_INGOT], [0, STICK], [0, STICK]], "table": true, "out": [I_HOE, 1]},
	{"pattern": [[IRON_INGOT, IRON_INGOT], [STICK, 0], [STICK, 0]], "table": true, "out": [I_HOE, 1]},
	{"pattern": [[IRON_INGOT, IRON_INGOT, IRON_INGOT], [IRON_INGOT, 0, IRON_INGOT]], "table": true, "out": [I_HELMET, 1]},
	{"pattern": [[IRON_INGOT, 0, IRON_INGOT], [IRON_INGOT, IRON_INGOT, IRON_INGOT], [IRON_INGOT, IRON_INGOT, IRON_INGOT]], "table": true, "out": [I_CHESTPLATE, 1]},
	{"pattern": [[IRON_INGOT, IRON_INGOT, IRON_INGOT], [IRON_INGOT, 0, IRON_INGOT], [IRON_INGOT, 0, IRON_INGOT]], "table": true, "out": [I_LEGGINGS, 1]},
	{"pattern": [[IRON_INGOT, 0, IRON_INGOT], [IRON_INGOT, 0, IRON_INGOT]], "table": true, "out": [I_BOOTS, 1]},
	{"pattern": [[DIAMOND, DIAMOND, DIAMOND], [0, STICK, 0], [0, STICK, 0]], "table": true, "out": [D_PICKAXE, 1]},
	{"pattern": [[DIAMOND], [DIAMOND], [STICK]], "table": true, "out": [D_SWORD, 1]},
	{"pattern": [[DIAMOND, DIAMOND], [DIAMOND, STICK], [0, STICK]], "table": true, "out": [D_AXE, 1]},
	{"pattern": [[DIAMOND], [STICK], [STICK]], "table": true, "out": [D_SHOVEL, 1]},
	{"pattern": [[DIAMOND, DIAMOND], [0, STICK], [0, STICK]], "table": true, "out": [D_HOE, 1]},
	{"pattern": [[DIAMOND, DIAMOND, DIAMOND], [DIAMOND, 0, DIAMOND]], "table": true, "out": [D_HELMET, 1]},
	{"pattern": [[DIAMOND, 0, DIAMOND], [DIAMOND, DIAMOND, DIAMOND], [DIAMOND, DIAMOND, DIAMOND]], "table": true, "out": [D_CHESTPLATE, 1]},
	{"pattern": [[DIAMOND, DIAMOND, DIAMOND], [DIAMOND, 0, DIAMOND], [DIAMOND, 0, DIAMOND]], "table": true, "out": [D_LEGGINGS, 1]},
	{"pattern": [[DIAMOND, 0, DIAMOND], [DIAMOND, 0, DIAMOND]], "table": true, "out": [D_BOOTS, 1]},
	{"pattern": [[PLANKS, DIAMOND, PLANKS], [PLANKS, PLANKS, PLANKS], [0, PLANKS, 0]], "table": true, "out": [D_SHIELD, 1]},
	{"pattern": [[PLANKS, PLANKS, PLANKS]], "table": true, "out": [BED, 1]},
	{"pattern": [[0, SHOVEL, 0], [PLANKS, 0, PLANKS], [PLANKS, PLANKS, PLANKS]], "table": true, "out": [BOAT, 1]},
	{"pattern": [[PLANKS, PLANKS, PLANKS], [PLANKS, STICK, PLANKS], [PLANKS, PLANKS, PLANKS]], "table": true, "out": [RAFT, 1]},
	{"pattern": [[PLANKS, 0, PLANKS], [PLANKS, IRON_INGOT, PLANKS], [PLANKS, 0, PLANKS]], "table": true, "out": [MUSIC_PLAYER, 1]},
	{"pattern": [[0, 0, 0], [IRON_INGOT, 0, IRON_INGOT], [IRON_INGOT, IRON_INGOT, IRON_INGOT]], "table": true, "out": [MINECART, 1]},
	{"pattern": [[COAL_ITEM], [STICK]], "table": false, "out": [TORCH, 4]},
]
const SMELTING := {
	SAND: GLASS,
	RAW_IRON: IRON_INGOT,
	RAW_PORK: COOKED_PORK,
	ROTTEN_FLESH: COOKED_FLESH,
}
const FUEL := {
	COAL_ITEM: 80.0, COAL: 80.0, PLANKS: 15.0, LOG: 15.0, STICK: 5.0, TABLE: 15.0,
}
const SMELT_TIME := 10.0

const FACE_N := [
	Vector3i(0, 1, 0), Vector3i(0, -1, 0),
	Vector3i(1, 0, 0), Vector3i(-1, 0, 0),
	Vector3i(0, 0, 1), Vector3i(0, 0, -1),
]
const FACE_V := [
	[Vector3(0, 1, 0), Vector3(1, 1, 0), Vector3(1, 1, 1), Vector3(0, 1, 1)],
	[Vector3(0, 0, 0), Vector3(0, 0, 1), Vector3(1, 0, 1), Vector3(1, 0, 0)],
	[Vector3(1, 0, 0), Vector3(1, 0, 1), Vector3(1, 1, 1), Vector3(1, 1, 0)],
	[Vector3(0, 0, 0), Vector3(0, 1, 0), Vector3(0, 1, 1), Vector3(0, 0, 1)],
	[Vector3(0, 0, 1), Vector3(0, 1, 1), Vector3(1, 1, 1), Vector3(1, 0, 1)],
	[Vector3(0, 0, 0), Vector3(1, 0, 0), Vector3(1, 1, 0), Vector3(0, 1, 0)],
]

var chunks: Array = []
var chunk_top: Array = []
var chunk_mi: Array = []
var chunk_cs: Array = []
var chunk_water_mi: Array = []
var water_mat: StandardMaterial3D
var glass_mat: StandardMaterial3D
var bed_mat: StandardMaterial3D
var bed_pillow_mat: StandardMaterial3D
var snow_mat: StandardMaterial3D
var trees_generated: Array[bool] = []
var villages_generated: Array[bool] = []
var heights := PackedInt32Array()
var control_mode := CONTROL_MODE_PC
var mobile_control_style := 0 # 0 — кнопки, 1 — виртуальный джойстик
var mobile_stick_touch := -1
var mobile_stick_origin := Vector2.ZERO
var mobile_stick_vector := Vector2.ZERO
var mobile_stick_base: Control
var mobile_stick_knob: Control
var mobile_dpad: Control
var mobile_virtual_stick: Control

var control_pc_button: Button
var control_mobile_button: Button
var hn := FastNoiseLite.new()
var mn := FastNoiseLite.new()
var ocean_noise := FastNoiseLite.new()
var biome_noise := FastNoiseLite.new()
var moisture_noise := FastNoiseLite.new()
var world_seed := 0
var treasure_target_cache := Vector2i(-1, -1)
var world_loaded := false
var world_load_failed := false
var saved_pos := Vector3.ZERO
var home_pos := Vector3.ZERO

var atlas_tex: Texture2D
var items_tex: Texture2D
var items2_tex: Texture2D
var block_mat: StandardMaterial3D
var highlight: MeshInstance3D
var break_overlay: MeshInstance3D
var break_mat: StandardMaterial3D
var crack_tex: Array = []

var player: CharacterBody3D
var step_timer := 0.0
var step_player: AudioStreamPlayer
var sfx_player: AudioStreamPlayer
var disc_audio_player: AudioStreamPlayer
var camera: Camera3D
var ray: RayCast3D
var pitch := 0.0
var player_cs: CollisionShape3D
var player_cap: CapsuleShape3D

var hand_pivot: Node3D
var hand_item: Node3D
var hand_left: Node3D
var fp_shield_mats: Array = []
var held_id := -1
var swing_phase := 0.0
var walk_bob := 0.0
var bob_amp := 0.0

var ready_done := false
var world_autosave_timer := 0.0
const WORLD_AUTOSAVE_INTERVAL := 12.0
var paused := false
var creative_mode := false
var creative_grid: GridContainer
var creative_scroll: ScrollContainer
var creative_scroll_direction := 0
var creative_scroll_repeat := 0.0
var inv_open := false
var table_mode := false
var breaking := false
var breaking_active := false
var mob_attack_cooldown := 0.0
var break_progress := 0.0
var break_cell := Vector3i(-1, -1, -1)

var close_x := MobileCloseX.new()

var blocking := false
var block_amt := 0.0
var health := 20.0
var health_label: Label
var breath_label: Label
var breath_time := 15.0
var drowning_tick := 0.0
var swimming := false
var fall_tracking := false
var fall_start_y := 0.0
var death_layer: CanvasLayer
var death_panel: PanelContainer
var death_respawn_button: Button
var is_dead := false
var msg_label: Label
var msg_t := 0.0

# Цикл дня и ночи
const DAY_NIGHT_CYCLE := 400.0
const DAY_LENGTH := 200.0
var cycle_time := 0.0
var sun_light: DirectionalLight3D
var world_env: Environment
var moon_node: MeshInstance3D
var star_nodes: Array[MeshInstance3D] = []
var day_night_label: Label
var held_name_label: Label
var held_name_timer := 0.0
var night_active := false
var sleep_votes: Dictionary = {}
var sleep_status_text := ""
var sleep_panel: PanelContainer
var sleep_panel_label: Label
var day_count := 1
var torch_lights: Dictionary = {}
var zombie_nodes: Array[Node3D] = []
var dropped_items: Dictionary = {}
var boat_nodes: Array[Node3D] = []
var riding_boat: Node3D = null
var riding_minecart := false
var minecart_cell := Vector3i.ZERO
var minecart_step_timer := 0.0
var raft_nodes: Array[Node3D] = []
var riding_raft: Node3D = null
var raft_rider_offset := Vector3.ZERO
var next_raft_id := 1
var raft_motion_sync_timer := 0.0
var pending_raft_board := false
var raft_is_driving := false
var next_drop_id: int = 1
var zombie_spawn_timer := 0.0
var spawn_protection := 30.0
var damage_flash: ColorRect
var damage_flash_timer := 0.0
var villagers: Array[Node3D] = []
var villager_targets: Dictionary = {}

# DareCraft Online: host-authoritative WebSocket room relay (8 players total).
var net_socket: WebSocketPeer
var net_remote_players: Dictionary = {}
var net_sync_timer: float = 0.0
var net_world_clock_timer: float = 0.0
var net_mob_sync_timer: float = 0.0
var net_raft_sync_timer: float = 0.0
var net_physics_sync_timer: float = 0.0
var physics_bodies: Dictionary = {}
var next_physics_body_id: int = 1
var net_remote_mobs: Dictionary = {}
var net_apply_remote_music := false
var net_connect_elapsed: float = 0.0
var net_storage_timer: float = 0.0
var net_last_storage_signature: String = ""
var net_storage_ready: bool = false
var net_connected: bool = false
var net_is_host: bool = false
var net_peer_id: int = 0
var net_host_peer_id: int = 1
var net_handshake_sent: bool = false
var net_apply_remote_block: bool = false
var net_changed_blocks: Dictionary = {}
var net_pending_packets: Array[Dictionary] = []
var net_snapshot_send_queue: Array[Dictionary] = []
var net_snapshot_send_timer := 0.0
var net_snapshot_parts: Array[String] = []
var net_snapshot_expected_parts := 0
var net_snapshot_raw_size := 0
var net_snapshot_end_received := false
var net_pickup_pending: Dictionary = {}
var net_status_label: Label

var pause_layer: CanvasLayer
var loading_layer: CanvasLayer
var hud_layer: CanvasLayer
var loading_label: Label
var inv_layer: CanvasLayer
var inv_title: Label
var craft_title: Label
var grid_small: GridContainer
var grid_big: GridContainer

var slots: Array = []
var armor: Array = []
var craft_grid: Array = []
var selected := 0
var cursor_item := {"id": 0, "n": 0}
var craft_recipe := {}
var hot_ui: Array = []
var inv_ui: Array = []
var armor_ui: Array = []
var armor_label: Label
var craft_small_ui: Array = []
var craft_big_ui: Array = []
var craft_out_ui: Dictionary = {}
var cursor_ui: Dictionary = {}
var icon_cache := {}
var rmb_down := false
var rmb_visited := {}

# Разделение предметов в инвентаре по двойному нажатию.
var split_button: Button
var split_mode := false
var split_source_slot := -1
var suppress_next_slot_click := false
var last_inv_click_slot := -1
var last_inv_click_time_msec := 0
var last_inv_click_stack := {"id": 0, "n": 0}

var crops := {}
var crop_nodes := {}
var grow_acc := 0.0

var doors := {}
var door_nodes := {}

var furnaces := {}
var furnace_ui_cell := Vector3i(-1, -1, -1)
var furnace_slots_ui: Array = []
var furnace_inv_ui: Array = []
var furnace_hot_ui: Array = []
var furnace_layer: CanvasLayer

var chests := {}
var chest_layer: CanvasLayer
var chest_ui_cell := Vector3i(-1, -1, -1)
var chest_slots_ui: Array = []
var chest_inv_ui: Array = []
var chest_hot_ui: Array = []
var chest_is_double := false
var chest_title_lbl: Label

var load_cam: Camera3D
var view_mode := 0
var emote_cooldown := 0.0
var local_emote_id := -1
var local_emote_time := 0.0
var emote_wheel_layer: CanvasLayer
var emote_wheel_open := false
const EMOTE_NAMES := ["Танец", "Привет", "Аплодисменты", "Флекс", "Фейспалм", "Лайк", "GG", "Победа"]
const EMOTE_SYMBOLS := ["♪", "👋", "👏", "💪", "🤦", "👍", "GG", "★"]
var aim_pivot: Node3D
var chars: Array = []
var player_char: Dictionary = {}
var preview_char: Dictionary = {}
var load_t := 0.0
var loading_bar: ProgressBar
var mobile_hud: Control
var quickbar_container: Control
var mobile_move_vec := Vector2.ZERO
var mobile_move_flags := {"up": false, "down": false, "left": false, "right": false}
var mobile_jump_held := false
var creative_flying := false
var commands_enabled := false
var chat_open := false
var chat_panel: PanelContainer
var chat_input: LineEdit
var chat_history: Label
var jump_was_down := false
var last_jump_msec := 0
var mobile_crouch_held := false
var mobile_sprint_held := false
var mobile_break_held := false
var mobile_look_touch_id := -1
var mobile_look_last_pos: Vector2 = Vector2.ZERO
var realistic_destruction := true
var mob_ragdoll_enabled := true
var physics_preset := 1 # 0 — мягкая, 1 — обычная, 2 — максимальная
var falling_body_count := 0

# Per-world achievement trackers. Unlock states are saved separately from world saves.
var achievement_elapsed := 0.0
var achievement_pacifist_timer := 0.0
var achievement_minute_bucket := 0
var achievement_kill_this_minute := false
var achievement_emotionless_streak := 0
var achievement_hostile_kill_times: Array[float] = []
var achievement_wheat_timer := 0.0
var achievement_check_timer := 0.0
var achievement_toast_layer: CanvasLayer
var achievement_toast: PanelContainer
var achievement_toast_label: Label
var achievement_toast_icon: Label
var achievement_toast_title: Label
var achievement_toast_description: Label
var achievement_toast_timer := 0.0
var nokia_pending_cell := Vector3i(-1, -1, -1)

func _ready() -> void:
	var game_font_theme: Theme = null
	var darecraft_font: Font = load("res://DareCraftDisplay.ttf") as Font
	if darecraft_font != null:
		game_font_theme = Theme.new()
		game_font_theme.default_font = darecraft_font
	randomize()
	Achievements.begin_world(Global.current_world)
	if not Achievements.achievement_unlocked.is_connected(_on_achievement_unlocked):
		Achievements.achievement_unlocked.connect(_on_achievement_unlocked)
	_load_control_mode()
	_load_physics_settings()
	add_child(close_x)
	close_x.setup([], control_mode == CONTROL_MODE_MOBILE, _close_any_open_menu)

	for i in TOTAL_SLOTS:
		slots.append({"id": 0, "n": 0})
	for i in 5:
		armor.append({"id": 0, "n": 0})
	for i in 9:
		craft_grid.append({"id": 0, "n": 0})
	_make_materials()
	sfx_player = AudioStreamPlayer.new()
	add_child(sfx_player)
	disc_audio_player = AudioStreamPlayer.new()
	disc_audio_player.bus = "Master"
	add_child(disc_audio_player)
	_make_crack_textures()
	_make_environment()
	_make_hud()
	_make_achievement_notice_ui()
	_make_sleep_ui()
	_make_chat_ui()
	_make_mobile_hud()
	_make_emote_wheel()
	_make_inventory_ui()
	_make_furnace_ui()
	_make_chest_ui()
	_make_cursor_ui()
	_make_pause_menu()
	_make_loading_ui()
	_make_loading_cam()
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	await get_tree().process_frame
	if Global.network_mode == "client":
		await _connect_client_before_world()
	await _generate_world()
	_make_player()
	_update_chunks(true)
	_make_hand()
	_spawn_loaded_crops()
	_spawn_loaded_doors()
	if load_cam != null:
		load_cam.queue_free()
		load_cam = null
	loading_layer.queue_free()
	ready_done = true
	achievement_elapsed = 0.0
	achievement_pacifist_timer = 0.0
	achievement_minute_bucket = 0
	achievement_kill_this_minute = false
	achievement_emotionless_streak = 0
	hud_layer.visible = true
	if not world_loaded and not world_load_failed:
		_save_world()
	elif world_load_failed:
		_show_msg("Сохранение не удалось прочитать. Старый файл оставлен без перезаписи.")
	_refresh_slots()
	_start_network_session()
	# In a hosted world only the host creates passive animals. Guest-side mob
	# simulation is intentionally disabled until entity replication is complete.
	if Global.network_mode != "client":
		for i in range(10):
			var rx = int(player.position.x) + (randi_range(-15, -9) if randf() < 0.5 else randi_range(9, 15))
			var rz = int(player.position.z) + randi_range(-15, 15)
			rx = clampi(rx, 2, WORLD_SIZE - 2)
			rz = clampi(rz, 2, WORLD_SIZE - 2)
			var ry = _height_at(rx, rz) + 2
			var pig = _create_pig(Vector3(rx + 0.5, ry, rz + 0.5))
			add_child(pig)
	_apply_control_mode()
	if not Localization.language_changed.is_connected(_on_game_language_changed):
		Localization.language_changed.connect(_on_game_language_changed)
	Localization.apply_to_tree(self)
	# Долгая защита при входе: мобы не должны атаковать до того, как игрок освоится.
	spawn_protection = 30.0
	day_night_label = Label.new()
	day_night_label.position = Vector2(16, 42)
	day_night_label.add_theme_font_size_override("font_size", 20)
	day_night_label.add_theme_color_override("font_outline_color", Color.BLACK)
	day_night_label.add_theme_constant_override("outline_size", 5)
	hud_layer.add_child(day_night_label)
	day_night_label.text = _seed_display()
	held_name_label = Label.new()
	held_name_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	held_name_label.visible = false
	held_name_label.set_anchors_preset(Control.PRESET_CENTER_BOTTOM)
	held_name_label.offset_left = -220
	held_name_label.offset_right = 220
	held_name_label.offset_top = -112
	held_name_label.offset_bottom = -82
	held_name_label.add_theme_font_size_override("font_size", 20)
	held_name_label.add_theme_color_override("font_outline_color", Color.BLACK)
	held_name_label.add_theme_constant_override("outline_size", 5)
	hud_layer.add_child(held_name_label)
	var initial_held: int = int(slots[selected]["id"])
	if initial_held != 0:
		held_name_label.text = _item_name(initial_held)
		held_name_label.visible = true
		held_name_timer = 2.0
	if game_font_theme != null:
		_apply_theme_to_controls(self, game_font_theme)

func _apply_theme_to_controls(root: Node, applied_theme: Theme) -> void:
	if root is Control:
		var ui_control := root as Control
		if ui_control.theme == null:
			ui_control.theme = applied_theme
	for child in root.get_children():
		_apply_theme_to_controls(child, applied_theme)

func _close_any_open_menu() -> void:
	if chest_layer != null and chest_layer.visible:
		_close_chest()
	elif furnace_layer != null and furnace_layer.visible:
		_close_furnace()
	elif inv_open:
		_close_inventory()

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_CLOSE_REQUEST or what == NOTIFICATION_APPLICATION_PAUSED or what == NOTIFICATION_PREDELETE:
		_save_world()

# ---------------- сохранение ----------------

func _save_world() -> bool:
	if not ready_done or player == null or Global.current_world.is_empty() or world_load_failed:
		return false
	var directory := ProjectSettings.globalize_path(Global.worlds_dir())
	var dir_error := DirAccess.make_dir_recursive_absolute(directory)
	if dir_error != OK and dir_error != ERR_ALREADY_EXISTS:
		push_error("DareCraft: не удалось создать папку миров: %s (%s)" % [directory, error_string(dir_error)])
		return false
	var final_path := ProjectSettings.globalize_path(Global.world_path(Global.current_world))
	var temp_path := final_path + ".tmp"
	var backup_path := final_path + ".bak"
	var f := FileAccess.open(temp_path, FileAccess.WRITE)
	if f == null:
		push_error("DareCraft: не удалось открыть файл сохранения: %s (%s)" % [temp_path, error_string(FileAccess.get_open_error())])
		return false
	f.store_32(SAVE_VERSION)
	f.store_32(world_seed)
	for i in CW * CW:
		var chunk_data: PackedByteArray = chunks[i] if chunks[i] is PackedByteArray else PackedByteArray()
		# Version 4 stores an explicit length so unexplored chunks do not corrupt
		# the following chunk data on load.
		f.store_32(chunk_data.size())
		if not chunk_data.is_empty():
			f.store_buffer(chunk_data)
	f.store_var(player.position)
	f.store_var(slots)
	f.store_var(armor)
	f.store_var(crops)
	f.store_var(doors)
	f.store_var(furnaces)
	f.store_var(chests)
	f.store_8(1 if commands_enabled else 0)
	f.store_float(cycle_time)
	f.store_32(day_count)
	f.store_var(_serialize_rafts())
	f.flush()
	var write_error := f.get_error()
	f.close()
	if write_error != OK:
		push_error("DareCraft: ошибка записи мира: %s" % error_string(write_error))
		DirAccess.remove_absolute(temp_path)
		return false
	# Сначала сохраняем предыдущую версию, чтобы прерванная запись не уничтожила мир.
	if FileAccess.file_exists(final_path):
		if FileAccess.file_exists(backup_path):
			DirAccess.remove_absolute(backup_path)
		var backup_error := DirAccess.rename_absolute(final_path, backup_path)
		if backup_error != OK:
			push_error("DareCraft: не удалось создать резервную копию мира: %s" % error_string(backup_error))
			DirAccess.remove_absolute(temp_path)
			return false
	var rename_error := DirAccess.rename_absolute(temp_path, final_path)
	if rename_error != OK:
		push_error("DareCraft: не удалось завершить сохранение: %s" % error_string(rename_error))
		if FileAccess.file_exists(backup_path) and not FileAccess.file_exists(final_path):
			DirAccess.rename_absolute(backup_path, final_path)
		DirAccess.remove_absolute(temp_path)
		return false
	world_autosave_timer = 0.0
	return true

func _load_control_mode() -> void:
	var config := ConfigFile.new()
	var error := config.load(CONTROL_SETTINGS_PATH)
	if error == OK:
		control_mode = clampi(
			int(config.get_value("controls", "mode", CONTROL_MODE_PC)),
			CONTROL_MODE_PC,
			CONTROL_MODE_MOBILE
		)
	else:
		control_mode = CONTROL_MODE_PC
	mobile_control_style = int(config.get_value("controls", "mobile_style", 0)) if error == OK else 0

func _save_control_mode() -> void:
	var config := ConfigFile.new()
	config.load(CONTROL_SETTINGS_PATH)
	config.set_value("controls", "mode", control_mode)
	var error := config.save(CONTROL_SETTINGS_PATH)
	if error != OK:
		push_warning("Не удалось сохранить режим управления")

func _set_control_mode(mode: int) -> void:
	control_mode = clampi(mode, CONTROL_MODE_PC, CONTROL_MODE_MOBILE)
	_save_control_mode()
	_refresh_control_mode_buttons()
	_apply_control_mode()

func _apply_control_mode() -> void:
	var is_mobile := control_mode == CONTROL_MODE_MOBILE
	close_x.set_mobile(is_mobile)
	if mobile_hud != null:
		mobile_hud.visible = is_mobile and ready_done and not paused and not inv_open
	if not is_mobile:
		_reset_mobile_inputs()
	if ready_done and not paused and not inv_open:
		Input.mouse_mode = Input.MOUSE_MODE_VISIBLE if is_mobile else Input.MOUSE_MODE_CAPTURED

func _reset_mobile_inputs() -> void:
	mobile_move_flags = {"up": false, "down": false, "left": false, "right": false}
	mobile_move_vec = Vector2.ZERO
	mobile_stick_vector = Vector2.ZERO
	mobile_stick_touch = -1
	if mobile_stick_knob != null: mobile_stick_knob.position = Vector2(56, 56)
	mobile_jump_held = false
	mobile_crouch_held = false
	mobile_sprint_held = false
	mobile_break_held = false
	breaking = false
	blocking = false
	mobile_look_touch_id = -1

func _refresh_control_mode_buttons() -> void:
	if control_pc_button == null or control_mobile_button == null:
		return
	control_pc_button.text = "✓ ПК" if control_mode == CONTROL_MODE_PC else "ПК"
	control_mobile_button.text = "✓ МОБИЛА" if control_mode == CONTROL_MODE_MOBILE else "МОБИЛА"

func _load_world() -> bool:
	var path: String = ProjectSettings.globalize_path(Global.world_path(Global.current_world))
	var backup_path := path + ".bak"
	if not FileAccess.file_exists(path) and FileAccess.file_exists(backup_path):
		var recovery_error := DirAccess.rename_absolute(backup_path, path)
		if recovery_error != OK:
			push_warning("DareCraft: не удалось восстановить резервное сохранение: %s" % error_string(recovery_error))
	if not FileAccess.file_exists(path):
		return false
	var f := FileAccess.open(path, FileAccess.READ)
	if f == null:
		return false
	if f.get_length() < 8:
		f.close()
		return false
	var file_version := f.get_32()
	if file_version < 1 or file_version > SAVE_VERSION:
		f.close()
		push_warning("DareCraft: неизвестная версия сохранения: %d" % file_version)
		return false
	# Legacy versions 1–3 wrote every chunk as a fixed-size buffer.
	if file_version <= 3 and f.get_length() < 8 + CW * CW * CS * CS * WORLD_H:
		f.close()
		push_warning("DareCraft: старое сохранение неполное или повреждено")
		return false
	world_seed = f.get_32()
	for i in CW * CW:
		var chunk_size := CS * CS * WORLD_H
		if file_version >= 4:
			if f.get_position() + 4 > f.get_length():
				f.close()
				return false
			chunk_size = int(f.get_32())
			if chunk_size != 0 and chunk_size != CS * CS * WORLD_H:
				f.close()
				push_warning("DareCraft: неверный размер чанка в сохранении")
				return false
		var buf := f.get_buffer(chunk_size) if chunk_size > 0 else PackedByteArray()
		if buf.size() != chunk_size:
			f.close()
			return false
		chunks[i] = buf
		var top := 0
		if buf.size() == CS * CS * WORLD_H:
			var y := WORLD_H - 1
			while y > 0 and top == 0:
				for j in 256:
					if buf[j + y * 256] != 0:
						top = y
						break
				y -= 1
		chunk_top[i] = top
	var pos = f.get_var()
	if pos is Vector3:
		saved_pos = pos
	var sv = f.get_var()
	if sv is Array and sv.size() == TOTAL_SLOTS:
		slots = sv
	if f.get_position() < f.get_length():
		var av = f.get_var()
		if av is Array:
			for i in mini(av.size(), 5):
				armor[i] = av[i]
	if f.get_position() < f.get_length():
		var cv = f.get_var()
		if cv is Dictionary:
			crops = cv
	if f.get_position() < f.get_length():
		var dv = f.get_var()
		if dv is Dictionary:
			doors = dv
	if f.get_position() < f.get_length():
		var fv = f.get_var()
		if fv is Dictionary:
			furnaces = fv
	if f.get_position() < f.get_length():
		var chv = f.get_var()
		if chv is Dictionary:
			chests = chv
	if f.get_position() < f.get_length():
		commands_enabled = f.get_8() != 0
	if f.get_position() + 4 <= f.get_length():
		cycle_time = clampf(f.get_float(), 0.0, DAY_NIGHT_CYCLE - 0.01)
	if f.get_position() + 4 <= f.get_length():
		day_count = maxi(1, int(f.get_32()))
	var saved_rafts: Variant = []
	if f.get_position() < f.get_length():
		saved_rafts = f.get_var()
	night_active = cycle_time >= DAY_LENGTH
	f.close()
	_restore_saved_rafts(saved_rafts)
	return true

# ---------------- материалы и окружение ----------------

func _color_mat(c: Color) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = c
	m.roughness = 1.0
	return m

func _make_materials() -> void:
	atlas_tex = load("res://atlas.png")
	items_tex = load("res://items.png")
	items2_tex = load("res://items2.png")
	block_mat = StandardMaterial3D.new()
	block_mat.albedo_texture = atlas_tex
	block_mat.texture_filter = BaseMaterial3D.TEXTURE_FILTER_NEAREST
	block_mat.roughness = 1.0
	# Альфа-канал используется стеклянным тайлом; остальные тайлы остаются непрозрачными.
	block_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA_SCISSOR
	block_mat.alpha_scissor_threshold = 0.5
	block_mat.roughness = 0.92
	glass_mat = StandardMaterial3D.new()
	glass_mat.albedo_texture = atlas_tex
	glass_mat.texture_filter = BaseMaterial3D.TEXTURE_FILTER_NEAREST
	glass_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA_DEPTH_PRE_PASS
	glass_mat.roughness = 0.18
	glass_mat.cull_mode = BaseMaterial3D.CULL_DISABLED
	bed_mat = StandardMaterial3D.new()
	bed_mat.albedo_color = Color(0.72, 0.08, 0.13, 1.0)
	bed_mat.roughness = 0.96
	bed_pillow_mat = StandardMaterial3D.new()
	bed_pillow_mat.albedo_color = Color(0.95, 0.88, 0.72, 1.0)
	bed_pillow_mat.roughness = 0.96
	snow_mat = StandardMaterial3D.new()
	var snow_image := Image.create(16, 16, false, Image.FORMAT_RGBA8)
	snow_image.fill(Color(0.91, 0.96, 1.0, 1.0))
	for sy in range(16):
		for sx in range(16):
			var snow_pixel := (sx * 7 + sy * 11 + sx * sy) % 13
			if snow_pixel == 0:
				snow_image.set_pixel(sx, sy, Color(0.72, 0.84, 0.94, 1.0))
			elif snow_pixel == 3 or snow_pixel == 8:
				snow_image.set_pixel(sx, sy, Color(1.0, 1.0, 1.0, 1.0))
	snow_mat.albedo_texture = ImageTexture.create_from_image(snow_image)
	snow_mat.texture_filter = BaseMaterial3D.TEXTURE_FILTER_NEAREST
	snow_mat.roughness = 0.96
	water_mat = StandardMaterial3D.new()
	water_mat.albedo_color = Color(0.055, 0.30, 0.66, 0.82)
	water_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA_DEPTH_PRE_PASS
	water_mat.shading_mode = BaseMaterial3D.SHADING_MODE_PER_PIXEL
	water_mat.roughness = 0.12
	water_mat.metallic = 0.04
	water_mat.specular_mode = BaseMaterial3D.SPECULAR_SCHLICK_GGX
	water_mat.cull_mode = BaseMaterial3D.CULL_DISABLED

	highlight = MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = Vector3(1.01, 1.01, 1.01)
	highlight.mesh = bm
	var hm := StandardMaterial3D.new()
	hm.albedo_color = Color(1, 1, 1, 0.18)
	hm.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	hm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	highlight.material_override = hm
	highlight.visible = false
	add_child(highlight)

	break_overlay = MeshInstance3D.new()
	break_overlay.mesh = _make_cube(0, 0.01)
	break_mat = StandardMaterial3D.new()
	break_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	break_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	break_mat.texture_filter = BaseMaterial3D.TEXTURE_FILTER_NEAREST
	break_overlay.material_override = break_mat
	break_overlay.visible = false
	add_child(break_overlay)

func _make_crack_textures() -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = 4242
	var dirs: Array[Vector2i] = [
		Vector2i(1, 0), Vector2i(1, 1), Vector2i(0, 1), Vector2i(-1, 1),
		Vector2i(-1, 0), Vector2i(-1, -1), Vector2i(0, -1), Vector2i(1, -1),
	]
	var walkers := 6
	var pos: Array[Vector2i] = []
	var main_dir: Array[Vector2i] = []
	for w in walkers:
		pos.append(Vector2i(8, 8))
		main_dir.append(dirs[int(w * 8.0 / walkers)])
	var pts: Array[Vector2i] = []
	for step in 10:
		for w in walkers:
			var d: Vector2i = main_dir[w] if rng.randf() < 0.7 else dirs[rng.randi_range(0, 7)]
			var p: Vector2i = pos[w] + d
			p = Vector2i(clampi(p.x, 0, 15), clampi(p.y, 0, 15))
			pos[w] = p
			pts.append(p)
	for stage in CRACK_STAGES:
		var img := Image.create(16, 16, false, Image.FORMAT_RGBA8)
		img.fill(Color(0, 0, 0, 0))
		var count := int(pts.size() * (stage + 1) / float(CRACK_STAGES))
		for k in count:
			img.set_pixelv(pts[k], Color(0, 0, 0, 0.75))
		crack_tex.append(ImageTexture.create_from_image(img))

func _make_environment() -> void:
	sun_light = DirectionalLight3D.new()
	sun_light.name = "DaySun"
	sun_light.rotation_degrees = Vector3(-50, -30, 0)
	sun_light.light_color = Color(1.0, 0.94, 0.78)
	sun_light.light_energy = 1.15
	add_child(sun_light)
	var we := WorldEnvironment.new()
	world_env = Environment.new()
	world_env.background_mode = Environment.BG_COLOR
	world_env.background_color = Color(0.5, 0.75, 1.0)
	world_env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	world_env.ambient_light_color = Color(1, 1, 1)
	world_env.ambient_light_energy = 0.5
	we.environment = world_env
	add_child(we)
	_make_sky_objects()

func _make_sky_objects() -> void:
	var moon_mesh := SphereMesh.new()
	moon_mesh.radius = 2.4
	moon_mesh.height = 4.8
	moon_node = MeshInstance3D.new()
	moon_node.name = "Moon"
	moon_node.mesh = moon_mesh
	var moon_mat := StandardMaterial3D.new()
	moon_mat.albedo_color = Color(0.78, 0.84, 1.0)
	moon_mat.emission_enabled = true
	moon_mat.emission = Color(0.48, 0.58, 0.9)
	moon_mat.emission_energy_multiplier = 0.8
	moon_node.material_override = moon_mat
	moon_node.visible = false
	add_child(moon_node)
	var star_mesh := SphereMesh.new()
	star_mesh.radius = 0.11
	star_mesh.height = 0.22
	var star_mat := StandardMaterial3D.new()
	star_mat.albedo_color = Color(0.92, 0.95, 1.0)
	star_mat.emission_enabled = true
	star_mat.emission = Color(0.75, 0.82, 1.0)
	star_mat.emission_energy_multiplier = 1.4
	for i in 90:
		var star := MeshInstance3D.new()
		star.mesh = star_mesh
		star.material_override = star_mat
		star.position = Vector3(randf_range(-75.0, 75.0), randf_range(18.0, 65.0), randf_range(-75.0, 75.0))
		star.visible = false
		add_child(star)
		star_nodes.append(star)

func _update_day_night(delta: float) -> void:
	cycle_time = fmod(cycle_time + delta, DAY_NIGHT_CYCLE)
	var is_night := cycle_time >= DAY_LENGTH
	var night_blend := 0.0
	if is_night:
		night_blend = clampf((cycle_time - DAY_LENGTH) / 18.0, 0.0, 1.0)
	else:
		night_blend = 1.0 - clampf(cycle_time / 18.0, 0.0, 1.0)
	var sun_angle := -15.0 - (cycle_time / DAY_NIGHT_CYCLE) * 360.0
	sun_light.rotation_degrees.x = sun_angle
	sun_light.light_energy = lerpf(1.15, 0.04, night_blend)
	world_env.background_color = Color(0.5, 0.75, 1.0).lerp(Color(0.012, 0.018, 0.055), night_blend)
	world_env.ambient_light_color = Color(1.0, 0.96, 0.86).lerp(Color(0.18, 0.22, 0.42), night_blend)
	world_env.ambient_light_energy = lerpf(0.55, 0.22, night_blend)
	moon_node.visible = night_blend > 0.15
	moon_node.global_position = player.global_position + Vector3(35.0, 48.0, -62.0)
	for star in star_nodes:
		star.visible = night_blend > 0.55
		star.global_position += Vector3.ZERO
		# Звёзды держатся вокруг игрока, чтобы не исчезать при перемещении.
		var rel := star.position
		star.global_position = player.global_position + Vector3(rel.x, rel.y, rel.z)
	if day_night_label != null and player != null:
		var biome_name := _biome_name(_biome_at(int(floor(player.position.x)), int(floor(player.position.z))))
		day_night_label.text = "%s · %s   X:%d Y:%d Z:%d" % [_seed_display(), biome_name, int(floor(player.position.x)), int(floor(player.position.y)), int(floor(player.position.z))]
	if is_night != night_active:
		if not is_night:
			day_count += 1
		night_active = is_night
		if night_active:
			_show_msg("Наступила ночь. В темноте появляются враждебные мобы!")
			zombie_spawn_timer = 0.5
		else:
			_show_msg("Рассвет! На открытой поверхности враждебные мобы исчезают.")
			var remaining_dark_mobs: Array[Node3D] = []
			for mob in zombie_nodes:
				if not is_instance_valid(mob):
					continue
				if _is_position_sheltered(mob.global_position):
					remaining_dark_mobs.append(mob)
				else:
					mob.queue_free()
			zombie_nodes = remaining_dark_mobs
	var night_is_dark := is_night and night_blend >= 0.75
	var player_is_in_dark_cave := _is_position_sheltered(player.global_position)
	if not creative_mode and (night_is_dark or player_is_in_dark_cave):
		_update_zombie_spawns(delta, 1.0)
	else:
		# Never allow a pending timer to create surface mobs during daytime.
		zombie_spawn_timer = maxf(zombie_spawn_timer, 4.0)

func _is_position_sheltered(world_pos: Vector3) -> bool:
	var x := clampi(roundi(world_pos.x), 1, WORLD_SIZE - 2)
	var z := clampi(roundi(world_pos.z), 1, WORLD_SIZE - 2)
	var y := roundi(world_pos.y)
	# A position is sheltered only when a real roof is present overhead.
	# A shallow hillside/surface height difference alone must not spawn mobs in daylight.
	var roof_columns := 0
	for dx in range(-1, 2):
		for dz in range(-1, 2):
			if get_block(x + dx, y + 2, z + dz) != 0 and get_block(x + dx, y + 3, z + dz) != 0:
				roof_columns += 1
	return roof_columns >= 5

func _player_is_near_mine() -> bool:
	var center := Vector3i(roundi(player.position.x), roundi(player.position.y), roundi(player.position.z))
	for dx in range(-10, 11):
		for dz in range(-10, 11):
			for dy in range(-3, 4):
				if get_block(center.x + dx, center.y + dy, center.z + dz) == RAIL:
					return true
	return false

func _spawn_mine_mob() -> void:
	var base := Vector3i(roundi(player.position.x), roundi(player.position.y), roundi(player.position.z))
	for attempt in 12:
		var x := base.x + randi_range(-7, 7)
		var y := base.y + randi_range(-1, 2)
		var z := base.z + randi_range(-7, 7)
		if get_block(x, y, z) != 0 or get_block(x, y + 1, z) != 0 or get_block(x, y - 1, z) == 0:
			continue
		var mob := CharacterBody3D.new()
		var roll := randf()
		var group_name := "mob_zombie"
		if roll < 0.30:
			mob.set_script(load("res://spider.gd"))
			group_name = "mob_spider"
		elif roll < 0.58:
			mob.set_script(load("res://skeleton.gd"))
			group_name = "mob_skeleton"
		else:
			mob.set_script(load("res://zombie.gd"))
		mob.add_to_group("darecraft_mob")
		mob.add_to_group(group_name)
		mob.position = Vector3(x + 0.5, y, z + 0.5)
		mob.set("target", player)
		mob.set("world_controller", self)
		add_child(mob)
		zombie_nodes.append(mob)
		return

func _update_zombie_spawns(delta: float, darkness_level: float = 1.0) -> void:
	# Host owns hostile mob simulation in online sessions.
	if net_connected and not net_is_host:
		return
	zombie_nodes = zombie_nodes.filter(func(z): return is_instance_valid(z))
	if spawn_protection > 0.0:
		return
	zombie_spawn_timer -= delta
	if zombie_spawn_timer <= 0.0 and (_player_is_near_mine() or _is_position_sheltered(player.global_position)):
		if zombie_nodes.size() < 7:
			zombie_spawn_timer = randf_range(7.0, 12.0)
			_spawn_mine_mob()
		return
	var max_mobs := 2 if darkness_level > 1.2 else 4
	if zombie_spawn_timer <= 0.0 and zombie_nodes.size() < max_mobs:
		zombie_spawn_timer = 32.0 if darkness_level > 1.2 else 22.0
		var angle := randf() * TAU
		var distance := randf_range(13.0, 22.0)
		var x := clampi(int(player.position.x + cos(angle) * distance), 2, WORLD_SIZE - 3)
		var zpos := clampi(int(player.position.z + sin(angle) * distance), 2, WORLD_SIZE - 3)
		var y := _height_at(x, zpos) + 1
		var attempts := 0
		while attempts < 8 and (get_block(x, y + 1, zpos) != 0 or get_block(x, y + 2, zpos) != 0):
			angle = randf() * TAU
			x = clampi(int(player.position.x + cos(angle) * distance), 2, WORLD_SIZE - 3)
			zpos = clampi(int(player.position.z + sin(angle) * distance), 2, WORLD_SIZE - 3)
			y = _height_at(x, zpos) + 1
			attempts += 1
		if attempts >= 8 and (get_block(x, y + 1, zpos) != 0 or get_block(x, y + 2, zpos) != 0):
			return
		var mob := CharacterBody3D.new()
		var mob_roll := randf()
		var mob_group := "mob_zombie"
		if mob_roll < 0.22:
			mob.set_script(load("res://spider.gd"))
			mob_group = "mob_spider"
		elif mob_roll < 0.48:
			mob.set_script(load("res://skeleton.gd"))
			mob_group = "mob_skeleton"
		else:
			mob.set_script(load("res://zombie.gd"))
		mob.add_to_group("darecraft_mob")
		mob.add_to_group(mob_group)
		mob.position = Vector3(x + 0.5, y, zpos + 0.5)
		mob.set("target", player)
		mob.set("world_controller", self)
		add_child(mob)
		zombie_nodes.append(mob)

func _append_box_geometry(vertices: Array, normals: Array, uvs: Array, indices: Array, cell_origin: Vector3, center: Vector3, size: Vector3, top_tile: int, side_tile: int, bottom_tile: int) -> void:
	for face in 6:
		var normal: Vector3i = FACE_N[face]
		var face_vertices: Array = FACE_V[face]
		var tile: int = top_tile if face == 0 else (bottom_tile if face == 1 else side_tile)
		var base: int = vertices.size()
		for corner in 4:
			var v: Vector3 = face_vertices[corner]
			vertices.append(cell_origin + center + (v - Vector3(0.5, 0.5, 0.5)) * size)
			normals.append(Vector3(normal))
			var u := v.x
			var w := v.z
			if face >= 2 and face < 4:
				u = v.z
				w = 1.0 - v.y
			elif face >= 4:
				w = 1.0 - v.y
			uvs.append(Vector2((tile + lerpf(0.01, 0.99, u)) / float(ATLAS_TILES), lerpf(0.01, 0.99, w)))
		indices.append(base)
		indices.append(base + 1)
		indices.append(base + 2)
		indices.append(base)
		indices.append(base + 2)
		indices.append(base + 3)

func _make_hand_torch(parent: Node3D, cube_scale: float) -> void:
	var torch := Node3D.new()
	torch.scale = Vector3.ONE * cube_scale
	torch.rotation_degrees.y = 25.0
	parent.add_child(torch)
	var wood := _color_mat(Color(0.34, 0.20, 0.10))
	var wood_light := _color_mat(Color(0.56, 0.34, 0.16))
	var flame := _color_mat(Color(1.0, 0.58, 0.12))
	var flame_light := _color_mat(Color(1.0, 0.86, 0.32))
	_box(torch, Vector3(0.16, 0.62, 0.16), Vector3(0.0, -0.08, 0.0), wood)
	_box(torch, Vector3(0.18, 0.12, 0.18), Vector3(0.0, 0.18, 0.0), wood_light)
	_box(torch, Vector3(0.22, 0.28, 0.22), Vector3(0.0, 0.36, 0.0), flame)
	_box(torch, Vector3(0.10, 0.16, 0.10), Vector3(0.0, 0.40, 0.0), flame_light)


func _make_hand_stick(parent: Node3D, cube_scale: float) -> void:
	var stick_root := Node3D.new()
	stick_root.scale = Vector3.ONE * cube_scale
	stick_root.rotation_degrees = Vector3(0.0, 0.0, -32.0)
	parent.add_child(stick_root)
	var stick_mat := _color_mat(Color(0.48, 0.29, 0.13))
	var tip_mat := _color_mat(Color(0.66, 0.43, 0.23))
	_box(stick_root, Vector3(0.13, 0.92, 0.13), Vector3.ZERO, stick_mat)
	_box(stick_root, Vector3(0.14, 0.12, 0.14), Vector3(0.0, 0.39, 0.0), tip_mat)

func _atlas_tile_material(tile: int) -> StandardMaterial3D:
	var texture_region := AtlasTexture.new()
	texture_region.atlas = atlas_tex
	texture_region.region = Rect2(float(tile * 16), 0.0, 16.0, 16.0)
	var material := StandardMaterial3D.new()
	material.albedo_texture = texture_region
	material.texture_filter = BaseMaterial3D.TEXTURE_FILTER_NEAREST
	material.shading_mode = BaseMaterial3D.SHADING_MODE_PER_PIXEL
	return material

func _make_hand_chest(parent: Node3D, cube_scale: float) -> void:
	var chest_root := Node3D.new()
	chest_root.scale = Vector3.ONE * cube_scale
	chest_root.rotation_degrees = Vector3(-4.0, 28.0, 0.0)
	parent.add_child(chest_root)
	var wood := _atlas_tile_material(19)
	var wood_light := _atlas_tile_material(20)
	var dark := _color_mat(Color(0.22, 0.13, 0.075))
	var metal := _atlas_tile_material(11)
	_box(chest_root, Vector3(0.92, 0.52, 0.76), Vector3(0.0, -0.10, 0.0), wood)
	_box(chest_root, Vector3(0.96, 0.12, 0.80), Vector3(0.0, 0.22, 0.0), dark)
	_box(chest_root, Vector3(0.92, 0.22, 0.76), Vector3(0.0, 0.35, 0.0), wood_light)
	_box(chest_root, Vector3(0.12, 0.20, 0.80), Vector3(-0.40, -0.10, 0.0), dark)
	_box(chest_root, Vector3(0.12, 0.20, 0.80), Vector3(0.40, -0.10, 0.0), dark)
	_box(chest_root, Vector3(0.12, 0.20, 0.80), Vector3(0.0, -0.10, -0.32), wood_light)
	_box(chest_root, Vector3(0.12, 0.20, 0.80), Vector3(0.0, -0.10, 0.32), wood_light)
	_box(chest_root, Vector3(0.16, 0.20, 0.08), Vector3(0.0, 0.12, -0.41), metal)
	_box(chest_root, Vector3(0.10, 0.12, 0.04), Vector3(0.0, 0.12, -0.46), dark)

func _make_hand_bed(parent: Node3D, cube_scale: float) -> void:
	var bed := Node3D.new()
	bed.scale = Vector3.ONE * cube_scale
	bed.rotation_degrees.y = 35.0
	parent.add_child(bed)
	var wood := _color_mat(Color(0.42, 0.25, 0.12))
	var wood_light := _color_mat(Color(0.58, 0.36, 0.18))
	var red := _color_mat(Color(0.72, 0.08, 0.13))
	var pillow := _color_mat(Color(0.95, 0.88, 0.72))
	_box(bed, Vector3(1.88, 0.14, 0.90), Vector3(0.0, -0.20, 0.0), wood)
	for x in [-0.82, 0.82]:
		for z in [-0.36, 0.36]:
			_box(bed, Vector3(0.13, 0.24, 0.13), Vector3(x, -0.32, z), wood_light)
	_box(bed, Vector3(0.12, 0.36, 0.88), Vector3(0.88, -0.005, 0.0), wood)
	_box(bed, Vector3(1.86, 0.27, 0.84), Vector3(-0.01, -0.055, 0.0), red)
	_box(bed, Vector3(0.34, 0.045, 0.62), Vector3(0.63, 0.102, 0.0), pillow)

func _make_hand_rail(parent: Node3D, cube_scale: float) -> void:
	var rail_root := Node3D.new()
	rail_root.scale = Vector3.ONE * cube_scale
	rail_root.rotation_degrees.y = 35.0
	parent.add_child(rail_root)
	var wood := _color_mat(Color(0.48, 0.29, 0.13, 1.0))
	var steel := _color_mat(Color(0.68, 0.73, 0.80, 1.0))
	var steel_dark := _color_mat(Color(0.36, 0.42, 0.50, 1.0))
	for z in [-0.30, 0.30]:
		_box(rail_root, Vector3(0.92, 0.10, 0.18), Vector3(0.0, -0.04, z), wood)
	for x in [-0.34, 0.34]:
		_box(rail_root, Vector3(0.10, 0.13, 0.82), Vector3(x, 0.10, 0.0), steel_dark)
		_box(rail_root, Vector3(0.075, 0.045, 0.82), Vector3(x, 0.19, 0.0), steel)

func _make_cube(id: int, grow: float = 0.0) -> ArrayMesh:
	var verts := PackedVector3Array()
	var norms := PackedVector3Array()
	var uvs := PackedVector2Array()
	var idx := PackedInt32Array()
	for f in 6:
		var n: Vector3i = FACE_N[f]
		var fv: Array = FACE_V[f]
		var tile := 0
		if id != 0:
			var tiles: Array = TILES[id]
			tile = tiles[0] if f == 0 else (tiles[2] if f == 1 else tiles[1])
		var base := verts.size()
		for c in 4:
			var v: Vector3 = fv[c]
			verts.append((v - Vector3(0.5, 0.5, 0.5)) * (1.0 + grow))
			norms.append(Vector3(n))
			var u := v.x
			var w := v.z
			if f >= 2 and f < 4:
				u = v.z
				w = 1.0 - v.y
			elif f >= 4:
				w = 1.0 - v.y
			if id != 0:
				uvs.append(Vector2((tile + lerpf(0.01, 0.99, u)) / float(ATLAS_TILES), lerpf(0.01, 0.99, w)))
			else:
				uvs.append(Vector2(u, w))
		idx.append(base)
		idx.append(base + 1)
		idx.append(base + 2)
		idx.append(base)
		idx.append(base + 2)
		idx.append(base + 3)
	var arrays := []
	arrays.resize(Mesh.ARRAY_MAX)
	arrays[Mesh.ARRAY_VERTEX] = verts
	arrays[Mesh.ARRAY_NORMAL] = norms
	arrays[Mesh.ARRAY_TEX_UV] = uvs
	arrays[Mesh.ARRAY_INDEX] = idx
	var mesh := ArrayMesh.new()
	mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
	return mesh

# ---------------- генерация мира ----------------

func _setup_noise() -> void:
	hn.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
	hn.seed = world_seed
	hn.frequency = 0.012
	hn.fractal_type = FastNoiseLite.FRACTAL_FBM
	hn.fractal_octaves = 4
	mn.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
	mn.seed = world_seed + 1337
	mn.frequency = 0.006
	mn.fractal_type = FastNoiseLite.FRACTAL_FBM
	mn.fractal_octaves = 3
	ocean_noise.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
	ocean_noise.seed = world_seed + 7777
	ocean_noise.frequency = 0.0022
	ocean_noise.fractal_type = FastNoiseLite.FRACTAL_FBM
	ocean_noise.fractal_octaves = 2
	biome_noise.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
	biome_noise.seed = world_seed + 2468
	biome_noise.frequency = 0.0024
	biome_noise.fractal_type = FastNoiseLite.FRACTAL_FBM
	biome_noise.fractal_octaves = 2
	moisture_noise.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
	moisture_noise.seed = world_seed + 9753
	moisture_noise.frequency = 0.0032
	moisture_noise.fractal_type = FastNoiseLite.FRACTAL_FBM
	moisture_noise.fractal_octaves = 2

func _biome_at(x: int, z: int) -> int:
	var temperature := biome_noise.get_noise_2d(x, z)
	var moisture := moisture_noise.get_noise_2d(x, z)
	if temperature < -0.34:
		return BIOME_SNOW
	if temperature > 0.28 and moisture < -0.08:
		return BIOME_DESERT
	if moisture > 0.42 and temperature > -0.10:
		return BIOME_SWAMP
	if temperature > 0.14 and moisture > 0.12:
		return BIOME_JUNGLE
	if temperature < -0.08 and moisture < 0.02:
		return BIOME_ROCKY
	if moisture > -0.02:
		return BIOME_FOREST
	return BIOME_PLAINS

func _biome_name(biome: int) -> String:
	match biome:
		BIOME_FOREST: return "Лес"
		BIOME_DESERT: return "Пустыня"
		BIOME_SNOW: return "Снежные земли"
		BIOME_JUNGLE: return "Джунгли"
		BIOME_SWAMP: return "Болото"
		BIOME_ROCKY: return "Каменистые горы"
		_: return "Равнины"

func _generate_world() -> void:
	for i in CW * CW:
		chunks.append(PackedByteArray())
		chunk_top.append(0)
		chunk_mi.append(null)
		chunk_cs.append(null)
		chunk_water_mi.append(null)
		trees_generated.append(false)
		villages_generated.append(false)
	heights.resize(WORLD_SIZE * WORLD_SIZE)
	world_loaded = _load_world()
	if not world_loaded:
		var requested_save_path := ProjectSettings.globalize_path(Global.world_path(Global.current_world))
		world_load_failed = FileAccess.file_exists(requested_save_path)
		if world_load_failed:
			push_warning("DareCraft: сохранение существует, но не прошло проверку. Оно не будет перезаписано автоматически.")
			if Global.network_mode == "host":
				Global.network_mode = "offline"
		world_seed = int(Global.pending_world_seed) if int(Global.pending_world_seed) > 0 else randi_range(1, 1235)
		Global.pending_world_seed = 0
	else:
		Global.pending_world_seed = 0
	_setup_noise()
	loading_label.text = "Подготовка мира..."
	loading_bar.value = 50.0
	await get_tree().process_frame

func _height_at(x: int, z: int) -> int:
	var n1 := hn.get_noise_2d(x, z)
	var m := maxf(0.0, mn.get_noise_2d(x, z) - 0.05)
	# Большие низкие области становятся океанами, края образуют песчаные берега.
	var ocean := ocean_noise.get_noise_2d(x, z)
	if ocean < -0.18:
		return clampi(int(round(11.5 + n1 * 2.2)), 8, 14)
	if ocean < -0.10:
		return clampi(int(round(15.0 + n1 * 2.0)), 14, 17)
	var biome := _biome_at(x, z)
	var biome_height := 0
	if biome == BIOME_SNOW or biome == BIOME_ROCKY:
		biome_height = 4
	elif biome == BIOME_SWAMP:
		biome_height = -3
	return clampi(int(round(22.0 + n1 * 9.0 + m * m * 60.0)) + biome_height, 4, 56)

func _gen_terrain(cx: int, cz: int) -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = world_seed * 31 + cx + cz * CW + 7
	var data := PackedByteArray()
	data.resize(CS * CS * WORLD_H)
	var top := 0
	for lz in CS:
		for lx in CS:
			var x := cx * CS + lx
			var z := cz * CS + lz
			var h := _height_at(x, z)
			var biome := _biome_at(x, z)
			heights[x + z * WORLD_SIZE] = h
			top = maxi(top, h)
			var rocky := h >= ROCK_LEVEL and biome != BIOME_SNOW
			var surface_id := GRASS
			var filler_id := DIRT
			if h <= 17 or biome == BIOME_DESERT:
				surface_id = SAND
				filler_id = SAND
			elif biome == BIOME_SNOW and not rocky:
				surface_id = SNOW
			elif biome == BIOME_SWAMP:
				surface_id = GRAVEL
			elif biome == BIOME_ROCKY:
				surface_id = STONE
			for y in range(0, h + 1):
				var id := STONE
				if y == h and not rocky:
					id = surface_id
				elif y >= h - 3 and not rocky and y > 0:
					id = filler_id
				if id == STONE and y > 0:
					var r := rng.randf()
					if y <= 18 and r < 0.004:
						id = DIAMOND_ORE
					elif y <= 22 and r < 0.012:
						id = IRON
					elif y <= 45 and r < 0.03:
						id = COAL
					elif y <= 28 and r < 0.035:
						id = GRAVEL
				data[lx + lz * CS + y * 256] = id
	var key := cx + cz * CW
	chunks[key] = data
	chunk_top[key] = top
	_gen_mine_in_chunk(cx, cz, rng)
	_gen_ruin_in_chunk(cx, cz, rng)
	_gen_ocean_wreck_in_chunk(cx, cz, rng)
	_gen_buried_treasure_in_chunk(cx, cz)

func _gen_ocean_wreck_in_chunk(cx: int, cz: int, rng: RandomNumberGenerator) -> void:
	# Редкие обломки кораблей на морском дне; генерация привязана к сиду чанка.
	if rng.randf() > 0.10:
		return
	var x0 := cx * CS + 5
	var z0 := cz * CS + 5
	if _height_at(x0 + 3, z0 + 3) >= 14:
		return
	var base_y := clampi(_height_at(x0 + 3, z0 + 3) + 1, 9, 13)
	# Разбитый деревянный корпус, частично занесённый песком.
	for x in range(7):
		for z in range(5):
			if x == 0 or x == 6 or z == 0 or z == 4 or (x > 1 and x < 5 and z > 0 and z < 4 and rng.randf() < 0.22):
				_force_generated_block(x0 + x, base_y, z0 + z, PLANKS)
	for y in range(1, 3):
		_force_generated_block(x0 + 1, base_y + y, z0 + 1, LOG)
		_force_generated_block(x0 + 5, base_y + y, z0 + 3, LOG)
	var chest_cell := Vector3i(x0 + 3, base_y + 1, z0 + 2)
	_force_generated_block(chest_cell.x, chest_cell.y, chest_cell.z, CHEST)
	var loot: Array = []
	for i in 27: loot.append({"id": 0, "n": 0})
	loot[0] = {"id": IRON_INGOT, "n": rng.randi_range(2, 5)}
	loot[1] = {"id": COOKED_PORK, "n": rng.randi_range(2, 4)}
	if rng.randf() < 0.35:
		loot[2] = {"id": TREASURE_MAP, "n": 1}
	if rng.randf() < 0.20:
		loot[3] = {"id": DIAMOND, "n": rng.randi_range(1, 2)}
	chests[chest_cell] = loot

func _treasure_target() -> Vector2i:
	if treasure_target_cache.x >= 0:
		return treasure_target_cache
	var rng := RandomNumberGenerator.new()
	rng.seed = world_seed * 92821 + 7717
	for attempt in 300:
		var x := rng.randi_range(48, WORLD_SIZE - 48)
		var z := rng.randi_range(48, WORLD_SIZE - 48)
		var h := _height_at(x, z)
		var nearby_water := 0
		for offset in [Vector2i(1, 0), Vector2i(-1, 0), Vector2i(0, 1), Vector2i(0, -1)]:
			if _height_at(x + offset.x * 8, z + offset.y * 8) < 16:
				nearby_water += 1
		if h >= 18 and h <= 38 and nearby_water >= 2 and _biome_at(x, z) != BIOME_ROCKY:
			treasure_target_cache = Vector2i(x, z)
			return treasure_target_cache
	treasure_target_cache = Vector2i(WORLD_SIZE >> 1, WORLD_SIZE >> 1)
	return treasure_target_cache

func _gen_buried_treasure_in_chunk(cx: int, cz: int) -> void:
	var target := _treasure_target()
	if (target.x >> 4) != cx or (target.y >> 4) != cz:
		return
	var surface := _height_at(target.x, target.y)
	var chest_cell := Vector3i(target.x, maxi(2, surface - 2), target.y)
	_force_generated_block(chest_cell.x, chest_cell.y, chest_cell.z, CHEST)
	var loot: Array = []
	for i in 27: loot.append({"id": 0, "n": 0})
	loot[0] = {"id": DIAMOND, "n": 4}
	loot[1] = {"id": IRON_INGOT, "n": 8}
	loot[2] = {"id": IRON_INGOT, "n": 6}
	loot[3] = {"id": TREASURE_MAP, "n": 1}
	chests[chest_cell] = loot

func _gen_trader_ship_in_chunk(cx: int, cz: int) -> void:
	# Небольшое число торговых кораблей; их ID одинаков на всех клиентах с тем же сидом.
	if cx < 8 or cz < 8 or cx % 32 != 16 or cz % 32 != 16:
		return
	var rng := RandomNumberGenerator.new()
	rng.seed = world_seed + cx * 7919 + cz * 104729 + 551
	if rng.randf() > 0.94:
		return
	var pos := Vector3(cx * CS + 8, 14.95, cz * CS + 8)
	if not _raft_area_is_water(pos, 0.0):
		return
	var ship_id := 100000 + cx + cz * CW
	var ship := _create_raft(pos, ship_id, 0.0)
	ship.set_meta("npc_ship", true)
	var direction := Vector3(1.0, 0.0, 0.25).normalized()
	if rng.randf() < 0.5: direction = -direction
	ship.set_meta("ship_direction", [direction.x, direction.z])
	_decorate_trader_ship(ship, rng)
	if net_connected and net_is_host:
		_net_send_event({"type": "raft_spawn", "raft_id": ship_id, "pos": _net_vec3_to_array(ship.position), "yaw": ship.rotation.y, "blocks": [], "npc_ship": true, "ship_direction": ship.get_meta("ship_direction", [1.0, 0.0])})

func _decorate_trader_ship(ship: Node3D, rng: RandomNumberGenerator) -> void:
	if ship.has_meta("ship_decorated"):
		return
	ship.set_meta("ship_decorated", true)
	var wood := _color_mat(Color(0.34, 0.20, 0.10))
	var sail := _color_mat(Color(0.82, 0.78, 0.61))
	_add_boat_piece(ship, Vector3(0, 2.2, 0), Vector3(0.22, 4.2, 0.22), wood)
	_add_boat_piece(ship, Vector3(0, 2.9, -0.3), Vector3(2.7, 2.1, 0.12), sail)
	_add_boat_piece(ship, Vector3(0, 0.65, 2.6), Vector3(2.3, 1.3, 1.5), wood)
	_add_boat_piece(ship, Vector3(0, 1.45, 2.6), Vector3(2.5, 0.18, 1.7), wood)
	for resident in 3:
		var local_pos := Vector3(rng.randf_range(-1.5, 1.5), 0.0, rng.randf_range(-2.7, 1.6))
		_spawn_villager(ship.position + local_pos, rng)
		var npc: Node3D = villagers.back()
		npc.reparent(ship, false)
		npc.position = local_pos
		var npc_state: Dictionary = villager_targets[npc.get_instance_id()]
		npc_state["home"] = local_pos
		npc_state["target"] = local_pos
		villager_targets[npc.get_instance_id()] = npc_state

func _update_npc_ships(delta: float) -> void:
	if net_connected and not net_is_host:
		return
	for ship in raft_nodes:
		if not is_instance_valid(ship) or not bool(ship.get_meta("npc_ship", false)):
			continue
		if riding_raft == ship:
			continue
		var raw_dir: Variant = ship.get_meta("ship_direction", [1.0, 0.0])
		var dir := Vector3(float(raw_dir[0]), 0.0, float(raw_dir[1])).normalized()
		var next_pos := ship.position + dir * delta * 0.42
		if _raft_area_is_water(next_pos, ship.rotation.y):
			ship.position = next_pos
		else:
			dir = -dir
			ship.set_meta("ship_direction", [dir.x, dir.z])

func _gen_ruin_in_chunk(cx: int, cz: int, rng: RandomNumberGenerator) -> void:
	if rng.randf() > 0.006:
		return
	var x0 := cx * CS + rng.randi_range(4, 9)
	var z0 := cz * CS + rng.randi_range(4, 9)
	var y0 := _height_at(x0 + 2, z0 + 2) + 1
	for x in range(5):
		for z in range(5):
			if x == 0 or x == 4 or z == 0 or z == 4:
				for y in range(2):
					if not (z == 0 and x == 2):
						_put(x0 + x, y0 + y, z0 + z, STONE if y == 0 else PLANKS)
	_put(x0 + 2, y0, z0 + 2, CHEST)

func _gen_mine_in_chunk(cx: int, cz: int, rng: RandomNumberGenerator) -> void:
	# Небольшая подземная шахта с проходом, деревянными стойками и сундуком.
	if rng.randf() > 0.12:
		return
	var x0 := cx * CS + rng.randi_range(2, 5)
	var z0 := cz * CS + rng.randi_range(3, 11)
	var surface := _height_at(x0, z0)
	var base_y := maxi(8, mini(surface - 5, 24))
	for step in range(0, 11):
		var xx := x0 + step
		for yy in range(base_y - 1, base_y + 3):
			for zz in range(z0 - 1, z0 + 2):
				var idx := (xx & 15) + (zz & 15) * CS + yy * 256
				if xx >= cx * CS and xx < (cx + 1) * CS and zz >= cz * CS and zz < (cz + 1) * CS and yy >= 0 and yy < WORLD_H:
					chunks[cx + cz * CW][idx] = 0
		# Деревянные стойки шахты через каждые три блока.
		if step % 3 == 0:
			for yy in range(base_y - 1, base_y + 3):
				for zz in [z0 - 1, z0 + 1]:
					var idx2: int = (xx & 15) + (zz & 15) * CS + yy * 256
					chunks[cx + cz * CW][idx2] = LOG
		var rail_idx := (xx & 15) + (z0 & 15) * CS + (base_y - 1) * 256
		chunks[cx + cz * CW][rail_idx] = RAIL
		if step == 4:
			chunks[cx + cz * CW][rail_idx + 256] = MINECART
	# Боковая камера с коротким ответвлением рельсов.
	if x0 + 8 < (cx + 1) * CS:
		for branch_step in range(1, 4):
			var bx := x0 + 7
			var bz := z0 + branch_step
			for by in range(base_y - 1, base_y + 3):
				var branch_idx := (bx & 15) + (bz & 15) * CS + by * 256
				chunks[cx + cz * CW][branch_idx] = 0
			var branch_rail := (bx & 15) + (bz & 15) * CS + (base_y - 1) * 256
			chunks[cx + cz * CW][branch_rail] = RAIL
	# Сундук с лутом в конце прохода.
	var chest_x := x0 + 10
	var chest_idx := (chest_x & 15) + (z0 & 15) * CS + base_y * 256
	chunks[cx + cz * CW][chest_idx] = CHEST

func _force_generated_block(x: int, y: int, z: int, id: int) -> void:
	if y < 0 or y >= WORLD_H or x < 0 or z < 0 or x >= WORLD_SIZE or z >= WORLD_SIZE:
		return
	var key := (x >> 4) + (z >> 4) * CW
	if chunks[key].size() != CS * CS * WORLD_H:
		return
	var idx := (x & 15) + (z & 15) * CS + y * 256
	chunks[key][idx] = id
	chunk_top[key] = maxi(chunk_top[key], y)

func _put(x: int, y: int, z: int, id: int) -> void:
	if y < 0 or y >= WORLD_H or x < 0 or z < 0 or x >= WORLD_SIZE or z >= WORLD_SIZE:
		return
	var key := (x >> 4) + (z >> 4) * CW
	var data: PackedByteArray = chunks[key]
	if data.size() != CS * CS * WORLD_H:
		return
	var i := (x & 15) + (z & 15) * CS + y * 256
	if data[i] != 0:
		return
	data[i] = id
	if y > chunk_top[key]:
		chunk_top[key] = y

func _gen_trees() -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = world_seed + 99
	var c := WORLD_SIZE >> 1
	for x in range(3, WORLD_SIZE - 3):
		for z in range(3, WORLD_SIZE - 3):
			if abs(x - c) < 6 and abs(z - c) < 6:
				continue
			var h: int = heights[x + z * WORLD_SIZE]
			if h >= ROCK_LEVEL - 2 or h <= 17:
				continue
			var biome := _biome_at(x, z)
			if biome == BIOME_DESERT or biome == BIOME_SNOW or biome == BIOME_ROCKY:
				continue
			if get_block(x, h, z) != GRASS and not (biome == BIOME_SWAMP and get_block(x, h, z) == GRAVEL):
				continue
			var density := 0.008
			if biome == BIOME_JUNGLE:
				density = 0.024
			elif biome == BIOME_SWAMP:
				density = 0.005
			if rng.randf() > density:
				continue
			var th := rng.randi_range(6, 9) if biome == BIOME_JUNGLE else (rng.randi_range(3, 5) if biome == BIOME_SWAMP else rng.randi_range(4, 6))
			for y in range(h + 1, h + th + 1):
				_put(x, y, z, LOG)
			for dy in range(-1, 3):
				var r := 2 if dy <= 0 else 1
				for dx in range(-r, r + 1):
					for dz in range(-r, r + 1):
						if r == 2 and abs(dx) == 2 and abs(dz) == 2:
							continue
						_put(x + dx, h + th + dy, z + dz, LEAVES)

func get_block(x: int, y: int, z: int) -> int:
	if y < 0:
		return STONE
	if y >= WORLD_H or x < 0 or z < 0 or x >= WORLD_SIZE or z >= WORLD_SIZE:
		return 0
	var key := (x >> 4) + (z >> 4) * CW
	var data: PackedByteArray = chunks[key]
	if data.size() == 0:
		return 0
	return data[(x & 15) + (z & 15) * CS + y * 256]

func _block_face_is_occluded(current_id: int, neighbor_id: int) -> bool:
	if neighbor_id == 0:
		return false
	# Two glass blocks do not need an internal face, but glass must never erase
	# the opaque wall face behind it. Rails, beds, torches and minecarts are
	# partial models and cannot occlude a full block face.
	if current_id == GLASS and neighbor_id == GLASS:
		return true
	if neighbor_id == GLASS or neighbor_id == RAIL or neighbor_id == BED or neighbor_id == TORCH or neighbor_id == MINECART:
		return false
	return true

func _build_chunk(cx: int, cz: int) -> void:
	var key := cx + cz * CW
	var data: PackedByteArray = chunks[key]
	var top_y: int = chunk_top[key]
	var verts := PackedVector3Array()
	var norms := PackedVector3Array()
	var uvs := PackedVector2Array()
	var idx := PackedInt32Array()
	var glass_verts := PackedVector3Array()
	var glass_norms := PackedVector3Array()
	var glass_uvs := PackedVector2Array()
	var glass_idx := PackedInt32Array()
	var snow_verts := PackedVector3Array()
	var snow_norms := PackedVector3Array()
	var snow_uvs := PackedVector2Array()
	var snow_idx := PackedInt32Array()
	var bed_verts: Array = []
	var bed_norms: Array = []
	var bed_uvs: Array = []
	var bed_idx: Array = []
	var pillow_verts: Array = []
	var pillow_norms: Array = []
	var pillow_uvs: Array = []
	var pillow_idx: Array = []
	var water_verts := PackedVector3Array()
	var water_norms := PackedVector3Array()
	var water_uvs := PackedVector2Array()
	var water_idx := PackedInt32Array()
	var ox := cx * CS
	var oz := cz * CS
	# Прозрачная поверхность океана строится отдельно от коллизии суши.
	for lz in CS:
		for lx in CS:
			var wx := ox + lx
			var wz := oz + lz
			if _height_at(wx, wz) < 15:
				var wb := water_verts.size()
				var wy := 15.02
				water_verts.append_array(PackedVector3Array([Vector3(wx, wy, wz), Vector3(wx + 1, wy, wz), Vector3(wx + 1, wy, wz + 1), Vector3(wx, wy, wz + 1)]))
				for wi in 4:
					water_norms.append(Vector3.UP)
				water_uvs.append_array(PackedVector2Array([Vector2(0, 0), Vector2(1, 0), Vector2(1, 1), Vector2(0, 1)]))
				water_idx.append_array(PackedInt32Array([wb, wb + 2, wb + 1, wb, wb + 3, wb + 2]))
	for y in range(0, top_y + 1):
		for lz in CS:
			for lx in CS:
				var id := data[lx + lz * CS + y * 256]
				if id == 0:
					continue
				var x := ox + lx
				var z := oz + lz
				if id == SNOW:
					var sv: Array = []
					var sn: Array = []
					var su: Array = []
					var si: Array = []
					_append_box_geometry(sv, sn, su, si, Vector3(x, y, z), Vector3(0.5, 0.5, 0.5), Vector3.ONE, 0, 0, 0)
					var sb := snow_verts.size()
					for v in sv: snow_verts.append(v)
					for n in sn: snow_norms.append(n)
					for uv in su: snow_uvs.append(uv)
					for ix in si: snow_idx.append(sb + int(ix))
					continue
				if id == TORCH:
					# Факел — тонкая деревянная рукоять с ярким огнём сверху.
					var torch_vertices: Array = []
					var torch_normals: Array = []
					var torch_uvs: Array = []
					var torch_indices: Array = []
					var torch_origin := Vector3(x, y, z)
					_append_box_geometry(torch_vertices, torch_normals, torch_uvs, torch_indices, torch_origin, Vector3(0.5, 0.30, 0.5), Vector3(0.14, 0.58, 0.14), 7, 7, 7)
					_append_box_geometry(torch_vertices, torch_normals, torch_uvs, torch_indices, torch_origin, Vector3(0.5, 0.68, 0.5), Vector3(0.22, 0.22, 0.22), 36, 36, 36)
					var torch_base := verts.size()
					for v in torch_vertices: verts.append(v)
					for n in torch_normals: norms.append(n)
					for uv in torch_uvs: uvs.append(uv)
					for ix in torch_indices: idx.append(torch_base + int(ix))
					continue
				if id == BED:
					# Кровать занимает два соседних блока по оси X. Дерево остаётся
					# в непрозрачном атласе, матрас и подушка имеют отдельные opaque-материалы.
					var cell_origin := Vector3(x, y, z)
					var has_bed_left := get_block(x - 1, y, z) == BED
					var has_bed_right := get_block(x + 1, y, z) == BED
					_append_box_geometry(verts, norms, uvs, idx, cell_origin, Vector3(0.5, 0.29, 0.5), Vector3(0.98, 0.16, 0.92), 7, 7, 7)
					for leg_z in [0.12, 0.88]:
						if not has_bed_left:
							_append_box_geometry(verts, norms, uvs, idx, cell_origin, Vector3(0.10, 0.12, leg_z), Vector3(0.14, 0.24, 0.14), 7, 7, 7)
						if not has_bed_right:
							_append_box_geometry(verts, norms, uvs, idx, cell_origin, Vector3(0.90, 0.12, leg_z), Vector3(0.14, 0.24, 0.14), 7, 7, 7)
					_append_box_geometry(bed_verts, bed_norms, bed_uvs, bed_idx, cell_origin, Vector3(0.5, 0.52, 0.5), Vector3(1.0, 0.34, 0.84), 37, 37, 37)
					if has_bed_left and not has_bed_right:
						# Изголовье находится на внешнем торце второй половины кровати.
						_append_box_geometry(verts, norms, uvs, idx, cell_origin, Vector3(0.90, 0.48, 0.5), Vector3(0.12, 0.36, 0.88), 7, 7, 7)
						_append_box_geometry(pillow_verts, pillow_norms, pillow_uvs, pillow_idx, cell_origin, Vector3(0.70, 0.71, 0.5), Vector3(0.28, 0.06, 0.62), 37, 37, 37)
					continue
				if id == RAIL:
					# Низкие шпалы и две металлические направляющие вместо полного блока.
					var rv: Array = []
					var rn: Array = []
					var ru: Array = []
					var ri: Array = []
					var ro := Vector3(x, y, z)
					for rz in [0.22, 0.78]:
						_append_box_geometry(rv, rn, ru, ri, ro, Vector3(0.5, 0.07, rz), Vector3(0.92, 0.10, 0.16), 7, 7, 7)
					for rx in [0.22, 0.78]:
						_append_box_geometry(rv, rn, ru, ri, ro, Vector3(rx, 0.15, 0.5), Vector3(0.075, 0.09, 0.96), 11, 11, 11)
					var rb := verts.size()
					for v in rv: verts.append(v)
					for n in rn: norms.append(n)
					for uv in ru: uvs.append(uv)
					for ix in ri: idx.append(rb + int(ix))
					continue
				if id == MUSIC_PLAYER:
					var jv: Array = []
					var jn: Array = []
					var ju: Array = []
					var ji: Array = []
					var jo := Vector3(x, y, z)
					_append_box_geometry(jv, jn, ju, ji, jo, Vector3(0.5, 0.5, 0.5), Vector3(0.96, 0.96, 0.96), 7, 7, 7)
					_append_box_geometry(jv, jn, ju, ji, jo, Vector3(0.5, 0.985, 0.5), Vector3(0.62, 0.025, 0.62), 3, 3, 3)
					_append_box_geometry(jv, jn, ju, ji, jo, Vector3(0.5, 0.965, 0.5), Vector3(0.28, 0.018, 0.28), 12, 12, 12)
					var jb := verts.size()
					for v in jv: verts.append(v)
					for n in jn: norms.append(n)
					for uv in ju: uvs.append(uv)
					for ix in ji: idx.append(jb + int(ix))
					continue
				if id == MINECART:
					# Открытая металлическая вагонетка с отдельными колёсами.
					var cv: Array = []
					var cn: Array = []
					var cu: Array = []
					var ci: Array = []
					var co := Vector3(x, y, z)
					# Низкая металлическая ванна вагонетки с открытым верхом, а не сплющенный сундук.
					_append_box_geometry(cv, cn, cu, ci, co, Vector3(0.5, 0.18, 0.5), Vector3(0.78, 0.12, 0.62), 3, 3, 3)
					_append_box_geometry(cv, cn, cu, ci, co, Vector3(0.5, 0.34, 0.12), Vector3(0.82, 0.24, 0.07), 3, 3, 3)
					_append_box_geometry(cv, cn, cu, ci, co, Vector3(0.5, 0.34, 0.88), Vector3(0.82, 0.24, 0.07), 3, 3, 3)
					_append_box_geometry(cv, cn, cu, ci, co, Vector3(0.12, 0.34, 0.5), Vector3(0.07, 0.24, 0.62), 3, 3, 3)
					_append_box_geometry(cv, cn, cu, ci, co, Vector3(0.88, 0.34, 0.5), Vector3(0.07, 0.24, 0.62), 3, 3, 3)
					for wz in [0.20, 0.80]:
						_append_box_geometry(cv, cn, cu, ci, co, Vector3(0.5, 0.07, wz), Vector3(0.24, 0.12, 0.24), 12, 12, 12)
					var cb := verts.size()
					for v in cv: verts.append(v)
					for n in cn: norms.append(n)
					for uv in cu: uvs.append(uv)
					for ix in ci: idx.append(cb + int(ix))
					continue
				for f in 6:
					var n: Vector3i = FACE_N[f]
					var neighbor_id := get_block(x + n.x, y + n.y, z + n.z)
					if _block_face_is_occluded(id, neighbor_id):
						continue
					var tiles: Array = TILES.get(id, TILES[STONE])
					var tile: int = tiles[0] if f == 0 else (tiles[2] if f == 1 else tiles[1])
					var fv: Array = FACE_V[f]
					var target_verts: PackedVector3Array = glass_verts if id == GLASS else verts
					var target_norms: PackedVector3Array = glass_norms if id == GLASS else norms
					var target_uvs: PackedVector2Array = glass_uvs if id == GLASS else uvs
					var target_idx: PackedInt32Array = glass_idx if id == GLASS else idx
					var base := target_verts.size()
					for c in 4:
						var v: Vector3 = fv[c]
						target_verts.append(Vector3(x, y, z) + v)
						target_norms.append(Vector3(n))
						var u := v.x
						var w := v.z
						if f >= 2 and f < 4:
							u = v.z
							w = 1.0 - v.y
						elif f >= 4:
							w = 1.0 - v.y
						target_uvs.append(Vector2((tile + lerpf(0.01, 0.99, u)) / float(ATLAS_TILES), lerpf(0.01, 0.99, w)))
					target_idx.append(base)
					target_idx.append(base + 1)
					target_idx.append(base + 2)
					target_idx.append(base)
					target_idx.append(base + 2)
					target_idx.append(base + 3)

	var mi: MeshInstance3D = chunk_mi[key]
	var cs: CollisionShape3D = chunk_cs[key]
	if mi == null:
		var body := StaticBody3D.new()
		mi = MeshInstance3D.new()
		cs = CollisionShape3D.new()
		body.add_child(mi)
		body.add_child(cs)
		var water_instance := MeshInstance3D.new()
		water_instance.name = "OceanSurface"
		water_instance.material_override = water_mat
		body.add_child(water_instance)
		chunk_water_mi[key] = water_instance
		add_child(body)
		chunk_mi[key] = mi
		chunk_cs[key] = cs
	if chunk_water_mi[key] != null:
		if water_verts.is_empty():
			chunk_water_mi[key].mesh = null
		else:
			var water_arrays := []
			water_arrays.resize(Mesh.ARRAY_MAX)
			water_arrays[Mesh.ARRAY_VERTEX] = water_verts
			water_arrays[Mesh.ARRAY_NORMAL] = water_norms
			water_arrays[Mesh.ARRAY_TEX_UV] = water_uvs
			water_arrays[Mesh.ARRAY_INDEX] = water_idx
			var water_mesh := ArrayMesh.new()
			water_mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, water_arrays)
			chunk_water_mi[key].mesh = water_mesh
	if verts.is_empty() and glass_verts.is_empty() and snow_verts.is_empty() and bed_verts.is_empty() and pillow_verts.is_empty():
		mi.mesh = null
		cs.shape = null
		return
	var mesh := ArrayMesh.new()
	if not verts.is_empty():
		var arrays := []
		arrays.resize(Mesh.ARRAY_MAX)
		arrays[Mesh.ARRAY_VERTEX] = verts
		arrays[Mesh.ARRAY_NORMAL] = norms
		arrays[Mesh.ARRAY_TEX_UV] = uvs
		arrays[Mesh.ARRAY_INDEX] = idx
		mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
		mesh.surface_set_material(mesh.get_surface_count() - 1, block_mat)
	if not glass_verts.is_empty():
		var glass_arrays := []
		glass_arrays.resize(Mesh.ARRAY_MAX)
		glass_arrays[Mesh.ARRAY_VERTEX] = glass_verts
		glass_arrays[Mesh.ARRAY_NORMAL] = glass_norms
		glass_arrays[Mesh.ARRAY_TEX_UV] = glass_uvs
		glass_arrays[Mesh.ARRAY_INDEX] = glass_idx
		mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, glass_arrays)
		mesh.surface_set_material(mesh.get_surface_count() - 1, glass_mat)
	if not snow_verts.is_empty():
		var snow_arrays := []
		snow_arrays.resize(Mesh.ARRAY_MAX)
		snow_arrays[Mesh.ARRAY_VERTEX] = snow_verts
		snow_arrays[Mesh.ARRAY_NORMAL] = snow_norms
		snow_arrays[Mesh.ARRAY_TEX_UV] = snow_uvs
		snow_arrays[Mesh.ARRAY_INDEX] = snow_idx
		mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, snow_arrays)
		mesh.surface_set_material(mesh.get_surface_count() - 1, snow_mat)
	if not bed_verts.is_empty():
		var bed_arrays := []
		bed_arrays.resize(Mesh.ARRAY_MAX)
		var bed_packed_verts := PackedVector3Array()
		var bed_packed_norms := PackedVector3Array()
		var bed_packed_uvs := PackedVector2Array()
		var bed_packed_idx := PackedInt32Array()
		for vertex in bed_verts: bed_packed_verts.append(vertex)
		for normal in bed_norms: bed_packed_norms.append(normal)
		for uv in bed_uvs: bed_packed_uvs.append(uv)
		for index in bed_idx: bed_packed_idx.append(index)
		bed_arrays[Mesh.ARRAY_VERTEX] = bed_packed_verts
		bed_arrays[Mesh.ARRAY_NORMAL] = bed_packed_norms
		bed_arrays[Mesh.ARRAY_TEX_UV] = bed_packed_uvs
		bed_arrays[Mesh.ARRAY_INDEX] = bed_packed_idx
		mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, bed_arrays)
		mesh.surface_set_material(mesh.get_surface_count() - 1, bed_mat)
	if not pillow_verts.is_empty():
		var pillow_arrays := []
		pillow_arrays.resize(Mesh.ARRAY_MAX)
		var pillow_packed_verts := PackedVector3Array()
		var pillow_packed_norms := PackedVector3Array()
		var pillow_packed_uvs := PackedVector2Array()
		var pillow_packed_idx := PackedInt32Array()
		for vertex in pillow_verts: pillow_packed_verts.append(vertex)
		for normal in pillow_norms: pillow_packed_norms.append(normal)
		for uv in pillow_uvs: pillow_packed_uvs.append(uv)
		for index in pillow_idx: pillow_packed_idx.append(index)
		pillow_arrays[Mesh.ARRAY_VERTEX] = pillow_packed_verts
		pillow_arrays[Mesh.ARRAY_NORMAL] = pillow_packed_norms
		pillow_arrays[Mesh.ARRAY_TEX_UV] = pillow_packed_uvs
		pillow_arrays[Mesh.ARRAY_INDEX] = pillow_packed_idx
		mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, pillow_arrays)
		mesh.surface_set_material(mesh.get_surface_count() - 1, bed_pillow_mat)
	mi.mesh = mesh
	cs.shape = mesh.create_trimesh_shape()

func _set_block(cell: Vector3i, id: int) -> void:
	if net_connected and not net_apply_remote_block:
		if net_is_host:
			_set_block_local(cell, id)
			_net_record_block(cell, id)
			_net_send_event({"type": "block_set", "cell": [cell.x, cell.y, cell.z], "id": id})
		else:
			_net_send_event({"type": "block_request", "cell": [cell.x, cell.y, cell.z], "id": id})
		return
	_set_block_local(cell, id)


func _net_record_block(cell: Vector3i, block_id: int) -> void:
	var key := "%d,%d,%d" % [cell.x, cell.y, cell.z]
	net_changed_blocks[key] = [cell.x, cell.y, cell.z, block_id]

func _set_block_local(cell: Vector3i, id: int) -> void:
	if cell.y < 0 or cell.y >= WORLD_H:
		return
	if cell.x < 0 or cell.z < 0 or cell.x >= WORLD_SIZE or cell.z >= WORLD_SIZE:
		return

	var cx := cell.x >> 4
	var cz := cell.z >> 4
	var key := cx + cz * CW

	var data: PackedByteArray = chunks[key]
	if data.size() != CS * CS * WORLD_H:
		return

	var lx := cell.x & 15
	var lz := cell.z & 15
	var index := lx + lz * CS + cell.y * 256
	var previous_id := int(data[index])
	if previous_id == TORCH or previous_id == GLOW_BLOCK:
		_remove_torch_light(cell)

	data[index] = id
	if id == TORCH or id == GLOW_BLOCK:
		_add_torch_light(cell, id)
	chunks[key] = data

	if cell.y > chunk_top[key]:
		chunk_top[key] = cell.y

	_queue_chunk_rebuild(cx, cz)

	if lx == 0:
		_queue_chunk_rebuild(cx - 1, cz)
	elif lx == CS - 1:
		_queue_chunk_rebuild(cx + 1, cz)

	if lz == 0:
		_queue_chunk_rebuild(cx, cz - 1)
	elif lz == CS - 1:
		_queue_chunk_rebuild(cx, cz + 1)

func _is_city_seed() -> bool:
	return world_seed >= 10001 and world_seed <= 10100

func _seed_display() -> String:
	if _is_city_seed():
		return "Сид city%d" % (world_seed - 10000)
	return "Сид %d" % world_seed

func _build_village_house(x0: int, z0: int, y0: int, w: int, d: int, wall_id: int = PLANKS) -> void:
	for x in range(w):
		for z in range(d):
			_set_block(Vector3i(x0 + x, y0 - 1, z0 + z), PLANKS)
			_set_block(Vector3i(x0 + x, y0 + 3, z0 + z), LOG if (x == 0 or z == 0 or x == w - 1 or z == d - 1) else PLANKS)
			for y in range(3):
				if x == 0 or x == w - 1 or z == 0 or z == d - 1:
					var is_door := z == 0 and x == int(w / 2) and y < 2
					var is_window := y == 1 and ((x == 0 or x == w - 1) and z == int(d / 2))
					if not is_door:
						_set_block(Vector3i(x0 + x, y0 + y, z0 + z), GLASS if is_window else wall_id)
	for x in range(w):
		for z in range(d):
			_set_block(Vector3i(x0 + x, y0 + 4, z0 + z), PLANKS)

func _place_village_chest(cell: Vector3i, rng: RandomNumberGenerator, rich: bool = false) -> void:
	_set_block(cell, CHEST)
	var loot: Array = _get_chest_inventory(cell, false)
	var rewards: Array = [[COAL_ITEM, 5], [IRON_INGOT, 3], [RAW_IRON, 4], [PLANKS, 16], [COOKED_PORK, 4], [TORCH, 8], [DIAMOND, 2], [BONE, 3], [SAND, 12]]
	if rich:
		rewards.append_array([[D_PICKAXE, 1], [I_PICKAXE, 1], [DIAMOND, 5], [GLASS, 16]])
	for i in range(8 if rich else 5):
		if rng.randf() < 0.05:
			loot[i] = {"id": rng.randi_range(MUSIC_DISC_1, MUSIC_DISC_5), "n": 1}
		else:
			var reward: Array = rewards[rng.randi_range(0, rewards.size() - 1)]
			loot[i] = {"id": reward[0], "n": reward[1]}
	chests[cell] = loot

func _spawn_villager(pos: Vector3, rng: RandomNumberGenerator) -> void:
	if villagers.size() >= 80:
		return
	var npc := Node3D.new()
	npc.position = pos
	npc.name = "Villager"
	var robe := _color_mat(Color(0.42, 0.30, 0.62))
	var skin := _color_mat(Color(0.78, 0.58, 0.43))
	var dark := _color_mat(Color(0.22, 0.16, 0.12))
	_box(npc, Vector3(0.62, 0.82, 0.38), Vector3(0, 0.85, 0), robe)
	_box(npc, Vector3(0.48, 0.48, 0.45), Vector3(0, 1.5, 0), skin)
	_box(npc, Vector3(0.18, 0.12, 0.16), Vector3(0, 1.52, -0.28), dark)
	_box(npc, Vector3(0.18, 0.65, 0.2), Vector3(-0.4, 0.9, 0), robe)
	_box(npc, Vector3(0.18, 0.65, 0.2), Vector3(0.4, 0.9, 0), robe)
	_box(npc, Vector3(0.2, 0.38, 0.22), Vector3(-0.17, 0.22, 0), dark)
	_box(npc, Vector3(0.2, 0.38, 0.22), Vector3(0.17, 0.22, 0), dark)
	add_child(npc)
	villagers.append(npc)
	villager_targets[npc.get_instance_id()] = {"target": pos, "wait": rng.randf_range(1.0, 4.0), "home": pos}

func _update_villagers(delta: float) -> void:
	for npc in villagers:
		if not is_instance_valid(npc):
			continue
		var key := npc.get_instance_id()
		if not villager_targets.has(key):
			continue
		var state: Dictionary = villager_targets[key]
		state["wait"] = float(state["wait"]) - delta
		var target: Vector3 = state["target"]
		var flat := Vector3(target.x - npc.position.x, 0, target.z - npc.position.z)
		if state["wait"] <= 0.0 or flat.length() < 0.35:
			var home: Vector3 = state["home"]
			state["target"] = home + Vector3(randf_range(-3.0, 3.0), 0, randf_range(-3.0, 3.0))
			state["wait"] = randf_range(2.0, 5.0)
		else:
			var dir := flat.normalized()
			npc.position.x += dir.x * delta * 0.7
			npc.position.z += dir.z * delta * 0.7
			npc.rotation.y = atan2(dir.x, dir.z)
		villager_targets[key] = state

func _gen_village_in_chunk(cx: int, cz: int) -> void:
	var center_chunk := Vector2i(CW / 2, CW / 2)
	var is_city := _is_city_seed()
	if is_city:
		if abs(cx - center_chunk.x) > 9 or abs(cz - center_chunk.y) > 9:
			return
	else:
		if cx < 4 or cz < 4 or cx % 24 != 12 or cz % 24 != 12:
			return
	var rng := RandomNumberGenerator.new()
	rng.seed = world_seed + cx * 7919 + cz * 104729
	var x0 := cx * CS
	var z0 := cz * CS
	var y0 := _height_at(x0 + 3, z0 + 3) + 1
	# Небольшая площадь и дорожки. В city-сиде кварталы заполняют большой район.
	var house_count := 3
	for h in range(house_count):
		var hx := x0 + (0 if h == 0 else 9 if h == 1 else 0)
		var hz := z0 + (0 if h < 2 else 9)
		if hx + 5 >= (cx + 1) * CS or hz + 5 >= (cz + 1) * CS:
			continue
		var is_smithy := h == 1
		var is_church := h == 2
		_build_village_house(hx, hz, y0, 5, 5, STONE if is_smithy else PLANKS)
		if is_smithy:
			_set_block(Vector3i(hx + 1, y0, hz + 1), FURNACE)
			_set_block(Vector3i(hx + 3, y0, hz + 1), FURNACE)
			_place_village_chest(Vector3i(hx + 3, y0, hz + 3), rng, true)
		elif is_church:
			for yy in range(4, 8):
				_set_block(Vector3i(hx + 2, y0 + yy, hz + 2), PLANKS)
			for xx in range(1, 4):
				for zz in range(1, 4):
					_set_block(Vector3i(hx + xx, y0 + 4, hz + zz), PLANKS)
			_place_village_chest(Vector3i(hx + 2, y0, hz + 3), rng, true)
		else:
			_place_village_chest(Vector3i(hx + 3, y0, hz + 3), rng, is_city)
	# Жители гуляют около домов; city-сиды заселены плотнее.
	var resident_count := rng.randi_range(2, 4) if is_city else 2
	for resident in resident_count:
		_spawn_villager(Vector3(x0 + 4 + rng.randf_range(-2, 5), y0, z0 + 4 + rng.randf_range(-2, 5)), rng)

func _add_torch_light(cell: Vector3i, block_id: int) -> void:
	if torch_lights.has(cell):
		return
	var light := OmniLight3D.new()
	light.position = Vector3(cell) + Vector3(0.5, 0.5, 0.5)
	light.light_color = Color(0.55, 0.9, 1.0) if block_id == GLOW_BLOCK else Color(1.0, 0.68, 0.32)
	light.light_energy = 1.4 if block_id == GLOW_BLOCK else 1.0
	light.omni_range = 10.0 if block_id == GLOW_BLOCK else 8.0
	add_child(light)
	torch_lights[cell] = light

func _remove_torch_light(cell: Vector3i) -> void:
	if not torch_lights.has(cell):
		return
	var light: OmniLight3D = torch_lights[cell]
	if is_instance_valid(light): light.queue_free()
	torch_lights.erase(cell)

func _sync_torch_lights() -> void:
	if player == null:
		return
	var pcx := int(player.position.x) >> 4
	var pcz := int(player.position.z) >> 4
	var found: Dictionary = {}
	for cz in range(maxi(0, pcz - RENDER_DISTANCE), mini(CW, pcz + RENDER_DISTANCE + 1)):
		for cx in range(maxi(0, pcx - RENDER_DISTANCE), mini(CW, pcx + RENDER_DISTANCE + 1)):
			var data: PackedByteArray = chunks[cx + cz * CW]
			if data.size() != CS * CS * WORLD_H:
				continue
			for y in WORLD_H:
				for z in CS:
					for x in CS:
						var id := int(data[x + z * CS + y * 256])
						if id == TORCH or id == GLOW_BLOCK:
							var cell := Vector3i(cx * CS + x, y, cz * CS + z)
							found[cell] = id
	for cell in found:
		if not torch_lights.has(cell): _add_torch_light(cell, int(found[cell]))
	for cell in torch_lights.keys().duplicate():
		if not found.has(cell): _remove_torch_light(cell)

func _queue_chunk_rebuild(cx: int, cz: int) -> void:
	if cx < 0 or cx >= CW or cz < 0 or cz >= CW:
		return
	var key := cx + cz * CW
	if chunks[key].size() != CS * CS * WORLD_H:
		return
	if chunk_mi[key] == null:
		return
	dirty_chunks[key] = Vector2i(cx, cz)

func _process_dirty_chunks() -> void:
	if dirty_chunks.is_empty():
		return
	var keys := dirty_chunks.keys()
	var key: int = int(keys[0])
	var coord: Vector2i = dirty_chunks[key]
	dirty_chunks.erase(key)
	if key < 0 or key >= chunk_mi.size():
		return
	if chunk_mi[key] == null:
		return
	if chunks[key].size() != CS * CS * WORLD_H:
		return
	_build_chunk(coord.x, coord.y)

func _make_player() -> void:
	player = CharacterBody3D.new()
	player_cs = CollisionShape3D.new()
	player_cap = CapsuleShape3D.new()
	player_cap.height = 1.8
	player_cap.radius = 0.4
	player_cs.shape = player_cap
	player.add_child(player_cs)
	camera = Camera3D.new()
	camera.position = Vector3(0, 0.7, 0)
	camera.fov = Global.fov
	player.add_child(camera)
	aim_pivot = Node3D.new()
	aim_pivot.position = Vector3(0, 0.7, 0)
	player.add_child(aim_pivot)
	ray = RayCast3D.new()
	ray.target_position = Vector3(0, 0, -6)
	ray.add_exception(player)
	aim_pivot.add_child(ray)
	player_char = _build_character()
	var pr: Node3D = player_char["root"]
	pr.position = Vector3(0, -0.9, 0)
	pr.visible = false
	player.add_child(pr)
	chars.append(player_char)
	var c := WORLD_SIZE >> 1
	home_pos = Vector3(c + 0.5, _height_at(c, c) + 3.0, c + 0.5)
	player.position = home_pos
	step_player = AudioStreamPlayer.new()
	step_player.stream = load("res://grass_steps.mp3")
	step_player.volume_db = linear_to_db(Music.sfx_volume * 0.8)
	player.add_child(step_player)
	add_child(player)
	camera.current = true

func _make_hand() -> void:
	hand_pivot = Node3D.new()
	hand_pivot.position = HAND_POS
	hand_pivot.rotation_degrees = Vector3(15, 12, 0)
	camera.add_child(hand_pivot)

	var sleeve := MeshInstance3D.new()
	var sm := BoxMesh.new()
	sm.size = Vector3(0.24, 0.24, 0.5)
	sleeve.mesh = sm
	sleeve.position = Vector3(0, 0, -0.25)
	sleeve.material_override = _color_mat(Color(0.25, 0.5, 0.85))
	hand_pivot.add_child(sleeve)

	var skin := MeshInstance3D.new()
	var km := BoxMesh.new()
	km.size = Vector3(0.22, 0.22, 0.32)
	skin.mesh = km
	skin.position = Vector3(0, 0, -0.66)
	skin.material_override = _color_mat(Color(0.9, 0.7, 0.55))
	hand_pivot.add_child(skin)

	hand_item = Node3D.new()
	hand_item.position = Vector3(-0.04, 0.12, -0.92)
	hand_pivot.add_child(hand_item)

	hand_left = Node3D.new()
	hand_left.position = HAND_L_POS
	hand_left.rotation_degrees = Vector3(10, -14, 0)
	hand_left.visible = false
	camera.add_child(hand_left)
	_box(hand_left, Vector3(0.24, 0.24, 0.5), Vector3(0, 0, -0.25), _color_mat(Color(0.25, 0.5, 0.85)))
	_box(hand_left, Vector3(0.22, 0.22, 0.32), Vector3(0, 0, -0.66), _color_mat(Color(0.9, 0.7, 0.55)))
	var fm := _color_mat(WOOD_COL[0])
	var fd := _color_mat(WOOD_COL[1])
	fp_shield_mats = [fm, fd]
	_box(hand_left, Vector3(0.52, 0.68, 0.05), Vector3(0.16, 0.1, -0.86), fd)
	_box(hand_left, Vector3(0.42, 0.58, 0.06), Vector3(0.16, 0.1, -0.83), fm)
	_box(hand_left, Vector3(0.14, 0.14, 0.05), Vector3(0.16, 0.1, -0.79), _color_mat(Color(0.6, 0.62, 0.66)))

	held_id = -1
	_refresh_slots()

func _rebuild_held(id: int) -> void:
	if hand_item != null:
		_fill_item(hand_item, id, 0.23, 0.024, 20.0)
	for c in chars:
		var hand_node: Node3D = c["hand"]
		_fill_item(hand_node, id, 0.16, 0.012, 90.0)

func _fill_item(parent: Node3D, id: int, cube_scale: float, px: float, sprite_yaw: float) -> void:
	for ch in parent.get_children():
		ch.queue_free()
	if id == 0:
		return
	if id == CHEST:
		_make_hand_chest(parent, cube_scale)
		return
	if id == STICK:
		_make_hand_stick(parent, cube_scale)
		return
	if id == RAIL:
		_make_hand_rail(parent, cube_scale)
		return
	if id == BED:
		_make_hand_bed(parent, cube_scale)
		return
	if id == TORCH:
		_make_hand_torch(parent, cube_scale)
		return
	if id == BOW:
		_make_hand_bow(parent, cube_scale)
		return
	if id == SNOW:
		var snow_item := MeshInstance3D.new()
		var snow_box := BoxMesh.new()
		snow_box.size = Vector3.ONE
		snow_box.material = snow_mat
		snow_item.mesh = snow_box
		snow_item.scale = Vector3(cube_scale, cube_scale, cube_scale)
		parent.add_child(snow_item)
		return
	if TILES.has(id):
		var mi := MeshInstance3D.new()
		mi.mesh = _make_cube(id)
		mi.material_override = glass_mat if id == GLASS else block_mat
		mi.scale = Vector3(cube_scale, cube_scale, cube_scale)
		mi.rotation_degrees = Vector3(0, 35, 0)
		parent.add_child(mi)
	else:
		var sp := Sprite3D.new()
		sp.texture = _icon_for(id)
		sp.region_enabled = false
		sp.pixel_size = px
		sp.texture_filter = BaseMaterial3D.TEXTURE_FILTER_NEAREST
		sp.shaded = false
		sp.double_sided = true
		sp.alpha_cut = SpriteBase3D.ALPHA_CUT_DISCARD
		sp.rotation_degrees = Vector3(0, sprite_yaw, 0)
		parent.add_child(sp)

func _make_hand_bow(parent: Node3D, cube_scale: float) -> void:
	var bow_root := Node3D.new()
	parent.add_child(bow_root)
	var size_scale := clampf(cube_scale / 0.3, 0.45, 1.2)
	var wood := _color_mat(Color(0.38, 0.20, 0.09))
	var wood_light := _color_mat(Color(0.66, 0.40, 0.18))
	var string_mat := _color_mat(Color(0.86, 0.82, 0.70))
	var upper := _box(bow_root, Vector3(0.075, 0.30, 0.075) * size_scale, Vector3(-0.035, 0.18, 0.0), wood)
	upper.rotation.z = -0.38
	var lower := _box(bow_root, Vector3(0.075, 0.30, 0.075) * size_scale, Vector3(-0.035, -0.18, 0.0), wood)
	lower.rotation.z = 0.38
	_box(bow_root, Vector3(0.09, 0.14, 0.09) * size_scale, Vector3(0.0, 0.0, 0.0), wood_light)
	_box(bow_root, Vector3(0.018, 0.70, 0.018) * size_scale, Vector3(0.12, 0.0, 0.0), string_mat)

func _update_hand(delta: float) -> void:
	if hand_pivot == null:
		return
	hand_pivot.visible = not inv_open and view_mode == 0
	var moving := Vector2(player.velocity.x, player.velocity.z).length() > 0.5 and player.is_on_floor() and not inv_open and not paused
	bob_amp = move_toward(bob_amp, 1.0 if moving else 0.0, delta * 6.0)
	if moving:
		walk_bob += delta * 9.0
	var bob := Vector3(cos(walk_bob * 0.5) * 0.012, absf(sin(walk_bob)) * -0.02, 0.0) * bob_amp
	if breaking_active or swing_phase > 0.0:
		swing_phase += delta * 3.4
		if swing_phase >= 1.0:
			swing_phase = fmod(swing_phase, 1.0) if breaking_active else 0.0
	var s := sin(swing_phase * PI)
	if not player_char.is_empty():
		var pr: Node3D = player_char["root"]
		pr.visible = view_mode != 0
		if pr.visible:
			_animate_char(player_char, sin(walk_bob) * 0.7 * bob_amp, s, pitch, local_emote_id, local_emote_time)
	hand_pivot.position = HAND_POS + bob + Vector3(-0.08, -0.12, -0.12) * s
	hand_pivot.rotation_degrees = Vector3(15.0 - 45.0 * s, 12.0 + 8.0 * s, -10.0 * s)
	if hand_left != null:
		if armor[4]["id"] == 0:
			blocking = false
		hand_left.visible = armor[4]["id"] != 0 and view_mode == 0 and not inv_open
		var want := 1.0 if (blocking and hand_left.visible) else 0.0
		block_amt = move_toward(block_amt, want, delta * 9.0)
		var e := block_amt * block_amt * (3.0 - 2.0 * block_amt)
		hand_left.position = HAND_L_POS.lerp(HAND_L_BLOCK_POS, e) + Vector3(-bob.x, bob.y, 0.0) * (1.0 - e)
		hand_left.rotation_degrees = Vector3(10.0, -14.0, 0.0).lerp(Vector3(0.0, 0.0, 0.0), e)

var current_chunk := Vector2i(-999, -999)
var dirty_chunks: Dictionary = {}
var chunk_build_queue: Array[Vector2i] = []
var chunk_build_queued: Dictionary = {}

const RENDER_DISTANCE := 3

func _update_chunks(force := false) -> void:
	if player == null:
		return

	var player_chunk := Vector2i(
		int(player.position.x) >> 4,
		int(player.position.z) >> 4
	)

	if player_chunk == current_chunk and not force:
		return

	current_chunk = player_chunk

	for cz in range(player_chunk.y - RENDER_DISTANCE - 2, player_chunk.y + RENDER_DISTANCE + 3):
		for cx in range(player_chunk.x - RENDER_DISTANCE - 2, player_chunk.x + RENDER_DISTANCE + 3):
			if cx < 0 or cx >= CW or cz < 0 or cz >= CW:
				continue
			var key := cx + cz * CW
			if chunks[key].is_empty():
				_gen_terrain(cx, cz)

	for cz in range(player_chunk.y - RENDER_DISTANCE - 1, player_chunk.y + RENDER_DISTANCE + 2):
		for cx in range(player_chunk.x - RENDER_DISTANCE - 1, player_chunk.x + RENDER_DISTANCE + 2):
			if cx < 0 or cx >= CW or cz < 0 or cz >= CW:
				continue
			var key := cx + cz * CW
			if not trees_generated[key]:
				_gen_trees_in_chunk(cx, cz)
				trees_generated[key] = true
			if not villages_generated[key]:
				_gen_village_in_chunk(cx, cz)
				_gen_trader_ship_in_chunk(cx, cz)
				villages_generated[key] = true

	for cz in range(player_chunk.y - RENDER_DISTANCE, player_chunk.y + RENDER_DISTANCE + 1):
		for cx in range(player_chunk.x - RENDER_DISTANCE, player_chunk.x + RENDER_DISTANCE + 1):
			if cx < 0 or cx >= CW or cz < 0 or cz >= CW:
				continue
			var key := cx + cz * CW
			if chunk_mi[key] == null:
				_queue_chunk_build(cx, cz)

	for key in range(chunk_mi.size()):
		var mi = chunk_mi[key]
		if mi != null:
			var cx := key % CW
			var cz := int(key / CW)
			if abs(cx - player_chunk.x) > RENDER_DISTANCE + 1 or abs(cz - player_chunk.y) > RENDER_DISTANCE + 1:
				mi.get_parent().queue_free()
				chunk_mi[key] = null
				chunk_cs[key] = null
	_sync_torch_lights()

func _physics_process(delta: float) -> void:
	raft_is_driving = false
	if paused or is_dead or not ready_done:
		return

	var is_crouching := Input.is_physical_key_pressed(KEY_SHIFT) or (control_mode == CONTROL_MODE_MOBILE and mobile_crouch_held)
	var is_sprinting := (Input.is_physical_key_pressed(KEY_CTRL) or (control_mode == CONTROL_MODE_MOBILE and mobile_sprint_held)) and not is_crouching

	var target_cam_y := 0.2 if is_crouching else 0.7
	camera.position.y = lerp(camera.position.y, target_cam_y, delta * 15.0)

	var dir := Vector3.ZERO
	if not inv_open:
		var b := player.global_transform.basis
		var move_x := float(int(Input.is_physical_key_pressed(KEY_D)) - int(Input.is_physical_key_pressed(KEY_A)))
		var move_z := float(int(Input.is_physical_key_pressed(KEY_S)) - int(Input.is_physical_key_pressed(KEY_W)))
		if control_mode == CONTROL_MODE_MOBILE:
			var mobile_vec := mobile_stick_vector if mobile_control_style == 1 else mobile_move_vec
			move_x += mobile_vec.x
			move_z += mobile_vec.y
		move_x = clampf(move_x, -1.0, 1.0)
		move_z = clampf(move_z, -1.0, 1.0)
		dir = b.x * move_x + b.z * move_z

	dir.y = 0
	dir = dir.normalized()

	if is_crouching and dir != Vector3.ZERO and not (_height_at(int(floor(player.position.x)), int(floor(player.position.z))) < 15 and player.position.y < 16.2 and player.position.y > 8.5):
		var next_x := player.position.x + dir.x * 0.4
		var next_z := player.position.z + dir.z * 0.4
		var feet_y := player.position.y - 0.9 - 0.1
		if get_block(int(floor(next_x)), int(floor(feet_y)), int(floor(next_z))) == 0:
			dir = Vector3.ZERO

	var current_speed := SPEED
	if is_sprinting and dir != Vector3.ZERO:
		current_speed *= 1.5

	var jump_down := Input.is_physical_key_pressed(KEY_SPACE) or (control_mode == CONTROL_MODE_MOBILE and mobile_jump_held)
	if riding_minecart:
		if is_crouching or jump_down:
			riding_minecart = false
			player.global_position = Vector3(minecart_cell.x + 1.2, minecart_cell.y + 0.8, minecart_cell.z + 0.5)
			_show_msg("Вы вышли из вагонетки")
		else:
			minecart_step_timer -= delta
			if dir.length() > 0.1 and minecart_step_timer <= 0.0:
				var step := Vector3i.ZERO
				if absf(dir.x) > absf(dir.z):
					step.x = 1 if dir.x > 0.0 else -1
				else:
					step.z = 1 if dir.z > 0.0 else -1
				var next_cell := minecart_cell + step
				if get_block(next_cell.x, minecart_cell.y - 1, next_cell.z) == RAIL and get_block(next_cell.x, next_cell.y, next_cell.z) == 0:
					_set_block(minecart_cell, 0)
					_set_block(next_cell, MINECART)
					minecart_cell = next_cell
				minecart_step_timer = 0.18
			player.global_position = Vector3(minecart_cell.x + 0.5, minecart_cell.y + 0.95, minecart_cell.z + 0.5)
			player.velocity = Vector3.ZERO
			jump_was_down = jump_down
			return
	var water_column := _height_at(int(floor(player.position.x)), int(floor(player.position.z))) < 15
	swimming = water_column and player.position.y < 16.2 and player.position.y > 8.5
	if swimming:
		current_speed = 2.7 if is_sprinting else 2.1
	if riding_raft != null and not is_instance_valid(riding_raft):
		riding_raft = null
	if riding_raft != null:
		swimming = false
		if is_crouching or jump_down:
			player.global_position = riding_raft.to_global(raft_rider_offset + Vector3(3.0, 0.25, 0.0))
			riding_raft = null
			raft_rider_offset = Vector3.ZERO
			_show_msg("Вы сошли с плота")
		else:
			var next_raft_pos := riding_raft.position + Vector3(dir.x, 0.0, dir.z) * 3.2 * delta
			var next_raft_yaw := player.rotation.y
			if dir != Vector3.ZERO:
				raft_is_driving = true
				if _raft_area_is_water(next_raft_pos, next_raft_yaw):
					riding_raft.position = next_raft_pos
				riding_raft.rotation.y = next_raft_yaw
			player.global_position = riding_raft.to_global(raft_rider_offset)
			player.velocity = Vector3.ZERO
			jump_was_down = jump_down
			return
	if riding_boat != null and not is_instance_valid(riding_boat):
		riding_boat = null
	if riding_boat != null:
		if is_crouching or Input.is_physical_key_pressed(KEY_SPACE) or (control_mode == CONTROL_MODE_MOBILE and mobile_jump_held):
			var exit_pos: Vector3 = riding_boat.global_position + Vector3(1.35, 0.9, 0.0)
			player.global_position = exit_pos
			riding_boat = null
		else:
			var boat_speed := 3.6
			riding_boat.global_position += Vector3(dir.x, 0.0, dir.z) * boat_speed * delta
			riding_boat.rotation.y = player.rotation.y
			player.global_position = riding_boat.global_position + Vector3(0.0, 0.85, 0.0)
			player.velocity = Vector3.ZERO
			jump_was_down = jump_down
			return
	player.velocity.x = dir.x * current_speed
	player.velocity.z = dir.z * current_speed
	if creative_mode and is_crouching:
		creative_flying = false
		player.velocity.y = -0.5
	elif creative_mode and jump_down and not jump_was_down and not inv_open:
		var now_ms := Time.get_ticks_msec()
		if now_ms - last_jump_msec <= 420:
			creative_flying = not creative_flying
		last_jump_msec = now_ms
		if not creative_flying and player.is_on_floor():
			player.velocity.y = JUMP_SPEED
	if creative_mode and creative_flying:
		player.velocity.y = JUMP_SPEED if jump_down else 0.0
	elif swimming:
		# Пробел всплывает/плывёт вверх, Shift или мобильное «Присед» ныряет.
		if jump_down:
			player.velocity.y = 2.8
		elif is_crouching:
			player.velocity.y = -2.4
		else:
			player.velocity.y = 0.0
	else:
		if not player.is_on_floor():
			player.velocity.y -= GRAVITY * delta
		elif jump_down and not jump_was_down and not inv_open and not is_crouching:
			player.velocity.y = JUMP_SPEED
		else:
			player.velocity.y = -0.5
	jump_was_down = jump_down

	var grounded_before_move := player.is_on_floor()
	player.move_and_slide()
	# Урон от падения: высота считается от момента схода с земли до приземления.
	# В творческом режиме и при плавании падение не наносит урон.
	if creative_mode or swimming:
		fall_tracking = false
	elif grounded_before_move and not player.is_on_floor():
		fall_start_y = player.global_position.y
		fall_tracking = true
	elif fall_tracking and player.is_on_floor():
		var fall_distance := maxf(0.0, fall_start_y - player.global_position.y)
		fall_tracking = false
		if fall_distance > 3.0:
			var fall_damage := float(maxi(1, floori(fall_distance - 3.0)))
			take_damage(fall_damage)
			if not is_dead and is_equal_approx(health, 1.0):
				var impact_feet := player.global_position - Vector3(0.0, 0.96, 0.0)
				var impact_cell := Vector3i(int(floor(impact_feet.x)), int(floor(impact_feet.y - 0.06)), int(floor(impact_feet.z)))
				if get_block(impact_cell.x, impact_cell.y, impact_cell.z) == STONE:
					nokia_pending_cell = impact_cell
			if not is_dead and health > 0.0:
				_show_msg("Урон от падения: %.1f" % fall_damage)
	var head_underwater := swimming and player.position.y + 0.72 < 15.08
	if head_underwater:
		breath_time = maxf(0.0, breath_time - delta)
		drowning_tick += delta
		if breath_time <= 0.0 and drowning_tick >= 1.5:
			drowning_tick = 0.0
			take_damage(1.0)
	else:
		breath_time = minf(15.0, breath_time + delta * 2.5)
		drowning_tick = 0.0
	if breath_label != null:
		breath_label.visible = swimming
		var bubbles := int(ceil(breath_time / 1.5))
		breath_label.text = "◉ " + "●".repeat(bubbles) + "○".repeat(10 - bubbles)

	var h_speed := Vector2(player.velocity.x, player.velocity.z).length()
	if player.is_on_floor() and h_speed > 0.5:
		step_timer -= delta
		var step_interval := 0.3 if is_sprinting else 0.45
		if step_timer <= 0.0:
			step_timer = step_interval
			var feet_pos := player.position - Vector3(0, 0.95, 0)
			var block_below := get_block(int(floor(feet_pos.x)), int(floor(feet_pos.y)), int(floor(feet_pos.z)))
			if block_below == GRASS:
				step_player.pitch_scale = randf_range(0.9, 1.1)
				step_player.play()
	else:
		step_timer = 0.0
		if step_player.playing:
			step_player.stop()

	player.position.x = clampf(player.position.x, 1.0, WORLD_SIZE - 1.0)
	player.position.z = clampf(player.position.z, 1.0, WORLD_SIZE - 1.0)
	if player.position.y < -10:
		health = 0.0
		_update_health_label()
		_show_death_screen()
	if view_mode != 0:
		_apply_camera_mode()

	_update_chunks()
	mob_attack_cooldown = maxf(0.0, mob_attack_cooldown - delta)
	_update_breaking(delta)

func _queue_chunk_build(cx: int, cz: int) -> void:
	if cx < 0 or cx >= CW or cz < 0 or cz >= CW:
		return
	var key := cx + cz * CW
	if chunk_mi[key] != null:
		return
	if chunks[key].size() != CS * CS * WORLD_H:
		return
	if chunk_build_queued.has(key):
		return
	chunk_build_queued[key] = true
	chunk_build_queue.append(Vector2i(cx, cz))

func _process_chunk_build_queue() -> void:
	if player == null or chunk_build_queue.is_empty():
		return
	var player_cx := int(player.position.x) >> 4
	var player_cz := int(player.position.z) >> 4
	var best_index := -1
	var best_distance := 2147483647
	for i in range(chunk_build_queue.size()):
		var candidate: Vector2i = chunk_build_queue[i]
		var dx := candidate.x - player_cx
		var dz := candidate.y - player_cz
		var distance := dx * dx + dz * dz
		if distance < best_distance:
			best_distance = distance
			best_index = i
	if best_index == -1:
		return
	var selected_coord: Vector2i = chunk_build_queue[best_index]
	chunk_build_queue.remove_at(best_index)
	var key := selected_coord.x + selected_coord.y * CW
	chunk_build_queued.erase(key)
	if abs(selected_coord.x - player_cx) > RENDER_DISTANCE:
		return
	if abs(selected_coord.y - player_cz) > RENDER_DISTANCE:
		return
	if chunks[key].size() != CS * CS * WORLD_H:
		return
	if chunk_mi[key] == null:
		_build_chunk(selected_coord.x, selected_coord.y)


func _make_sleep_ui() -> void:
	sleep_panel = PanelContainer.new()
	sleep_panel.set_anchors_preset(Control.PRESET_CENTER)
	sleep_panel.position = Vector2(-190, -62)
	sleep_panel.size = Vector2(380, 124)
	sleep_panel.custom_minimum_size = Vector2(320, 124)
	sleep_panel.visible = false
	sleep_panel.z_index = 80
	hud_layer.add_child(sleep_panel)
	var body := VBoxContainer.new()
	body.alignment = BoxContainer.ALIGNMENT_CENTER
	sleep_panel.add_child(body)
	var heading := Label.new()
	heading.text = "Вы лежите в кровати"
	heading.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	heading.add_theme_font_size_override("font_size", 20)
	body.add_child(heading)
	sleep_panel_label = Label.new()
	sleep_panel_label.text = "Ждём, пока все игроки лягут спать…"
	sleep_panel_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	sleep_panel_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	body.add_child(sleep_panel_label)

func _request_sleep(_bed_cell: Vector3i) -> void:
	if cycle_time < DAY_LENGTH:
		_show_msg("Спать можно только ночью")
		return
	if sleep_panel != null:
		sleep_panel.visible = true
		sleep_panel_label.text = "Ждём, пока все игроки лягут спать…"
	if not net_connected:
		_finish_sleep()
		return
	if net_is_host:
		sleep_votes[1] = true
		_update_sleep_vote_status()
	else:
		_net_send_event({"type": "sleep_request"})
		_show_msg("Ты лёг в кровать. Ждём, пока остальные игроки тоже лягут…")

func _update_sleep_vote_status() -> void:
	var total_players: int = 1 + net_remote_players.size()
	var sleeping: int = sleep_votes.size()
	sleep_status_text = "Спят: %d/%d игроков" % [sleeping, total_players]
	if sleep_panel != null:
		sleep_panel.visible = true
		sleep_panel_label.text = sleep_status_text + "\nНужно, чтобы легли все!"
	_show_msg(sleep_status_text)
	_net_send_event({"type": "sleep_status", "sleeping": sleeping, "total": total_players})
	if sleeping >= total_players:
		_finish_sleep()

func _finish_sleep() -> void:
	sleep_votes.clear()
	if sleep_panel != null:
		sleep_panel.visible = false
	cycle_time = 0.0
	day_count += 1
	night_active = false
	for mob in zombie_nodes:
		if is_instance_valid(mob):
			mob.queue_free()
	zombie_nodes.clear()
	if net_connected and net_is_host:
		_net_send_event({"type": "sleep_done", "cycle_time": cycle_time, "day_count": day_count})
	_show_msg("Все игроки легли спать. Наступило утро!")

func _process(delta: float) -> void:
	if load_cam != null:
		_update_load_cam(delta)
	if not ready_done:
		return
	world_autosave_timer += delta
	if not paused and not is_dead:
		_update_achievement_trackers(delta)
	if achievement_toast_timer > 0.0:
		achievement_toast_timer = maxf(0.0, achievement_toast_timer - delta)
		if achievement_toast_timer <= 0.0 and achievement_toast != null:
			achievement_toast.visible = false
	mob_attack_cooldown = maxf(0.0, mob_attack_cooldown - delta)
	emote_cooldown = maxf(0.0, emote_cooldown - delta)
	local_emote_time = maxf(0.0, local_emote_time - delta)
	if local_emote_time <= 0.0:
		local_emote_id = -1
	_update_remote_avatar_animations(delta)
	if world_autosave_timer >= WORLD_AUTOSAVE_INTERVAL:
		_save_world()
	_update_network_sync(delta)
	_update_dropped_items(delta)
	if not paused:
		_update_npc_ships(delta)
	var had_dirty_chunks := not dirty_chunks.is_empty()
	_process_dirty_chunks()
	if not had_dirty_chunks:
		_process_chunk_build_queue()

	if inv_open:
		if creative_scroll_direction != 0 and creative_scroll != null and creative_mode:
			creative_scroll_repeat -= delta
			if creative_scroll_repeat <= 0.0:
				creative_scroll.scroll_vertical = maxi(0, creative_scroll.scroll_vertical + creative_scroll_direction * 18)
				creative_scroll_repeat = 0.035
		cursor_ui["btn"].position = get_viewport().get_mouse_position() - Vector2(24, 24)
		highlight.visible = false
		if not preview_char.is_empty():
			var vs := get_viewport().get_visible_rect().size
			var mx := clampf((get_viewport().get_mouse_position().x / vs.x - 0.5) * 2.0, -1.0, 1.0)
			var prv: Node3D = preview_char["root"]
			prv.rotation.y = PI + mx * 0.8
		_rmb_drag()
	else:
		var t := _target()
		if t.is_empty() or paused:
			highlight.visible = false
		else:
			var cell: Vector3i = t["cell"]
			highlight.visible = true
			highlight.position = Vector3(cell) + Vector3(0.5, 0.5, 0.5)
	_update_hand(delta)
	if spawn_protection > 0.0:
		spawn_protection = maxf(0.0, spawn_protection - delta)
	if damage_flash_timer > 0.0 and damage_flash != null:
		damage_flash_timer = maxf(0.0, damage_flash_timer - delta)
		damage_flash.color.a = 0.22 * (damage_flash_timer / 0.42)
	if not paused:
		_update_villagers(delta)
	if not paused:
		_update_day_night(delta)
		if not net_connected or net_is_host:
			_grow_crops(delta)
			_update_furnaces(delta)
	if held_name_timer > 0.0:
		held_name_timer -= delta
		if held_name_timer <= 0.0 and held_name_label != null:
			held_name_label.visible = false
	if msg_t > 0.0:
		msg_t -= delta
		if msg_t <= 0.0 and msg_label != null:
			msg_label.text = ""

# ---------------- посевы ----------------

func _crop_stage(c: Dictionary) -> int:
	return mini(2, int(float(c["t"]) / GROW_TIME))

func _spawn_crop_node(cell: Vector3i) -> void:
	var root := Node3D.new()
	root.position = Vector3(cell) + Vector3(0.5, 0.5, 0.5)
	for k in 2:
		var sp := Sprite3D.new()
		sp.texture = items_tex
		sp.region_enabled = true
		sp.pixel_size = 1.0 / 16.0
		sp.texture_filter = BaseMaterial3D.TEXTURE_FILTER_NEAREST
		sp.shaded = false
		sp.double_sided = true
		sp.alpha_cut = SpriteBase3D.ALPHA_CUT_DISCARD
		sp.rotation_degrees = Vector3(0, 45 + 90 * k, 0)
		root.add_child(sp)
	add_child(root)
	crop_nodes[cell] = root
	_update_crop_node(cell)

func _update_crop_node(cell: Vector3i) -> void:
	if not crop_nodes.has(cell) or not crops.has(cell):
		return
	var c: Dictionary = crops[cell]
	var tile := 16 + int(c["type"]) * 3 + _crop_stage(c)
	var root: Node3D = crop_nodes[cell]
	for ch in root.get_children():
		var sp := ch as Sprite3D
		sp.region_rect = Rect2(float(tile * 16), 0.0, 16.0, 16.0)

func _spawn_loaded_crops() -> void:
	for k in crops.keys():
		var cell: Vector3i = k
		if get_block(cell.x, cell.y - 1, cell.z) == FARMLAND and get_block(cell.x, cell.y, cell.z) == 0:
			_spawn_crop_node(cell)
		else:
			crops.erase(cell)

func _remove_crop(cell: Vector3i) -> void:
	crops.erase(cell)
	if crop_nodes.has(cell):
		var n: Node3D = crop_nodes[cell]
		n.queue_free()
		crop_nodes.erase(cell)

func _grow_crops(delta: float) -> void:
	grow_acc += delta
	if grow_acc < 1.0:
		return
	var dt := grow_acc
	grow_acc = 0.0
	for k in crops.keys():
		var cell: Vector3i = k
		var c: Dictionary = crops[cell]
		var before := _crop_stage(c)
		c["t"] = float(c["t"]) + dt
		if _crop_stage(c) != before:
			_update_crop_node(cell)

func _break_crop(cell: Vector3i) -> void:
	if not crops.has(cell):
		return
	var c: Dictionary = crops[cell]
	var ty: int = c["type"]
	if _crop_stage(c) >= 2:
		add_item(CROP_DROP[ty], randi_range(1, 2))
		add_item(CROP_SEED[ty], randi_range(1, 2))
	else:
		add_item(CROP_SEED[ty], 1)
	_remove_crop(cell)

func _use_hoe(t: Dictionary) -> void:
	var cell: Vector3i = t["cell"]
	var id: int = t["id"]
	if id != GRASS and id != DIRT:
		return
	if cell.y < 1:
		return
	if get_block(cell.x, cell.y + 1, cell.z) != 0:
		return
	_set_block(cell, FARMLAND)
	swing_phase = 0.001

func _plant_seed(t: Dictionary, s: Dictionary) -> void:
	var cell: Vector3i = t["cell"]
	var up := cell + Vector3i(0, 1, 0)
	if t["id"] != FARMLAND or t["place"] != up:
		return
	if get_block(up.x, up.y, up.z) != 0 or crops.has(up):
		return
	crops[up] = {"type": SEED_CROP[s["id"]], "t": 0.0}
	_spawn_crop_node(up)
	swing_phase = 0.001
	s["n"] -= 1
	if s["n"] <= 0:
		s["id"] = 0
		s["n"] = 0
	_refresh_slots()

# ---------------- двери ----------------

func _door_occupies(c: Vector3i) -> bool:
	return doors.has(c) or doors.has(c + Vector3i(0, -1, 0))

func _spawn_door_node(cell: Vector3i) -> void:
	var d: Dictionary = doors[cell]
	var root := Node3D.new()
	root.position = Vector3(cell) + Vector3(0.5, 0.0, 0.5)
	root.rotation_degrees = Vector3(0.0, float(int(d["dir"]) * 90), 0.0)
	var hinge := StaticBody3D.new()
	hinge.position = Vector3(-0.5, 0.0, 0.0)
	hinge.set_meta("door_cell", cell)
	hinge.rotation_degrees = Vector3(0.0, 90.0 if d["open"] else 0.0, 0.0)
	root.add_child(hinge)
	var cs := CollisionShape3D.new()
	var sh := BoxShape3D.new()
	sh.size = Vector3(1.0, 2.0, 0.16)
	cs.shape = sh
	cs.position = Vector3(0.5, 1.0, 0.0)
	hinge.add_child(cs)
	var wood := _color_mat(Color(0.62, 0.44, 0.24))
	var dark := _color_mat(Color(0.46, 0.31, 0.16))
	var iron := _color_mat(Color(0.7, 0.72, 0.76))
	_box(hinge, Vector3(1.0, 2.0, 0.16), Vector3(0.5, 1.0, 0.0), wood)
	for zs in [1.0, -1.0]:
		_box(hinge, Vector3(0.7, 0.8, 0.02), Vector3(0.5, 0.5, 0.085 * zs), dark)
		_box(hinge, Vector3(0.7, 0.8, 0.02), Vector3(0.5, 1.5, 0.085 * zs), dark)
	_box(hinge, Vector3(0.1, 0.1, 0.24), Vector3(0.82, 1.0, 0.0), iron)
	add_child(root)
	door_nodes[cell] = hinge

func _spawn_loaded_doors() -> void:
	for k in doors.keys():
		var cell: Vector3i = k
		if get_block(cell.x, cell.y, cell.z) == 0 and get_block(cell.x, cell.y + 1, cell.z) == 0:
			_spawn_door_node(cell)
		else:
			doors.erase(cell)

func _toggle_door(cell: Vector3i) -> void:
	if not doors.has(cell) or not door_nodes.has(cell):
		return
	var d: Dictionary = doors[cell]
	d["open"] = not bool(d["open"])
	var hinge: StaticBody3D = door_nodes[cell]
	var tw := create_tween()
	tw.tween_property(hinge, "rotation_degrees:y", 90.0 if d["open"] else 0.0, 0.18)

func _break_door(cell: Vector3i) -> void:
	if door_nodes.has(cell):
		var h: StaticBody3D = door_nodes[cell]
		var r := h.get_parent()
		r.queue_free()
		door_nodes.erase(cell)
	doors.erase(cell)
	add_item(DOOR, 1)

func _place_door(t: Dictionary, s: Dictionary) -> void:
	var cell: Vector3i = t["place"]
	var up := cell + Vector3i(0, 1, 0)
	if cell.y < 1 or up.y >= WORLD_H or cell.x < 0 or cell.z < 0 or cell.x >= WORLD_SIZE or cell.z >= WORLD_SIZE:
		return
	if get_block(cell.x, cell.y, cell.z) != 0 or get_block(up.x, up.y, up.z) != 0:
		return
	if get_block(cell.x, cell.y - 1, cell.z) == 0:
		return
	if _door_occupies(cell) or _door_occupies(up) or crops.has(cell):
		return
	if _overlaps_player(cell) or _overlaps_player(up):
		return
	var q := int(round(player.rotation.y / (PI / 2.0)))
	doors[cell] = {"dir": q & 3, "open": false}
	_spawn_door_node(cell)
	swing_phase = 0.001
	s["n"] -= 1
	if s["n"] <= 0:
		s["id"] = 0
		s["n"] = 0
	_refresh_slots()

# ---------------- ломание блоков ----------------

func _break_time(id: int) -> float:
	var t: float = HARDNESS.get(id, 1.0)
	var held: int = slots[selected]["id"]
	var mult := 1.0
	if id in [STONE, COAL, IRON, FURNACE, DIAMOND_ORE]:
		if held == PICKAXE:
			mult = 3.0
		elif held == S_PICKAXE:
			mult = 5.0
		elif held == I_PICKAXE:
			mult = 8.0
		elif held == D_PICKAXE:
			mult = 11.0
	elif id in [GRASS, DIRT, FARMLAND]:
		if held == SHOVEL:
			mult = 3.0
		elif held == S_SHOVEL:
			mult = 5.0
		elif held == I_SHOVEL:
			mult = 8.0
		elif held == D_SHOVEL:
			mult = 11.0
	elif id in [LOG, PLANKS, TABLE, DOOR, CHEST, MINECART, MUSIC_PLAYER]:
		if held == AXE:
			mult = 3.0
		elif held == S_AXE:
			mult = 5.0
		elif held == I_AXE:
			mult = 8.0
		elif held == D_AXE:
			mult = 11.0
	elif id == LEAVES:
		if held == SWORD:
			mult = 3.0
		elif held == S_SWORD:
			mult = 5.0
		elif held == I_SWORD:
			mult = 8.0
		elif held == D_SWORD:
			mult = 11.0
	return t / mult

func _update_breaking(delta: float) -> void:
	var active := false
	if breaking and not inv_open and int(slots[selected].get("id", 0)) == BOW:
		if mob_attack_cooldown <= 0.0:
			_shoot_player_bow()
		break_overlay.visible = false
		return
	if breaking and not inv_open and _try_attack_mob():
		breaking_active = true
		break_overlay.visible = false
		return
	if breaking and not inv_open:
		var t := _target()
		if not t.is_empty():
			var cell: Vector3i = t["cell"]
			var id: int = t["id"]
			if id != 0 and cell.y > 0:
				if cell != break_cell:
					break_cell = cell
					break_progress = 0.0
				active = true
				break_progress += delta / _break_time(id)
				if break_progress >= 1.0:
					_break_block_now(cell, id)
					break_progress = 0.0
					break_cell = Vector3i(-1, -1, -1)
	if not active:
		break_progress = 0.0
	breaking_active = active
	if active and break_progress > 0.0:
		var stage := clampi(int(break_progress * CRACK_STAGES), 0, CRACK_STAGES - 1)
		break_mat.albedo_texture = crack_tex[stage]
		break_overlay.position = Vector3(break_cell) + Vector3(0.5, 0.5, 0.5)
		break_overlay.visible = true
	else:
		break_overlay.visible = false

func _break_block_now(cell: Vector3i, id: int) -> void:
	if id == STONE and cell == nokia_pending_cell:
		nokia_pending_cell = Vector3i(-1, -1, -1)
		Achievements.unlock("nokia_3310")
	_play_sfx("res://break.wav")
	var raft_target := _target()
	if not raft_target.is_empty() and raft_target.has("raft") and int(raft_target.get("id", 0)) > 0:
		var raft: Node3D = raft_target["raft"] as Node3D
		var raft_cell: Vector3i = raft_target["cell"]
		var removed_id := _remove_raft_block_local(raft, raft_cell)
		if removed_id > 0:
			add_item(removed_id, 1)
			if net_connected:
				if net_is_host:
					_net_send_event({"type": "raft_block_remove", "raft_id": int(raft.get_meta("raft_id", 0)), "cell": [raft_cell.x, raft_cell.y, raft_cell.z]})
				else:
					_net_send_event({"type": "raft_block_remove_request", "raft_id": int(raft.get_meta("raft_id", 0)), "cell": [raft_cell.x, raft_cell.y, raft_cell.z]})
			return
	if id == DOOR:
		_break_door(cell)
		return
	if id == BED:
		var other_bed_cell := cell + Vector3i(1, 0, 0)
		if get_block(cell.x - 1, cell.y, cell.z) == BED:
			other_bed_cell = cell + Vector3i(-1, 0, 0)
		_set_block(cell, 0)
		if get_block(other_bed_cell.x, other_bed_cell.y, other_bed_cell.z) == BED:
			_set_block(other_bed_cell, 0)
		add_item(BED, 1)
		return
	if id == FARMLAND:
		var up := cell + Vector3i(0, 1, 0)
		if crops.has(up):
			_break_crop(up)
			return
	if id == GRASS and randf() < SEED_CHANCE:
		add_item(CROP_SEED[randi() % 3], 1)

	if id == CHEST or id == MINECART:
		var origin := cell
		var is_cart := id == MINECART
		var is_double := false
		if id == CHEST:
			var group := _get_chest_group(cell)
			origin = group["origin"]
			is_double = bool(group["double"])
		var inv := _get_chest_inventory(origin, is_double)
		for item in inv:
			if item["id"] != 0:
				add_item(item["id"], item["n"])
		chests.erase(origin)
		add_item(MINECART if is_cart else CHEST, 1)
		_set_block(cell, 0)
		if not net_connected or net_is_host:
			_physics_after_block_removed(cell)
		return

	if id == FURNACE and furnaces.has(cell):
		var fd: Dictionary = furnaces[cell]
		for key in ["input", "fuel", "output"]:
			var it: Dictionary = fd[key]
			if it["id"] != 0:
				add_item(it["id"], it["n"])
		furnaces.erase(cell)

	if id == COAL:
		add_item(COAL_ITEM, randi_range(1, 2))
	elif id == TORCH or id == BED:
		add_item(id, 1)
	elif id == DIAMOND_ORE:
		add_item(DIAMOND, 1)
	elif id == IRON:
		add_item(RAW_IRON, 1)
	else:
		add_item(DIRT if (id == GRASS or id == FARMLAND) else id, 1)
	_set_block(cell, 0)
	if not net_connected or net_is_host:
		_physics_after_block_removed(cell)

func add_item(id: int, n: int = 1) -> int:
	_play_sfx("res://pickup.wav")
	var left := _store_items(slots, id, n)
	_refresh_slots()
	return left

func _store_items(arr: Array, id: int, n: int) -> int:
	for i in TOTAL_SLOTS:
		var s: Dictionary = arr[i]
		if s["id"] == id and s["n"] < MAX_STACK and n > 0:
			var add: int = mini(n, MAX_STACK - int(s["n"]))
			s["n"] += add
			n -= add
	for i in TOTAL_SLOTS:
		var s: Dictionary = arr[i]
		if s["id"] == 0 and n > 0:
			var add: int = mini(n, MAX_STACK)
			s["id"] = id
			s["n"] = add
			n -= add
	return n

func _on_game_language_changed(_language_code: String) -> void:
	Localization.apply_to_tree(self)

func _on_achievement_unlocked(id: String, title: String, description: String, is_global: bool) -> void:
	if is_global:
		return
	var nick: String = str(Global.network_player_name).strip_edges()
	if nick.is_empty():
		nick = "Игрок"
	_display_achievement_announcement(nick, title, description)
	if net_connected:
		if net_is_host:
			_net_send_event({"type": "achievement_announce", "id": id, "nick": nick, "title": title})
		else:
			_net_send_event({"type": "achievement_announce_request", "id": id, "nick": nick})

func _display_achievement_announcement(nick: String, title: String, description: String = "") -> void:
	var safe_nick := nick.strip_edges().substr(0, 20)
	if safe_nick.is_empty():
		safe_nick = "Игрок"
	var shown_title := Localization.translate_text(title.substr(0, 80)).to_upper()
	var shown_description := Localization.translate_text(description.substr(0, 120))
	if achievement_toast_icon != null:
		achievement_toast_icon.text = _achievement_icon_for_title(title)
	if achievement_toast_title != null:
		achievement_toast_title.text = shown_title
	if achievement_toast_description != null:
		achievement_toast_description.text = shown_description
	if achievement_toast_label != null:
		var player_line := safe_nick.to_upper()
		achievement_toast_label.text = player_line
	if achievement_toast != null:
		achievement_toast.visible = true
		achievement_toast_timer = 6.0
	var line := "Игрок \"%s\" получил достижение \"%s\"" % [safe_nick.to_upper(), shown_title]
	if Localization.language == "uk":
		line = "Гравець \"%s\" отримав досягнення \"%s\"" % [safe_nick.to_upper(), shown_title]
	elif Localization.language == "en":
		line = "Player \"%s\" unlocked achievement \"%s\"" % [safe_nick.to_upper(), shown_title]
	if chat_history != null:
		_append_network_chat("DareCraft", line)

func _achievement_icon_for_title(title: String) -> String:
	var key := title.to_lower()
	if key.contains("гряд") or key.contains("farmer"): return "🌾"
	if key.contains("дров") or key.contains("lumber"): return "🪓"
	if key.contains("пациф") or key.contains("pacif"): return "🕊️"
	if key.contains("nokia"): return "📱"
	if key.contains("гус") or key.contains("goose"): return "🪿"
	if key.contains("лингв") or key.contains("lingu"): return "🌐"
	if key.contains("оборот"): return "🐺"
	if key.contains("коллекц"): return "🏺"
	if key.contains("медаль"): return "🏅"
	if key.contains("бесчув") or key.contains("emotion"): return "💀"
	if key.contains("witty"): return "👽"
	return "🏆"

func on_mob_killed(_mob: Node, hostile: bool = true) -> void:
	achievement_pacifist_timer = 0.0
	achievement_kill_this_minute = true
	if hostile:
		achievement_hostile_kill_times.append(achievement_elapsed)
		while not achievement_hostile_kill_times.is_empty() and achievement_elapsed - achievement_hostile_kill_times[0] > 15.0:
			achievement_hostile_kill_times.pop_front()
		if achievement_hostile_kill_times.size() >= 5:
			Achievements.unlock("magnus_wins")

func _inventory_has_item(item_id: int) -> bool:
	for slot in slots:
		if int(slot.get("id", 0)) == item_id and int(slot.get("n", 0)) > 0:
			return true
	return false

func _update_achievement_trackers(delta: float) -> void:
	achievement_elapsed += delta
	if not Achievements.is_unlocked("pacifist"):
		achievement_pacifist_timer += delta
		if achievement_pacifist_timer >= 900.0:
			Achievements.unlock("pacifist")
	if _inventory_has_item(WHEAT):
		achievement_wheat_timer += delta
	else:
		achievement_wheat_timer = 0.0
	if achievement_wheat_timer >= 600.0:
		Achievements.unlock("farmer")
	var log_count := 0
	for slot in slots:
		if int(slot.get("id", 0)) == LOG:
			log_count += int(slot.get("n", 0))
	if log_count >= MAX_STACK * 3:
		Achievements.unlock("lumberjack")
	while int(floor(achievement_elapsed / 60.0)) > achievement_minute_bucket:
		if achievement_kill_this_minute:
			achievement_emotionless_streak += 1
		else:
			achievement_emotionless_streak = 0
		achievement_minute_bucket += 1
		achievement_kill_this_minute = false
	if achievement_emotionless_streak >= 10:
		Achievements.unlock("emotionless")
	achievement_check_timer += delta
	if achievement_check_timer >= 8.0:
		achievement_check_timer = 0.0
		_check_collector_achievement()

func _check_collector_achievement() -> void:
	var found := PackedByteArray()
	found.resize(94)
	for slot in slots:
		var item_id := int(slot.get("id", 0))
		if item_id > 0 and item_id < found.size() and int(slot.get("n", 0)) > 0:
			found[item_id] = 1
	for slot in armor:
		var item_id := int(slot.get("id", 0))
		if item_id > 0 and item_id < found.size():
			found[item_id] = 1
	for slot in craft_grid:
		var item_id := int(slot.get("id", 0))
		if item_id > 0 and item_id < found.size():
			found[item_id] = 1
	for chest_value in chests.values():
		if chest_value is Array:
			for slot in chest_value:
				if slot is Dictionary:
					var item_id := int(slot.get("id", 0))
					if item_id > 0 and item_id < found.size() and int(slot.get("n", 0)) > 0:
						found[item_id] = 1
	for furnace_value in furnaces.values():
		if furnace_value is Dictionary:
			for slot_name in ["input", "fuel", "output"]:
				var slot: Variant = furnace_value.get(slot_name, {})
				if slot is Dictionary:
					var item_id := int(slot.get("id", 0))
					if item_id > 0 and item_id < found.size() and int(slot.get("n", 0)) > 0:
						found[item_id] = 1
	for item_id in range(1, 94):
		if found[item_id] == 0:
			return
	Achievements.unlock("collector")

# ---------------- ввод ----------------

func _unhandled_input(event: InputEvent) -> void:
	if not ready_done:
		return

	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT and not event.pressed:
		breaking = false
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_RIGHT and not event.pressed:
		blocking = false

	if event is InputEventKey and event.pressed and not event.echo:
		if chat_open:
			if event.keycode == KEY_ESCAPE:
				_close_chat()
			return
		if event.keycode == KEY_T and not paused and not inv_open:
			_open_chat()
			return
		if event.keycode == KEY_ESCAPE:
			if emote_wheel_open:
				_close_emote_wheel()
				return
			if control_mode == CONTROL_MODE_MOBILE and (chest_layer.visible or furnace_layer.visible or inv_open):
				return
			if chest_layer.visible:
				_close_chest()
			elif furnace_layer.visible:
				_close_furnace()
			elif inv_open:
				_close_inventory()
			else:
				_set_paused(not paused)
			return

		if event.physical_keycode == KEY_E and not paused:
			if control_mode == CONTROL_MODE_MOBILE:
				return
			if chest_layer.visible:
				_close_chest()
			elif furnace_layer.visible:
				_close_furnace()
			elif inv_open:
				_close_inventory()
			else:
				_open_inventory(false)
			return

		if event.physical_keycode == KEY_G and not paused and not inv_open:
			_toggle_emote_wheel()
			return

		if event.physical_keycode == KEY_Q and not paused and not inv_open:
			_drop_selected_item()
			return

		if event.physical_keycode == KEY_R and not paused and not inv_open:
			player.position = home_pos
			player.velocity = Vector3.ZERO
			_show_msg("Возврат на точку появления")
			return

		if event.physical_keycode == KEY_K and not paused and not inv_open:
			take_damage(4.0)
			return

		if (event.keycode == KEY_F5 or event.physical_keycode == KEY_V) and not paused and not inv_open:
			view_mode = (view_mode + 1) % 3
			_apply_camera_mode()
			return

	if emote_wheel_open:
		return
	if paused or inv_open:
		return
	# On mobile, the chat panel must not disable the second-finger camera look.
	# Keyboard input remains captured by LineEdit while the chat is open.
	if chat_open and control_mode != CONTROL_MODE_MOBILE:
		return

	if control_mode == CONTROL_MODE_MOBILE:
		if event is InputEventScreenTouch:
			if event.pressed and mobile_look_touch_id == -1:
				mobile_look_touch_id = event.index
				mobile_look_last_pos = event.position
			elif not event.pressed and event.index == mobile_look_touch_id:
				mobile_look_touch_id = -1
		elif event is InputEventScreenDrag and event.index == mobile_look_touch_id:
			var delta_pos : Vector2 = event.position - mobile_look_last_pos
			mobile_look_last_pos = event.position
			player.rotate_y(-delta_pos.x * MOUSE_SENS * 1.4)
			pitch = clamp(pitch - delta_pos.y * MOUSE_SENS * 1.4, -1.5, 1.5)
			aim_pivot.rotation.x = pitch
			_apply_camera_mode()
		elif event is InputEventMouseMotion and Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT) and mobile_look_touch_id == -1:
			player.rotate_y(-event.relative.x * MOUSE_SENS * 1.4)
			pitch = clamp(pitch - event.relative.y * MOUSE_SENS * 1.4, -1.5, 1.5)
			aim_pivot.rotation.x = pitch
			_apply_camera_mode()
		return

	if event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
		player.rotate_y(-event.relative.x * MOUSE_SENS)
		pitch = clamp(pitch - event.relative.y * MOUSE_SENS, -1.5, 1.5)
		aim_pivot.rotation.x = pitch
		_apply_camera_mode()

	elif event is InputEventMouseButton and event.pressed:
		if Input.mouse_mode != Input.MOUSE_MODE_CAPTURED:
			Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
			return
		match event.button_index:
			MOUSE_BUTTON_LEFT:
				if int(slots[selected].get("id", 0)) == BOW:
					_shoot_player_bow()
				else:
					breaking = true
			MOUSE_BUTTON_RIGHT:
				if _eat_selected_food():
					return
				if _can_block():
					blocking = true
				else:
					_use_or_place()
			MOUSE_BUTTON_WHEEL_UP:
				selected = (selected + HOTBAR - 1) % HOTBAR
				_refresh_slots()
			MOUSE_BUTTON_WHEEL_DOWN:
				selected = (selected + 1) % HOTBAR
				_refresh_slots()

	elif event is InputEventKey and event.pressed and not event.echo:
		var k: int = event.physical_keycode - KEY_1
		if k >= 0 and k < HOTBAR:
			selected = k
			_refresh_slots()

func _drop_selected_item() -> void:
	var stack: Dictionary = slots[selected]
	if int(stack["id"]) == 0 or int(stack["n"]) <= 0:
		return
	var item_id: int = int(stack["id"])
	var amount: int = int(stack["n"])
	stack["id"] = 0
	stack["n"] = 0
	_refresh_slots()
	var spawn_pos: Vector3 = player.global_position + -player.global_transform.basis.z * 1.15 + Vector3.UP * 0.7
	if net_connected:
		if net_is_host:
			_server_create_drop(item_id, amount, spawn_pos)
			_net_send_event({"type": "drop_spawn", "drop_id": next_drop_id - 1, "item_id": item_id, "amount": amount, "pos": _net_vec3_to_array(spawn_pos)})
		else:
			_net_send_event({"type": "drop_request", "item_id": item_id, "amount": amount, "pos": _net_vec3_to_array(spawn_pos)})
	else:
		_server_create_drop(item_id, amount, spawn_pos)
	_show_msg("Выброшено: %s × %d" % [_item_name(item_id), amount])


func _server_create_drop(item_id: int, amount: int, pos: Vector3) -> void:
	var drop_id: int = next_drop_id
	next_drop_id += 1
	_create_drop_visual(drop_id, item_id, amount, pos)


func _create_drop_visual(drop_id: int, item_id: int, amount: int, pos: Vector3) -> void:
	if dropped_items.has(drop_id):
		return
	var root := Node3D.new()
	root.name = "DroppedItem_%d" % drop_id
	root.position = pos
	var sprite := Sprite3D.new()
	sprite.texture = _icon_for(item_id)
	sprite.pixel_size = 0.012
	sprite.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	sprite.shaded = false
	root.add_child(sprite)
	var label := Label3D.new()
	label.text = str(amount) if amount > 1 else ""
	label.position.y = -0.18
	label.font_size = 28
	label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	root.add_child(label)
	add_child(root)
	dropped_items[drop_id] = {"node": root, "id": item_id, "amount": amount, "vel": Vector3(0, 1.8, 0), "age": 0.0}


func _remove_drop_local(drop_id: int) -> void:
	net_pickup_pending.erase(drop_id)
	if not dropped_items.has(drop_id): return
	var entry: Dictionary = dropped_items[drop_id]
	var node: Node3D = entry["node"] as Node3D
	if is_instance_valid(node): node.queue_free()
	dropped_items.erase(drop_id)

func _update_dropped_items(delta: float) -> void:
	for key in dropped_items.keys():
		var entry: Dictionary = dropped_items[key]
		var node: Node3D = entry["node"] as Node3D
		if not is_instance_valid(node):
			dropped_items.erase(key)
			continue
		entry["age"] = float(entry["age"]) + delta
		entry["vel"] = Vector3(0, float(entry["vel"].y) - 9.8 * delta, 0)
		var next_pos: Vector3 = node.position + Vector3(0, float(entry["vel"].y) * delta, 0)
		var floor_y: float = float(_height_at(int(floor(node.position.x)), int(floor(node.position.z)))) + 1.12
		if next_pos.y < floor_y:
			next_pos.y = floor_y
			entry["vel"] = Vector3.ZERO
		node.position = next_pos
		node.rotation.y += delta * 1.4
		if node.global_position.distance_to(player.global_position) <= 1.65 and float(entry["age"]) > 0.35:
			if net_connected:
				if net_is_host:
					var item_id: int = int(entry["id"])
					var amount: int = int(entry["amount"])
					var left: int = add_item(item_id, amount)
					if left == 0:
						_remove_drop_local(int(key))
						_net_send_event({"type": "drop_remove", "drop_id": int(key)})
				else:
					if not net_pickup_pending.has(int(key)):
						net_pickup_pending[int(key)] = true
						_net_send_event({"type": "pickup_request", "drop_id": int(key)})
			else:
				var left: int = add_item(int(entry["id"]), int(entry["amount"]))
				if left == 0: _remove_drop_local(int(key))

func _use_spawn_egg(egg_id: int) -> void:
	if net_connected and not net_is_host:
		_show_msg("В сетевой бете мобов и животных призывает хозяин мира.")
		return
	var t: Dictionary = _target()
	var pos: Vector3 = player.global_position + -player.global_transform.basis.z * 2.0
	if not t.is_empty(): pos = Vector3(t["place"]) + Vector3(0.5, 0.1, 0.5)
	if egg_id == SPAWN_EGG_PIG:
		_create_pig(pos)
	else:
		var mob := CharacterBody3D.new()
		if egg_id == SPAWN_EGG_SKELETON:
			mob.set_script(load("res://skeleton.gd"))
		elif egg_id == SPAWN_EGG_SPIDER:
			mob.set_script(load("res://spider.gd"))
		else:
			mob.set_script(load("res://zombie.gd"))
		mob.position = pos
		mob.set("target", player)
		mob.set("world_controller", self)
		mob.add_to_group("darecraft_mob")
		mob.add_to_group("mob_skeleton" if egg_id == SPAWN_EGG_SKELETON else ("mob_spider" if egg_id == SPAWN_EGG_SPIDER else "mob_zombie"))
		add_child(mob)
		zombie_nodes.append(mob)
	var stack: Dictionary = slots[selected]
	stack["n"] = int(stack["n"]) - 1
	if int(stack["n"]) <= 0:
		stack["id"] = 0
		stack["n"] = 0
	_refresh_slots()
	_show_msg("Моб призван")

func _mob_damage_for_selected_item() -> float:
	var held: int = slots[selected]["id"]
	if held == SWORD: return 1.0
	if held == S_SWORD: return 3.0
	if held == I_SWORD: return 4.0
	if held == D_SWORD: return 6.0
	return 1.0

func _shoot_player_bow() -> void:
	if mob_attack_cooldown > 0.0:
		return
	var origin := camera.global_position
	var direction := -camera.global_transform.basis.z.normalized()
	var projectile := Node3D.new()
	projectile.set_script(load("res://arrow_projectile.gd"))
	projectile.set("velocity", direction * 18.0)
	projectile.set("world_controller", self)
	projectile.set("shooter", player)
	projectile.set("damage", 4.0)
	projectile.set("player_fired", true)
	ray.force_raycast_update()
	if ray.is_colliding():
		var hit_node: Node = ray.get_collider() as Node
		while hit_node != null and not hit_node.has_method("receive_hit"):
			hit_node = hit_node.get_parent()
		if hit_node is Node3D:
			projectile.set("target", hit_node)
	get_tree().current_scene.add_child(projectile)
	projectile.global_position = origin + direction * 0.65
	mob_attack_cooldown = 0.45
	swing_phase = 0.08

func _try_attack_mob() -> bool:
	ray.force_raycast_update()
	if not ray.is_colliding():
		return false
	var hit: Object = ray.get_collider()
	var mob: Node = hit as Node
	while mob != null and not mob.has_method("receive_hit"):
		mob = mob.get_parent()
	if mob == null:
		return false
	if mob_attack_cooldown > 0.0:
		return true # Не добываем блок за мобом, пока идёт перезарядка удара.
	var accepted: bool = mob.receive_hit(_mob_damage_for_selected_item())
	if accepted:
		_play_sfx("res://hit.wav")
		mob_attack_cooldown = 0.42
		swing_phase = 0.08
		return true
	# A rushing zombie is intentionally immune; still consume the swing.
	if mob.has_method("is_rushing") and mob.is_rushing():
		mob_attack_cooldown = 0.42
		return true
	return false

func _target() -> Dictionary:
	ray.force_raycast_update()
	if not ray.is_colliding():
		return {}
	var col := ray.get_collider()
	if col != null and col.has_meta("door_cell"):
		var dc: Vector3i = col.get_meta("door_cell")
		return {"cell": dc, "place": dc, "id": DOOR}
	var p := ray.get_collision_point()
	var n := ray.get_collision_normal()
	if col != null and col.has_meta("raft_root"):
		var raft: Node3D = col.get_meta("raft_root") as Node3D
		if raft != null and is_instance_valid(raft):
			var local_normal := raft.global_basis.inverse() * n
			if col.has_meta("raft_block_cell"):
				var raft_cell: Vector3i = col.get_meta("raft_block_cell")
				var offset := Vector3i(roundi(local_normal.x), roundi(local_normal.y), roundi(local_normal.z))
				return {"cell": raft_cell, "place": raft_cell + offset, "id": int(col.get_meta("raft_block_id", 0)), "raft": raft, "raft_cell": raft_cell}
			var local_hit := raft.to_local(p)
			var deck_x := clampi(int(floor(local_hit.x + 2.5)), 0, RAFT_WIDTH - 1)
			var deck_z := clampi(int(floor(local_hit.z + 4.0)), 0, RAFT_LENGTH - 1)
			var deck_cell := Vector3i(deck_x, 0, deck_z)
			return {"cell": deck_cell, "place": Vector3i(deck_x, 1, deck_z), "id": 0, "raft": raft, "raft_cell": deck_cell}
	var cell := Vector3i((p - n * 0.01).floor())
	return {
		"cell": cell,
		"place": Vector3i((p + n * 0.01).floor()),
		"id": get_block(cell.x, cell.y, cell.z),
	}

func _overlaps_player(cell: Vector3i) -> bool:
	var p := player.position
	return p.x + 0.4 > cell.x and p.x - 0.4 < cell.x + 1 \
		and p.z + 0.4 > cell.z and p.z - 0.4 < cell.z + 1 \
		and p.y + 0.9 > cell.y and p.y - 0.9 < cell.y + 1

func _eat_selected_food() -> bool:
	var id: int = int(slots[selected]["id"])
	var heal := 0.0
	if id == ROTTEN_FLESH or id == COOKED_FLESH:
		heal = 2.0
	elif id == COOKED_PORK:
		heal = 8.0
	else:
		return false
	if health >= 20.0:
		_show_msg("Здоровье уже полное")
		return true
	health = minf(20.0, health + heal)
	slots[selected]["n"] -= 1
	if slots[selected]["n"] <= 0:
		slots[selected] = {"id": 0, "n": 0}
	_update_health_label()
	_refresh_slots()
	_show_msg("Восстановлено %.0f HP" % heal)
	return true

func _make_emote_wheel() -> void:
	emote_wheel_layer = CanvasLayer.new()
	emote_wheel_layer.layer = 80
	add_child(emote_wheel_layer)
	var overlay := Control.new()
	overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	overlay.visible = false
	overlay.mouse_filter = Control.MOUSE_FILTER_STOP
	emote_wheel_layer.add_child(overlay)
	var shade := ColorRect.new()
	shade.color = Color(0.015, 0.02, 0.035, 0.78)
	shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	shade.mouse_filter = Control.MOUSE_FILTER_STOP
	shade.gui_input.connect(func(event: InputEvent):
		if event is InputEventMouseButton and event.pressed:
			_close_emote_wheel()
	)
	overlay.add_child(shade)
	var center := PanelContainer.new()
	center.set_anchors_preset(Control.PRESET_CENTER)
	var center_size := 132.0 if get_viewport().get_visible_rect().size.x < 700.0 else 190.0
	center.position = Vector2(-center_size * 0.5, -center_size * 0.5)
	center.size = Vector2(center_size, center_size)
	var center_label := Label.new()
	center_label.text = "КОЛЕСО\nЭМОЦИЙ"
	center_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	center_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	center_label.add_theme_font_size_override("font_size", 17 if get_viewport().get_visible_rect().size.x < 700.0 else 22)
	center.add_child(center_label)
	overlay.add_child(center)
	var viewport_size: Vector2 = get_viewport().get_visible_rect().size
	var compact: bool = viewport_size.x < 700.0
	var button_size := Vector2(88, 54) if compact else Vector2(118, 62)
	var radius := minf(205.0, minf(viewport_size.x, viewport_size.y) * (0.30 if compact else 0.32))
	for i in EMOTE_NAMES.size():
		var angle := -PI / 2.0 + TAU * float(i) / float(EMOTE_NAMES.size())
		var button := Button.new()
		button.text = EMOTE_SYMBOLS[i] + "\n" + EMOTE_NAMES[i]
		button.custom_minimum_size = button_size
		button.add_theme_font_size_override("font_size", 16 if compact else 18)
		button.set_anchors_preset(Control.PRESET_CENTER)
		button.position = Vector2(cos(angle) * radius - button_size.x * 0.5, sin(angle) * radius - button_size.y * 0.5)
		button.pressed.connect(func():
			_trigger_emote(i)
			_close_emote_wheel()
		)
		overlay.add_child(button)

func _toggle_emote_wheel() -> void:
	if view_mode == 0:
		_show_msg("Эмоции доступны от третьего лица")
		return
	if paused or inv_open or emote_wheel_layer == null:
		return
	emote_wheel_open = not emote_wheel_open
	emote_wheel_layer.get_child(0).visible = emote_wheel_open
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE if emote_wheel_open else (Input.MOUSE_MODE_VISIBLE if control_mode == CONTROL_MODE_MOBILE else Input.MOUSE_MODE_CAPTURED)

func _close_emote_wheel() -> void:
	emote_wheel_open = false
	if emote_wheel_layer != null and emote_wheel_layer.get_child_count() > 0:
		emote_wheel_layer.get_child(0).visible = false
	if control_mode != CONTROL_MODE_MOBILE and not paused and not inv_open:
		Input.mouse_mode = Input.MOUSE_MODE_CAPTURED

func _trigger_emote(emote_id: int, broadcast: bool = true) -> void:
	if paused or inv_open or view_mode == 0 or emote_cooldown > 0.0:
		_show_msg("Эмоции доступны от третьего лица")
		return
	emote_id = clampi(emote_id, 0, EMOTE_NAMES.size() - 1)
	emote_cooldown = 1.0
	local_emote_id = emote_id
	local_emote_time = 1.7
	if broadcast and net_connected:
		if net_is_host:
			_net_send_event({"type": "emote", "peer_id": 1, "emote": emote_id})
		else:
			_net_send_event({"type": "emote_request", "emote": emote_id})
	_show_msg(EMOTE_NAMES[emote_id] + "!")

func _play_remote_emote(peer_id: int, emote_id: int) -> void:
	var avatar: Node3D = net_remote_players.get(peer_id) as Node3D
	if avatar == null or not is_instance_valid(avatar):
		return
	avatar.set_meta("remote_emote_id", clampi(emote_id, 0, EMOTE_NAMES.size() - 1))
	avatar.set_meta("remote_emote_time", 1.7)

func _update_remote_avatar_animations(delta: float) -> void:
	for peer_variant in net_remote_players.keys():
		var avatar: Node3D = net_remote_players.get(peer_variant) as Node3D
		if avatar == null or not is_instance_valid(avatar):
			continue
		var target_pos: Vector3 = avatar.get_meta("network_target_position", avatar.global_position)
		var previous := avatar.global_position
		avatar.global_position = avatar.global_position.lerp(target_pos, clampf(delta * 12.0, 0.0, 1.0))
		var target_yaw := float(avatar.get_meta("network_target_yaw", avatar.rotation.y))
		avatar.rotation.y = lerp_angle(avatar.rotation.y, target_yaw, clampf(delta * 10.0, 0.0, 1.0))
		var rig: Dictionary = avatar.get_meta("character_rig", {})
		if rig.is_empty():
			continue
		var moving := avatar.global_position.distance_to(previous) > 0.001
		var phase := float(avatar.get_meta("walk_phase", 0.0))
		if moving:
			phase += delta * 8.5
		avatar.set_meta("walk_phase", phase)
		var emote_id := int(avatar.get_meta("remote_emote_id", -1))
		var emote_time := float(avatar.get_meta("remote_emote_time", 0.0))
		emote_time = maxf(0.0, emote_time - delta)
		avatar.set_meta("remote_emote_time", emote_time)
		if emote_time <= 0.0:
			emote_id = -1
			avatar.set_meta("remote_emote_id", -1)
		_animate_char(rig, sin(phase) * (0.65 if moving else 0.0), 0.0, 0.0, emote_id, emote_time)

func _use_or_place() -> void:
	if riding_raft != null and is_instance_valid(riding_raft):
		player.global_position = riding_raft.to_global(raft_rider_offset + Vector3(3.0, 0.25, 0.0))
		riding_raft = null
		raft_rider_offset = Vector3.ZERO
		_show_msg("Вы сошли с плота")
		return
	if riding_boat != null and is_instance_valid(riding_boat):
		player.global_position = riding_boat.global_position + Vector3(1.35, 0.9, 0.0)
		riding_boat = null
		_show_msg("Вы вышли из лодки")
		return
	var hs: Dictionary = slots[selected]
	var held_id: int = int(hs["id"])
	if held_id == TREASURE_MAP:
		var treasure := _treasure_target()
		_show_msg("Карта сокровищ: X:%d Z:%d. Ищи сундук под землёй!" % [treasure.x, treasure.y])
		return
	if held_id == RAFT:
		var raft_pos := Vector3(player.global_position.x, 14.95, player.global_position.z)
		if not _raft_area_is_water(raft_pos, player.rotation.y):
			_show_msg("Для плота 5×8 нужно глубокое и достаточно широкое место в океане")
			return
		if net_connected and not net_is_host:
			pending_raft_board = true
			_net_send_event({"type": "raft_spawn_request", "pos": _net_vec3_to_array(raft_pos), "yaw": player.rotation.y})
		else:
			var raft := _create_raft(raft_pos, 0, player.rotation.y)
			if net_connected:
				_net_send_event({"type": "raft_spawn", "raft_id": int(raft.get_meta("raft_id", 0)), "pos": _net_vec3_to_array(raft.position), "yaw": raft.rotation.y, "blocks": []})
			_mount_raft(raft)
		var raft_stack: Dictionary = slots[selected]
		raft_stack["n"] = int(raft_stack["n"]) - 1
		if int(raft_stack["n"]) <= 0:
			raft_stack["id"] = 0
			raft_stack["n"] = 0
		_refresh_slots()
		return
	var nearby_raft := _find_nearby_raft()
	if nearby_raft != null:
		_mount_raft(nearby_raft)
		return
	var nearby_boat := _find_nearby_boat()
	if nearby_boat != null:
		riding_boat = nearby_boat
		player.global_position = riding_boat.global_position + Vector3(0.0, 0.85, 0.0)
		_show_msg("Вы сели в лодку")
		return
	if held_id == BOAT:
		var wx: int = int(floor(player.global_position.x))
		var wz: int = int(floor(player.global_position.z))
		if _height_at(wx, wz) >= 15 or player.global_position.y > 17.0:
			_show_msg("Лодку можно поставить только на воду")
			return
		var boat := _create_boat(Vector3(player.global_position.x, 14.85, player.global_position.z) - player.global_transform.basis.z * 1.3)
		var boat_stack: Dictionary = slots[selected]
		boat_stack["n"] = int(boat_stack["n"]) - 1
		if int(boat_stack["n"]) <= 0:
			boat_stack["id"] = 0
			boat_stack["n"] = 0
		_refresh_slots()
		riding_boat = boat
		player.global_position = boat.global_position + Vector3(0.0, 0.85, 0.0)
		_show_msg("Лодка поставлена — вы сели в неё")
		return
	if held_id >= SPAWN_EGG_SKELETON and held_id <= SPAWN_EGG_ZOMBIE:
		_use_spawn_egg(held_id)
		return
	if ARMOR_SLOT_OF.has(int(hs["id"])):
		_equip_from(slots, selected)
		return
	var t := _target()
	if t.is_empty():
		return
	if t.has("raft"):
		var raft_target: Node3D = t["raft"] as Node3D
		var raft_cell: Vector3i = t["place"]
		if not TILES.has(held_id):
			return
		if raft_cell.y < 1 or raft_cell.y > 8 or raft_cell.x < 0 or raft_cell.x >= RAFT_WIDTH or raft_cell.z < 0 or raft_cell.z >= RAFT_LENGTH:
			_show_msg("На плоту можно строить до 8 блоков в высоту")
			return
		if not _add_raft_block_local(raft_target, raft_cell, held_id):
			_show_msg("Это место на плоту уже занято")
			return
		if net_connected:
			if net_is_host:
				_net_send_event({"type": "raft_block_set", "raft_id": int(raft_target.get_meta("raft_id", 0)), "cell": [raft_cell.x, raft_cell.y, raft_cell.z], "id": held_id})
			else:
				_net_send_event({"type": "raft_block_request", "raft_id": int(raft_target.get_meta("raft_id", 0)), "cell": [raft_cell.x, raft_cell.y, raft_cell.z], "id": held_id})
		var raft_item_stack: Dictionary = slots[selected]
		raft_item_stack["n"] = int(raft_item_stack["n"]) - 1
		if int(raft_item_stack["n"]) <= 0:
			raft_item_stack["id"] = 0
			raft_item_stack["n"] = 0
		_refresh_slots()
		return
	if t["id"] == MUSIC_PLAYER:
		var disc_id: int = int(slots[selected]["id"])
		if disc_id >= MUSIC_DISC_1 and disc_id <= MUSIC_DISC_5:
			_play_music_disc(disc_id)
		else:
			disc_audio_player.stop()
			if net_connected:
				if net_is_host:
					_net_send_event({"type": "music_stop"})
				else:
					_net_send_event({"type": "music_stop_request"})
			_show_msg("Музыкальный проигрыватель остановлен")
		return
	if t["id"] == DOOR:
		_toggle_door(t["cell"])
		swing_phase = 0.001
		return
	if t["id"] == TABLE:
		_open_inventory(true)
		return
	if t["id"] == MINECART:
		var cart_cell: Vector3i = t["cell"]
		if get_block(cart_cell.x, cart_cell.y - 1, cart_cell.z) != RAIL:
			_show_msg("Поставь вагонетку на рельсы")
			return
		riding_minecart = true
		minecart_cell = cart_cell
		player.global_position = Vector3(cart_cell.x + 0.5, cart_cell.y + 0.95, cart_cell.z + 0.5)
		player.velocity = Vector3.ZERO
		_show_msg("Вы сели в вагонетку. Присед — выйти")
		return
	if t["id"] == CHEST:
		_open_chest(t["cell"])
		return
	if t["id"] == FURNACE:
		_open_furnace(t["cell"])
		return
	if t["id"] == BED:
		_request_sleep(t["cell"])
		return
	var s: Dictionary = slots[selected]
	var hid: int = s["id"]
	if hid == HOE or hid == S_HOE or hid == I_HOE or hid == D_HOE:
		_use_hoe(t)
		return
	if SEED_CROP.has(hid):
		_plant_seed(t, s)
		return
	if hid == DOOR:
		_place_door(t, s)
		return
	if hid == 0 or not TILES.has(hid):
		return
	var cell: Vector3i = t["place"]
	if held_id == RAIL:
		var support: Vector3i = t["cell"]
		if int(t.get("id", 0)) == 0 or get_block(support.x, support.y, support.z) == 0:
			return
		cell = support + Vector3i(0, 1, 0)
	if cell.y < 1 or cell.y >= WORLD_H or cell.x < 0 or cell.z < 0 or cell.x >= WORLD_SIZE or cell.z >= WORLD_SIZE:
		return
	if get_block(cell.x, cell.y, cell.z) != 0 or _overlaps_player(cell) or _door_occupies(cell):
		return
	if crops.has(cell):
		_remove_crop(cell)
	if hid == BED:
		var second_bed_cell := cell + Vector3i(1, 0, 0)
		if second_bed_cell.x >= WORLD_SIZE or get_block(second_bed_cell.x, second_bed_cell.y, second_bed_cell.z) != 0 or _overlaps_player(second_bed_cell):
			_show_msg("Для кровати нужно два свободных блока рядом")
			return
		_set_block(cell, BED)
		_set_block(second_bed_cell, BED)
	else:
		_set_block(cell, hid)
	swing_phase = 0.001
	s["n"] -= 1
	if s["n"] <= 0:
		s["id"] = 0
		s["n"] = 0
	_refresh_slots()

func _find_nearby_boat() -> Node3D:
	for i in range(boat_nodes.size() - 1, -1, -1):
		var boat: Node3D = boat_nodes[i]
		if not is_instance_valid(boat):
			boat_nodes.remove_at(i)
			continue
		if boat.global_position.distance_to(player.global_position) <= 2.4:
			return boat
	return null

func _create_boat(pos: Vector3) -> Node3D:
	var boat := Node3D.new()
	boat.name = "DareCraftBoat"
	boat.position = pos
	var wood := StandardMaterial3D.new()
	wood.albedo_color = Color(0.43, 0.25, 0.11)
	wood.roughness = 0.88
	var dark_wood := StandardMaterial3D.new()
	dark_wood.albedo_color = Color(0.28, 0.15, 0.07)
	dark_wood.roughness = 0.9
	_add_boat_piece(boat, Vector3(0, 0, 0), Vector3(1.25, 0.28, 1.85), wood)
	_add_boat_piece(boat, Vector3(-0.57, 0.2, 0), Vector3(0.16, 0.42, 1.8), dark_wood)
	_add_boat_piece(boat, Vector3(0.57, 0.2, 0), Vector3(0.16, 0.42, 1.8), dark_wood)
	_add_boat_piece(boat, Vector3(0, 0.2, -0.82), Vector3(1.1, 0.42, 0.16), wood)
	_add_boat_piece(boat, Vector3(0, 0.2, 0.82), Vector3(1.1, 0.42, 0.16), wood)
	add_child(boat)
	boat_nodes.append(boat)
	return boat

func _add_boat_piece(parent: Node3D, local_pos: Vector3, dimensions: Vector3, material: Material) -> void:
	var piece := MeshInstance3D.new()
	var mesh := BoxMesh.new()
	mesh.size = dimensions
	mesh.material = material
	piece.mesh = mesh
	piece.position = local_pos
	parent.add_child(piece)

func _raft_key(cell: Vector3i) -> String:
	return "%d,%d,%d" % [cell.x, cell.y, cell.z]

func _raft_block_rows(raft: Node3D) -> Array:
	var rows: Array = []
	if raft == null or not is_instance_valid(raft):
		return rows
	var block_ids: Dictionary = raft.get_meta("raft_block_ids", {})
	for key in block_ids.keys():
		var parts := str(key).split(",")
		if parts.size() == 3:
			rows.append([int(parts[0]), int(parts[1]), int(parts[2]), int(block_ids[key])])
	return rows

func _serialize_rafts() -> Array:
	var result: Array = []
	for raft in raft_nodes:
		if not is_instance_valid(raft):
			continue
		result.append({
			"id": int(raft.get_meta("raft_id", 0)),
			"pos": [raft.position.x, raft.position.y, raft.position.z],
			"yaw": raft.rotation.y,
			"blocks": _raft_block_rows(raft),
			"npc_ship": bool(raft.get_meta("npc_ship", false)),
			"ship_direction": raft.get_meta("ship_direction", [1.0, 0.0])
		})
	return result

func _restore_saved_rafts(rows: Variant) -> void:
	if not (rows is Array):
		return
	for row in rows:
		if not (row is Dictionary):
			continue
		var pos := _net_array_to_vec3(row.get("pos", []))
		var raft_id := int(row.get("id", 0))
		var raft := _create_raft(pos, raft_id, float(row.get("yaw", 0.0)), row.get("blocks", []))
		if raft != null:
			next_raft_id = maxi(next_raft_id, raft_id + 1)
			if bool(row.get("npc_ship", false)):
				raft.set_meta("npc_ship", true)
				raft.set_meta("ship_direction", row.get("ship_direction", [1.0, 0.0]))
				var ship_rng := RandomNumberGenerator.new()
				ship_rng.seed = raft_id
				_decorate_trader_ship(raft, ship_rng)

func _get_raft_by_id(raft_id: int) -> Node3D:
	for raft in raft_nodes:
		if is_instance_valid(raft) and int(raft.get_meta("raft_id", 0)) == raft_id:
			return raft
	return null

func _raft_area_is_water(pos: Vector3, yaw: float = 0.0) -> bool:
	if pos.x < 5.0 or pos.z < 5.0 or pos.x > WORLD_SIZE - 5.0 or pos.z > WORLD_SIZE - 5.0:
		return false
	var heading := Basis(Vector3.UP, yaw)
	var samples := [
		Vector3(-2.0, 0.0, -3.5), Vector3(2.0, 0.0, -3.5),
		Vector3(-2.0, 0.0, 3.5), Vector3(2.0, 0.0, 3.5),
		Vector3.ZERO, Vector3(-2.0, 0.0, 0.0), Vector3(2.0, 0.0, 0.0),
		Vector3(0.0, 0.0, -3.5), Vector3(0.0, 0.0, 3.5)
	]
	for local_sample in samples:
		var sample: Vector3 = heading * local_sample
		if _height_at(int(floor(pos.x + sample.x)), int(floor(pos.z + sample.z))) >= 15:
			return false
	return true

func _create_raft(pos: Vector3, raft_id: int = 0, yaw: float = 0.0, block_rows: Variant = []) -> Node3D:
	if raft_id > 0:
		var existing := _get_raft_by_id(raft_id)
		if existing != null:
			return existing
	else:
		raft_id = next_raft_id
		next_raft_id += 1
	var raft := Node3D.new()
	raft.name = "DareCraftRaft_%d" % raft_id
	raft.position = Vector3(pos.x, 14.95, pos.z)
	raft.rotation.y = yaw
	raft.set_meta("raft_id", raft_id)
	raft.set_meta("raft_block_ids", {})
	raft.set_meta("raft_block_nodes", {})
	var wood := StandardMaterial3D.new()
	wood.albedo_color = Color(0.48, 0.30, 0.15, 1.0)
	wood.roughness = 0.92
	var trim := StandardMaterial3D.new()
	trim.albedo_color = Color(0.27, 0.16, 0.08, 1.0)
	trim.roughness = 0.95
	# 40 отдельных досок создают видимую решётку 5×8, но имеют общую физическую платформу.
	for z in range(RAFT_LENGTH):
		var plank := MeshInstance3D.new()
		var plank_mesh := BoxMesh.new()
		plank_mesh.size = Vector3(4.94, 0.18, 0.96)
		plank_mesh.material = wood
		plank.mesh = plank_mesh
		plank.position = Vector3(0.0, 0.0, float(z) - 3.5)
		raft.add_child(plank)
	# Нижние поперечины укрепляют настил и хорошо видны сбоку.
	for x in [-2.0, 0.0, 2.0]:
		var beam := MeshInstance3D.new()
		var beam_mesh := BoxMesh.new()
		beam_mesh.size = Vector3(0.22, 0.22, 7.8)
		beam_mesh.material = trim
		beam.mesh = beam_mesh
		beam.position = Vector3(x, -0.17, 0.0)
		raft.add_child(beam)
	# Единая коллизия позволяет ходить по всей площади и ставить на неё блоки.
	var deck_body := StaticBody3D.new()
	deck_body.name = "RaftDeckCollision"
	var deck_collision := CollisionShape3D.new()
	var deck_shape := BoxShape3D.new()
	deck_shape.size = Vector3(4.98, 0.20, 7.98)
	deck_collision.shape = deck_shape
	deck_body.add_child(deck_collision)
	deck_body.set_meta("raft_root", raft)
	raft.add_child(deck_body)
	add_child(raft)
	raft_nodes.append(raft)
	if block_rows is Array:
		for row in block_rows:
			if row is Array and row.size() >= 4:
				_add_raft_block_local(raft, Vector3i(int(row[0]), int(row[1]), int(row[2])), int(row[3]))
	return raft

func _add_raft_block_local(raft: Node3D, cell: Vector3i, block_id: int) -> bool:
	if raft == null or not is_instance_valid(raft) or not TILES.has(block_id):
		return false
	if cell.x < 0 or cell.x >= RAFT_WIDTH or cell.z < 0 or cell.z >= RAFT_LENGTH or cell.y < 1 or cell.y > 8:
		return false
	var key := _raft_key(cell)
	var block_ids: Dictionary = raft.get_meta("raft_block_ids", {})
	if block_ids.has(key):
		return false
	var root := Node3D.new()
	root.name = "RaftBlock_%s" % key
	root.position = Vector3(float(cell.x) - 2.0, float(cell.y) - 0.4, float(cell.z) - 3.5)
	var body := StaticBody3D.new()
	var mesh_instance := MeshInstance3D.new()
	var box := BoxMesh.new()
	box.size = Vector3(0.98, 0.98, 0.98)
	var material := StandardMaterial3D.new()
	var tile := int(ICON_TILE.get(block_id, TILES.get(block_id, [3, 3, 3])[0]))
	var tile_texture := AtlasTexture.new()
	tile_texture.atlas = atlas_tex
	tile_texture.region = Rect2(float(tile * 16), 0.0, 16.0, 16.0)
	if block_id == SNOW:
		material.albedo_color = Color(0.91, 0.96, 1.0, 1.0)
	else:
		material.albedo_texture = tile_texture
		material.texture_filter = BaseMaterial3D.TEXTURE_FILTER_NEAREST
	material.roughness = 0.95
	box.material = material
	mesh_instance.mesh = box
	body.add_child(mesh_instance)
	var collision := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = Vector3(0.98, 0.98, 0.98)
	collision.shape = shape
	body.add_child(collision)
	body.set_meta("raft_root", raft)
	body.set_meta("raft_block_cell", cell)
	body.set_meta("raft_block_id", block_id)
	root.add_child(body)
	raft.add_child(root)
	var block_nodes: Dictionary = raft.get_meta("raft_block_nodes", {})
	block_nodes[key] = root
	block_ids[key] = block_id
	raft.set_meta("raft_block_nodes", block_nodes)
	raft.set_meta("raft_block_ids", block_ids)
	return true

func _remove_raft_block_local(raft: Node3D, cell: Vector3i) -> int:
	if raft == null or not is_instance_valid(raft):
		return 0
	var key := _raft_key(cell)
	var block_ids: Dictionary = raft.get_meta("raft_block_ids", {})
	if not block_ids.has(key):
		return 0
	var block_id := int(block_ids[key])
	var block_nodes: Dictionary = raft.get_meta("raft_block_nodes", {})
	var block_node: Node3D = block_nodes.get(key) as Node3D
	if is_instance_valid(block_node):
		block_node.queue_free()
	block_ids.erase(key)
	block_nodes.erase(key)
	raft.set_meta("raft_block_ids", block_ids)
	raft.set_meta("raft_block_nodes", block_nodes)
	return block_id

func _find_nearby_raft() -> Node3D:
	for i in range(raft_nodes.size() - 1, -1, -1):
		var raft: Node3D = raft_nodes[i]
		if not is_instance_valid(raft):
			raft_nodes.remove_at(i)
			continue
		var local_pos := raft.to_local(player.global_position)
		if absf(local_pos.x) <= 2.8 and absf(local_pos.z) <= 4.3 and absf(local_pos.y) <= 2.5:
			return raft
	return null

func _mount_raft(raft: Node3D) -> void:
	if raft == null or not is_instance_valid(raft):
		return
	riding_raft = raft
	var seat_index := maxi(0, (net_peer_id if net_connected else 1) - 1)
	var col := seat_index % 3
	var row := int(floor(float(seat_index) / 3.0))
	raft_rider_offset = Vector3(-1.55 + float(col) * 1.55, 0.96, -2.25 + float(row) * 2.25)
	player.global_position = raft.to_global(raft_rider_offset)
	player.velocity = Vector3.ZERO
	_show_msg("Вы на плоту 5×8. Можно строить прямо на настиле!")

# ---------------- щит и урон ----------------

func _can_block() -> bool:
	if armor[4]["id"] == 0:
		return false
	var hid: int = slots[selected]["id"]
	if hid != 0 and (TILES.has(hid) or hid == DOOR or hid == HOE or hid == S_HOE or hid == I_HOE or hid == D_HOE or SEED_CROP.has(hid) or ARMOR_SLOT_OF.has(hid)):
		return false
	var t := _target()
	if not t.is_empty() and (t["id"] == DOOR or t["id"] == TABLE or t["id"] == CHEST or t["id"] == FURNACE):
		return false
	return true

func _armor_points() -> int:
	var pts := 0
	for k in 5:
		var id: int = armor[k]["id"]
		if id == 0:
			continue
		var tier := _armor_tier(id)
		if tier == 3:
			pts += int(ARMOR_POINTS_DIAMOND[k])
		elif tier == 2:
			pts += int(ARMOR_POINTS_IRON[k])
		elif tier == 1:
			pts += int(ARMOR_POINTS_STONE[k])
		else:
			pts += int(ARMOR_POINTS[k])
	return pts

func take_damage(amount: float) -> bool:
	if is_dead or creative_mode or spawn_protection > 0.0:
		return false
	if blocking and armor[4]["id"] != 0:
		_show_msg("Урон заблокирован щитом!")
		return false
	_play_sfx("res://damage_uf.wav")
	if damage_flash != null:
		damage_flash_timer = 0.42
		damage_flash.color.a = 0.22
	var dmg := amount * (1.0 - minf(0.8, _armor_points() * 0.04))
	health = maxf(0.0, health - dmg)
	_show_msg("Урон: %.1f" % dmg)
	if health <= 0.0:
		health = 0.0
		_show_death_screen()
	_update_health_label()
	return true

func _play_music_disc(disc_id: int) -> void:
	if disc_audio_player == null:
		return
	if net_connected and not net_apply_remote_music:
		if net_is_host:
			_net_send_event({"type": "music_play", "disc_id": disc_id})
		else:
			_net_send_event({"type": "music_play_request", "disc_id": disc_id})
	var melodies: Array = [
		[523.25, 659.25, 783.99, 659.25, 587.33, 698.46, 880.0, 698.46],
		[392.0, 493.88, 587.33, 659.25, 587.33, 493.88, 440.0, 392.0],
		[220.0, 261.63, 311.13, 293.66, 196.0, 233.08, 277.18, 261.63],
		[440.0, 554.37, 659.25, 880.0, 783.99, 659.25, 554.37, 493.88],
		[659.25, 587.33, 783.99, 880.0, 987.77, 880.0, 783.99, 659.25]
	]
	var melody: Array = melodies[clampi(disc_id - MUSIC_DISC_1, 0, 4)]
	var rate: int = 22050
	var note_seconds: float = 0.42
	var samples := PackedByteArray()
	var sample_count: int = int(rate * note_seconds * melody.size())
	samples.resize(sample_count * 2)
	var offset := 0
	for note_index in melody.size():
		var freq: float = float(melody[note_index])
		for i in int(rate * note_seconds):
			var t: float = float(i) / float(rate)
			var fade: float = minf(1.0, t * 18.0) * minf(1.0, (note_seconds - t) * 12.0)
			var sample_value: int = int(sin(TAU * freq * t) * 6500.0 * fade)
			samples.encode_s16(offset, sample_value)
			offset += 2
	var stream := AudioStreamWAV.new()
	stream.format = AudioStreamWAV.FORMAT_16_BITS
	stream.mix_rate = rate
	stream.stereo = false
	stream.data = samples
	stream.loop_mode = AudioStreamWAV.LOOP_FORWARD
	stream.loop_begin = 0
	stream.loop_end = sample_count
	disc_audio_player.stop()
	disc_audio_player.stream = stream
	disc_audio_player.volume_db = linear_to_db(maxf(0.01, Music.music_volume))
	disc_audio_player.play()
	_show_msg("Играет: " + _item_name(disc_id))

func _play_sfx(path: String) -> void:
	if sfx_player == null or Music.sfx_volume <= 0.001:
		return
	var stream := load(path) as AudioStream
	if stream == null:
		return
	sfx_player.stream = stream
	sfx_player.volume_db = linear_to_db(Music.sfx_volume)
	sfx_player.play()

func _show_msg(text: String) -> void:
	if msg_label == null:
		return
	msg_label.text = Localization.translate_text(text)
	msg_t = 1.6

func _update_health_label() -> void:
	if health_label == null:
		return
	var full_hearts := int(ceil(health / 2.0))
	var hearts := "♥".repeat(full_hearts) + "♡".repeat(10 - full_hearts)
	health_label.text = hearts + "   🛡 %d" % _armor_points()

# ---------------- инвентарь и крафт ----------------

func _open_inventory(table: bool) -> void:
	if chat_open:
		_close_chat()
	inv_open = true
	breaking = false
	blocking = false
	table_mode = table
	if mobile_hud != null:
		mobile_hud.visible = false
	inv_layer.visible = true
	close_x.set_mobile(control_mode == CONTROL_MODE_MOBILE)
	inv_title.text = ("Верстак" if table else ("Инвентарь — Креатив" if creative_mode else "Инвентарь")) + ("" if control_mode == CONTROL_MODE_MOBILE else "   (E / Esc: закрыть)")
	if creative_grid != null:
		creative_grid.visible = creative_mode and not table
	craft_title.text = "Крафт 3×3" if table else "Крафт 2×2"
	grid_small.visible = not table
	grid_big.visible = table
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	_refresh_all()

func _close_inventory() -> void:
	inv_open = false
	creative_scroll_direction = 0
	inv_layer.visible = false
	rmb_down = false
	rmb_visited.clear()
	_cancel_split_selection(true)
	last_inv_click_slot = -1
	last_inv_click_stack = {"id": 0, "n": 0}
	for i in 9:
		var s: Dictionary = craft_grid[i]
		if s["id"] != 0:
			add_item(s["id"], s["n"])
			craft_grid[i] = {"id": 0, "n": 0}
	if cursor_item["id"] != 0:
		add_item(cursor_item["id"], cursor_item["n"])
		cursor_item = {"id": 0, "n": 0}
	_refresh_all()
	_apply_control_mode()

func _click_slot(arr: Array, i: int) -> void:
	var s: Dictionary = arr[i]
	var c: Dictionary = cursor_item
	if c["id"] == 0:
		if s["id"] != 0:
			cursor_item = s.duplicate()
			arr[i] = {"id": 0, "n": 0}
	elif s["id"] == 0:
		arr[i] = c.duplicate()
		cursor_item = {"id": 0, "n": 0}
	elif s["id"] == c["id"]:
		var moved: int = mini(MAX_STACK - int(s["n"]), int(c["n"]))
		s["n"] += moved
		c["n"] -= moved
		if c["n"] <= 0:
			cursor_item = {"id": 0, "n": 0}
	else:
		arr[i] = c.duplicate()
		cursor_item = s.duplicate()
	_refresh_all()

func _on_slot_pressed(i: int) -> void:
	# Второй клик двойного нажатия нужен только для открытия действия «Разделить».
	if suppress_next_slot_click:
		suppress_next_slot_click = false
		return
	if split_mode:
		_split_one_to_slot(i)
		return
	if split_button != null and split_button.visible:
		_cancel_split_selection(true)
	_click_slot(slots, i)

func _on_craft_slot(i: int) -> void:
	_click_slot(craft_grid, i)

func _on_armor_slot(k: int) -> void:
	var s: Dictionary = armor[k]
	var c: Dictionary = cursor_item
	if c["id"] == 0:
		if s["id"] != 0:
			cursor_item = s.duplicate()
			armor[k] = {"id": 0, "n": 0}
	elif int(ARMOR_SLOT_OF.get(int(c["id"]), -1)) == k:
		if s["id"] == 0:
			armor[k] = {"id": c["id"], "n": 1}
			c["n"] -= 1
			if c["n"] <= 0:
				cursor_item = {"id": 0, "n": 0}
		elif int(c["n"]) == 1:
			var old: Dictionary = s.duplicate()
			armor[k] = {"id": c["id"], "n": 1}
			cursor_item = old
	_refresh_all()

func _place_one(arr: Array, i: int) -> void:
	var c: Dictionary = cursor_item
	if c["id"] == 0:
		return
	var s: Dictionary = arr[i]
	if s["id"] == 0:
		arr[i] = {"id": c["id"], "n": 1}
	elif s["id"] == c["id"] and int(s["n"]) < MAX_STACK:
		s["n"] += 1
	else:
		return
	c["n"] -= 1
	if c["n"] <= 0:
		cursor_item = {"id": 0, "n": 0}
	_refresh_all()

func _rmb_try(kind: String, i: int) -> void:
	var key := kind + str(i)
	if rmb_visited.has(key):
		return
	rmb_visited[key] = true
	var arr: Array = slots
	if kind == "c":
		arr = craft_grid
	elif kind == "k":
		arr = _get_chest_inventory(chest_ui_cell, chest_is_double)
	_place_one(arr, i)

func _slot_gui_input(event: InputEvent, kind: String, i: int) -> void:
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT and event.pressed:
		if kind == "s" and inv_open and not split_mode:
			if _track_inventory_double_click(i, event.double_click):
				suppress_next_slot_click = true
				_open_split_action(i)
				return
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_RIGHT and event.pressed:
		if cursor_item["id"] == 0 and kind == "s":
			if _equip_from(slots, i):
				return
		rmb_down = true
		rmb_visited.clear()
		_rmb_try(kind, i)

func _track_inventory_double_click(slot_index: int, native_double_click: bool) -> bool:
	var now := Time.get_ticks_msec()
	var same_slot := last_inv_click_slot == slot_index
	var within_time := same_slot and now - last_inv_click_time_msec <= 420
	var is_double := same_slot and (native_double_click or within_time)
	if is_double:
		var current: Dictionary = slots[slot_index]
		var previous_id := int(last_inv_click_stack.get("id", 0))
		var previous_count := int(last_inv_click_stack.get("n", 0))
		var restored_from_cursor := false
		if current["id"] == 0 and previous_id != 0 \
				and int(cursor_item["id"]) == previous_id \
				and int(cursor_item["n"]) == previous_count:
			slots[slot_index] = cursor_item.duplicate()
			cursor_item = {"id": 0, "n": 0}
			restored_from_cursor = true
		var restored: Dictionary = slots[slot_index]
		var valid_stack := int(restored["id"]) != 0 and int(restored["n"]) > 1
		last_inv_click_slot = -1
		last_inv_click_stack = {"id": 0, "n": 0}
		if valid_stack and (restored_from_cursor or cursor_item["id"] == 0):
			_refresh_all()
			return true
		return false
	last_inv_click_slot = slot_index
	last_inv_click_time_msec = now
	var stack: Dictionary = slots[slot_index]
	last_inv_click_stack = stack.duplicate() if cursor_item["id"] == 0 and int(stack["id"]) != 0 and int(stack["n"]) > 1 else {"id": 0, "n": 0}
	return false

func _open_split_action(slot_index: int) -> void:
	if split_button == null:
		return
	split_source_slot = slot_index
	split_mode = false
	split_button.text = "Разделить 1 предмет"
	split_button.disabled = false
	split_button.visible = true
	_refresh_all()

func _on_split_button_pressed() -> void:
	if split_button == null:
		return
	if split_mode:
		_cancel_split_selection(true)
		return
	if split_source_slot < 0 or split_source_slot >= TOTAL_SLOTS:
		_cancel_split_selection(true)
		return
	var source: Dictionary = slots[split_source_slot]
	if int(source["id"]) == 0 or int(source["n"]) < 2:
		_cancel_split_selection(true)
		return
	split_mode = true
	split_button.text = "Выберите слот… (Отмена)"

func _split_one_to_slot(target_index: int) -> void:
	if split_source_slot < 0 or split_source_slot >= TOTAL_SLOTS:
		_cancel_split_selection(true)
		return
	if target_index == split_source_slot:
		return
	var source: Dictionary = slots[split_source_slot]
	var target: Dictionary = slots[target_index]
	var item_id := int(source["id"])
	if item_id == 0 or int(source["n"]) < 2:
		_cancel_split_selection(true)
		_refresh_all()
		return
	if int(target["id"]) == 0:
		slots[target_index] = {"id": item_id, "n": 1}
	elif int(target["id"]) == item_id and int(target["n"]) < MAX_STACK:
		target["n"] = int(target["n"]) + 1
	else:
		split_button.text = "Слот занят — выберите другой"
		return
	source["n"] = int(source["n"]) - 1
	if int(source["n"]) <= 0:
		slots[split_source_slot] = {"id": 0, "n": 0}
	_cancel_split_selection(true)
	_refresh_all()

func _cancel_split_selection(hide_button: bool) -> void:
	split_mode = false
	split_source_slot = -1
	if split_button != null:
		split_button.text = "Разделить 1 предмет"
		if hide_button:
			split_button.visible = false

func _rmb_check(ui: Dictionary, kind: String, i: int, mp: Vector2) -> void:
	var b: Button = ui["btn"]
	if b.is_visible_in_tree() and b.get_global_rect().has_point(mp):
		_rmb_try(kind, i)

func _rmb_drag() -> void:
	if not rmb_down:
		return
	if not Input.is_mouse_button_pressed(MOUSE_BUTTON_RIGHT):
		rmb_down = false
		rmb_visited.clear()
		return
	var mp := get_viewport().get_mouse_position()
	if furnace_layer.visible:
		for i in range(HOTBAR, TOTAL_SLOTS):
			_rmb_check(furnace_inv_ui[i - HOTBAR], "s", i, mp)
		for i in HOTBAR:
			_rmb_check(furnace_hot_ui[i], "s", i, mp)
	elif chest_layer.visible:
		var n := 54 if chest_is_double else 27
		for i in n:
			_rmb_check(chest_slots_ui[i], "k", i, mp)
		for i in range(HOTBAR, TOTAL_SLOTS):
			_rmb_check(chest_inv_ui[i - HOTBAR], "s", i, mp)
		for i in HOTBAR:
			_rmb_check(chest_hot_ui[i], "s", i, mp)
	else:
		for j in 4:
			_rmb_check(craft_small_ui[j], "c", SMALL_MAP[j], mp)
		for i in 9:
			_rmb_check(craft_big_ui[i], "c", i, mp)
		for i in TOTAL_SLOTS:
			_rmb_check(inv_ui[i], "s", i, mp)

func _match_recipe() -> Dictionary:
	var size := 3 if table_mode else 2
	var minr := 99
	var maxr := -1
	var minc := 99
	var maxc := -1
	for r in size:
		for c in size:
			if craft_grid[r * 3 + c]["id"] != 0:
				minr = mini(minr, r)
				maxr = maxi(maxr, r)
				minc = mini(minc, c)
				maxc = maxi(maxc, c)
	if maxr < 0:
		return {}
	var h := maxr - minr + 1
	var w := maxc - minc + 1
	for rec in RECIPES:
		if rec["table"] and not table_mode:
			continue
		var p: Array = rec["pattern"]
		var row0: Array = p[0]
		if p.size() != h or row0.size() != w:
			continue
		var ok := true
		for r in h:
			var prow: Array = p[r]
			for c in w:
				var have: int = craft_grid[(minr + r) * 3 + minc + c]["id"]
				if int(prow[c]) != have:
					ok = false
		if ok:
			return rec
	return {}

func _update_craft_output() -> void:
	craft_recipe = _match_recipe()
	if craft_recipe.is_empty():
		_show_item(craft_out_ui, {"id": 0, "n": 0})
	else:
		var out: Array = craft_recipe["out"]
		_show_item(craft_out_ui, {"id": out[0], "n": out[1]})

func _take_output() -> void:
	if craft_recipe.is_empty():
		return
	var out: Array = craft_recipe["out"]
	var oid: int = out[0]
	var on: int = out[1]
	if cursor_item["id"] == 0:
		cursor_item = {"id": oid, "n": on}
	elif cursor_item["id"] == oid and int(cursor_item["n"]) + on <= MAX_STACK:
		cursor_item["n"] += on
	else:
		return
	for i in 9:
		var s: Dictionary = craft_grid[i]
		if s["id"] != 0:
			s["n"] -= 1
			if s["n"] <= 0:
				craft_grid[i] = {"id": 0, "n": 0}
	_refresh_all()

func _make_special_pixel_icon(id: int) -> Texture2D:
	var image := Image.create(16, 16, false, Image.FORMAT_RGBA8)
	image.fill(Color(0, 0, 0, 0))
	if id == RAW_PORK or id == COOKED_PORK:
		var meat := Color(0.78, 0.30, 0.27, 1.0) if id == RAW_PORK else Color(0.66, 0.34, 0.16, 1.0)
		var edge := Color(0.34, 0.16, 0.12, 1.0)
		for y in range(4, 12):
			for x in range(3, 13):
				if (x + y) % 7 != 0:
					image.set_pixel(x, y, meat)
		for x in range(5, 11):
			image.set_pixel(x, 3, edge)
			image.set_pixel(x, 12, edge)
		image.set_pixel(2, 7, edge)
		image.set_pixel(13, 8, edge)
		if id == COOKED_PORK:
			for x in range(5, 9): image.set_pixel(x, 6, Color(0.92, 0.65, 0.30, 1))
	elif id >= SPAWN_EGG_SKELETON and id <= SPAWN_EGG_ZOMBIE:
		var egg_color: Color = [Color(0.88,0.86,0.78), Color(0.96,0.62,0.67), Color(0.20,0.20,0.22), Color(0.28,0.72,0.25)][id - SPAWN_EGG_SKELETON]
		for y in range(2, 14):
			for x in range(3, 13):
				if pow((float(x)-7.5)/5.0, 2) + pow((float(y)-8.0)/6.0, 2) <= 1.0:
					image.set_pixel(x, y, egg_color)
		image.set_pixel(6, 5, Color(1,1,1,1))
		image.set_pixel(7, 5, Color(1,1,1,1))
	elif id >= MUSIC_DISC_1 and id <= MUSIC_DISC_5:
		var disc_colors: Array[Color] = [Color(0.85, 0.25, 0.22), Color(0.22, 0.72, 0.34), Color(0.42, 0.42, 0.86), Color(0.18, 0.68, 0.82), Color(0.82, 0.68, 0.22)]
		var dc: Color = disc_colors[id - MUSIC_DISC_1]
		for x in range(2, 14):
			for y in range(2, 14):
				if Vector2(x - 7.5, y - 7.5).length() <= 5.5:
					image.set_pixel(x, y, dc)
		for x in range(6, 10):
			for y in range(6, 10): image.set_pixel(x, y, Color(0.12, 0.12, 0.14, 1))
	elif id == ROTTEN_FLESH:
		var flesh_dark := Color(0.18, 0.25, 0.12, 1.0)
		var flesh_mid := Color(0.43, 0.49, 0.20, 1.0)
		var flesh_light := Color(0.68, 0.62, 0.31, 1.0)
		for y in range(3, 13):
			for x in range(3, 13):
				var edge := x == 3 or x == 12 or y == 3 or y == 12
				image.set_pixel(x, y, flesh_dark if edge else flesh_mid)
		for p in [Vector2i(5, 5), Vector2i(6, 5), Vector2i(9, 8), Vector2i(8, 10), Vector2i(4, 9)]:
			image.set_pixel(p.x, p.y, flesh_light)
		for p in [Vector2i(7, 7), Vector2i(10, 5), Vector2i(5, 11)]:
			image.set_pixel(p.x, p.y, flesh_dark)
	elif id == RAFT:
		var raft_wood := Color(0.56, 0.36, 0.18, 1)
		var raft_edge := Color(0.25, 0.15, 0.08, 1)
		for y in range(4, 12):
			for x in range(3, 13):
				image.set_pixel(x, y, raft_wood)
		for x in [2, 13]:
			for y in range(4, 12): image.set_pixel(x, y, raft_edge)
		for y in [3, 12]:
			for x in range(3, 13): image.set_pixel(x, y, raft_edge)
	elif id == SNOW:
		for y in range(3, 13):
			for x in range(3, 13): image.set_pixel(x, y, Color(0.90, 0.96, 1.0, 1.0))
	elif id == BOAT:
		var hull := Color(0.48, 0.29, 0.13, 1)
		var edge := Color(0.25, 0.14, 0.07, 1)
		for x in range(2, 14):
			image.set_pixel(x, 6, edge)
			image.set_pixel(x, 11, edge)
		for x in range(3, 13):
			for y in range(7, 11):
				if x >= 4 and x <= 11:
					image.set_pixel(x, y, hull)
		image.set_pixel(2, 7, hull)
		image.set_pixel(13, 7, hull)
	elif id == GLASS:
		for x in range(2, 14):
			image.set_pixel(x, 2, Color(0.55, 0.86, 0.98, 0.72))
			image.set_pixel(x, 13, Color(0.35, 0.68, 0.84, 0.48))
		for y in range(2, 14):
			image.set_pixel(2, y, Color(0.55, 0.86, 0.98, 0.72))
			image.set_pixel(13, y, Color(0.35, 0.68, 0.84, 0.48))
		for x in range(4, 8):
			image.set_pixel(x, 4, Color(0.85, 0.96, 1.0, 0.78))
	elif id == MUSIC_PLAYER:
		for x in range(3, 13):
			for y in range(5, 13):
				image.set_pixel(x, y, Color(0.48, 0.29, 0.14, 1))
		for x in range(4, 12):
			image.set_pixel(x, 4, Color(0.16, 0.17, 0.20, 1))
		for x in range(6, 10):
			image.set_pixel(x, 7, Color(0.72, 0.74, 0.78, 1))
	elif id == BONE:
		var bone_shadow := Color(0.30, 0.31, 0.33, 1.0)
		var bone_light := Color(0.94, 0.91, 0.78, 1.0)
		for i in range(3, 13):
			var px := i
			var py := 14 - i
			for ox in range(-1, 2):
				for oy in range(-1, 2):
					var xx := px + ox
					var yy := py + oy
					if xx >= 0 and xx < 16 and yy >= 0 and yy < 16:
						image.set_pixel(xx, yy, bone_shadow)
			image.set_pixel(px, py, bone_light)
		for center in [Vector2i(4, 12), Vector2i(12, 4)]:
			for ox in range(-2, 2):
				for oy in range(-2, 2):
					if abs(ox) + abs(oy) <= 3:
						image.set_pixel(center.x + ox, center.y + oy, bone_light)
	elif id == BOW:
		var bow_dark := Color(0.20, 0.10, 0.045, 1.0)
		var bow_wood := Color(0.65, 0.38, 0.16, 1.0)
		var bow_glint := Color(0.88, 0.62, 0.30, 1.0)
		var bow_path: Array[Vector2i] = [Vector2i(5, 2), Vector2i(8, 4), Vector2i(9, 7), Vector2i(9, 9), Vector2i(8, 12), Vector2i(5, 14)]
		for p in bow_path:
			for ox in range(-1, 2):
				for oy in range(-1, 2):
					var xx := p.x + ox
					var yy := p.y + oy
					if xx >= 0 and xx < 16 and yy >= 0 and yy < 16:
						image.set_pixel(xx, yy, bow_dark)
			image.set_pixel(p.x - 1, p.y, bow_wood)
			image.set_pixel(p.x, p.y, bow_glint)
		for y in range(3, 14):
			image.set_pixel(10, y, Color(0.88, 0.84, 0.72, 1.0))
		image.set_pixel(10, 2, Color(0.55, 0.55, 0.52, 1.0))
		image.set_pixel(10, 14, Color(0.55, 0.55, 0.52, 1.0))
	elif id == COBWEB:
		var web_color := Color(0.88, 0.91, 0.94, 1.0)
		var web_shadow := Color(0.40, 0.47, 0.55, 1.0)
		# Radial strands.
		for p in [Vector2i(1, 1), Vector2i(14, 1), Vector2i(1, 14), Vector2i(14, 14), Vector2i(8, 0), Vector2i(8, 15), Vector2i(0, 8), Vector2i(15, 8)]:
			var steps := 10
			for i in range(steps + 1):
				var t := float(i) / float(steps)
				var xx := clampi(roundi(lerpf(float(p.x), 7.5, t)), 0, 15)
				var yy := clampi(roundi(lerpf(float(p.y), 7.5, t)), 0, 15)
				image.set_pixel(xx, yy, web_color)
		# Broken concentric diamond rings make it read as a web, not a grid.
		for r in [3, 5, 7]:
			for side in range(4):
				for i in range(r + 1):
					var x0: int = 8 + i if side == 0 else (8 + r if side == 1 else (8 - i if side == 2 else 8 - r))
					var y0: int = 8 - r if side == 0 else (8 + i if side == 1 else (8 + r if side == 2 else 8 - i))
					if x0 >= 0 and x0 < 16 and y0 >= 0 and y0 < 16 and (i % 3 != 1):
						image.set_pixel(x0, y0, web_color)
		image.set_pixel(8, 8, web_shadow)
	elif id == RAIL:
		for x in range(2, 14):
			image.set_pixel(x, 5 + int(x / 4) % 2, Color(0.48, 0.29, 0.13, 1))
			image.set_pixel(x, 11 - int(x / 4) % 2, Color(0.48, 0.29, 0.13, 1))
		for y in range(3, 13):
			image.set_pixel(4, y, Color(0.72, 0.76, 0.82, 1))
			image.set_pixel(11, y, Color(0.72, 0.76, 0.82, 1))
	else:
		for x in range(3, 13):
			image.set_pixel(x, 5, Color(0.55, 0.59, 0.64, 1))
			image.set_pixel(x, 10, Color(0.55, 0.59, 0.64, 1))
		for y in range(5, 11):
			image.set_pixel(3, y, Color(0.55, 0.59, 0.64, 1))
			image.set_pixel(12, y, Color(0.55, 0.59, 0.64, 1))
		for x in [4, 11]:
			image.set_pixel(x, 12, Color(0.16, 0.17, 0.19, 1))
	return ImageTexture.create_from_image(image)

func _icon_for(id: int) -> Texture2D:
	if not icon_cache.has(id):
		if id == GLASS or id == RAIL or id == MINECART or id == MUSIC_PLAYER or id == BONE or id == BOW or id == COBWEB or (id >= SPAWN_EGG_SKELETON and id <= SPAWN_EGG_ZOMBIE) or id == RAW_PORK or id == COOKED_PORK or (id >= MUSIC_DISC_1 and id <= MUSIC_DISC_5) or id == BOAT or id == RAFT or id == SNOW or id == ROTTEN_FLESH:
			icon_cache[id] = _make_special_pixel_icon(id)
			return icon_cache[id]
		var t := AtlasTexture.new()
		if ITEM_ICON.has(id):
			t.atlas = items_tex
			t.region = Rect2(float(int(ITEM_ICON[id]) * 16), 0.0, 16.0, 16.0)
		elif ITEM2_ICON.has(id):
			t.atlas = items2_tex
			t.region = Rect2(float(int(ITEM2_ICON[id]) * 16), 0.0, 16.0, 16.0)
		elif ICON_TILE.has(id):
			t.atlas = atlas_tex
			var tile_index: int = int(ICON_TILE[id])
			t.region = Rect2(float(tile_index * 16), 0.0, 16.0, 16.0)
		else:
			var missing := Image.create(16, 16, false, Image.FORMAT_RGBA8)
			for yy in range(16):
				for xx in range(16):
					missing.set_pixel(xx, yy, Color(0.95, 0.05, 0.72, 1.0) if (((xx >> 2) + (yy >> 2)) % 2) == 0 else Color(0.05, 0.05, 0.05, 1.0))
			icon_cache[id] = ImageTexture.create_from_image(missing)
			return icon_cache[id]
		icon_cache[id] = t
	return icon_cache[id]

func _show_item(ui: Dictionary, s: Dictionary) -> void:
	var icon: TextureRect = ui["icon"]
	var cnt: Label = ui["count"]
	if s["id"] == 0:
		icon.texture = null
		cnt.text = ""
	else:
		icon.texture = _icon_for(s["id"])
		cnt.text = str(s["n"]) if s["n"] > 1 else ""

func _armor_tier(id: int) -> int:
	if id >= D_HELMET and id <= D_SHIELD:
		return 3
	if id >= I_HELMET and id <= I_BOOTS:
		return 2
	if id >= S_HELMET and id <= S_SHIELD:
		return 1
	return 0

func _refresh_slots() -> void:
	if hot_ui.is_empty() or inv_ui.is_empty() or cursor_ui.is_empty() or craft_out_ui.is_empty() or armor_ui.is_empty():
		return
	for i in TOTAL_SLOTS:
		_show_item(inv_ui[i], slots[i])
	for j in 4:
		_show_item(craft_small_ui[j], craft_grid[SMALL_MAP[j]])
	for i in 9:
		_show_item(craft_big_ui[i], craft_grid[i])
	for k in 5:
		var aui: Dictionary = armor_ui[k]
		_show_item(aui, armor[k])
		var aicon: TextureRect = aui["icon"]
		if armor[k]["id"] == 0:
			aicon.texture = _icon_for(ARMOR_SLOT_IDS[k])
			aicon.modulate = Color(1, 1, 1, 0.22)
		else:
			aicon.modulate = Color(1, 1, 1, 1)
	armor_label.text = "Броня: %d" % _armor_points()
	_update_health_label()
	_update_char_gear()
	_update_craft_output()
	for i in HOTBAR:
		var ui: Dictionary = hot_ui[i]
		_show_item(ui, slots[i])
		ui["btn"].add_theme_stylebox_override("normal", _slot_style(i == selected))
	_show_item(cursor_ui, cursor_item)
	cursor_ui["btn"].visible = inv_open and cursor_item["id"] != 0
	var sid: int = slots[selected]["id"]
	if sid != held_id and hand_item != null:
		held_id = sid
		_rebuild_held(sid)
		if held_name_label != null:
			held_name_label.text = _item_name(sid) if sid != 0 else "Пустая рука"
			held_name_label.visible = sid != 0
			held_name_timer = 2.0

func _refresh_all() -> void:
	_refresh_slots()
	if chest_layer != null and chest_layer.visible:
		_refresh_chest_ui()
	if furnace_layer != null and furnace_layer.visible:
		_refresh_furnace_ui()

# ---------------- интерфейс ----------------

func _slot_style(sel: bool, light: bool = false) -> StyleBoxFlat:
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.3, 0.3, 0.36, 0.95) if light else Color(0.2, 0.2, 0.24, 0.9)
	sb.set_border_width_all(3)
	sb.border_color = Color(1, 0.85, 0.2) if sel else Color(0.45, 0.45, 0.5)
	sb.set_corner_radius_all(4)
	return sb

func _make_slot(size: float, clickable: bool) -> Dictionary:
	var b := Button.new()
	b.custom_minimum_size = Vector2(size, size)
	b.focus_mode = Control.FOCUS_NONE
	if not clickable:
		b.mouse_filter = Control.MOUSE_FILTER_IGNORE
	b.add_theme_stylebox_override("normal", _slot_style(false))
	b.add_theme_stylebox_override("hover", _slot_style(false, true))
	b.add_theme_stylebox_override("pressed", _slot_style(false, true))

	var icon := TextureRect.new()
	icon.mouse_filter = Control.MOUSE_FILTER_IGNORE
	icon.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	icon.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	icon.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	b.add_child(icon)
	icon.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	icon.offset_left = 8
	icon.offset_top = 8
	icon.offset_right = -8
	icon.offset_bottom = -8

	var cnt := Label.new()
	cnt.mouse_filter = Control.MOUSE_FILTER_IGNORE
	cnt.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	cnt.vertical_alignment = VERTICAL_ALIGNMENT_BOTTOM
	cnt.add_theme_font_size_override("font_size", 18)
	cnt.add_theme_color_override("font_outline_color", Color.BLACK)
	cnt.add_theme_constant_override("outline_size", 6)
	b.add_child(cnt)
	cnt.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	cnt.offset_right = -5
	cnt.offset_bottom = -2
	return {"btn": b, "icon": icon, "count": cnt}

func _on_hotbar_mobile_select(i: int) -> void:
	if control_mode != CONTROL_MODE_MOBILE or paused or inv_open:
		return
	selected = i
	_refresh_slots()

func _make_achievement_notice_ui() -> void:
	achievement_toast_layer = CanvasLayer.new()
	achievement_toast_layer.layer = 20
	add_child(achievement_toast_layer)
	achievement_toast = PanelContainer.new()
	achievement_toast.visible = false
	achievement_toast.mouse_filter = Control.MOUSE_FILTER_IGNORE
	achievement_toast.set_anchors_preset(Control.PRESET_TOP_RIGHT)
	achievement_toast.offset_left = -390.0
	achievement_toast.offset_top = 22.0
	achievement_toast.offset_right = -22.0
	achievement_toast.offset_bottom = 112.0
	var toast_style := StyleBoxFlat.new()
	toast_style.bg_color = Color(0.035, 0.045, 0.065, 0.96)
	toast_style.border_color = Color(0.95, 0.78, 0.25, 0.98)
	toast_style.set_border_width_all(2)
	toast_style.set_corner_radius_all(10)
	toast_style.set_content_margin_all(10)
	achievement_toast.add_theme_stylebox_override("panel", toast_style)
	achievement_toast_layer.add_child(achievement_toast)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 12)
	achievement_toast.add_child(row)
	achievement_toast_icon = Label.new()
	achievement_toast_icon.text = "🏆"
	achievement_toast_icon.add_theme_font_size_override("font_size", 34)
	achievement_toast_icon.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	row.add_child(achievement_toast_icon)
	var text_column := VBoxContainer.new()
	text_column.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(text_column)
	achievement_toast_label = Label.new()
	achievement_toast_label.add_theme_font_size_override("font_size", 12)
	achievement_toast_label.add_theme_color_override("font_color", Color(0.78, 0.82, 0.90))
	text_column.add_child(achievement_toast_label)
	achievement_toast_title = Label.new()
	achievement_toast_title.add_theme_font_size_override("font_size", 19)
	achievement_toast_title.add_theme_color_override("font_color", Color(1.0, 0.91, 0.58))
	text_column.add_child(achievement_toast_title)
	achievement_toast_description = Label.new()
	achievement_toast_description.add_theme_font_size_override("font_size", 13)
	achievement_toast_description.add_theme_color_override("font_color", Color(0.88, 0.90, 0.94))
	achievement_toast_description.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	text_column.add_child(achievement_toast_description)

func _make_hud() -> void:
	var layer := CanvasLayer.new()
	hud_layer = layer
	layer.visible = false
	add_child(layer)
	var cross := Label.new()
	cross.text = "+"
	cross.mouse_filter = Control.MOUSE_FILTER_IGNORE
	cross.add_theme_font_size_override("font_size", 32)
	cross.set_anchors_preset(Control.PRESET_CENTER)
	layer.add_child(cross)

	var root := VBoxContainer.new()
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	layer.add_child(root)
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var spacer := Control.new()
	spacer.size_flags_vertical = Control.SIZE_EXPAND_FILL
	spacer.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(spacer)
	msg_label = Label.new()
	msg_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	msg_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	msg_label.add_theme_font_size_override("font_size", 22)
	msg_label.add_theme_color_override("font_outline_color", Color.BLACK)
	msg_label.add_theme_constant_override("outline_size", 6)
	root.add_child(msg_label)
	var cc := CenterContainer.new()
	cc.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(cc)
	var quickbar_panel := PanelContainer.new()
	quickbar_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var quickbar_style := StyleBoxFlat.new()
	quickbar_style.bg_color = Color(0.035, 0.045, 0.065, 0.78)
	quickbar_style.set_border_width_all(2)
	quickbar_style.border_color = Color(0.72, 0.78, 0.9, 0.48)
	quickbar_style.set_corner_radius_all(9)
	quickbar_style.set_content_margin_all(6)
	quickbar_panel.add_theme_stylebox_override("panel", quickbar_style)
	quickbar_container = quickbar_panel
	cc.add_child(quickbar_panel)
	var hb := HBoxContainer.new()
	hb.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hb.add_theme_constant_override("separation", 4)
	quickbar_panel.add_child(hb)
	var quick_slot_size := clampf((get_viewport().get_visible_rect().size.x - 128.0) / float(HOTBAR), 20.0, 56.0)
	for i in HOTBAR:
		var s := _make_slot(quick_slot_size, true)
		s["btn"].pressed.connect(_on_hotbar_mobile_select.bind(i))
		hb.add_child(s["btn"])
		hot_ui.append(s)
	var gap := Control.new()
	gap.custom_minimum_size = Vector2(0, 14)
	gap.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(gap)
	health_label = Label.new()
	health_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	health_label.position = Vector2(16, 10)
	health_label.add_theme_font_size_override("font_size", 23)
	health_label.add_theme_color_override("font_outline_color", Color.BLACK)
	health_label.add_theme_constant_override("outline_size", 6)
	layer.add_child(health_label)
	net_status_label = Label.new()
	net_status_label.position = Vector2(16, 108)
	net_status_label.size = Vector2(500, 54)
	net_status_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	net_status_label.add_theme_font_size_override("font_size", 17)
	net_status_label.add_theme_color_override("font_color", Color(0.72, 0.95, 1.0))
	net_status_label.add_theme_color_override("font_outline_color", Color.BLACK)
	net_status_label.add_theme_constant_override("outline_size", 5)
	net_status_label.visible = false
	layer.add_child(net_status_label)
	breath_label = Label.new()
	breath_label.position = Vector2(16, 72)
	breath_label.add_theme_font_size_override("font_size", 20)
	breath_label.add_theme_color_override("font_outline_color", Color.BLACK)
	breath_label.add_theme_constant_override("outline_size", 5)
	breath_label.visible = false
	layer.add_child(breath_label)
	damage_flash = ColorRect.new()
	damage_flash.color = Color(0.9, 0.03, 0.02, 0.0)
	damage_flash.mouse_filter = Control.MOUSE_FILTER_IGNORE
	damage_flash.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	damage_flash.z_index = 20
	layer.add_child(damage_flash)
	death_layer = CanvasLayer.new()
	death_layer.layer = 30
	death_layer.visible = false
	add_child(death_layer)
	var shade := ColorRect.new()
	shade.color = Color(0.035, 0.015, 0.02, 0.88)
	shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	death_layer.add_child(shade)
	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	death_layer.add_child(center)
	death_panel = PanelContainer.new()
	death_panel.custom_minimum_size = Vector2(320, 210)
	center.add_child(death_panel)
	var death_box := VBoxContainer.new()
	death_box.add_theme_constant_override("separation", 18)
	death_box.alignment = BoxContainer.ALIGNMENT_CENTER
	death_panel.add_child(death_box)
	var death_title := Label.new()
	death_title.text = "ВЫ УМЕРЛИ"
	death_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	death_title.add_theme_font_size_override("font_size", 34)
	death_title.add_theme_color_override("font_color", Color(0.95, 0.16, 0.13))
	death_box.add_child(death_title)
	var death_subtitle := Label.new()
	death_subtitle.text = "Ваше приключение не окончено"
	death_subtitle.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	death_box.add_child(death_subtitle)
	death_respawn_button = Button.new()
	death_respawn_button.text = "Возродиться"
	death_respawn_button.custom_minimum_size = Vector2(220, 48)
	death_respawn_button.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	death_respawn_button.pressed.connect(_respawn_after_death)
	death_box.add_child(death_respawn_button)

func _show_death_screen() -> void:
	if is_dead:
		return
	# The loss achievement is for dying just after creating a NEW world,
	# not for loading an old save and dying within its first ten seconds.
	if not world_loaded and achievement_elapsed <= 10.0:
		Achievements.unlock("magnus_loses")
	# Pacifist means surviving the full 15 minutes, so a death resets the run.
	achievement_pacifist_timer = 0.0
	is_dead = true
	paused = true
	breaking = false
	blocking = false
	_reset_mobile_inputs()
	if mobile_hud != null:
		mobile_hud.visible = false
	if pause_layer != null:
		pause_layer.visible = false
	if death_layer != null:
		death_layer.visible = true
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	_save_world()

func _respawn_after_death() -> void:
	health = 20.0
	fall_tracking = false
	fall_start_y = 0.0
	if is_instance_valid(player):
		player.position = home_pos
		player.velocity = Vector3.ZERO
	is_dead = false
	paused = false
	if death_layer != null:
		death_layer.visible = false
	_update_health_label()
	_save_world()
	_apply_control_mode()
	_show_msg("Вы возродились!")

func _make_mobile_btn(text: String, size: Vector2) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = size
	b.focus_mode = Control.FOCUS_NONE
	b.add_theme_font_size_override("font_size", 14 if size.x < 70.0 else 18)
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.15, 0.15, 0.18, 0.65)
	sb.set_border_width_all(2)
	sb.border_color = Color(1, 1, 1, 0.45)
	sb.set_corner_radius_all(10)
	b.add_theme_stylebox_override("normal", sb)
	var sbp := sb.duplicate() as StyleBoxFlat
	sbp.bg_color = Color(0.35, 0.55, 0.85, 0.8)
	b.add_theme_stylebox_override("pressed", sbp)
	return b

func _make_mobile_hud() -> void:
	if hud_layer == null:
		return
	mobile_hud = Control.new()
	mobile_hud.name = "MobileHUD"
	mobile_hud.mouse_filter = Control.MOUSE_FILTER_IGNORE
	mobile_hud.visible = false
	hud_layer.add_child(mobile_hud)
	mobile_hud.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	# Bedrock-style bottom bar: permanent hotbar with View and Inventory beside it.
	var bottom_center := CenterContainer.new()
	bottom_center.name = "MobileHotbarRow"
	bottom_center.mouse_filter = Control.MOUSE_FILTER_IGNORE
	bottom_center.set_anchors_preset(Control.PRESET_BOTTOM_WIDE)
	bottom_center.offset_top = -78
	bottom_center.offset_bottom = -8
	mobile_hud.add_child(bottom_center)
	var bottom_row := HBoxContainer.new()
	bottom_row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	bottom_row.add_theme_constant_override("separation", 4)
	bottom_center.add_child(bottom_row)
	if quickbar_container != null and quickbar_container.get_parent() != null:
		quickbar_container.get_parent().remove_child(quickbar_container)
		bottom_row.add_child(quickbar_container)
	var bottom_button_size := Vector2(42, 46) if get_viewport().get_visible_rect().size.x < 430.0 else Vector2(58, 50)
	var btn_bottom_inventory := _make_mobile_btn("Инв", bottom_button_size)
	btn_bottom_inventory.pressed.connect(func():
		if not paused:
			if inv_open:
				_close_inventory()
			else:
				_open_inventory(false)
	)
	bottom_row.add_child(btn_bottom_inventory)

	var top_bar := VBoxContainer.new()
	top_bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
	top_bar.add_theme_constant_override("separation", 5)
	top_bar.set_anchors_preset(Control.PRESET_TOP_RIGHT)
	top_bar.offset_top = 14
	top_bar.offset_right = -12
	top_bar.offset_left = -300
	top_bar.offset_bottom = 116
	mobile_hud.add_child(top_bar)
	var primary_row := HBoxContainer.new()
	primary_row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	primary_row.add_theme_constant_override("separation", 5)
	top_bar.add_child(primary_row)
	var secondary_row := HBoxContainer.new()
	secondary_row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	secondary_row.add_theme_constant_override("separation", 5)
	top_bar.add_child(secondary_row)

	var compact_hud: bool = get_viewport().get_visible_rect().size.x < 700.0
	var small_button := Vector2(66, 46) if compact_hud else Vector2(78, 48)
	var btn_top_view := _make_mobile_btn("Вид", small_button)
	btn_top_view.pressed.connect(func():
		if not paused and not inv_open:
			view_mode = (view_mode + 1) % 3
			_apply_camera_mode()
	)
	primary_row.add_child(btn_top_view)
	var btn_emote := _make_mobile_btn("Эмоции", small_button)
	btn_emote.pressed.connect(func():
		if not paused and not inv_open:
			_toggle_emote_wheel()
	)
	primary_row.add_child(btn_emote)

	var btn_pause := _make_mobile_btn("Пауза", small_button)
	btn_pause.pressed.connect(func():
		if not paused:
			_set_paused(true)
	)
	secondary_row.add_child(btn_pause)
	var btn_spawn := _make_mobile_btn("Спавн", small_button)
	btn_spawn.pressed.connect(func():
		if not paused and player != null:
			player.position = home_pos
			player.velocity = Vector3.ZERO
			_show_msg("Возврат на точку появления")
	)
	secondary_row.add_child(btn_spawn)

	var left_col := VBoxContainer.new()
	left_col.mouse_filter = Control.MOUSE_FILTER_IGNORE
	left_col.add_theme_constant_override("separation", 8)
	left_col.set_anchors_preset(Control.PRESET_BOTTOM_LEFT)
	left_col.offset_left = 24
	left_col.offset_bottom = -24
	left_col.offset_top = -256
	left_col.offset_right = 216
	mobile_hud.add_child(left_col)

	var btn_sprint := _make_mobile_btn("Бег", Vector2(186, 44))
	btn_sprint.button_down.connect(func(): mobile_sprint_held = true)
	btn_sprint.button_up.connect(func(): mobile_sprint_held = false)
	left_col.add_child(btn_sprint)

	var dpad := GridContainer.new()
	dpad.name = "DPadControls"
	dpad.mouse_filter = Control.MOUSE_FILTER_IGNORE
	dpad.columns = 3
	dpad.add_theme_constant_override("h_separation", 6)
	dpad.add_theme_constant_override("v_separation", 6)
	left_col.add_child(dpad)

	var empty1 := Control.new(); empty1.mouse_filter = Control.MOUSE_FILTER_IGNORE; dpad.add_child(empty1)
	var btn_w := _make_mobile_btn("W", Vector2(58, 58))
	btn_w.button_down.connect(_on_mobile_dir.bind("up", true))
	btn_w.button_up.connect(_on_mobile_dir.bind("up", false))
	dpad.add_child(btn_w)
	var empty2 := Control.new(); empty2.mouse_filter = Control.MOUSE_FILTER_IGNORE; dpad.add_child(empty2)

	var btn_a := _make_mobile_btn("A", Vector2(58, 58))
	btn_a.button_down.connect(_on_mobile_dir.bind("left", true))
	btn_a.button_up.connect(_on_mobile_dir.bind("left", false))
	dpad.add_child(btn_a)
	var btn_s := _make_mobile_btn("S", Vector2(58, 58))
	btn_s.button_down.connect(_on_mobile_dir.bind("down", true))
	btn_s.button_up.connect(_on_mobile_dir.bind("down", false))
	dpad.add_child(btn_s)
	var btn_d := _make_mobile_btn("D", Vector2(58, 58))
	btn_d.button_down.connect(_on_mobile_dir.bind("right", true))
	btn_d.button_up.connect(_on_mobile_dir.bind("right", false))
	dpad.add_child(btn_d)

	var virtual_stick := Control.new()
	virtual_stick.name = "VirtualStick"
	virtual_stick.custom_minimum_size = Vector2(170, 170)
	virtual_stick.set_anchors_preset(Control.PRESET_BOTTOM_LEFT)
	virtual_stick.offset_left = 28
	virtual_stick.offset_bottom = -24
	virtual_stick.offset_top = -194
	virtual_stick.offset_right = 198
	virtual_stick.visible = mobile_control_style == 1
	mobile_hud.add_child(virtual_stick)
	var stick_base := ColorRect.new()
	stick_base.color = Color(0.1, 0.1, 0.12, 0.45)
	stick_base.size = Vector2(150, 150)
	stick_base.position = Vector2(10, 10)
	stick_base.mouse_filter = Control.MOUSE_FILTER_STOP
	virtual_stick.add_child(stick_base)	
	stick_base.gui_input.connect(_on_virtual_stick_input)
	var stick_knob := ColorRect.new()
	stick_knob.color = Color(0.75, 0.8, 0.9, 0.75)
	stick_knob.size = Vector2(58, 58)
	stick_knob.position = Vector2(56, 56)
	stick_knob.mouse_filter = Control.MOUSE_FILTER_IGNORE
	stick_base.add_child(stick_knob)
	mobile_stick_base = stick_base
	mobile_stick_knob = stick_knob
	mobile_dpad = dpad
	mobile_virtual_stick = virtual_stick
	virtual_stick.visible = mobile_control_style == 1
	dpad.visible = mobile_control_style == 0

	var actions := VBoxContainer.new()
	actions.mouse_filter = Control.MOUSE_FILTER_IGNORE
	actions.add_theme_constant_override("separation", 8)
	actions.set_anchors_preset(Control.PRESET_BOTTOM_RIGHT)
	actions.offset_right = -24
	actions.offset_bottom = -24
	actions.offset_left = -194
	# Keep the full six-button stack above Android's bottom navigation area.
	actions.offset_top = -382
	mobile_hud.add_child(actions)

	var btn_crouch := _make_mobile_btn("Присед", Vector2(160, 52))
	btn_crouch.button_down.connect(func(): mobile_crouch_held = true)
	btn_crouch.button_up.connect(func(): mobile_crouch_held = false)
	actions.add_child(btn_crouch)

	var btn_jump := _make_mobile_btn("Прыжок", Vector2(160, 52))
	btn_jump.button_down.connect(func(): mobile_jump_held = true)
	btn_jump.button_up.connect(func(): mobile_jump_held = false)
	actions.add_child(btn_jump)

	var btn_break := _make_mobile_btn("Ломать", Vector2(160, 52))
	btn_break.button_down.connect(func():
		mobile_break_held = true
		breaking = true
	)
	btn_break.button_up.connect(func():
		mobile_break_held = false
		breaking = false
	)
	actions.add_child(btn_break)

	var btn_drop := _make_mobile_btn("Выбросить", Vector2(160, 46))
	btn_drop.pressed.connect(func():
		if not paused and not inv_open: _drop_selected_item()
	)
	actions.add_child(btn_drop)

	var btn_place := _make_mobile_btn("Поставить", Vector2(160, 52))
	btn_place.pressed.connect(func():
		if not paused and not inv_open:
			if _eat_selected_food(): return
			if _can_block():
				blocking = not blocking
			else:
				_use_or_place()
	)
	actions.add_child(btn_place)

func _on_virtual_stick_input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		if event.pressed:
			mobile_stick_touch = event.index
			_update_virtual_stick(event.position)
		else:
			mobile_stick_touch = -1
			mobile_stick_vector = Vector2.ZERO
			if mobile_stick_knob != null: mobile_stick_knob.position = Vector2(56, 56)
	elif event is InputEventScreenDrag and event.index == mobile_stick_touch:
		_update_virtual_stick(event.position)

func _update_virtual_stick(screen_pos: Vector2) -> void:
	if mobile_stick_base == null: return
	var local := screen_pos
	var center := Vector2(75, 75)
	var v := local - center
	if v.length() > 48.0: v = v.normalized() * 48.0
	mobile_stick_vector = Vector2(v.x / 48.0, v.y / 48.0)
	if mobile_stick_knob != null: mobile_stick_knob.position = center + v - Vector2(29, 29)

func _on_mobile_dir(dir_key: String, pressed: bool) -> void:
	mobile_move_flags[dir_key] = pressed
	var x := float(int(mobile_move_flags["right"]) - int(mobile_move_flags["left"]))
	var y := float(int(mobile_move_flags["down"]) - int(mobile_move_flags["up"]))
	mobile_move_vec = Vector2(x, y)

func _make_inventory_ui() -> void:
	inv_layer = CanvasLayer.new()
	inv_layer.layer = 5
	inv_layer.visible = false
	add_child(inv_layer)

	var dim := ColorRect.new()
	dim.color = Color(0, 0, 0, 0.6)
	inv_layer.add_child(dim)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	var center := CenterContainer.new()
	inv_layer.add_child(center)
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	var panel := PanelContainer.new()
	center.add_child(panel)
	var margin := MarginContainer.new()
	for side in ["left", "right", "top", "bottom"]:
		margin.add_theme_constant_override("margin_" + side, 14)
	panel.add_child(margin)
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 6)
	margin.add_child(box)

	var header := HBoxContainer.new()
	box.add_child(header)
	inv_title = Label.new()
	inv_title.add_theme_font_size_override("font_size", 26)
	header.add_child(inv_title)
	close_x.attach_to_header(header, _close_inventory)

	var top_row := HBoxContainer.new()
	top_row.add_theme_constant_override("separation", 14)
	box.add_child(top_row)

	var acol := VBoxContainer.new()
	acol.add_theme_constant_override("separation", 3)
	top_row.add_child(acol)
	for k in 5:
		var s := _make_slot(46, true)
		s["btn"].tooltip_text = ARMOR_NAMES[k]
		s["btn"].pressed.connect(_on_armor_slot.bind(k))
		acol.add_child(s["btn"])
		armor_ui.append(s)

	var pv := SubViewportContainer.new()
	pv.stretch = true
	pv.custom_minimum_size = Vector2(170, 240)
	pv.mouse_filter = Control.MOUSE_FILTER_IGNORE
	top_row.add_child(pv)
	var vp := SubViewport.new()
	vp.own_world_3d = true
	vp.size = Vector2i(170, 240)
	vp.render_target_update_mode = SubViewport.UPDATE_WHEN_VISIBLE
	pv.add_child(vp)
	var env := Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.background_color = Color(0.09, 0.09, 0.12)
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(1, 1, 1)
	env.ambient_light_energy = 0.7
	var we := WorldEnvironment.new()
	we.environment = env
	vp.add_child(we)
	var light := DirectionalLight3D.new()
	light.rotation_degrees = Vector3(-30, 20, 0)
	vp.add_child(light)
	var pcam := Camera3D.new()
	pcam.position = Vector3(0, 0.95, 3.4)
	pcam.fov = 35.0
	vp.add_child(pcam)
	pcam.current = true
	preview_char = _build_character()
	var prv: Node3D = preview_char["root"]
	prv.rotation.y = PI
	vp.add_child(prv)
	chars.append(preview_char)

	var right := VBoxContainer.new()
	right.add_theme_constant_override("separation", 6)
	top_row.add_child(right)

	craft_title = Label.new()
	craft_title.add_theme_font_size_override("font_size", 20)
	right.add_child(craft_title)

	var craft_box := HBoxContainer.new()
	craft_box.add_theme_constant_override("separation", 12)
	right.add_child(craft_box)

	grid_small = GridContainer.new()
	grid_small.columns = 2
	grid_small.add_theme_constant_override("h_separation", 4)
	grid_small.add_theme_constant_override("v_separation", 4)
	craft_box.add_child(grid_small)
	for j in 4:
		var idx: int = SMALL_MAP[j]
		var s := _make_slot(46, true)
		s["btn"].pressed.connect(_on_craft_slot.bind(idx))
		s["btn"].gui_input.connect(_slot_gui_input.bind("c", idx))
		grid_small.add_child(s["btn"])
		craft_small_ui.append(s)

	grid_big = GridContainer.new()
	grid_big.columns = 3
	grid_big.add_theme_constant_override("h_separation", 4)
	grid_big.add_theme_constant_override("v_separation", 4)
	grid_big.visible = false
	craft_box.add_child(grid_big)
	for i in 9:
		var s := _make_slot(46, true)
		s["btn"].pressed.connect(_on_craft_slot.bind(i))
		s["btn"].gui_input.connect(_slot_gui_input.bind("c", i))
		grid_big.add_child(s["btn"])
		craft_big_ui.append(s)

	var arrow := Label.new()
	arrow.text = "→"
	arrow.add_theme_font_size_override("font_size", 36)
	craft_box.add_child(arrow)

	craft_out_ui = _make_slot(56, true)
	craft_out_ui["btn"].pressed.connect(_take_output)
	craft_box.add_child(craft_out_ui["btn"])

	armor_label = Label.new()
	armor_label.add_theme_font_size_override("font_size", 20)
	right.add_child(armor_label)

	var bl := Label.new()
	bl.text = "Рюкзак"
	bl.add_theme_font_size_override("font_size", 18)
	box.add_child(bl)

	inv_ui.resize(TOTAL_SLOTS)
	var grid := GridContainer.new()
	grid.columns = 5
	grid.add_theme_constant_override("h_separation", 6)
	grid.add_theme_constant_override("v_separation", 6)
	box.add_child(grid)
	for i in range(HOTBAR, TOTAL_SLOTS):
		var s := _make_slot(46, true)
		s["btn"].pressed.connect(_on_slot_pressed.bind(i))
		s["btn"].gui_input.connect(_slot_gui_input.bind("s", i))
		grid.add_child(s["btn"])
		inv_ui[i] = s

	var hl := Label.new()
	hl.text = "Быстрые слоты"
	hl.add_theme_font_size_override("font_size", 18)
	box.add_child(hl)

	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 6)
	box.add_child(row)
	for i in HOTBAR:
		var s := _make_slot(46, true)
		s["btn"].pressed.connect(_on_slot_pressed.bind(i))
		s["btn"].gui_input.connect(_slot_gui_input.bind("s", i))
		row.add_child(s["btn"])
		inv_ui[i] = s

	split_button = Button.new()
	split_button.text = "Разделить 1 предмет"
	split_button.custom_minimum_size = Vector2(210, 42)
	split_button.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	split_button.focus_mode = Control.FOCUS_NONE
	split_button.add_theme_font_size_override("font_size", 18)
	split_button.visible = false
	split_button.pressed.connect(_on_split_button_pressed)
	box.add_child(split_button)

	var creative_title := Label.new()
	creative_title.text = "Креатив: каталог предметов (бесконечно)"
	creative_title.add_theme_font_size_override("font_size", 18)
	box.add_child(creative_title)
	var creative_catalog_row := HBoxContainer.new()
	creative_catalog_row.add_theme_constant_override("separation", 6)
	box.add_child(creative_catalog_row)
	creative_scroll = ScrollContainer.new()
	creative_scroll.custom_minimum_size = Vector2(0, 190)
	creative_scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	creative_scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	creative_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	creative_catalog_row.add_child(creative_scroll)
	creative_grid = GridContainer.new()
	creative_grid.columns = 6
	creative_grid.add_theme_constant_override("h_separation", 4)
	creative_grid.add_theme_constant_override("v_separation", 4)
	creative_scroll.add_child(creative_grid)
	var creative_arrows := VBoxContainer.new()
	creative_arrows.add_theme_constant_override("separation", 8)
	creative_catalog_row.add_child(creative_arrows)
	var creative_up_button := Button.new()
	creative_up_button.text = "▲"
	creative_up_button.custom_minimum_size = Vector2(48, 64)
	creative_up_button.focus_mode = Control.FOCUS_NONE
	creative_up_button.button_down.connect(_set_creative_scroll_direction.bind(-1))
	creative_up_button.button_up.connect(_set_creative_scroll_direction.bind(0))	
	creative_arrows.add_child(creative_up_button)
	var creative_down_button := Button.new()
	creative_down_button.text = "▼"
	creative_down_button.custom_minimum_size = Vector2(48, 64)
	creative_down_button.focus_mode = Control.FOCUS_NONE
	creative_down_button.button_down.connect(_set_creative_scroll_direction.bind(1))
	creative_down_button.button_up.connect(_set_creative_scroll_direction.bind(0))
	creative_arrows.add_child(creative_down_button)
	for item_id in range(1, 94):
		var item_btn := Button.new()
		item_btn.custom_minimum_size = Vector2(58, 54)
		item_btn.tooltip_text = _item_name(item_id)
		var icon_rect := TextureRect.new()
		icon_rect.texture = _icon_for(item_id)
		icon_rect.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		icon_rect.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		icon_rect.custom_minimum_size = Vector2(28, 28)
		item_btn.add_child(icon_rect)
		item_btn.pressed.connect(_creative_give_item.bind(item_id))
		creative_grid.add_child(item_btn)
	creative_title.visible = creative_mode
	creative_grid.visible = creative_mode

func _make_cursor_ui() -> void:
	var layer := CanvasLayer.new()
	layer.layer = 20
	add_child(layer)
	cursor_ui = _make_slot(48, false)
	cursor_ui["btn"].add_theme_stylebox_override("normal", StyleBoxEmpty.new())
	cursor_ui["btn"].visible = false
	layer.add_child(cursor_ui["btn"])

# ---------------- загрузка мира: камера летает над миром ----------------

func _make_loading_cam() -> void:
	load_cam = Camera3D.new()
	add_child(load_cam)
	load_cam.current = true
	_update_load_cam(0.0)

func _update_load_cam(delta: float) -> void:
	load_t += delta
	var c := Vector3(WORLD_SIZE / 2.0, 0.0, WORLD_SIZE / 2.0)
	var a := load_t * 0.16
	var r := 46.0 + sin(load_t * 0.3) * 14.0
	var pos := c + Vector3(cos(a) * r, 44.0 + sin(load_t * 0.5) * 6.0, sin(a) * r)
	load_cam.position = pos
	load_cam.look_at(pos + Vector3(-sin(a), -0.35, cos(a)) * 10.0)

func _make_loading_ui() -> void:
	loading_layer = CanvasLayer.new()
	loading_layer.layer = 100
	add_child(loading_layer)

	var shade := ColorRect.new()
	shade.color = Color(0, 0, 0, 0.18)
	shade.mouse_filter = Control.MOUSE_FILTER_IGNORE
	loading_layer.add_child(shade)
	shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 8)
	loading_layer.add_child(vb)
	vb.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	var top := Control.new()
	top.custom_minimum_size = Vector2(0, 24)
	vb.add_child(top)

	var logo := TextureRect.new()
	logo.texture = load("res://darecraft_logo_clean.svg")
	logo.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	logo.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	logo.custom_minimum_size = Vector2(380, 157)
	logo.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	vb.add_child(logo)

	var credit := Label.new()
	credit.text = "MADE WITH CLAUDE AND DANYIL"
	credit.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	credit.add_theme_font_size_override("font_size", 20)
	credit.add_theme_color_override("font_outline_color", Color(0.1, 0.2, 0.1))
	credit.add_theme_constant_override("outline_size", 6)
	vb.add_child(credit)

	var spacer := Control.new()
	spacer.size_flags_vertical = Control.SIZE_EXPAND_FILL
	spacer.mouse_filter = Control.MOUSE_FILTER_IGNORE
	vb.add_child(spacer)

	var cc := CenterContainer.new()
	vb.add_child(cc)
	var panel := PanelContainer.new()
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.1, 0.1, 0.13, 0.9)
	sb.set_border_width_all(3)
	sb.border_color = Color(0.5, 0.5, 0.55)
	sb.set_corner_radius_all(6)
	sb.set_content_margin_all(20)
	panel.add_theme_stylebox_override("panel", sb)
	cc.add_child(panel)

	var pv := VBoxContainer.new()
	pv.add_theme_constant_override("separation", 14)
	panel.add_child(pv)

	loading_label = Label.new()
	loading_label.text = "Генерация мира..."
	loading_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	loading_label.add_theme_font_size_override("font_size", 28)
	pv.add_child(loading_label)

	var tip := Label.new()
	tip.text = LOAD_TIPS[randi() % LOAD_TIPS.size()]
	tip.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	tip.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	tip.custom_minimum_size = Vector2(560, 0)
	tip.add_theme_font_size_override("font_size", 20)
	tip.add_theme_color_override("font_color", Color(0.8, 0.85, 0.9))
	pv.add_child(tip)

	loading_bar = ProgressBar.new()
	loading_bar.custom_minimum_size = Vector2(560, 18)
	loading_bar.show_percentage = false
	loading_bar.min_value = 0.0
	loading_bar.max_value = 100.0
	loading_bar.value = 0.0
	var fill := StyleBoxFlat.new()
	fill.bg_color = Color(0.4, 0.8, 0.25)
	var back := StyleBoxFlat.new()
	back.bg_color = Color(0.22, 0.22, 0.26)
	loading_bar.add_theme_stylebox_override("fill", fill)
	loading_bar.add_theme_stylebox_override("background", back)
	pv.add_child(loading_bar)

	var bottom := Control.new()
	bottom.custom_minimum_size = Vector2(0, 40)
	bottom.mouse_filter = Control.MOUSE_FILTER_IGNORE
	vb.add_child(bottom)

# ---------------- пауза ----------------

func _set_paused(value: bool) -> void:
	if value and chat_open:
		_close_chat()
	paused = value
	breaking = false
	blocking = false
	break_overlay.visible = false
	pause_layer.visible = paused
	if paused:
		_save_world()
		_reset_mobile_inputs()
		if mobile_hud != null:
			mobile_hud.visible = false
		Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	else:
		_apply_control_mode()

func _set_creative_mode(enabled: bool) -> void:
	creative_mode = enabled
	if enabled:
		creative_flying = false
		for mob in zombie_nodes:
			if is_instance_valid(mob): mob.queue_free()
		zombie_nodes.clear()
	if creative_grid != null:
		creative_grid.visible = enabled and inv_open
	if inv_open and inv_title != null:
		inv_title.text = "Инвентарь — Креатив" if enabled else "Инвентарь"
	_show_msg("Креатив включён" if enabled else "Креатив выключен")

func _item_name(item_id: int) -> String:
	var names := {
		1:"Трава", 2:"Земля", 3:"Камень", 4:"Бревно", 5:"Листва", 6:"Доски", 7:"Верстак", 8:"Угольная руда", 9:"Железная руда", 10:"Палка",
		11:"Деревянная кирка", 12:"Пашня", 13:"Деревянная лопата", 14:"Деревянный меч", 15:"Деревянный топор", 16:"Деревянная мотыга", 17:"Семена пшеницы", 18:"Семена картофеля", 19:"Семена свёклы", 20:"Пшеница", 21:"Картофель", 22:"Свёкла",
		23:"Шлем", 24:"Нагрудник", 25:"Поножи", 26:"Ботинки", 27:"Щит", 28:"Дверь", 29:"Печь", 30:"Каменная кирка", 31:"Каменная лопата", 32:"Каменный меч", 33:"Каменный топор", 34:"Каменная мотыга", 35:"Каменный шлем", 36:"Каменный нагрудник", 37:"Каменные поножи", 38:"Каменные ботинки", 39:"Каменный щит",
		40:"Уголь", 41:"Железный слиток", 42:"Железо", 43:"Сундук", 44:"Железная кирка", 45:"Железная лопата", 46:"Железный меч", 47:"Железный топор", 48:"Железная мотыга", 49:"Железный шлем", 50:"Железный нагрудник", 51:"Железные поножи", 52:"Железные ботинки", 53:"Сырая свинина", 54:"Жареная свинина", 55:"Гнилая плоть", 56:"Приготовленная плоть", 57:"Алмазная руда", 58:"Алмаз", 59:"Алмазная кирка", 60:"Алмазный меч", 61:"Алмазный топор", 62:"Алмазная лопата", 63:"Стекло", 64:"Рельсы", 65:"Вагонетка", 66:"Алмазная мотыга", 67:"Алмазный шлем", 68:"Алмазный нагрудник", 69:"Алмазные поножи", 70:"Алмазные ботинки", 71:"Алмазный щит", 72:"Кровать", 73:"Кость", 74:"Факел", 75:"Песок", 76:"Гравий", 77:"Светящийся блок", 78:"Музыкальный проигрыватель", 79:"Пластинка «Рассвет»", 80:"Пластинка «Лес»", 81:"Пластинка «Пещера»", 82:"Пластинка «Море»", 83:"Пластинка «Звёзды»", 84:"Лук", 85:"Паутина", 86:"Яйцо призыва скелета", 87:"Яйцо призыва свиньи", 88:"Яйцо призыва паука", 89:"Яйцо призыва зомби", 90:"Лодка", 91:"Снег", 92:"Плот 5×8", 93:"Карта сокровищ"
	}
	return Localization.translate_text(str(names.get(item_id, "Неизвестный предмет")))

func _set_creative_scroll_direction(direction: int) -> void:
	creative_scroll_direction = direction
	creative_scroll_repeat = 0.0

func _creative_give_item(item_id: int) -> void:
	if not creative_mode:
		return
	add_item(item_id, MAX_STACK)
	_refresh_slots()

func _make_chat_ui() -> void:
	chat_panel = PanelContainer.new()
	chat_panel.visible = false
	chat_panel.custom_minimum_size = Vector2(380, 250)
	chat_panel.set_anchors_preset(Control.PRESET_BOTTOM_LEFT)
	chat_panel.position = Vector2(14, -166)
	chat_panel.z_index = 80
	hud_layer.add_child(chat_panel)
	var column := VBoxContainer.new()
	chat_panel.add_child(column)
	var title_row := HBoxContainer.new()
	column.add_child(title_row)
	var title := Label.new()
	title.text = "Чат DareCraft"
	title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	title_row.add_child(title)
	var close_x_btn := Button.new()
	close_x_btn.text = "×"
	close_x_btn.tooltip_text = "Закрыть чат"
	close_x_btn.custom_minimum_size = Vector2(38, 34)
	close_x_btn.pressed.connect(_close_chat)
	title_row.add_child(close_x_btn)
	chat_history = Label.new()
	chat_history.text = "Нажми T, чтобы открыть чат. Команды начинаются с /"
	chat_history.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	chat_history.custom_minimum_size = Vector2(340, 160)
	column.add_child(chat_history)
	chat_input = LineEdit.new()
	chat_input.placeholder_text = "Сообщение или команда. /help — список"
	chat_input.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	chat_input.text_submitted.connect(_on_chat_submitted)
	column.add_child(chat_input)
	var send := Button.new()
	send.text = "Отправить"
	send.pressed.connect(func(): _on_chat_submitted(chat_input.text))
	column.add_child(send)
	var close_btn := Button.new()
	close_btn.text = "Закрыть чат"
	close_btn.pressed.connect(_close_chat)
	column.add_child(close_btn)
	var open_btn := Button.new()
	open_btn.text = "Чат"
	# Put chat below the top action row so it never covers the Spawn button.
	open_btn.position = Vector2(-98, 70)
	open_btn.set_anchors_preset(Control.PRESET_TOP_RIGHT)
	open_btn.custom_minimum_size = Vector2(82, 38)
	open_btn.z_index = 50
	open_btn.pressed.connect(_open_chat)
	hud_layer.add_child(open_btn)

func _open_chat() -> void:
	if paused or inv_open or chat_panel == null:
		return
	chat_open = true
	chat_panel.visible = true
	chat_input.grab_focus()
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE

func _close_chat() -> void:
	chat_open = false
	if chat_panel != null:
		chat_panel.visible = false
	if control_mode == CONTROL_MODE_PC and not paused and not inv_open:
		Input.mouse_mode = Input.MOUSE_MODE_CAPTURED

func _set_commands_enabled(enabled: bool) -> void:
	commands_enabled = enabled
	_save_world()
	_show_msg("Команды включены" if enabled else "Команды выключены")

func _on_chat_submitted(raw_text: String) -> void:
	var message := raw_text.strip_edges()
	chat_input.clear()
	if message.is_empty():
		return
	if message.begins_with("/"):
		_run_chat_command(message)
	else:
		if net_connected:
			var nick: String = str(Global.network_player_name) if not str(Global.network_player_name).is_empty() else "Игрок"
			if net_is_host:
				_append_network_chat(nick, message)
				_net_send_event({"type": "chat", "nick": nick, "message": message.substr(0, 180)})
			else:
				_net_send_event({"type": "chat_request", "nick": nick, "message": message.substr(0, 180)})
		else:
			chat_history.text = "Ты: " + message

func _run_chat_command(command_text: String) -> void:
	var parts := command_text.split(" ", false)
	if parts.is_empty():
		return
	var command := String(parts[0]).to_lower()
	if command == "/help":
		chat_history.text = "Команды:\n/give ID [количество] — выдать предмет\n/day — утро\n/night — ночь\n/twilight — сумерки\n/time число (0–200) — время внутри текущей части суток\n/hp число (0–20) — здоровье\n/kill pig|spider|zombie|skeleton|all — убрать мобов рядом\n/ids — список ID предметов.\nЧиты включаются в настройках мира."
		return
	if command == "/ids":
		chat_history.text = "1 Трава · 2 Земля · 3 Камень · 4 Бревно · 5 Листва · 6 Доски · 7 Верстак · 8 Угольная руда · 9 Железная руда · 10 Палка\n11 Деревянная кирка · 12 Пашня · 13 Деревянная лопата · 14 Деревянный меч · 15 Деревянный топор · 16 Деревянная мотыга · 17 Семена пшеницы · 18 Семена картофеля · 19 Семена свёклы · 20 Пшеница · 21 Картофель · 22 Свёкла · 23 Шлем · 24 Нагрудник · 25 Поножи · 26 Ботинки · 27 Щит · 28 Дверь · 29 Печь · 30 Каменная кирка · 31 Каменная лопата · 32 Каменный меч · 33 Каменный топор · 34 Каменная мотыга · 35 Каменный шлем · 36 Каменный нагрудник · 37 Каменные поножи · 38 Каменные ботинки · 39 Каменный щит · 40 Уголь · 41 Железный слиток · 42 Железо · 43 Сундук · 44 Железная кирка · 45 Железная лопата · 46 Железный меч · 47 Железный топор · 48 Железная мотыга · 49 Железный шлем · 50 Железный нагрудник · 51 Железные поножи · 52 Железные ботинки · 53 Сырая свинина · 54 Жареная свинина · 55 Гнилая плоть · 56 Приготовленная плоть · 57 Алмазная руда · 58 Алмаз · 59 Алмазная кирка · 60 Алмазный меч · 61 Алмазный топор · 62 Алмазная лопата · 63 Стекло · 64 Рельсы · 65 Вагонетка · 66 Алмазная мотыга · 67 Алмазный шлем · 68 Алмазный нагрудник · 69 Алмазные поножи · 70 Алмазные ботинки · 71 Алмазный щит · 72 Кровать · 73 Кость · 74 Факел · 75 Песок · 76 Гравий · 77 Светящийся блок · 78 Музыкальный проигрыватель · 79 Пластинка «Рассвет» · 80 Пластинка «Лес» · 81 Пластинка «Пещера» · 82 Пластинка «Море» · 83 Пластинка «Звёзды» · 84 Лук · 85 Паутина"
		return
	if not commands_enabled:
		chat_history.text = "Команды отключены. Включи их в настройках мира."
		return

	if command == "/day":
		cycle_time = 18.0
		_update_day_night(0.0)
		_save_world()
		chat_history.text = "Установлено утро."
		return
	if command == "/night":
		cycle_time = DAY_LENGTH + 18.0
		_update_day_night(0.0)
		_save_world()
		chat_history.text = "Установлена ночь."
		return
	if command == "/twilight":
		cycle_time = DAY_LENGTH + 9.0
		_update_day_night(0.0)
		_save_world()
		chat_history.text = "Установлены вечерние сумерки."
		return
	if command == "/time":
		if parts.size() < 2 or not String(parts[1]).is_valid_int():
			chat_history.text = "Использование: /time число (0–200)."
			return
		var seconds := int(parts[1])
		if seconds < 0 or seconds > int(DAY_LENGTH):
			chat_history.text = "Время должно быть от 0 до 200 секунд."
			return
		var currently_night := cycle_time >= DAY_LENGTH
		cycle_time = (DAY_LENGTH if currently_night else 0.0) + float(seconds)
		_update_day_night(0.0)
		_save_world()
		var remain := int(ceil(DAY_LENGTH - float(seconds)))
		chat_history.text = "Время установлено: %dс. До %s — %dс." % [seconds, "рассвета" if currently_night else "ночи", remain]
		return
	if command == "/hp":
		if parts.size() < 2 or not String(parts[1]).is_valid_float():
			chat_history.text = "Использование: /hp число (0–20)."
			return
		var new_health := float(parts[1])
		if new_health < 0.0 or new_health > 20.0:
			chat_history.text = "Здоровье должно быть от 0 до 20."
			return
		health = new_health
		_update_health_label()
		if health <= 0.0:
			_show_death_screen()
			chat_history.text = "Здоровье установлено: 0."
		else:
			chat_history.text = "Здоровье установлено: %.1f/20." % health
		_save_world()
		return
	if command == "/kill":
		if parts.size() < 2:
			chat_history.text = "Использование: /kill pig|spider|zombie|skeleton|all"
			return
		var mob_type := String(parts[1]).to_lower()
		var group_names: Array[String] = []
		if mob_type == "all":
			group_names = ["mob_pig", "mob_spider", "mob_zombie", "mob_skeleton"]
		elif mob_type == "pig" or mob_type == "spider" or mob_type == "zombie" or mob_type == "skeleton":
			group_names = ["mob_" + mob_type]
		else:
			chat_history.text = "Моб не найден. Варианты: pig, spider, zombie, skeleton, all."
			return
		var killed := 0
		for group_name in group_names:
			for mob in get_tree().get_nodes_in_group(group_name):
				if not is_instance_valid(mob) or not (mob is Node3D):
					continue
				if player.global_position.distance_to((mob as Node3D).global_position) > 40.0:
					continue
				mob.queue_free()
				killed += 1
		zombie_nodes = zombie_nodes.filter(func(m): return is_instance_valid(m) and not m.is_queued_for_deletion())
		chat_history.text = "Убрано мобов рядом: %d." % killed
		return

	if command != "/give":
		chat_history.text = "Неизвестная команда. Используй /help."
		return
	if parts.size() < 2 or not String(parts[1]).is_valid_int():
		chat_history.text = "Использование: /give ID [количество]"
		return
	var item_id := int(parts[1])
	if item_id < 1 or item_id > TREASURE_MAP:
		chat_history.text = "Нет предмета с ID %d. Допустимые ID: 1–93." % item_id
		return
	var amount := 1
	if parts.size() >= 3 and String(parts[2]).is_valid_int():
		amount = clampi(int(parts[2]), 1, 64)
	add_item(item_id, amount)
	_refresh_slots()
	chat_history.text = "Выдано: %s (ID %d) × %d" % [_item_name(item_id), item_id, amount]

func _set_mobile_control_style(style: int) -> void:
	mobile_control_style = clampi(style, 0, 1)
	var config := ConfigFile.new()
	config.load(CONTROL_SETTINGS_PATH)
	config.set_value("controls", "mobile_style", mobile_control_style)
	config.save(CONTROL_SETTINGS_PATH)
	if mobile_dpad != null: mobile_dpad.visible = mobile_control_style == 0
	if mobile_virtual_stick != null: mobile_virtual_stick.visible = mobile_control_style == 1

func _load_physics_settings() -> void:
	var cfg := ConfigFile.new()
	if cfg.load(PHYSICS_SETTINGS_PATH) == OK:
		realistic_destruction = bool(cfg.get_value("physics", "realistic_destruction", true))
		mob_ragdoll_enabled = bool(cfg.get_value("physics", "mob_ragdoll", true))
		physics_preset = clampi(int(cfg.get_value("physics", "preset", 1)), 0, 2)

func _save_physics_settings() -> void:
	var cfg := ConfigFile.new()
	cfg.set_value("physics", "realistic_destruction", realistic_destruction)
	cfg.set_value("physics", "mob_ragdoll", mob_ragdoll_enabled)
	cfg.set_value("physics", "preset", physics_preset)
	var err := cfg.save(PHYSICS_SETTINGS_PATH)
	if err != OK:
		push_warning("Не удалось сохранить настройки Physics Mod")

func _is_physics_block(block_id: int) -> bool:
	return TILES.has(block_id) and block_id != LEAVES and block_id != TORCH and block_id != RAIL and block_id != MINECART and block_id != MUSIC_PLAYER

func _find_unsupported_structure(seed_cell: Vector3i) -> Array:
	var found: Array = []
	var queue: Array[Vector3i] = []
	var seen: Dictionary = {}
	for n in FACE_N:
		var next_cell: Vector3i = seed_cell + n
		var next_id := get_block(next_cell.x, next_cell.y, next_cell.z)
		if _is_physics_block(next_id) and not seen.has(next_cell):
			seen[next_cell] = true
			queue.append(next_cell)
	var supported := false
	var index := 0
	while index < queue.size():
		var current: Vector3i = queue[index]
		index += 1
		var current_id := get_block(current.x, current.y, current.z)
		found.append([current, current_id])
		if found.size() > PHYSICS_MAX_BLOCKS:
			return [] # Ограничение защищает мобильные устройства от огромных расчётов.
		var below := current + Vector3i(0, -1, 0)
		var below_id := get_block(below.x, below.y, below.z)
		if below_id > 0 and not _is_physics_block(below_id):
			supported = true
		for n in FACE_N:
			var next_cell: Vector3i = current + n
			if seen.has(next_cell):
				continue
			var next_id := get_block(next_cell.x, next_cell.y, next_cell.z)
			if _is_physics_block(next_id):
				seen[next_cell] = true
				queue.append(next_cell)
	if supported:
		return []
	return found

func _spawn_falling_structure(records: Array, network_id: int = -1, network_preset: int = -1) -> void:
	if records.is_empty() or falling_body_count >= PHYSICS_MAX_BODIES:
		return
	var active_preset := physics_preset if network_preset < 0 else clampi(network_preset, 0, 2)
	var packed_blocks: Array = []
	var center := Vector3.ZERO
	for record in records:
		center += Vector3(record[0]) + Vector3(0.5, 0.5, 0.5)
		var packed_cell: Vector3i = record[0]
		packed_blocks.append([packed_cell.x, packed_cell.y, packed_cell.z, int(record[1])])
	center /= float(records.size())
	var body := RigidBody3D.new()
	var body_id := network_id
	if body_id <= 0:
		body_id = next_physics_body_id
		next_physics_body_id += 1
	body.name = "FallingStructure_%d" % body_id
	body.set_meta("physics_net_id", body_id)
	body.set_meta("physics_blocks", packed_blocks)
	body.position = center
	body.mass = maxf(1.0, float(records.size()) * (0.7 if active_preset == 0 else (1.0 if active_preset == 1 else 1.4)))
	body.gravity_scale = 0.65 if active_preset == 0 else (1.0 if active_preset == 1 else 1.35)
	var verts := PackedVector3Array()
	var norms := PackedVector3Array()
	var uvs := PackedVector2Array()
	var indices := PackedInt32Array()
	for record in records:
		var cell: Vector3i = record[0]
		var block_id := int(record[1])
		var tiles: Array = TILES.get(block_id, [3, 3, 3])
		var base := verts.size()
		var temp_v: Array = []
		var temp_n: Array = []
		var temp_uv: Array = []
		var temp_i: Array = []
		_append_box_geometry(temp_v, temp_n, temp_uv, temp_i, Vector3.ZERO, Vector3(cell) + Vector3(0.5, 0.5, 0.5) - center, Vector3.ONE, int(tiles[0]), int(tiles[1]), int(tiles[2]))
		for v in temp_v: verts.append(v)
		for n in temp_n: norms.append(n)
		for uv in temp_uv: uvs.append(uv)
		for ix in temp_i: indices.append(base + int(ix))
		var shape := CollisionShape3D.new()
		var box := BoxShape3D.new()
		box.size = Vector3.ONE * 0.98
		shape.shape = box
		shape.position = Vector3(cell) + Vector3(0.5, 0.5, 0.5) - center
		body.add_child(shape)
	var mesh := ArrayMesh.new()
	var arrays := []
	arrays.resize(Mesh.ARRAY_MAX)
	arrays[Mesh.ARRAY_VERTEX] = verts
	arrays[Mesh.ARRAY_NORMAL] = norms
	arrays[Mesh.ARRAY_TEX_UV] = uvs
	arrays[Mesh.ARRAY_INDEX] = indices
	mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
	var visual := MeshInstance3D.new()
	visual.mesh = mesh
	var material := StandardMaterial3D.new()
	material.albedo_texture = atlas_tex
	material.texture_filter = BaseMaterial3D.TEXTURE_FILTER_NEAREST
	visual.material_override = material
	body.add_child(visual)
	add_child(body)
	if net_connected and not net_is_host:
		body.gravity_scale = 0.65 if active_preset == 0 else (1.0 if active_preset == 1 else 1.35)
	else:
		body.apply_central_impulse(Vector3(randf_range(-0.8, 0.8), 0.15, randf_range(-0.8, 0.8)) * (0.5 if active_preset == 0 else (1.0 if active_preset == 1 else 1.5)))
	physics_bodies[body_id] = body
	falling_body_count += 1
	body.tree_exited.connect(func():
		physics_bodies.erase(body_id)
		falling_body_count = maxi(0, falling_body_count - 1)
	)
	get_tree().create_timer(18.0).timeout.connect(func():
		if is_instance_valid(body):
			body.queue_free()
	)

func _physics_after_block_removed(cell: Vector3i) -> void:
	if not realistic_destruction or falling_body_count >= PHYSICS_MAX_BODIES:
		return
	var records := _find_unsupported_structure(cell)
	if records.is_empty():
		return
	var cells: Array = []
	for record in records:
		var block_cell: Vector3i = record[0]
		var block_id := int(record[1])
		cells.append([block_cell.x, block_cell.y, block_cell.z, block_id])
		_set_block_local(block_cell, 0)
		_net_record_block(block_cell, 0)
	var body_id := next_physics_body_id
	next_physics_body_id += 1
	if net_connected and net_is_host:
		_net_send_event({"type": "physics_collapse", "body_id": body_id, "preset": physics_preset, "blocks": cells})
	_spawn_falling_structure(records, body_id)

func _apply_network_collapse(raw_blocks: Variant, network_id: int, network_preset: int) -> void:
	if not (raw_blocks is Array) or raw_blocks.size() == 0 or raw_blocks.size() > PHYSICS_MAX_BLOCKS:
		return
	var records: Array = []
	for entry in raw_blocks:
		if entry is Array and entry.size() >= 4:
			var cell := Vector3i(int(entry[0]), int(entry[1]), int(entry[2]))
			var block_id := int(entry[3])
			if cell.x < 0 or cell.x >= WORLD_SIZE or cell.z < 0 or cell.z >= WORLD_SIZE or cell.y < 0 or cell.y >= WORLD_H or not _is_physics_block(block_id):
				continue
			records.append([cell, block_id])
			_set_block_local(cell, 0)
	_spawn_falling_structure(records, network_id, network_preset)

func spawn_mob_ragdoll(mob: Node3D) -> void:
	# Упрощённый физический регдолл: визуальные части моба переносятся
	# в единое физическое тело с отдельными коллайдерами.
	if not mob_ragdoll_enabled or not is_instance_valid(mob):
		return
	if net_connected and not net_is_host:
		return
	var body := RigidBody3D.new()
	body.name = "MobRagdoll"
	body.global_transform = mob.global_transform
	body.mass = 6.0
	body.gravity_scale = 1.0 if physics_preset == 1 else (0.75 if physics_preset == 0 else 1.25)
	body.linear_damp = 0.8
	body.angular_damp = 1.4
	body.collision_layer = 1
	body.collision_mask = 1
	var inverse_root: Transform3D = mob.global_transform.affine_inverse()
	var mesh_nodes: Array[Node] = mob.find_children("*", "MeshInstance3D", true, false)
	for node in mesh_nodes:
		var source := node as MeshInstance3D
		if source == null or source.mesh == null:
			continue
		var local_transform: Transform3D = inverse_root * source.global_transform
		var visual := MeshInstance3D.new()
		visual.mesh = source.mesh
		visual.material_override = source.material_override
		visual.transform = local_transform
		body.add_child(visual)
		var bounds: AABB = source.mesh.get_aabb()
		var shape := CollisionShape3D.new()
		var box := BoxShape3D.new()
		box.size = Vector3(maxf(0.12, bounds.size.x), maxf(0.12, bounds.size.y), maxf(0.12, bounds.size.z))
		shape.shape = box
		shape.transform = local_transform * Transform3D(Basis.IDENTITY, bounds.position + bounds.size * 0.5)
		body.add_child(shape)
	if body.get_child_count() == 0:
		body.free()
		return
	add_child(body)
	body.apply_central_impulse(Vector3(randf_range(-1.4, 1.4), 1.2, randf_range(-1.4, 1.4)))
	body.apply_torque_impulse(Vector3(randf_range(-1.8, 1.8), randf_range(-1.8, 1.8), randf_range(-1.8, 1.8)))
	get_tree().create_timer(5.0).timeout.connect(func():
		if is_instance_valid(body):
			body.queue_free()
	)

func _make_pause_menu() -> void:
	pause_layer = CanvasLayer.new()
	pause_layer.layer = 101
	pause_layer.visible = false
	add_child(pause_layer)

	var dim := ColorRect.new()
	dim.color = Color(0, 0, 0, 0.55)
	pause_layer.add_child(dim)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	var center := CenterContainer.new()
	pause_layer.add_child(center)
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	var main_box := VBoxContainer.new()
	main_box.add_theme_constant_override("separation", 20)
	center.add_child(main_box)

	var logo := TextureRect.new()
	logo.texture = load("res://darecraft_logo_clean.svg")
	logo.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	logo.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	logo.custom_minimum_size = Vector2(320, 132)
	main_box.add_child(logo)

	var title := Label.new()
	title.text = "Пауза"
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_size_override("font_size", 56)
	main_box.add_child(title)

	var resume := Button.new()
	resume.text = "Продолжить"
	resume.custom_minimum_size = Vector2(480, 70)
	resume.add_theme_font_size_override("font_size", 28)
	resume.pressed.connect(_set_paused.bind(false))
	main_box.add_child(resume)

	var settings_btn := Button.new()
	settings_btn.text = "Настройки"
	settings_btn.custom_minimum_size = Vector2(480, 70)
	settings_btn.add_theme_font_size_override("font_size", 28)
	main_box.add_child(settings_btn)

	var to_menu := Button.new()
	to_menu.text = "Выйти в меню"
	to_menu.custom_minimum_size = Vector2(480, 70)
	to_menu.add_theme_font_size_override("font_size", 24)
	to_menu.pressed.connect(_on_to_menu)
	main_box.add_child(to_menu)

	var settings_scroll := ScrollContainer.new()
	settings_scroll.visible = false
	settings_scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	settings_scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	var physics_viewport_size: Vector2 = get_viewport().get_visible_rect().size
	settings_scroll.custom_minimum_size = Vector2(minf(620.0, physics_viewport_size.x * 0.92), minf(620.0, physics_viewport_size.y * 0.78))
	center.add_child(settings_scroll)
	var settings_box := VBoxContainer.new()
	settings_box.add_theme_constant_override("separation", 20)
	settings_box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	settings_box.custom_minimum_size.x = minf(620.0, physics_viewport_size.x * 0.90)
	settings_scroll.add_child(settings_box)

	var st_title := Label.new()
	st_title.text = "Настройки"
	st_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	st_title.add_theme_font_size_override("font_size", 48)
	settings_box.add_child(st_title)

	var world_settings_title := Label.new()
	world_settings_title.text = "Настройки мира"
	world_settings_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	world_settings_title.add_theme_font_size_override("font_size", 24)
	settings_box.add_child(world_settings_title)
	var creative_toggle := CheckButton.new()
	creative_toggle.text = "Креативный режим"
	creative_toggle.button_pressed = creative_mode
	creative_toggle.toggled.connect(_set_creative_mode)
	creative_toggle.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	settings_box.add_child(creative_toggle)
	var commands_toggle := CheckButton.new()
	commands_toggle.text = "Команды в чате (читы)"
	commands_toggle.button_pressed = commands_enabled
	commands_toggle.toggled.connect(_set_commands_enabled)
	commands_toggle.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	settings_box.add_child(commands_toggle)
	var physics_title := Label.new()
	physics_title.text = "Physics Mod"
	physics_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	physics_title.add_theme_font_size_override("font_size", 24)
	settings_box.add_child(physics_title)
	var realistic_toggle := CheckButton.new()
	realistic_toggle.text = "Реалистичное разрушение (падение построек)"
	realistic_toggle.button_pressed = realistic_destruction
	realistic_toggle.toggled.connect(func(value: bool):
		realistic_destruction = value
		_save_physics_settings()
	)
	realistic_toggle.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	settings_box.add_child(realistic_toggle)
	var ragdoll_toggle := CheckButton.new()
	ragdoll_toggle.text = "Физическое падение мобов (регдолл)"
	ragdoll_toggle.button_pressed = mob_ragdoll_enabled
	ragdoll_toggle.toggled.connect(func(value: bool):
		mob_ragdoll_enabled = value
		_save_physics_settings()
	)
	ragdoll_toggle.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	settings_box.add_child(ragdoll_toggle)
	var physics_hint := Label.new()
	physics_hint.text = "Физика построек и падение мобов применяются сразу. Настройки сохраняются на устройстве."
	physics_hint.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	physics_hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	physics_hint.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	settings_box.add_child(physics_hint)
	var physics_preset_row := HBoxContainer.new()
	physics_preset_row.alignment = BoxContainer.ALIGNMENT_CENTER
	settings_box.add_child(physics_preset_row)
	var physics_preset_label := Label.new()
	physics_preset_label.text = "Физика:"
	physics_preset_row.add_child(physics_preset_label)
	var physics_preset_select := OptionButton.new()
	physics_preset_select.add_item("Мягкая")
	physics_preset_select.add_item("Обычная")
	physics_preset_select.add_item("Максимальная")
	physics_preset_select.select(physics_preset)
	physics_preset_select.item_selected.connect(func(index: int):
		physics_preset = clampi(index, 0, 2)
		_save_physics_settings()
	)
	physics_preset_row.add_child(physics_preset_select)

	var controls_label := Label.new()
	controls_label.text = "Управление"
	controls_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	controls_label.add_theme_font_size_override("font_size", 24)
	settings_box.add_child(controls_label)

	var controls_row := HBoxContainer.new()
	controls_row.alignment = BoxContainer.ALIGNMENT_CENTER
	controls_row.add_theme_constant_override("separation", 16)
	settings_box.add_child(controls_row)

	control_pc_button = Button.new()
	control_pc_button.custom_minimum_size = Vector2(180, 55)
	control_pc_button.add_theme_font_size_override("font_size", 22)
	control_pc_button.pressed.connect(_set_control_mode.bind(CONTROL_MODE_PC))
	controls_row.add_child(control_pc_button)

	control_mobile_button = Button.new()
	control_mobile_button.custom_minimum_size = Vector2(180, 55)
	control_mobile_button.add_theme_font_size_override("font_size", 22)
	control_mobile_button.pressed.connect(_set_control_mode.bind(CONTROL_MODE_MOBILE))
	controls_row.add_child(control_mobile_button)

	_refresh_control_mode_buttons()

	var mobile_style_row := HBoxContainer.new()
	mobile_style_row.alignment = BoxContainer.ALIGNMENT_CENTER
	mobile_style_row.add_theme_constant_override("separation", 12)
	settings_box.add_child(mobile_style_row)
	var mobile_style_label := Label.new()
	mobile_style_label.text = "Мобильное управление:"
	mobile_style_label.add_theme_font_size_override("font_size", 20)
	mobile_style_row.add_child(mobile_style_label)
	var buttons_style := Button.new()
	buttons_style.text = "Кнопки"
	buttons_style.pressed.connect(func(): _set_mobile_control_style(0))
	mobile_style_row.add_child(buttons_style)
	var stick_style := Button.new()
	stick_style.text = "Джойстик"
	stick_style.pressed.connect(func(): _set_mobile_control_style(1))
	mobile_style_row.add_child(stick_style)

	var fov_row := HBoxContainer.new()
	fov_row.alignment = BoxContainer.ALIGNMENT_CENTER
	fov_row.add_theme_constant_override("separation", 20)
	settings_box.add_child(fov_row)

	var fov_lbl := Label.new()
	fov_lbl.text = "Обзор: " + str(int(Global.fov))
	fov_lbl.add_theme_font_size_override("font_size", 24)
	fov_row.add_child(fov_lbl)

	var fov_slider := HSlider.new()
	fov_slider.custom_minimum_size = Vector2(250, 30)
	fov_slider.min_value = 30.0
	fov_slider.max_value = 110.0
	fov_slider.step = 1.0
	fov_slider.value = Global.fov
	fov_row.add_child(fov_slider)
	fov_slider.value_changed.connect(func(val):
		Global.fov = val
		fov_lbl.text = "Обзор: " + str(int(val))
		if camera != null:
			camera.fov = val
	)

	var vol_row := HBoxContainer.new()
	vol_row.alignment = BoxContainer.ALIGNMENT_CENTER
	vol_row.add_theme_constant_override("separation", 20)
	settings_box.add_child(vol_row)

	var vol_lbl := Label.new()
	vol_lbl.text = "Музыка: " + str(int(Music.music_volume * 100)) + "%"
	vol_lbl.add_theme_font_size_override("font_size", 24)
	vol_row.add_child(vol_lbl)

	var vol_slider := HSlider.new()
	vol_slider.custom_minimum_size = Vector2(250, 30)
	vol_slider.min_value = 0.0
	vol_slider.max_value = 1.0
	vol_slider.step = 0.01
	vol_slider.value = Music.music_volume
	vol_row.add_child(vol_slider)
	vol_slider.value_changed.connect(func(val):
		Music.set_music_volume(val)
		vol_lbl.text = "Музыка: " + str(int(val * 100)) + "%"
	)

	var sfx_row := HBoxContainer.new()
	sfx_row.alignment = BoxContainer.ALIGNMENT_CENTER
	sfx_row.add_theme_constant_override("separation", 20)
	settings_box.add_child(sfx_row)

	var sfx_lbl := Label.new()
	sfx_lbl.text = "Звуки: " + str(int(Music.sfx_volume * 100)) + "%"
	sfx_lbl.add_theme_font_size_override("font_size", 24)
	sfx_row.add_child(sfx_lbl)

	var sfx_slider := HSlider.new()
	sfx_slider.custom_minimum_size = Vector2(250, 30)
	sfx_slider.min_value = 0.0
	sfx_slider.max_value = 1.0
	sfx_slider.step = 0.01
	sfx_slider.value = Music.sfx_volume
	sfx_row.add_child(sfx_slider)
	sfx_slider.value_changed.connect(func(val):
		Music.set_sfx_volume(val)
		sfx_lbl.text = "Звуки: " + str(int(val * 100)) + "%"
	)

	var back_btn := Button.new()
	back_btn.text = "Назад"
	back_btn.custom_minimum_size = Vector2(480, 70)
	back_btn.add_theme_font_size_override("font_size", 28)
	settings_box.add_child(back_btn)

	settings_btn.pressed.connect(func():
		main_box.visible = false
		settings_scroll.visible = true
	)

	back_btn.pressed.connect(func():
		settings_scroll.visible = false
		main_box.visible = true
	)

func _on_to_menu() -> void:
	_save_world()
	get_tree().change_scene_to_file("res://menu.tscn")

# ---------------- персонаж и камера ----------------

func _box(parent: Node3D, size: Vector3, pos: Vector3, mat: StandardMaterial3D) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	mi.mesh = bm
	mi.position = pos
	mi.material_override = mat
	parent.add_child(mi)
	return mi

func _build_character(skin_index: int = -1, appearance: Dictionary = {}) -> Dictionary:
	var preset: Dictionary = Global.get_skin_preset(skin_index)
	for color_key in ["skin", "shirt", "pants", "hair"]:
		if appearance.has(color_key):
			var raw_color: Variant = appearance[color_key]
			if raw_color is String:
				preset[color_key] = Color.from_string(raw_color, preset[color_key])
	if appearance.has("long_hair"):
		preset["long_hair"] = bool(appearance["long_hair"])
	var skin := _color_mat(preset["skin"])
	var shirt := _color_mat(preset["shirt"])
	var pants := _color_mat(preset["pants"])
	var hair := _color_mat(preset["hair"])
	var long_hair: bool = bool(preset["long_hair"])
	var dark := _color_mat(Color(0.08, 0.08, 0.15))
	var mouth := _color_mat(Color(0.55, 0.3, 0.25))
	var iron := _color_mat(Color(0.6, 0.62, 0.66))
	var gmat: Array = []
	for k in 5:
		gmat.append([_color_mat(WOOD_COL[0]), _color_mat(WOOD_COL[1])])
	var gh: Array = gmat[0]
	var gc: Array = gmat[1]
	var gl: Array = gmat[2]
	var gb: Array = gmat[3]
	var gs: Array = gmat[4]
	var root := Node3D.new()
	var gear: Array = [[], [], [], [], []]

	_box(root, Vector3(0.45, 0.675, 0.225), Vector3(0, 1.0125, 0), shirt)
	gear[1].append(_box(root, Vector3(0.5, 0.7, 0.27), Vector3(0, 1.0125, 0), gc[0]))
	gear[1].append(_box(root, Vector3(0.51, 0.08, 0.28), Vector3(0, 0.72, 0), gc[1]))

	var head := Node3D.new()
	head.position = Vector3(0, 1.35, 0)
	root.add_child(head)
	_box(head, Vector3(0.45, 0.45, 0.45), Vector3(0, 0.225, 0), skin)
	_box(head, Vector3(0.47, 0.12, 0.47), Vector3(0, 0.42, 0), hair)
	_box(head, Vector3(0.47, 0.3, 0.06), Vector3(0, 0.26, 0.215), hair)
	if long_hair:
		_box(head, Vector3(0.10, 0.43, 0.28), Vector3(-0.205, -0.015, 0.015), hair)
		_box(head, Vector3(0.10, 0.43, 0.28), Vector3(0.205, -0.015, 0.015), hair)
		_box(head, Vector3(0.43, 0.08, 0.43), Vector3(0, 0.34, 0), hair)
	_box(head, Vector3(0.09, 0.07, 0.02), Vector3(-0.1, 0.26, -0.226), dark)
	_box(head, Vector3(0.09, 0.07, 0.02), Vector3(0.1, 0.26, -0.226), dark)
	_box(head, Vector3(0.14, 0.035, 0.02), Vector3(0, 0.1, -0.226), mouth)
	gear[0].append(_box(head, Vector3(0.5, 0.16, 0.5), Vector3(0, 0.43, 0), gh[0]))
	gear[0].append(_box(head, Vector3(0.5, 0.38, 0.07), Vector3(0, 0.24, 0.235), gh[0]))
	gear[0].append(_box(head, Vector3(0.07, 0.38, 0.5), Vector3(0.235, 0.24, 0), gh[0]))
	gear[0].append(_box(head, Vector3(0.07, 0.38, 0.5), Vector3(-0.235, 0.24, 0), gh[0]))
	gear[0].append(_box(head, Vector3(0.5, 0.07, 0.07), Vector3(0, 0.37, -0.235), gh[1]))

	var arms: Array = []
	for sx in [1.0, -1.0]:
		var arm := Node3D.new()
		arm.position = Vector3(0.3375 * sx, 1.35, 0)
		root.add_child(arm)
		_box(arm, Vector3(0.225, 0.45, 0.225), Vector3(0, -0.225, 0), shirt)
		_box(arm, Vector3(0.225, 0.225, 0.225), Vector3(0, -0.5625, 0), skin)
		gear[1].append(_box(arm, Vector3(0.27, 0.24, 0.27), Vector3(0, -0.12, 0), gc[0]))
		arms.append(arm)
	var arm_l: Node3D = arms[1]
	gear[4].append(_box(arm_l, Vector3(0.38, 0.54, 0.04), Vector3(0, -0.38, -0.15), gs[1]))
	gear[4].append(_box(arm_l, Vector3(0.3, 0.46, 0.06), Vector3(0, -0.38, -0.155), gs[0]))
	gear[4].append(_box(arm_l, Vector3(0.12, 0.12, 0.09), Vector3(0, -0.38, -0.17), iron))

	var legs: Array = []
	for sx in [1.0, -1.0]:
		var leg := Node3D.new()
		leg.position = Vector3(0.1125 * sx, 0.675, 0)
		root.add_child(leg)
		_box(leg, Vector3(0.225, 0.675, 0.225), Vector3(0, -0.3375, 0), pants)
		gear[2].append(_box(leg, Vector3(0.27, 0.42, 0.27), Vector3(0, -0.21, 0), gl[0]))
		gear[3].append(_box(leg, Vector3(0.27, 0.2, 0.27), Vector3(0, -0.575, 0), gb[1]))
		legs.append(leg)

	for k in 5:
		for n in gear[k]:
			var node: Node3D = n
			node.visible = false

	var hand := Node3D.new()
	hand.position = Vector3(0, -0.6, -0.12)
	var arm_r: Node3D = arms[0]
	arm_r.add_child(hand)
	return {
		"root": root, "head": head, "arm_r": arm_r, "arm_l": arm_l,
		"leg_r": legs[0], "leg_l": legs[1], "hand": hand, "gear": gear, "gmat": gmat,
	}

func _animate_char(c: Dictionary, sw: float, hit: float, head_pitch: float, emote_id: int = -1, emote_time: float = 0.0) -> void:
	var ar: Node3D = c["arm_r"]
	var al: Node3D = c["arm_l"]
	var lr: Node3D = c["leg_r"]
	var ll: Node3D = c["leg_l"]
	var hd: Node3D = c["head"]
	ar.rotation = Vector3.ZERO
	al.rotation = Vector3.ZERO
	lr.rotation = Vector3.ZERO
	ll.rotation = Vector3.ZERO
	hd.rotation.x = head_pitch
	var active_emote := local_emote_id if emote_id < 0 and local_emote_time > 0.0 else emote_id
	var active_time := local_emote_time if emote_id < 0 else emote_time
	if active_emote >= 0 and active_time > 0.0:
		var phase := 1.0 - active_time / 1.7
		match active_emote:
			0: # dance
				ar.rotation.x = -1.1 + sin(phase * TAU * 2.0) * 0.4
				al.rotation.x = 1.1 - sin(phase * TAU * 2.0) * 0.4
				ar.rotation.z = sin(phase * TAU * 2.0) * 0.35
				al.rotation.z = -sin(phase * TAU * 2.0) * 0.35
				lr.rotation.x = sin(phase * TAU * 2.0) * 0.25
				ll.rotation.x = -lr.rotation.x
			1: # wave
				ar.rotation.x = -2.1 + sin(phase * TAU * 3.0) * 0.16
				ar.rotation.z = sin(phase * TAU * 3.0) * 0.55
				al.rotation.x = 0.0
			2: # clap
				ar.rotation.x = -1.35
				al.rotation.x = -1.35
				ar.rotation.z = -0.35
				al.rotation.z = 0.35
			3: # flex
				ar.rotation.x = -2.3
				al.rotation.x = -2.3
				ar.rotation.z = -0.65
				al.rotation.z = 0.65
			4: # facepalm
				ar.rotation.x = -2.4
				ar.rotation.z = -0.25
				hd.rotation.x = -0.25
			5: # thumbs up
				ar.rotation.x = -1.8
				ar.rotation.z = -0.15
			6: # GG cheer
				ar.rotation.x = -2.5 + sin(phase * TAU * 2.0) * 0.2
				al.rotation.x = -2.5 - sin(phase * TAU * 2.0) * 0.2
			7: # victory
				ar.rotation.x = -2.0
				al.rotation.x = -2.0
				ar.rotation.z = -0.6
				al.rotation.z = 0.6
		if active_emote != 0:
			lr.rotation.x = 0.0
			ll.rotation.x = 0.0
	else:
		ar.rotation.x = -sw + hit * 1.6
		al.rotation.x = sw
		lr.rotation.x = sw
		ll.rotation.x = -sw
		hd.rotation.x = head_pitch

func _tier_colors(tier: int) -> Array:
	if tier == 3:
		return DIAMOND_COL
	if tier == 2:
		return IRON_COL
	if tier == 1:
		return STONE_COL
	return WOOD_COL

func _update_char_gear() -> void:
	var tiers: Array = []
	for k in 5:
		tiers.append(_armor_tier(int(armor[k]["id"])))
	for c in chars:
		var gear: Array = c["gear"]
		var gmat: Array = c["gmat"]
		for k in 5:
			var vis: bool = armor[k]["id"] != 0
			for n in gear[k]:
				var node: Node3D = n
				node.visible = vis
			var cols: Array = _tier_colors(int(tiers[k]))
			var gm: Array = gmat[k]
			var m0: StandardMaterial3D = gm[0]
			var m1: StandardMaterial3D = gm[1]
			m0.albedo_color = cols[0]
			m1.albedo_color = cols[1]
	if fp_shield_mats.size() == 2:
		var cols2: Array = _tier_colors(int(tiers[4]))
		var f0: StandardMaterial3D = fp_shield_mats[0]
		var f1: StandardMaterial3D = fp_shield_mats[1]
		f0.albedo_color = cols2[0]
		f1.albedo_color = cols2[1]

func _apply_camera_mode() -> void:
	if camera == null or player == null:
		return
	if view_mode == 2:
		camera.rotation = Vector3(-pitch, PI, 0.0)
	else:
		camera.rotation = Vector3(pitch, 0.0, 0.0)
	var head_pos := Vector3(0, 0.7, 0)
	if view_mode == 0:
		camera.position = head_pos
		return
	var d := THIRD_DIST
	var local_off: Vector3 = camera.basis * Vector3(0, 0, 1)
	var from: Vector3 = player.global_transform * head_pos
	var to: Vector3 = from + player.global_transform.basis * (local_off * d)
	var q := PhysicsRayQueryParameters3D.create(from, to)
	var ex: Array[RID] = [player.get_rid()]
	q.exclude = ex
	var hit := get_world_3d().direct_space_state.intersect_ray(q)
	if not hit.is_empty():
		var hp: Vector3 = hit["position"]
		d = maxf(0.4, from.distance_to(hp) - 0.25)
	camera.position = head_pos + local_off * d

func _equip_from(arr: Array, i: int) -> bool:
	var s: Dictionary = arr[i]
	var k: int = int(ARMOR_SLOT_OF.get(int(s["id"]), -1))
	if k < 0:
		return false
	var old: Dictionary = armor[k].duplicate()
	armor[k] = {"id": s["id"], "n": 1}
	s["n"] -= 1
	if s["n"] <= 0:
		arr[i] = old
	elif old["id"] != 0:
		add_item(old["id"], old["n"])
	_refresh_all()
	return true

# ---------------- печка ----------------

func _make_furnace_ui() -> void:
	furnace_layer = CanvasLayer.new()
	furnace_layer.layer = 6
	furnace_layer.visible = false
	add_child(furnace_layer)

	var dim := ColorRect.new()
	dim.color = Color(0, 0, 0, 0.6)
	furnace_layer.add_child(dim)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	var center := CenterContainer.new()
	furnace_layer.add_child(center)
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	var panel := PanelContainer.new()
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.7, 0.7, 0.7)
	sb.set_border_width_all(3)
	sb.border_color = Color(0.2, 0.2, 0.2)
	panel.add_theme_stylebox_override("panel", sb)
	center.add_child(panel)

	var margin := MarginContainer.new()
	for side in ["left", "right", "top", "bottom"]:
		margin.add_theme_constant_override("margin_" + side, 14)
	panel.add_child(margin)

	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 10)
	margin.add_child(box)

	var header := HBoxContainer.new()
	box.add_child(header)
	var title := Label.new()
	title.text = "Печка" if control_mode == CONTROL_MODE_MOBILE else "Печка (E / Esc: закрыть)"
	title.add_theme_font_size_override("font_size", 20)
	title.add_theme_color_override("font_color", Color(0.2, 0.2, 0.2))
	header.add_child(title)
	close_x.attach_to_header(header, _close_furnace)

	var top_row := CenterContainer.new()
	box.add_child(top_row)
	var main_row := HBoxContainer.new()
	main_row.add_theme_constant_override("separation", 16)
	top_row.add_child(main_row)

	var left_col := VBoxContainer.new()
	left_col.add_theme_constant_override("separation", 4)
	main_row.add_child(left_col)

	var s_in := _make_slot(50, true)
	s_in["btn"].pressed.connect(_on_furnace_slot.bind("input"))
	left_col.add_child(s_in["btn"])
	furnace_slots_ui.append(s_in)

	var flame := ProgressBar.new()
	flame.name = "FlameBar"
	flame.custom_minimum_size = Vector2(50, 20)
	flame.show_percentage = false
	flame.fill_mode = ProgressBar.FILL_BOTTOM_TO_TOP
	var flame_bg := StyleBoxFlat.new()
	flame_bg.bg_color = Color(0.3, 0.3, 0.3)
	var flame_fill := StyleBoxFlat.new()
	flame_fill.bg_color = Color(1.0, 0.5, 0.0)
	flame.add_theme_stylebox_override("background", flame_bg)
	flame.add_theme_stylebox_override("fill", flame_fill)
	left_col.add_child(flame)

	var s_fuel := _make_slot(50, true)
	s_fuel["btn"].pressed.connect(_on_furnace_slot.bind("fuel"))
	left_col.add_child(s_fuel["btn"])
	furnace_slots_ui.append(s_fuel)

	var right_col := HBoxContainer.new()
	right_col.add_theme_constant_override("separation", 10)
	right_col.alignment = BoxContainer.ALIGNMENT_CENTER
	main_row.add_child(right_col)

	var arrow := ProgressBar.new()
	arrow.name = "ArrowBar"
	arrow.custom_minimum_size = Vector2(60, 20)
	arrow.show_percentage = false
	arrow.max_value = SMELT_TIME
	var arrow_bg := StyleBoxFlat.new()
	arrow_bg.bg_color = Color(0.4, 0.4, 0.4)
	var arrow_fill := StyleBoxFlat.new()
	arrow_fill.bg_color = Color(1, 1, 1)
	arrow.add_theme_stylebox_override("background", arrow_bg)
	arrow.add_theme_stylebox_override("fill", arrow_fill)
	right_col.add_child(arrow)

	var s_out := _make_slot(56, true)
	s_out["btn"].pressed.connect(_on_furnace_slot.bind("output"))
	right_col.add_child(s_out["btn"])
	furnace_slots_ui.append(s_out)

	box.add_child(HSeparator.new())

	var inv_lbl := Label.new()
	inv_lbl.text = "Инвентарь"
	inv_lbl.add_theme_font_size_override("font_size", 18)
	inv_lbl.add_theme_color_override("font_color", Color(0.2, 0.2, 0.2))
	box.add_child(inv_lbl)

	furnace_inv_ui.clear()
	furnace_hot_ui.clear()

	var grid := GridContainer.new()
	grid.columns = 5
	grid.add_theme_constant_override("h_separation", 6)
	grid.add_theme_constant_override("v_separation", 6)
	box.add_child(grid)
	for i in range(HOTBAR, TOTAL_SLOTS):
		var s := _make_slot(46, true)
		s["btn"].pressed.connect(_on_slot_pressed.bind(i))
		s["btn"].gui_input.connect(_slot_gui_input.bind("s", i))
		grid.add_child(s["btn"])
		furnace_inv_ui.append(s)

	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 6)
	box.add_child(row)
	for i in HOTBAR:
		var s := _make_slot(46, true)
		s["btn"].pressed.connect(_on_slot_pressed.bind(i))
		s["btn"].gui_input.connect(_slot_gui_input.bind("s", i))
		row.add_child(s["btn"])
		furnace_hot_ui.append(s)

func _on_furnace_slot(kind: String) -> void:
	if furnace_ui_cell == Vector3i(-1, -1, -1):
		return
	var f := _get_furnace(furnace_ui_cell)
	var s: Dictionary = f[kind]
	var c: Dictionary = cursor_item

	if kind == "output":
		if s["id"] != 0 and c["id"] == 0:
			cursor_item = s.duplicate()
			f["output"] = {"id": 0, "n": 0}
		elif s["id"] != 0 and c["id"] == s["id"] and int(c["n"]) + int(s["n"]) <= MAX_STACK:
			c["n"] += s["n"]
			f["output"] = {"id": 0, "n": 0}
		else:
			return
		_refresh_furnace_ui()
		return

	if c["id"] == 0:
		if s["id"] != 0:
			cursor_item = s.duplicate()
			f[kind] = {"id": 0, "n": 0}
	elif s["id"] == 0:
		f[kind] = c.duplicate()
		cursor_item = {"id": 0, "n": 0}
	elif s["id"] == c["id"]:
		var moved: int = mini(MAX_STACK - int(s["n"]), int(c["n"]))
		s["n"] += moved
		c["n"] -= moved
		if c["n"] <= 0:
			cursor_item = {"id": 0, "n": 0}
	else:
		f[kind] = c.duplicate()
		cursor_item = s.duplicate()
	_refresh_furnace_ui()

func _get_furnace(cell: Vector3i) -> Dictionary:
	if not furnaces.has(cell):
		furnaces[cell] = {
			"input": {"id": 0, "n": 0}, "fuel": {"id": 0, "n": 0},
			"output": {"id": 0, "n": 0}, "progress": 0.0, "burn": 0.0, "burn_max": 80.0,
		}
	return furnaces[cell]

func _open_furnace(cell: Vector3i) -> void:
	_get_furnace(cell)
	furnace_ui_cell = cell
	inv_open = true
	breaking = false
	blocking = false
	if mobile_hud != null:
		mobile_hud.visible = false
	inv_layer.visible = false
	furnace_layer.visible = true
	close_x.set_mobile(control_mode == CONTROL_MODE_MOBILE)
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	_refresh_furnace_ui()

func _close_furnace() -> void:
	furnace_layer.visible = false
	furnace_ui_cell = Vector3i(-1, -1, -1)
	rmb_down = false
	rmb_visited.clear()
	if cursor_item["id"] != 0:
		add_item(cursor_item["id"], cursor_item["n"])
		cursor_item = {"id": 0, "n": 0}
	inv_open = false
	_refresh_slots()
	_apply_control_mode()

func _refresh_furnace_ui() -> void:
	if furnace_ui_cell == Vector3i(-1, -1, -1):
		return
	var f := _get_furnace(furnace_ui_cell)
	_show_item(furnace_slots_ui[0], f["input"])
	_show_item(furnace_slots_ui[1], f["fuel"])
	_show_item(furnace_slots_ui[2], f["output"])

	var flame_bar = furnace_layer.find_child("FlameBar", true, false)
	var arrow_bar = furnace_layer.find_child("ArrowBar", true, false)
	if arrow_bar:
		arrow_bar.value = float(f["progress"])
	if flame_bar:
		if float(f["burn"]) > 0.0:
			flame_bar.value = clampf(float(f["burn"]) / float(f.get("burn_max", 80.0)), 0.0, 1.0) * 100.0
		else:
			flame_bar.value = 0.0

	for i in range(HOTBAR, TOTAL_SLOTS):
		_show_item(furnace_inv_ui[i - HOTBAR], slots[i])
	for i in HOTBAR:
		_show_item(furnace_hot_ui[i], slots[i])

	_show_item(cursor_ui, cursor_item)
	cursor_ui["btn"].visible = inv_open and cursor_item["id"] != 0

func _update_furnaces(delta: float) -> void:
	for k in furnaces.keys():
		var f: Dictionary = furnaces[k]
		var inp: Dictionary = f["input"]
		var fuel: Dictionary = f["fuel"]
		var out: Dictionary = f["output"]

		var can_smelt: bool = inp["id"] != 0 and SMELTING.has(int(inp["id"]))
		if can_smelt:
			var res_id: int = int(SMELTING[int(inp["id"])])
			can_smelt = out["id"] == 0 or (out["id"] == res_id and int(out["n"]) < MAX_STACK)

		if f["burn"] <= 0.0 and can_smelt and fuel["id"] != 0 and FUEL.has(int(fuel["id"])):
			f["burn"] = float(FUEL[int(fuel["id"])])
			f["burn_max"] = f["burn"]
			fuel["n"] -= 1
			if fuel["n"] <= 0:
				f["fuel"] = {"id": 0, "n": 0}

		if f["burn"] > 0.0:
			f["burn"] -= delta
			if can_smelt:
				f["progress"] += delta
				if f["progress"] >= SMELT_TIME:
					f["progress"] = 0.0
					var res: int = int(SMELTING[int(inp["id"])])
					inp["n"] -= 1
					if inp["n"] <= 0:
						f["input"] = {"id": 0, "n": 0}
					if out["id"] == 0:
						f["output"] = {"id": res, "n": 1}
					else:
						out["n"] += 1
			else:
				f["progress"] = 0.0
		else:
			f["progress"] = maxf(0.0, f["progress"] - delta * 2.0)

		if inv_open and furnace_ui_cell == k:
			_refresh_furnace_ui()

# ---------------- сундук ----------------

func _make_chest_ui() -> void:
	chest_layer = CanvasLayer.new()
	chest_layer.layer = 6
	chest_layer.visible = false
	add_child(chest_layer)

	var dim := ColorRect.new()
	dim.color = Color(0, 0, 0, 0.6)
	chest_layer.add_child(dim)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	var center := CenterContainer.new()
	chest_layer.add_child(center)
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	var panel := PanelContainer.new()
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.7, 0.7, 0.7)
	sb.set_border_width_all(3)
	sb.border_color = Color(0.2, 0.2, 0.2)
	panel.add_theme_stylebox_override("panel", sb)
	center.add_child(panel)

	var margin := MarginContainer.new()
	for side in ["left", "right", "top", "bottom"]:
		margin.add_theme_constant_override("margin_" + side, 12)
	panel.add_child(margin)

	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 8)
	margin.add_child(box)

	var header := HBoxContainer.new()
	box.add_child(header)
	chest_title_lbl = Label.new()
	chest_title_lbl.text = "Сундук"
	chest_title_lbl.add_theme_font_size_override("font_size", 20)
	chest_title_lbl.add_theme_color_override("font_color", Color(0.2, 0.2, 0.2))
	header.add_child(chest_title_lbl)
	close_x.attach_to_header(header, _close_chest)

	var c_grid := GridContainer.new()
	c_grid.columns = 9
	c_grid.add_theme_constant_override("h_separation", 4)
	c_grid.add_theme_constant_override("v_separation", 4)
	box.add_child(c_grid)

	chest_slots_ui.clear()
	for i in 54:
		var s := _make_slot(40, true)
		s["btn"].pressed.connect(_on_chest_slot.bind(i))
		s["btn"].gui_input.connect(_slot_gui_input.bind("k", i))
		c_grid.add_child(s["btn"])
		chest_slots_ui.append(s)

	box.add_child(HSeparator.new())

	var inv_lbl := Label.new()
	inv_lbl.text = "Инвентарь"
	inv_lbl.add_theme_font_size_override("font_size", 18)
	inv_lbl.add_theme_color_override("font_color", Color(0.2, 0.2, 0.2))
	box.add_child(inv_lbl)

	chest_inv_ui.clear()
	chest_hot_ui.clear()
	var grid := GridContainer.new()
	grid.columns = 9
	grid.add_theme_constant_override("h_separation", 4)
	grid.add_theme_constant_override("v_separation", 4)
	box.add_child(grid)
	for i in range(HOTBAR, TOTAL_SLOTS):
		var s := _make_slot(40, true)
		s["btn"].pressed.connect(_on_slot_pressed.bind(i))
		s["btn"].gui_input.connect(_slot_gui_input.bind("s", i))
		grid.add_child(s["btn"])
		chest_inv_ui.append(s)

	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 4)
	box.add_child(row)
	for i in HOTBAR:
		var s := _make_slot(40, true)
		s["btn"].pressed.connect(_on_slot_pressed.bind(i))
		s["btn"].gui_input.connect(_slot_gui_input.bind("s", i))
		row.add_child(s["btn"])
		chest_hot_ui.append(s)

func _get_chest_group(cell: Vector3i) -> Dictionary:
	var dirs := [Vector3i(1, 0, 0), Vector3i(-1, 0, 0), Vector3i(0, 0, 1), Vector3i(0, 0, -1)]
	for d in dirs:
		if get_block(cell.x + d.x, cell.y, cell.z + d.z) == CHEST:
			var origin := Vector3i(mini(cell.x, cell.x + d.x), cell.y, mini(cell.z, cell.z + d.z))
			return {"origin": origin, "double": true}
	return {"origin": cell, "double": false}

func _get_chest_inventory(origin: Vector3i, is_double: bool) -> Array:
	var size := 54 if is_double else 27
	if not chests.has(origin):
		var loot: Array = []
		for j in 27: loot.append({"id": 0, "n": 0})
		var loot_rng := RandomNumberGenerator.new()
		loot_rng.seed = world_seed + origin.x * 7919 + origin.z * 104729
		var loot_ids := [COAL_ITEM, IRON_INGOT, RAW_IRON, STICK, DIAMOND, TORCH, BONE, COOKED_PORK, RAIL, PLANKS, D_PICKAXE, I_PICKAXE]
		var loot_amounts := [4, 2, 3, 6, 1, 4, 2, 3, 8, 12, 1, 1]
		var entries := loot_rng.randi_range(5, 9)
		for j in entries:
			var li := loot_rng.randi_range(0, 26)
			if loot_rng.randf() < 0.035:
				loot[li] = {"id": loot_rng.randi_range(MUSIC_DISC_1, MUSIC_DISC_5), "n": 1}
			else:
				var reward := loot_rng.randi_range(0, loot_ids.size() - 1)
				loot[li] = {"id": loot_ids[reward], "n": loot_amounts[reward] if reward >= 9 else loot_rng.randi_range(1, loot_amounts[reward])}
		if loot_rng.randf() < 0.08:
			loot[loot_rng.randi_range(0, 26)] = {"id": TREASURE_MAP, "n": 1}
		chests[origin] = loot
	var inv: Array = chests[origin]
	while inv.size() < size:
		inv.append({"id": 0, "n": 0})
	return inv

func _open_chest(cell: Vector3i) -> void:
	var group := _get_chest_group(cell)
	var origin: Vector3i = group["origin"]
	chest_is_double = bool(group["double"])
	_get_chest_inventory(origin, chest_is_double)
	chest_ui_cell = origin
	inv_open = true
	breaking = false
	blocking = false
	if mobile_hud != null:
		mobile_hud.visible = false
	inv_layer.visible = false
	chest_layer.visible = true
	close_x.set_mobile(control_mode == CONTROL_MODE_MOBILE)
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	chest_title_lbl.text = "Двойной сундук" if chest_is_double else "Сундук"
	for i in 54:
		chest_slots_ui[i]["btn"].visible = i < (54 if chest_is_double else 27)
	_refresh_chest_ui()

func _close_chest() -> void:
	chest_layer.visible = false
	chest_ui_cell = Vector3i(-1, -1, -1)
	rmb_down = false
	rmb_visited.clear()
	if cursor_item["id"] != 0:
		add_item(cursor_item["id"], cursor_item["n"])
		cursor_item = {"id": 0, "n": 0}
	inv_open = false
	_refresh_slots()
	_apply_control_mode()

func _on_chest_slot(i: int) -> void:
	if chest_ui_cell == Vector3i(-1, -1, -1):
		return
	var inv := _get_chest_inventory(chest_ui_cell, chest_is_double)
	_click_slot(inv, i)

func _refresh_chest_ui() -> void:
	if chest_ui_cell == Vector3i(-1, -1, -1):
		return
	var inv := _get_chest_inventory(chest_ui_cell, chest_is_double)
	for i in inv.size():
		_show_item(chest_slots_ui[i], inv[i])
	for i in range(HOTBAR, TOTAL_SLOTS):
		_show_item(chest_inv_ui[i - HOTBAR], slots[i])
	for i in HOTBAR:
		_show_item(chest_hot_ui[i], slots[i])
	_show_item(cursor_ui, cursor_item)
	cursor_ui["btn"].visible = cursor_item["id"] != 0

func _create_pig(pos: Vector3) -> CharacterBody3D:
	var pig = CharacterBody3D.new()
	pig.set_script(load("res://pig.gd"))
	pig.position = pos
	pig.set("world_controller", self)
	pig.add_to_group("darecraft_mob")
	pig.add_to_group("mob_pig")

	var col = CollisionShape3D.new()
	var shape = BoxShape3D.new()
	shape.size = Vector3(0.9, 0.9, 1.4)
	col.shape = shape
	col.position.y = 0.45
	pig.add_child(col)

	var pink = _color_mat(Color(0.95, 0.65, 0.65))
	var dark_pink = _color_mat(Color(0.85, 0.5, 0.5))
	var black = _color_mat(Color.BLACK)

	_box(pig, Vector3(0.9, 0.9, 1.4), Vector3(0, 0.45, 0), pink)

	var head = Node3D.new()
	head.position = Vector3(0, 0.6, 0.8)
	pig.add_child(head)
	_box(head, Vector3(0.7, 0.7, 0.7), Vector3.ZERO, pink)
	_box(head, Vector3(0.4, 0.3, 0.1), Vector3(0, -0.1, 0.35), dark_pink)
	_box(head, Vector3(0.1, 0.1, 0.05), Vector3(0.2, 0.15, 0.35), black)
	_box(head, Vector3(0.1, 0.1, 0.05), Vector3(-0.2, 0.15, 0.35), black)

	var legs: Array[Node3D] = []
	for x in [-0.3, 0.3]:
		for z in [-0.5, 0.5]:
			var leg_pivot := Node3D.new()
			leg_pivot.position = Vector3(x, 0.15, z)
			pig.add_child(leg_pivot)
			_box(leg_pivot, Vector3(0.25, 0.4, 0.25), Vector3(0, -0.2, 0), dark_pink)
			legs.append(leg_pivot)
	pig.set("leg_pivots", legs)
	return pig

func _gen_trees_in_chunk(cx: int, cz: int) -> void:
	var ox := cx * CS
	var oz := cz * CS
	for lx in CS:
		for lz in CS:
			var x := ox + lx
			var z := oz + lz
			var rng := RandomNumberGenerator.new()
			rng.seed = hash(Vector2i(x, z)) + world_seed
			var biome := _biome_at(x, z)
			var density := 0.008
			if biome == BIOME_JUNGLE:
				density = 0.024
			elif biome == BIOME_SWAMP:
				density = 0.005
			elif biome == BIOME_FOREST:
				density = 0.014
			if biome == BIOME_DESERT or biome == BIOME_SNOW or biome == BIOME_ROCKY or rng.randf() > density:
				continue

			var h: int = _height_at(x, z)
			# Деревья не растут в океане и на прибрежном песке.
			if h <= 17 or h >= ROCK_LEVEL - 2:
				continue
			if get_block(x, h, z) != GRASS and not (biome == BIOME_SWAMP and get_block(x, h, z) == GRAVEL):
				continue

			var th := rng.randi_range(6, 9) if biome == BIOME_JUNGLE else (rng.randi_range(3, 5) if biome == BIOME_SWAMP else rng.randi_range(4, 6))
			for y in range(h + 1, h + th + 1):
				_put(x, y, z, LOG)
			for dy in range(-1, 3):
				var r := 2 if dy <= 0 else 1
				for dx in range(-r, r + 1):
					for dz in range(-r, r + 1):
						if r == 2 and abs(dx) == 2 and abs(dz) == 2:
							continue
						_put(x + dx, h + th + dy, z + dz, LEAVES)


func _append_network_chat(nick: String, message: String) -> void:
	if chat_history == null:
		return
	var line := "%s: %s" % [nick, message]
	chat_history.text = (chat_history.text + "\n" + line).right(1200)

# ---------------- DareCraft Online: WebSocket room relay ----------------

func _connect_client_before_world() -> void:
	# A guest must receive the host's world seed before terrain is generated.
	net_is_host = false
	net_socket = WebSocketPeer.new()
	var relay_url: String = str(Global.network_server_url).strip_edges()
	if not (relay_url.begins_with("wss://") or relay_url.begins_with("ws://")):
		_show_msg("Сеть: неверный адрес WSS-релея")
		net_socket = null
		Global.network_mode = "offline"
		return
	var err := net_socket.connect_to_url(relay_url)
	if err != OK:
		_show_msg("Сеть: не удалось подключиться (%s)" % error_string(err))
		net_socket = null
		Global.network_mode = "offline"
		return
	var handshake_sent := false
	var joined := false
	var failure_message := "Сервер не ответил за 20 секунд."
	for frame_index in range(400):
		net_socket.poll()
		if net_socket.get_ready_state() == WebSocketPeer.STATE_OPEN and not handshake_sent:
			_net_send_json({"type": "join", "code": Global.network_room_code, "name": Global.network_player_name})
			handshake_sent = true
			net_handshake_sent = true
		while net_socket.get_available_packet_count() > 0:
			var raw := net_socket.get_packet().get_string_from_utf8()
			var parsed: Variant = JSON.parse_string(raw)
			if not (parsed is Dictionary):
				continue
			var packet_type := str(parsed.get("type", ""))
			if packet_type == "joined":
				net_peer_id = int(parsed.get("peer_id", 0))
				net_host_peer_id = int(parsed.get("host_peer_id", 1))
				var host_seed := int(parsed.get("seed", 0))
				var valid_seed := (host_seed >= 1 and host_seed <= 1235) or (host_seed >= 10001 and host_seed <= 10100)
				if net_peer_id > 1 and valid_seed:
					Global.pending_world_seed = host_seed
					net_connected = net_peer_id > 1 and host_seed > 0
					Global.network_room_code = str(parsed.get("code", Global.network_room_code))
					joined = net_connected
				else:
					failure_message = "Сервер вернул неверный сид мира."
				break
			elif packet_type == "error":
				failure_message = str(parsed.get("message", "Комната не найдена."))
				break
			else:
				net_pending_packets.append(parsed)
		if joined:
			break
		if net_socket.get_ready_state() == WebSocketPeer.STATE_CLOSED:
			failure_message = "Соединение с сервером закрыто."
			break
		await get_tree().process_frame
	if not joined:
		if net_socket != null:
			net_socket.close()
		net_socket = null
		net_connected = false
		Global.network_mode = "offline"
		Global.pending_world_seed = 0
		_show_msg("Не удалось войти в комнату: " + failure_message)


func _start_network_session() -> void:
	if Global.network_mode == "offline":
		return
	if net_socket != null and net_connected:
		# Client already joined before world generation. Now its player node exists.
		_net_send_event({"type": "player_state_request", "peer_id": net_peer_id, "pos": _net_vec3_to_array(player.global_position), "yaw": player.rotation.y, "skin": Global.selected_skin, "appearance": _net_skin_appearance()})
		_show_msg("Подключено к комнате " + Global.network_room_code)
		return
	net_is_host = Global.network_mode == "host"
	net_peer_id = 0
	net_host_peer_id = 1
	net_connected = false
	net_handshake_sent = false
	net_changed_blocks.clear()
	net_pending_packets.clear()
	net_pickup_pending.clear()
	net_connect_elapsed = 0.0
	net_storage_timer = 0.0
	net_last_storage_signature = ""
	net_storage_ready = false
	net_socket = WebSocketPeer.new()
	var relay_url: String = str(Global.network_server_url).strip_edges()
	if not (relay_url.begins_with("wss://") or relay_url.begins_with("ws://")):
		_show_msg("Сеть: неверный адрес WSS-релея")
		Global.network_mode = "offline"
		return
	var err := net_socket.connect_to_url(relay_url)
	if err != OK:
		_show_msg("Сеть: не удалось начать подключение (%s)" % error_string(err))
		Global.network_mode = "offline"
		return
	_show_msg("Подключаемся к серверу комнат...")


func _net_send_json(packet: Dictionary) -> void:
	if net_socket == null or net_socket.get_ready_state() != WebSocketPeer.STATE_OPEN:
		return
	net_socket.send_text(JSON.stringify(packet))


func _net_send_event(payload: Dictionary, target_peer_id: int = 0) -> void:
	if not net_connected:
		return
	var packet := {"type": "data", "payload": payload}
	if target_peer_id > 0:
		packet["to"] = target_peer_id
	_net_send_json(packet)


func _net_vec3_to_array(v: Vector3) -> Array:
	return [v.x, v.y, v.z]


func _net_array_to_vec3(value: Variant) -> Vector3:
	if value is Array and value.size() >= 3:
		return Vector3(float(value[0]), float(value[1]), float(value[2]))
	return Vector3.ZERO


func _net_update_status(message: String) -> void:
	_show_msg(message)
	if net_status_label != null:
		if not Global.network_room_code.is_empty():
			net_status_label.text = "Код комнаты: %s\n%s" % [Global.network_room_code, message]
		else:
			net_status_label.text = message
		net_status_label.visible = true


func _update_network_sync(delta: float) -> void:
	if net_socket == null:
		return
	net_socket.poll()
	if net_is_host and net_connected and not net_snapshot_send_queue.is_empty():
		net_snapshot_send_timer -= delta
		if net_snapshot_send_timer <= 0.0:
			var queued_snapshot_packet: Dictionary = net_snapshot_send_queue.pop_front()
			_net_send_event(queued_snapshot_packet.get("payload", {}), int(queued_snapshot_packet.get("to", 0)))
			net_snapshot_send_timer = 0.012
	if not net_pending_packets.is_empty():
		var queued_packets := net_pending_packets.duplicate()
		net_pending_packets.clear()
		for queued_packet in queued_packets:
			_net_handle_server_packet(queued_packet)
	var state := net_socket.get_ready_state()
	if not net_connected and state != WebSocketPeer.STATE_CLOSED:
		net_connect_elapsed += delta
		if net_connect_elapsed > 20.0:
			_net_update_status("Не удалось связаться с сервером-релеем за 20 секунд.")
			Global.network_mode = "offline"
			net_socket.close()
			return
	if state == WebSocketPeer.STATE_OPEN and not net_handshake_sent:
		if net_is_host:
			_net_send_json({"type": "create", "name": Global.network_player_name, "seed": world_seed})
		else:
			_net_send_json({"type": "join", "code": Global.network_room_code, "name": Global.network_player_name})
		net_handshake_sent = true
	if state == WebSocketPeer.STATE_OPEN:
		while net_socket.get_available_packet_count() > 0:
			var raw := net_socket.get_packet().get_string_from_utf8()
			var parsed: Variant = JSON.parse_string(raw)
			if parsed is Dictionary:
				_net_handle_server_packet(parsed)
	elif state == WebSocketPeer.STATE_CLOSED:
		var was_connected := net_connected
		net_connected = false
		for peer_id in net_remote_players.keys():
			_remove_remote_player(int(peer_id))
		if was_connected:
			if net_is_host:
				_net_update_status("Сервер-релей отключён. Комната закрыта.")
			else:
				_net_update_status("Соединение с комнатой потеряно.")
		else:
			_net_update_status("Не удалось подключиться к серверу-релею. Проверь адрес и доступность сервера.")
		Global.network_mode = "offline"
		return
	if not net_connected or player == null:
		return
	net_sync_timer -= delta
	if net_sync_timer <= 0.0:
		net_sync_timer = 0.10
		var player_state := {
			"type": "player_state",
			"peer_id": net_peer_id,
			"pos": _net_vec3_to_array(player.global_position),
			"yaw": player.rotation.y,
			"skin": Global.selected_skin,
			"appearance": _net_skin_appearance()
		}
		if net_is_host:
			player_state["peer_id"] = 1
			_net_send_event(player_state)
		else:
			player_state["type"] = "player_state_request"
			_net_send_event(player_state)
	if net_is_host:
		net_world_clock_timer -= delta
		if net_world_clock_timer <= 0.0:
			net_world_clock_timer = 1.0
			_net_send_event({"type": "world_clock", "cycle_time": cycle_time, "day_count": day_count})
		net_mob_sync_timer -= delta
		if net_mob_sync_timer <= 0.0:
			net_mob_sync_timer = 0.20
			_net_broadcast_mob_state()
		net_raft_sync_timer -= delta
		if net_raft_sync_timer <= 0.0:
			net_raft_sync_timer = 0.20
			_net_broadcast_raft_states()
		net_physics_sync_timer -= delta
		if net_physics_sync_timer <= 0.0:
			net_physics_sync_timer = 0.10
			_net_broadcast_physics_states()
	elif riding_raft != null and is_instance_valid(riding_raft) and raft_is_driving:
		raft_motion_sync_timer -= delta
		if raft_motion_sync_timer <= 0.0:
			raft_motion_sync_timer = 0.15
			_net_send_event({"type": "raft_state_request", "raft_id": int(riding_raft.get_meta("raft_id", 0)), "pos": _net_vec3_to_array(riding_raft.position), "yaw": riding_raft.rotation.y})
	_net_sync_shared_storage(delta)


func _net_broadcast_physics_states() -> void:
	var rows: Array = []
	for body_id in physics_bodies.keys():
		var body: RigidBody3D = physics_bodies[body_id] as RigidBody3D
		if not is_instance_valid(body) or body.is_queued_for_deletion():
			continue
		rows.append({
			"id": int(body_id),
			"pos": _net_vec3_to_array(body.global_position),
			"rot": _net_vec3_to_array(body.global_rotation),
			"vel": _net_vec3_to_array(body.linear_velocity),
			"ang": _net_vec3_to_array(body.angular_velocity)
		})
	_net_send_event({"type": "physics_state", "bodies": rows})

func _apply_network_physics_state(raw_bodies: Variant) -> void:
	if not (raw_bodies is Array):
		return
	var seen: Dictionary = {}
	for row in raw_bodies:
		if not (row is Dictionary):
			continue
		var body_id := int(row.get("id", 0))
		if body_id <= 0:
			continue
		seen[body_id] = true
		var body: RigidBody3D = physics_bodies.get(body_id) as RigidBody3D
		if body == null or not is_instance_valid(body):
			continue
		var target_pos := _net_array_to_vec3(row.get("pos", []))
		var target_rot := _net_array_to_vec3(row.get("rot", []))
		body.global_position = target_pos
		body.global_rotation = target_rot
		body.linear_velocity = _net_array_to_vec3(row.get("vel", []))
		body.angular_velocity = _net_array_to_vec3(row.get("ang", []))
	for old_id in physics_bodies.keys():
		if not seen.has(old_id):
			var old_body: RigidBody3D = physics_bodies[old_id] as RigidBody3D
			if is_instance_valid(old_body):
				old_body.queue_free()
			physics_bodies.erase(old_id)


func _net_collect_mob_rows() -> Array:
	var rows: Array = []
	for mob in get_tree().get_nodes_in_group("darecraft_mob"):
		if not is_instance_valid(mob) or mob.is_queued_for_deletion():
			continue
		var mob_type := "zombie"
		if mob.is_in_group("mob_pig"):
			mob_type = "pig"
		elif mob.is_in_group("mob_spider"):
			mob_type = "spider"
		elif mob.is_in_group("mob_skeleton"):
			mob_type = "skeleton"
		var surface_normal := Vector3.UP
		if mob_type == "spider":
			var normal_value: Variant = mob.get("surface_normal")
			if normal_value is Vector3:
				surface_normal = normal_value
		var mob_velocity := Vector3.ZERO
		if mob is CharacterBody3D:
			mob_velocity = (mob as CharacterBody3D).velocity
		var attack_active := false
		if mob_type != "pig":
			var attack_value: Variant = mob.get("attack_anim_timer")
			if attack_value != null:
				attack_active = float(attack_value) > 0.0
		rows.append({
			"id": int(mob.get_instance_id()),
			"kind": mob_type,
			"pos": _net_vec3_to_array(mob.global_position),
			"yaw": mob.rotation.y,
			"vel": _net_vec3_to_array(mob_velocity),
			"normal": _net_vec3_to_array(surface_normal),
			"attack": attack_active
		})
	return rows

func _net_broadcast_mob_state() -> void:
	_net_send_event({"type": "mob_state", "mobs": _net_collect_mob_rows()})

func _net_broadcast_raft_states() -> void:
	for raft in raft_nodes:
		if not is_instance_valid(raft):
			continue
		_net_send_event({"type": "raft_state", "raft_id": int(raft.get_meta("raft_id", 0)), "pos": _net_vec3_to_array(raft.position), "yaw": raft.rotation.y})

func _net_apply_mob_state(rows: Variant) -> void:
	if not (rows is Array):
		return
	var seen: Dictionary = {}
	for row in rows:
		if not (row is Dictionary):
			continue
		var mob_id := int(row.get("id", -1))
		if mob_id < 0:
			continue
		seen[mob_id] = true
		var kind := str(row.get("kind", "zombie"))
		var mob: Node3D = net_remote_mobs.get(mob_id) as Node3D
		if mob != null and is_instance_valid(mob) and str(mob.get_meta("network_kind", "")) != kind:
			mob.queue_free()
			mob = null
		if mob == null or not is_instance_valid(mob):
			mob = CharacterBody3D.new()
			if kind == "pig":
				mob = _create_pig(Vector3.ZERO)
			elif kind == "spider":
				mob.set_script(load("res://spider.gd"))
			elif kind == "skeleton":
				mob.set_script(load("res://skeleton.gd"))
			else:
				mob.set_script(load("res://zombie.gd"))
			if kind != "pig":
				mob.set("target", null)
				mob.set("world_controller", null)
			mob.set_meta("network_remote_mob", true)
			mob.set_meta("network_kind", kind)
			add_child(mob)
			if mob is CharacterBody3D:
				mob.collision_layer = 0
				mob.collision_mask = 0
			net_remote_mobs[mob_id] = mob
		var target_pos := _net_array_to_vec3(row.get("pos", []))
		var target_yaw := float(row.get("yaw", 0.0))
		if not mob.has_meta("network_target_position") or mob.global_position.distance_to(target_pos) > 8.0:
			mob.global_position = target_pos
		mob.set_meta("network_target_position", target_pos)
		mob.set_meta("network_target_yaw", target_yaw)
		mob.set_meta("network_velocity", _net_array_to_vec3(row.get("vel", [])))
		mob.set_meta("network_surface_normal", _net_array_to_vec3(row.get("normal", [0.0, 1.0, 0.0])))
		mob.set_meta("network_attack", bool(row.get("attack", false)))
	for old_id in net_remote_mobs.keys():
		if not seen.has(old_id):
			var old_mob: Node3D = net_remote_mobs[old_id] as Node3D
			if is_instance_valid(old_mob):
				old_mob.queue_free()
			net_remote_mobs.erase(old_id)

func _net_handle_server_packet(packet: Dictionary) -> void:
	var packet_type := str(packet.get("type", ""))
	match packet_type:
		"created":
			net_peer_id = int(packet.get("peer_id", 1))
			net_storage_ready = true
			net_handshake_sent = true
			net_connected = true
			net_connect_elapsed = 0.0
			Global.network_room_code = str(packet.get("code", ""))
			_net_update_status("Комната создана: " + Global.network_room_code + " · 1/8")
			_net_send_event({"type": "player_state", "peer_id": 1, "pos": _net_vec3_to_array(player.global_position), "yaw": player.rotation.y, "skin": Global.selected_skin, "appearance": _net_skin_appearance()})
		"joined":
			net_peer_id = int(packet.get("peer_id", 0))
			net_handshake_sent = true
			net_host_peer_id = int(packet.get("host_peer_id", 1))
			net_connected = net_peer_id > 1
			if net_connected:
				net_connect_elapsed = 0.0
				_net_update_status("Подключено к миру хоста! Игрок %d/8" % net_peer_id)
				_net_send_event({"type": "player_state_request", "peer_id": net_peer_id, "pos": _net_vec3_to_array(player.global_position), "yaw": player.rotation.y, "skin": Global.selected_skin, "appearance": _net_skin_appearance()})
		"room_state":
			pass
		"peer_joined":
			var joined_id := int(packet.get("peer_id", 0))
			if net_is_host and joined_id > 1:
				_net_send_initial_state(joined_id)
				_net_update_status("Игрок подключился (%d/8)" % int(packet.get("count", 1)))
		"peer_left":
			var left_id := int(packet.get("peer_id", 0))
			_remove_remote_player(left_id)
			# Drop any unsent world snapshot packets for a player who left.
			for queue_index in range(net_snapshot_send_queue.size() - 1, -1, -1):
				if int(net_snapshot_send_queue[queue_index].get("to", 0)) == left_id:
					net_snapshot_send_queue.remove_at(queue_index)
			_net_update_status("Игрок %d вышел" % left_id)
		"host_left":
			net_connected = false
			_net_update_status("Хозяин мира отключился. Комната закрыта.")
			if net_socket != null:
				net_socket.close()
		"data":
			var sender_id := int(packet.get("from", 0))
			var payload: Variant = packet.get("payload", {})
			if payload is Dictionary:
				_net_handle_game_event(payload, sender_id)
		"error":
			_net_update_status("Сервер: " + str(packet.get("message", "ошибка подключения")))
			if not net_connected:
				Global.network_mode = "offline"
				if net_socket != null:
					net_socket.close()


func _net_handle_game_event(payload: Dictionary, sender_id: int) -> void:
	var event_type := str(payload.get("type", ""))
	if net_is_host:
		if sender_id <= 1:
			return
		match event_type:
			"achievement_announce_request":
				var achievement_id := str(payload.get("id", ""))
				if not Achievements.DEFINITIONS.has(achievement_id):
					return
				var achievement_definition: Dictionary = Achievements.DEFINITIONS[achievement_id]
				if str(achievement_definition.get("scope", "")) != "world":
					return
				var announce_nick := str(payload.get("nick", "Игрок")).strip_edges().substr(0, 20)
				if announce_nick.is_empty():
					return
				var announce_title := str(achievement_definition.get("title", "Достижение"))
				var announce_description := str(achievement_definition.get("description", ""))
				_display_achievement_announcement(announce_nick, announce_title, announce_description)
				_net_send_event({"type": "achievement_announce", "id": achievement_id, "nick": announce_nick, "title": announce_title, "peer_id": sender_id})
			"sleep_request":
				if cycle_time < DAY_LENGTH or not net_remote_players.has(sender_id):
					return
				sleep_votes[sender_id] = true
				_update_sleep_vote_status()
			"emote_request":
				var emote_id := clampi(int(payload.get("emote", 0)), 0, EMOTE_NAMES.size() - 1)
				_net_send_event({"type": "emote", "peer_id": sender_id, "emote": emote_id})
				_play_remote_emote(sender_id, emote_id)
			"player_state_request":
				var pos := _net_array_to_vec3(payload.get("pos", []))
				if absf(pos.x) > WORLD_SIZE + 10 or absf(pos.z) > WORLD_SIZE + 10 or pos.y < -30 or pos.y > WORLD_H + 60:
					return
				var skin := clampi(int(payload.get("skin", 0)), 0, Global.SKIN_PRESETS.size())
				var appearance: Dictionary = payload.get("appearance", {}) if payload.get("appearance", {}) is Dictionary else {}
				_network_set_player_state(sender_id, pos, float(payload.get("yaw", 0.0)), skin, appearance)
				_net_send_event({"type": "player_state", "peer_id": sender_id, "pos": _net_vec3_to_array(pos), "yaw": float(payload.get("yaw", 0.0)), "skin": skin, "appearance": appearance})
				if cycle_time >= DAY_LENGTH and not sleep_votes.is_empty():
					_update_sleep_vote_status()
			"block_request":
				var cell_arr: Variant = payload.get("cell", [])
				if not (cell_arr is Array) or cell_arr.size() < 3:
					return
				var cell := Vector3i(int(cell_arr[0]), int(cell_arr[1]), int(cell_arr[2]))
				var block_id := int(payload.get("id", 0))
				var avatar: Node3D = net_remote_players.get(sender_id) as Node3D
				if avatar == null or block_id < 0 or block_id > SNOW:
					return
				if cell.x < 0 or cell.x >= WORLD_SIZE or cell.z < 0 or cell.z >= WORLD_SIZE or cell.y < 0 or cell.y >= WORLD_H:
					return
				if avatar.global_position.distance_to(Vector3(cell) + Vector3(0.5, 0.5, 0.5)) > 9.0:
					return
				_set_block_local(cell, block_id)
				_net_record_block(cell, block_id)
				_net_send_event({"type": "block_set", "cell": [cell.x, cell.y, cell.z], "id": block_id})
				if block_id == 0:
					_physics_after_block_removed(cell)
			"drop_request":
				var item_id := int(payload.get("item_id", 0))
				var amount := int(payload.get("amount", 0))
				var pos := _net_array_to_vec3(payload.get("pos", []))
				var avatar: Node3D = net_remote_players.get(sender_id) as Node3D
				if avatar == null or item_id <= 0 or item_id > TREASURE_MAP or amount <= 0 or amount > MAX_STACK:
					return
				if avatar.global_position.distance_to(pos) > 5.0:
					return
				_server_create_drop(item_id, amount, pos)
				_net_send_event({"type": "drop_spawn", "drop_id": next_drop_id - 1, "item_id": item_id, "amount": amount, "pos": _net_vec3_to_array(pos)})
			"pickup_request":
				var drop_id := int(payload.get("drop_id", 0))
				if not dropped_items.has(drop_id):
					return
				var avatar: Node3D = net_remote_players.get(sender_id) as Node3D
				var entry: Dictionary = dropped_items[drop_id]
				var drop_node: Node3D = entry.get("node") as Node3D
				if avatar == null or not is_instance_valid(drop_node) or avatar.global_position.distance_to(drop_node.global_position) > 2.6:
					return
				var item_id := int(entry.get("id", 0))
				var amount := int(entry.get("amount", 0))
				_remove_drop_local(drop_id)
				_net_send_event({"type": "drop_remove", "drop_id": drop_id})
				_net_send_event({"type": "pickup_result", "item_id": item_id, "amount": amount}, sender_id)
			"raft_spawn_request":
				var raft_pos := _net_array_to_vec3(payload.get("pos", []))
				var raft_yaw := float(payload.get("yaw", 0.0))
				var avatar: Node3D = net_remote_players.get(sender_id) as Node3D
				if avatar == null or avatar.global_position.distance_to(raft_pos) > 8.0 or not _raft_area_is_water(raft_pos, raft_yaw):
					return
				var new_raft := _create_raft(raft_pos, 0, raft_yaw)
				_net_send_event({"type": "raft_spawn", "raft_id": int(new_raft.get_meta("raft_id", 0)), "pos": _net_vec3_to_array(new_raft.position), "yaw": new_raft.rotation.y, "blocks": []})
			"raft_state_request":
				var raft_id := int(payload.get("raft_id", 0))
				var moving_raft := _get_raft_by_id(raft_id)
				var avatar: Node3D = net_remote_players.get(sender_id) as Node3D
				var requested_pos := _net_array_to_vec3(payload.get("pos", []))
				var requested_yaw := float(payload.get("yaw", moving_raft.rotation.y if moving_raft != null else 0.0))
				if moving_raft == null or avatar == null or avatar.global_position.distance_to(moving_raft.global_position) > 8.0:
					return
				if not _raft_area_is_water(requested_pos, requested_yaw):
					return
				moving_raft.position = Vector3(requested_pos.x, 14.95, requested_pos.z)
				moving_raft.rotation.y = requested_yaw
				_net_send_event({"type": "raft_state", "raft_id": raft_id, "pos": _net_vec3_to_array(moving_raft.position), "yaw": moving_raft.rotation.y})
			"raft_block_request":
				var raft_id := int(payload.get("raft_id", 0))
				var building_raft := _get_raft_by_id(raft_id)
				var avatar: Node3D = net_remote_players.get(sender_id) as Node3D
				var cell_data: Variant = payload.get("cell", [])
				var block_id := int(payload.get("id", 0))
				if building_raft == null or avatar == null or avatar.global_position.distance_to(building_raft.global_position) > 14.0:
					return
				if not (cell_data is Array) or cell_data.size() < 3 or not TILES.has(block_id):
					return
				var raft_cell := Vector3i(int(cell_data[0]), int(cell_data[1]), int(cell_data[2]))
				if _add_raft_block_local(building_raft, raft_cell, block_id):
					_net_send_event({"type": "raft_block_set", "raft_id": raft_id, "cell": [raft_cell.x, raft_cell.y, raft_cell.z], "id": block_id})
			"raft_block_remove_request":
				var raft_id := int(payload.get("raft_id", 0))
				var building_raft: Node3D = _get_raft_by_id(raft_id)
				var avatar: Node3D = net_remote_players.get(sender_id) as Node3D
				var cell_data: Variant = payload.get("cell", [])
				if building_raft == null or avatar == null or avatar.global_position.distance_to(building_raft.global_position) > 14.0 or not (cell_data is Array) or cell_data.size() < 3:
					return
				var raft_cell := Vector3i(int(cell_data[0]), int(cell_data[1]), int(cell_data[2]))
				if _remove_raft_block_local(building_raft, raft_cell) > 0:
					_net_send_event({"type": "raft_block_remove", "raft_id": raft_id, "cell": [raft_cell.x, raft_cell.y, raft_cell.z]})
			"storage_request":
				var incoming_state: Variant = payload.get("state", {})
				if incoming_state is Dictionary:
					_net_apply_storage_state(incoming_state)
					var accepted_state := _net_build_storage_state()
					net_last_storage_signature = JSON.stringify(accepted_state)
					_net_send_event({"type": "storage_state", "state": accepted_state})
			"music_play_request":
				var disc := clampi(int(payload.get("disc_id", MUSIC_DISC_1)), MUSIC_DISC_1, MUSIC_DISC_5)
				_play_music_disc(disc)
			"music_stop_request":
				disc_audio_player.stop()
				_net_send_event({"type": "music_stop"})
			"chat_request":
				var nick := str(payload.get("nick", "Игрок")).substr(0, 20)
				var message := str(payload.get("message", "")).substr(0, 180)
				if not message.is_empty():
					_append_network_chat(nick, message)
					_net_send_event({"type": "chat", "nick": nick, "message": message})
	else:
		if sender_id != net_host_peer_id:
			return
		match event_type:
			"sleep_status":
				var sleeping_count := int(payload.get("sleeping", 0))
				var player_count := int(payload.get("total", 1))
				if sleep_panel != null:
					sleep_panel.visible = true
					sleep_panel_label.text = "Спят: %d/%d игроков\nНужно, чтобы легли все!" % [sleeping_count, player_count]
				_show_msg("Спят: %d/%d игроков" % [sleeping_count, player_count])
			"sleep_done":
				if sleep_panel != null:
					sleep_panel.visible = false
				cycle_time = clampf(float(payload.get("cycle_time", 0.0)), 0.0, DAY_NIGHT_CYCLE - 0.01)
				day_count = maxi(1, int(payload.get("day_count", day_count)))
				night_active = false
				_show_msg("Все игроки легли спать. Наступило утро!")
			"emote":
				_play_remote_emote(int(payload.get("peer_id", 0)), clampi(int(payload.get("emote", 0)), 0, EMOTE_NAMES.size() - 1))
			"player_state":
				var peer_id := int(payload.get("peer_id", 0))
				if peer_id <= 0:
					return
				var appearance: Dictionary = payload.get("appearance", {}) if payload.get("appearance", {}) is Dictionary else {}
				_network_set_player_state(peer_id, _net_array_to_vec3(payload.get("pos", [])), float(payload.get("yaw", 0.0)), int(payload.get("skin", 0)), appearance)
			"physics_collapse":
				_apply_network_collapse(payload.get("blocks", []), int(payload.get("body_id", 0)), int(payload.get("preset", physics_preset)))
			"physics_state":
				_apply_network_physics_state(payload.get("bodies", []))
			"block_set":
				var cell_arr: Variant = payload.get("cell", [])
				if cell_arr is Array and cell_arr.size() >= 3:
					var cell := Vector3i(int(cell_arr[0]), int(cell_arr[1]), int(cell_arr[2]))
					net_apply_remote_block = true
					_set_block_local(cell, int(payload.get("id", 0)))
					net_apply_remote_block = false
			"drop_spawn":
				_create_drop_visual(int(payload.get("drop_id", 0)), int(payload.get("item_id", 0)), int(payload.get("amount", 0)), _net_array_to_vec3(payload.get("pos", [])))
			"drop_remove":
				_remove_drop_local(int(payload.get("drop_id", 0)))
			"pickup_result":
				add_item(int(payload.get("item_id", 0)), int(payload.get("amount", 0)))
			"chat":
				_append_network_chat(str(payload.get("nick", "Игрок")), str(payload.get("message", "")))
			"world_clock":
				cycle_time = clampf(float(payload.get("cycle_time", cycle_time)), 0.0, DAY_NIGHT_CYCLE - 0.01)
				day_count = maxi(1, int(payload.get("day_count", day_count)))
			"storage_state":
				_net_apply_storage_state(payload.get("state", {}))
				net_storage_ready = true
				net_last_storage_signature = JSON.stringify(_net_build_storage_state())
			"world_snapshot_start":
				_net_begin_world_snapshot(payload)
			"world_snapshot_part":
				_net_receive_world_snapshot_part(payload)
			"world_snapshot_end":
				net_snapshot_end_received = true
				_net_try_apply_world_snapshot()
			"achievement_announce":
				if int(payload.get("peer_id", 0)) != net_peer_id:
					var remote_achievement_id := str(payload.get("id", ""))
					var remote_definition: Dictionary = Achievements.DEFINITIONS.get(remote_achievement_id, {})
					_display_achievement_announcement(str(payload.get("nick", "Игрок")), str(remote_definition.get("title", payload.get("title", "Достижение"))), str(remote_definition.get("description", "")))
			"snapshot_blocks":
				var blocks: Variant = payload.get("blocks", [])
				if blocks is Array:
					for item in blocks:
						if item is Array and item.size() >= 4:
							var cell := Vector3i(int(item[0]), int(item[1]), int(item[2]))
							net_apply_remote_block = true
							_set_block_local(cell, int(item[3]))
							net_apply_remote_block = false
			"snapshot_drop":
				_create_drop_visual(int(payload.get("drop_id", 0)), int(payload.get("item_id", 0)), int(payload.get("amount", 0)), _net_array_to_vec3(payload.get("pos", [])))
			"mob_state":
				_net_apply_mob_state(payload.get("mobs", []))
			"raft_spawn":
				var raft_pos := _net_array_to_vec3(payload.get("pos", []))
				var raft_id := int(payload.get("raft_id", 0))
				var raft := _create_raft(raft_pos, raft_id, float(payload.get("yaw", 0.0)), payload.get("blocks", []))
				if bool(payload.get("npc_ship", false)):
					raft.set_meta("npc_ship", true)
					raft.set_meta("ship_direction", payload.get("ship_direction", [1.0, 0.0]))
					var ship_rng := RandomNumberGenerator.new()
					ship_rng.seed = raft_id
					_decorate_trader_ship(raft, ship_rng)
				if pending_raft_board:
					pending_raft_board = false
					_mount_raft(raft)
			"raft_state":
				var raft := _get_raft_by_id(int(payload.get("raft_id", 0)))
				if raft != null:
					var raft_pos := _net_array_to_vec3(payload.get("pos", []))
					raft.position = Vector3(raft_pos.x, 14.95, raft_pos.z)
					raft.rotation.y = float(payload.get("yaw", raft.rotation.y))
			"raft_block_set":
				var raft := _get_raft_by_id(int(payload.get("raft_id", 0)))
				var cell_data: Variant = payload.get("cell", [])
				if raft != null and cell_data is Array and cell_data.size() >= 3:
					_add_raft_block_local(raft, Vector3i(int(cell_data[0]), int(cell_data[1]), int(cell_data[2])), int(payload.get("id", 0)))
			"raft_block_remove":
				var raft := _get_raft_by_id(int(payload.get("raft_id", 0)))
				var cell_data: Variant = payload.get("cell", [])
				if raft != null and cell_data is Array and cell_data.size() >= 3:
					_remove_raft_block_local(raft, Vector3i(int(cell_data[0]), int(cell_data[1]), int(cell_data[2])))
			"music_play":
				net_apply_remote_music = true
				_play_music_disc(int(payload.get("disc_id", MUSIC_DISC_1)))
				net_apply_remote_music = false
			"music_stop":
				disc_audio_player.stop()


func _net_send_initial_state(peer_id: int) -> void:
	_net_send_event({"type": "player_state", "peer_id": 1, "pos": _net_vec3_to_array(player.global_position), "yaw": player.rotation.y, "skin": Global.selected_skin, "appearance": _net_skin_appearance()}, peer_id)
	for existing_id in net_remote_players.keys():
		var avatar: Node3D = net_remote_players[existing_id] as Node3D
		if is_instance_valid(avatar):
			_net_send_event({"type": "player_state", "peer_id": int(existing_id), "pos": _net_vec3_to_array(avatar.global_position), "yaw": avatar.rotation.y, "skin": int(avatar.get_meta("network_skin", 0)), "appearance": avatar.get_meta("network_appearance", {})}, peer_id)
	for drop_key in dropped_items.keys():
		var drop_entry: Dictionary = dropped_items[drop_key]
		var drop_node: Node3D = drop_entry.get("node") as Node3D
		if is_instance_valid(drop_node):
			_net_send_event({"type": "snapshot_drop", "drop_id": int(drop_key), "item_id": int(drop_entry.get("id", 0)), "amount": int(drop_entry.get("amount", 0)), "pos": _net_vec3_to_array(drop_node.global_position)}, peer_id)
	_net_send_event({"type": "world_clock", "cycle_time": cycle_time, "day_count": day_count}, peer_id)
	_net_send_event({"type": "mob_state", "mobs": _net_collect_mob_rows()}, peer_id)
	var initial_physics_rows: Array = []
	for body_id in physics_bodies.keys():
		var falling_body: RigidBody3D = physics_bodies[body_id] as RigidBody3D
		if not is_instance_valid(falling_body) or falling_body.is_queued_for_deletion():
			continue
		_net_send_event({"type": "physics_collapse", "body_id": int(body_id), "preset": physics_preset, "blocks": falling_body.get_meta("physics_blocks", [])}, peer_id)
		initial_physics_rows.append({"id": int(body_id), "pos": _net_vec3_to_array(falling_body.global_position), "rot": _net_vec3_to_array(falling_body.global_rotation), "vel": _net_vec3_to_array(falling_body.linear_velocity), "ang": _net_vec3_to_array(falling_body.angular_velocity)})
	_net_send_event({"type": "physics_state", "bodies": initial_physics_rows}, peer_id)
	for raft in raft_nodes:
		if is_instance_valid(raft):
			_net_send_event({"type": "raft_spawn", "raft_id": int(raft.get_meta("raft_id", 0)), "pos": _net_vec3_to_array(raft.position), "yaw": raft.rotation.y, "blocks": _raft_block_rows(raft), "npc_ship": bool(raft.get_meta("npc_ship", false)), "ship_direction": raft.get_meta("ship_direction", [1.0, 0.0])}, peer_id)
	_net_send_event({"type": "storage_state", "state": _net_build_storage_state()}, peer_id)
	_net_queue_world_snapshot(peer_id)


func _net_append_snapshot_u32(buffer: PackedByteArray, value: int) -> PackedByteArray:
	var encoded := PackedByteArray()
	encoded.resize(4)
	encoded.encode_u32(0, value)
	buffer.append_array(encoded)
	return buffer

func _net_queue_world_snapshot(peer_id: int) -> void:
	if not net_is_host or not net_connected or peer_id <= 1:
		return
	var non_empty_count := 0
	for chunk_variant in chunks:
		if chunk_variant is PackedByteArray and chunk_variant.size() == CHUNK_DATA_SIZE:
			non_empty_count += 1
	var raw := PackedByteArray()
	raw = _net_append_snapshot_u32(raw, non_empty_count)
	for index in range(chunks.size()):
		var chunk_data: Variant = chunks[index]
		if not (chunk_data is PackedByteArray) or chunk_data.size() != CHUNK_DATA_SIZE:
			continue
		raw = _net_append_snapshot_u32(raw, index)
		raw = _net_append_snapshot_u32(raw, chunk_data.size())
		var generation_flags := (1 if trees_generated[index] else 0) | (2 if villages_generated[index] else 0)
		raw.append(generation_flags)
		raw.append_array(chunk_data)
	var compressed := raw.compress(FileAccess.COMPRESSION_DEFLATE)
	if compressed.is_empty():
		_net_update_status("Не удалось подготовить снимок мира для отправки.")
		return
	var total_parts := int(ceil(float(compressed.size()) / float(WORLD_SNAPSHOT_PART_BYTES)))
	net_snapshot_send_queue.append({
		"to": peer_id,
		"payload": {"type": "world_snapshot_start", "parts": total_parts, "raw_size": raw.size(), "host_pos": _net_vec3_to_array(player.global_position)}
	})
	for part_index in range(total_parts):
		var start_offset := part_index * WORLD_SNAPSHOT_PART_BYTES
		var end_offset := mini(start_offset + WORLD_SNAPSHOT_PART_BYTES, compressed.size())
		var part_data := compressed.slice(start_offset, end_offset)
		net_snapshot_send_queue.append({
			"to": peer_id,
			"payload": {"type": "world_snapshot_part", "index": part_index, "data": Marshalls.raw_to_base64(part_data)}
		})
	net_snapshot_send_queue.append({"to": peer_id, "payload": {"type": "world_snapshot_end"}})
	_show_msg("Отправка сохранённого мира игроку %d…" % peer_id)

func _net_begin_world_snapshot(payload: Dictionary) -> void:
	var part_count := int(payload.get("parts", 0))
	var raw_size := int(payload.get("raw_size", 0))
	if part_count <= 0 or part_count > 10000 or raw_size <= 0 or raw_size > 160 * 1024 * 1024:
		_net_update_status("Сервер прислал неверные параметры снимка мира.")
		return
	net_snapshot_expected_parts = part_count
	net_snapshot_raw_size = raw_size
	net_snapshot_parts.clear()
	net_snapshot_parts.resize(part_count)
	for index in range(part_count):
		net_snapshot_parts[index] = ""
	net_snapshot_end_received = false
	var host_pos: Variant = payload.get("host_pos", [])
	if player != null and host_pos is Array and host_pos.size() >= 3:
		var target_pos := _net_array_to_vec3(host_pos)
		player.global_position = target_pos + Vector3(float(maxi(0, net_peer_id - 2)) * 1.4, 0.0, 1.4)
	_net_update_status("Получение сохранённого мира хоста…")

func _net_receive_world_snapshot_part(payload: Dictionary) -> void:
	var index := int(payload.get("index", -1))
	if index < 0 or index >= net_snapshot_expected_parts:
		return
	var data := str(payload.get("data", ""))
	if data.is_empty() or data.length() > 90000:
		return
	net_snapshot_parts[index] = data
	if net_snapshot_end_received:
		_net_try_apply_world_snapshot()

func _net_try_apply_world_snapshot() -> void:
	if not net_snapshot_end_received or net_snapshot_expected_parts <= 0:
		return
	var encoded := ""
	for part in net_snapshot_parts:
		if part.is_empty():
			return
		encoded += part
	var compressed := Marshalls.base64_to_raw(encoded)
	var raw := compressed.decompress(net_snapshot_raw_size, FileAccess.COMPRESSION_DEFLATE)
	if raw.size() != net_snapshot_raw_size or raw.size() < 4:
		_net_update_status("Снимок мира повреждён при передаче.")
		return
	var count := int(raw.decode_u32(0))
	if count < 0 or count > CW * CW:
		_net_update_status("Снимок мира содержит неверное количество чанков.")
		return
	# Validate the complete snapshot before mutating the current client world.
	var entries: Array[Dictionary] = []
	var seen_chunks: Dictionary = {}
	var cursor := 4
	for _entry in range(count):
		if cursor + 9 > raw.size():
			_net_update_status("Снимок мира обрезан.")
			return
		var chunk_index := int(raw.decode_u32(cursor))
		var chunk_size := int(raw.decode_u32(cursor + 4))
		var generation_flags := int(raw[cursor + 8])
		cursor += 9
		if chunk_index < 0 or chunk_index >= CW * CW or seen_chunks.has(chunk_index) or chunk_size != CHUNK_DATA_SIZE or cursor + chunk_size > raw.size():
			_net_update_status("Снимок мира содержит неверный чанк.")
			return
		seen_chunks[chunk_index] = true
		entries.append({"index": chunk_index, "flags": generation_flags, "offset": cursor})
		cursor += chunk_size
	if cursor != raw.size() or entries.size() != count:
		_net_update_status("Снимок мира не прошёл проверку целостности.")
		return
	# Only after validation do we replace the generated chunks.
	for index in range(CW * CW):
		chunks[index] = PackedByteArray()
		chunk_top[index] = 0
		trees_generated[index] = false
		villages_generated[index] = false
	for entry in entries:
		var chunk_index := int(entry["index"])
		var chunk_data := raw.slice(int(entry["offset"]), int(entry["offset"]) + CHUNK_DATA_SIZE)
		chunks[chunk_index] = chunk_data
		trees_generated[chunk_index] = (int(entry["flags"]) & 1) != 0
		villages_generated[chunk_index] = (int(entry["flags"]) & 2) != 0
		var chunk_x := chunk_index % CW
		var chunk_z := int(chunk_index / CW)
		for local_z in CS:
			for local_x in CS:
				var world_x := chunk_x * CS + local_x
				var world_z := chunk_z * CS + local_z
				heights[world_x + world_z * WORLD_SIZE] = _height_at(world_x, world_z)
		var top := 0
		for y in range(WORLD_H - 1, -1, -1):
			var found_at_height := false
			for cell_index in 256:
				if chunk_data[cell_index + y * 256] != 0:
					found_at_height = true
					break
			if found_at_height:
				top = y
				break
		chunk_top[chunk_index] = top
	# Remove old chunk bodies/meshes and rebuild around the joining player.
	for index in range(chunk_mi.size()):
		var mesh_instance: MeshInstance3D = chunk_mi[index] as MeshInstance3D
		if is_instance_valid(mesh_instance):
			var parent_node := mesh_instance.get_parent()
			if is_instance_valid(parent_node):
				parent_node.queue_free()
		chunk_mi[index] = null
		chunk_cs[index] = null
		var water_instance: MeshInstance3D = chunk_water_mi[index] as MeshInstance3D
		if is_instance_valid(water_instance):
			water_instance.queue_free()
		chunk_water_mi[index] = null
	chunk_build_queue.clear()
	chunk_build_queued.clear()
	dirty_chunks.clear()
	# Storage data arrives before the voxel snapshot. Rebuild crop/door visuals
	# once against the final host blocks so objects are neither missing nor duplicated.
	for crop_cell in crop_nodes.keys():
		var crop_node: Node3D = crop_nodes[crop_cell] as Node3D
		if is_instance_valid(crop_node):
			crop_node.queue_free()
	crop_nodes.clear()
	for door_cell in door_nodes.keys():
		var door_hinge: StaticBody3D = door_nodes[door_cell] as StaticBody3D
		if is_instance_valid(door_hinge):
			var door_root := door_hinge.get_parent()
			if is_instance_valid(door_root):
				door_root.queue_free()
	door_nodes.clear()
	if player != null:
		_update_chunks(true)
	_spawn_loaded_crops()
	_spawn_loaded_doors()
	world_loaded = true
	world_load_failed = false
	_net_update_status("Мир хоста загружен. Можно играть!")
	net_snapshot_parts.clear()
	net_snapshot_expected_parts = 0
	net_snapshot_raw_size = 0
	net_snapshot_end_received = false

func _net_pack_storage_dict(source: Dictionary) -> Array:
	var packed: Array = []
	for key in source.keys():
		if key is Vector3i:
			packed.append({"cell": [key.x, key.y, key.z], "value": source[key]})
	return packed


func _net_build_storage_state() -> Dictionary:
	return {
		"chests": _net_pack_storage_dict(chests),
		"furnaces": _net_pack_storage_dict(furnaces),
		"crops": _net_pack_storage_dict(crops),
		"doors": _net_pack_storage_dict(doors)
	}


func _net_unpack_storage_dict(rows: Variant) -> Dictionary:
	var result: Dictionary = {}
	if not (rows is Array):
		return result
	for row in rows:
		if row is Dictionary:
			var cell_data: Variant = row.get("cell", [])
			if cell_data is Array and cell_data.size() >= 3:
				var cell := Vector3i(int(cell_data[0]), int(cell_data[1]), int(cell_data[2]))
				result[cell] = row.get("value", {})
	return result


func _net_apply_storage_state(state: Variant) -> void:
	if not (state is Dictionary):
		return
	chests = _net_unpack_storage_dict(state.get("chests", []))
	furnaces = _net_unpack_storage_dict(state.get("furnaces", []))
	crops = _net_unpack_storage_dict(state.get("crops", []))
	doors = _net_unpack_storage_dict(state.get("doors", []))
	# Refresh crop sprites and door models after applying the host's shared state.
	for cell_key in crop_nodes.keys():
		if not crops.has(cell_key):
			var old_crop: Node3D = crop_nodes[cell_key]
			if is_instance_valid(old_crop):
				old_crop.queue_free()
			crop_nodes.erase(cell_key)
	for cell_key in crops.keys():
		if get_block(cell_key.x, cell_key.y - 1, cell_key.z) == FARMLAND and get_block(cell_key.x, cell_key.y, cell_key.z) == 0:
			if not crop_nodes.has(cell_key):
				_spawn_crop_node(cell_key)
			else:
				_update_crop_node(cell_key)
	for cell_key in door_nodes.keys():
		if not doors.has(cell_key):
			var old_hinge: StaticBody3D = door_nodes[cell_key]
			if is_instance_valid(old_hinge):
				old_hinge.get_parent().queue_free()
			door_nodes.erase(cell_key)
	for cell_key in doors.keys():
		var door_data: Dictionary = doors[cell_key]
		if not door_nodes.has(cell_key):
			_spawn_door_node(cell_key)
		var hinge: StaticBody3D = door_nodes[cell_key]
		hinge.rotation_degrees.y = 90.0 if bool(door_data.get("open", false)) else 0.0
	if chest_layer != null and chest_layer.visible:
		_refresh_chest_ui()
	if furnace_layer != null and furnace_layer.visible:
		_refresh_furnace_ui()


func _net_sync_shared_storage(delta: float) -> void:
	if not net_connected or not net_storage_ready:
		return
	net_storage_timer -= delta
	if net_storage_timer > 0.0:
		return
	net_storage_timer = 0.75
	var state := _net_build_storage_state()
	var signature := JSON.stringify(state)
	if signature == net_last_storage_signature:
		return
	net_last_storage_signature = signature
	if net_is_host:
		_net_send_event({"type": "storage_state", "state": state})
	else:
		_net_send_event({"type": "storage_request", "state": state})


func _net_skin_appearance() -> Dictionary:
	if Global.selected_skin < Global.SKIN_PRESETS.size():
		return {}
	return {
		"skin": Global.CUSTOM_SKIN["skin"].to_html(),
		"shirt": Global.CUSTOM_SKIN["shirt"].to_html(),
		"pants": Global.CUSTOM_SKIN["pants"].to_html(),
		"hair": Global.CUSTOM_SKIN["hair"].to_html(),
		"long_hair": bool(Global.CUSTOM_SKIN.get("long_hair", false))
	}

func _network_set_player_state(peer_id: int, pos: Vector3, yaw: float, skin_index: int, appearance: Dictionary = {}) -> void:
	if peer_id == net_peer_id:
		return
	var avatar: Node3D = net_remote_players.get(peer_id) as Node3D
	if avatar == null:
		avatar = _create_network_avatar(skin_index, appearance)
		avatar.name = "RemotePlayer_%d" % peer_id
		add_child(avatar)
		net_remote_players[peer_id] = avatar
		avatar.global_position = pos
		avatar.rotation.y = yaw
	avatar.set_meta("network_target_position", pos)
	avatar.set_meta("network_target_yaw", yaw)
	avatar.set_meta("network_skin", clampi(skin_index, 0, Global.SKIN_PRESETS.size()))
	avatar.set_meta("network_appearance", appearance.duplicate(true))

func _create_network_avatar(skin_index: int, appearance: Dictionary = {}) -> Node3D:
	var rig: Dictionary = _build_character(skin_index, appearance)
	var root: Node3D = rig["root"]
	root.position = Vector3(0.0, -0.9, 0.0)
	var animation_rig: Dictionary = rig.duplicate()
	animation_rig.erase("root")
	root.set_meta("character_rig", animation_rig)
	root.set_meta("remote_emote_id", -1)
	root.set_meta("remote_emote_time", 0.0)
	root.set_meta("walk_phase", 0.0)
	return root


func _remove_remote_player(peer_id: int) -> void:
	if net_remote_players.has(peer_id):
		var avatar: Node3D = net_remote_players[peer_id] as Node3D
		if is_instance_valid(avatar):
			avatar.queue_free()
		net_remote_players.erase(peer_id)
	if sleep_votes.has(peer_id):
		sleep_votes.erase(peer_id)
	if net_is_host and net_connected and cycle_time >= DAY_LENGTH and not sleep_votes.is_empty():
		_update_sleep_vote_status()

